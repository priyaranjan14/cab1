<?php
session_start();

if (!isset($_SESSION['driver_id']) || $_SERVER["REQUEST_METHOD"] != "POST") {
    header("Location: login.php");
    exit();
}

$driver_id  = $_SESSION['driver_id'];
$booking_id = intval($_POST['booking_id']);
$action     = $_POST['action'];

$conn = new mysqli("localhost", "root", "", "ranjancab");
if ($conn->connect_error) {
    die("Database engine failure: " . $conn->connect_error);
}

if ($action === 'accept') {
    // ATOMIC GUARD: Update assignment only if another pilot hasn't claimed it yet
    $claim_sql = "UPDATE bookings SET assigned_driver_id = ? WHERE id = ? AND assigned_driver_id IS NULL";
    $claim_stmt = $conn->prepare($claim_sql);
    $claim_stmt->bind_param("ii", $driver_id, $booking_id);
    $claim_stmt->execute();

    if ($claim_stmt->affected_rows > 0) {
        $claim_stmt->close();
        $conn->close();
        header("Location: driver_dashboard.php?status=assigned");
        exit();
    } else {
        $claim_stmt->close();
        $conn->close();
        header("Location: driver_dashboard.php?status=missed");
        exit();
    }
}

if ($action === 'reject') {
    // Write into database log rejection sequence matching schema mapping
    $reject_sql = "INSERT INTO booking_rejections (booking_id, driver_id) VALUES (?, ?)";
    $reject_stmt = $conn->prepare($reject_sql);
    $reject_stmt->bind_param("ii", $booking_id, $driver_id);
    $reject_stmt->execute();
    $reject_stmt->close();

    $conn->close();
    header("Location: driver_dashboard.php?status=rejected");
    exit();
}

$conn->close();
header("Location: driver_dashboard.php");
exit();
?>