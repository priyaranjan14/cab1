CREATE DATABASE IF NOT EXISTS `ranjancab`
  CHARACTER SET utf8mb4
  COLLATE utf8mb4_unicode_ci;

USE `ranjancab`;

SET FOREIGN_KEY_CHECKS = 0;

DROP TABLE IF EXISTS `booking_rejections`;
DROP TABLE IF EXISTS `cancelled_bookings`;
DROP TABLE IF EXISTS `bookings`;
DROP TABLE IF EXISTS `blogs`;
DROP TABLE IF EXISTS `pricing_settings`;
DROP TABLE IF EXISTS `routes`;
DROP TABLE IF EXISTS `fleet`;

SET FOREIGN_KEY_CHECKS = 1;

CREATE TABLE `fleet` (
  `id` INT NOT NULL AUTO_INCREMENT,
  `driver_name` VARCHAR(100) NOT NULL,
  `mobile_number` VARCHAR(15) NOT NULL,
  `password` VARCHAR(255) NOT NULL,
  `is_first_login` TINYINT(1) NOT NULL DEFAULT 1,
  `vehicle_number` VARCHAR(20) NOT NULL,
  `model_name` VARCHAR(80) NOT NULL,
  `car_type` VARCHAR(30) NOT NULL,
  `base_station` VARCHAR(120) NOT NULL,
  `star_rating` DECIMAL(3,2) NOT NULL DEFAULT 5.00,
  `rating` DECIMAL(3,2) NOT NULL DEFAULT 5.00,
  `is_verified` TINYINT(1) NOT NULL DEFAULT 1,
  `status` VARCHAR(20) NOT NULL DEFAULT 'Active',
  `driver_license_no` VARCHAR(50) DEFAULT NULL,
  `aadhaar_no` VARCHAR(50) DEFAULT NULL,
  `rc_no` VARCHAR(50) DEFAULT NULL,
  `doc_license_path` VARCHAR(255) DEFAULT NULL,
  `doc_aadhaar_path` VARCHAR(255) DEFAULT NULL,
  `doc_rc_path` VARCHAR(255) DEFAULT NULL,
  `doc_cab_path` VARCHAR(255) DEFAULT NULL,
  `doc_avatar_path` VARCHAR(255) DEFAULT NULL,
  `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_fleet_mobile_number` (`mobile_number`),
  KEY `idx_fleet_status_type_station` (`status`, `car_type`, `base_station`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE `routes` (
  `id` INT NOT NULL AUTO_INCREMENT,
  `pickup_point` VARCHAR(255) NOT NULL,
  `drop_point` VARCHAR(255) NOT NULL,
  `estimated_distance` DOUBLE NOT NULL,
  `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_route_pair` (`pickup_point`, `drop_point`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE `pricing_settings` (
  `id` INT NOT NULL AUTO_INCREMENT,
  `car_type` VARCHAR(30) NOT NULL,
  `rate_per_km` DECIMAL(10,2) NOT NULL,
  `portal_charges` DECIMAL(10,2) NOT NULL,
  `advance_percentage` DECIMAL(10,2) NOT NULL,
  `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_pricing_car_type` (`car_type`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE `bookings` (
  `id` INT NOT NULL AUTO_INCREMENT,
  `booking_ref_no` VARCHAR(30) DEFAULT NULL,
  `customer_name` VARCHAR(120) DEFAULT NULL,
  `customer_phone` VARCHAR(15) DEFAULT NULL,
  `first_name` VARCHAR(50) DEFAULT NULL,
  `last_name` VARCHAR(50) DEFAULT NULL,
  `mobile_number` VARCHAR(15) DEFAULT NULL,
  `trip_type` VARCHAR(30) NOT NULL DEFAULT 'Oneway',
  `pickup_location` VARCHAR(255) NOT NULL,
  `drop_location` VARCHAR(255) NOT NULL,
  `pickup_date` DATE NOT NULL,
  `return_date` DATE DEFAULT NULL,
  `pickup_time` TIME NOT NULL,
  `car_type` VARCHAR(30) NOT NULL,
  `distance` DOUBLE NOT NULL DEFAULT 0,
  `total_fare` DOUBLE NOT NULL DEFAULT 0,
  `advance_paid` DOUBLE NOT NULL DEFAULT 0,
  `driver_balance` DOUBLE NOT NULL DEFAULT 0,
  `otp_code` VARCHAR(6) NOT NULL,
  `booking_flag` TINYINT NOT NULL DEFAULT 1 COMMENT '1=active/searching, 2=in transit/cancelled in some admin views, 3=completed, -1=failed',
  `assigned_driver_id` INT DEFAULT NULL,
  `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_booking_ref_no` (`booking_ref_no`),
  KEY `idx_bookings_customer_phone` (`customer_phone`),
  KEY `idx_bookings_mobile_number` (`mobile_number`),
  KEY `idx_bookings_flag_driver` (`booking_flag`, `assigned_driver_id`),
  KEY `idx_bookings_car_pickup` (`car_type`, `pickup_location`),
  CONSTRAINT `fk_bookings_driver` FOREIGN KEY (`assigned_driver_id`) REFERENCES `fleet` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE `cancelled_bookings` (
  `id` INT NOT NULL AUTO_INCREMENT,
  `booking_id` INT DEFAULT NULL,
  `booking_ref_no` VARCHAR(30) DEFAULT NULL,
  `customer_name` VARCHAR(120) DEFAULT NULL,
  `customer_phone` VARCHAR(15) DEFAULT NULL,
  `pickup_location` VARCHAR(255) NOT NULL,
  `drop_location` VARCHAR(255) NOT NULL,
  `pickup_date` DATE NOT NULL,
  `pickup_time` TIME NOT NULL,
  `car_type` VARCHAR(30) NOT NULL,
  `total_fare` DOUBLE NOT NULL DEFAULT 0,
  `assigned_driver_id` INT DEFAULT NULL,
  `cancelled_by` VARCHAR(50) NOT NULL DEFAULT 'Admin',
  `cancellation_reason` TEXT DEFAULT NULL,
  `cancelled_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_cancelled_driver` (`assigned_driver_id`),
  CONSTRAINT `fk_cancelled_bookings_driver` FOREIGN KEY (`assigned_driver_id`) REFERENCES `fleet` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE `booking_rejections` (
  `id` INT NOT NULL AUTO_INCREMENT,
  `booking_id` INT NOT NULL,
  `driver_id` INT NOT NULL,
  `rejected_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_booking_driver_rejection` (`booking_id`, `driver_id`),
  KEY `idx_rejections_driver` (`driver_id`),
  CONSTRAINT `fk_rejections_booking` FOREIGN KEY (`booking_id`) REFERENCES `bookings` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_rejections_driver` FOREIGN KEY (`driver_id`) REFERENCES `fleet` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE `blogs` (
  `id` INT NOT NULL AUTO_INCREMENT,
  `title` VARCHAR(180) NOT NULL,
  `slug` VARCHAR(220) NOT NULL,
  `excerpt` VARCHAR(300) NOT NULL,
  `content` TEXT NOT NULL,
  `author` VARCHAR(100) NOT NULL DEFAULT 'RanjanCabs Admin',
  `status` ENUM('draft', 'published') NOT NULL DEFAULT 'published',
  `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_blogs_slug` (`slug`),
  KEY `idx_blogs_status_created` (`status`, `created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `fleet`
  (`id`, `driver_name`, `mobile_number`, `password`, `is_first_login`, `vehicle_number`, `model_name`, `car_type`, `base_station`, `star_rating`, `rating`, `is_verified`, `status`, `driver_license_no`, `aadhaar_no`, `rc_no`, `doc_license_path`, `doc_aadhaar_path`, `doc_rc_path`, `doc_cab_path`, `doc_avatar_path`)
VALUES
  (1, 'Sanjeev Kumar', '8959158195', 'Kumar', 1, 'MP-04-HE-1234', 'Maruti Dzire', 'Sedan', 'Bhopal', 4.90, 4.90, 1, 'Active', 'MP0420220001', 'XXXX-XXXX-1111', 'MP04HE1234RC', 'uploads/drivers/dr_1_doc_license_1780469222.pdf', 'uploads/drivers/dr_1_doc_aadhaar_1780469222.pdf', 'uploads/drivers/dr_1_doc_rc_1780469222.PDF', 'uploads/drivers/dr_1_doc_cab_1780469222.jpg', 'uploads/drivers/dr_1_doc_avatar_1780469222.jpg'),
  (2, 'Amit Sharma', '9000000002', 'Sharma', 1, 'MP-04-CB-7788', 'Hyundai Aura', 'Sedan', 'Bhopal', 4.70, 4.70, 0, 'Active', 'MP0420220002', 'XXXX-XXXX-2222', 'MP04CB7788RC', NULL, NULL, NULL, NULL, NULL),
  (3, 'Ravi Verma', '9000000003', 'Verma', 1, 'MP-04-SU-5511', 'Mahindra Scorpio', 'SUV', 'Bhopal', 4.80, 4.80, 0, 'Active', 'MP0420220003', 'XXXX-XXXX-3333', 'MP04SU5511RC', NULL, NULL, NULL, NULL, NULL),
  (4, 'Nitin Patel', '9000000004', 'Patel', 1, 'MP-09-HA-3210', 'Maruti WagonR', 'Hatchback', 'Indore', 4.50, 4.50, 0, 'Inactive', 'MP0920220004', 'XXXX-XXXX-4444', 'MP09HA3210RC', NULL, NULL, NULL, NULL, NULL);

INSERT INTO `routes` (`id`, `pickup_point`, `drop_point`, `estimated_distance`) VALUES
  (1, 'Bhopal', 'Indore', 195),
  (2, 'Indore', 'Bhopal', 195),
  (3, 'Bhopal', 'Ujjain', 190),
  (4, 'Ujjain', 'Bhopal', 190),
  (5, 'Bhopal', 'Sanchi', 48),
  (6, 'Sanchi', 'Bhopal', 48),
  (7, 'Indore', 'Ujjain', 55),
  (8, 'Ujjain', 'Indore', 55);

INSERT INTO `pricing_settings` (`id`, `car_type`, `rate_per_km`, `portal_charges`, `advance_percentage`) VALUES
  (1, 'Sedan', 14.50, 200.00, 500.00),
  (2, 'SUV', 20.00, 300.00, 800.00),
  (3, 'Hatchback', 12.00, 150.00, 400.00);

INSERT INTO `bookings`
  (`id`, `booking_ref_no`, `customer_name`, `customer_phone`, `first_name`, `last_name`, `mobile_number`, `trip_type`, `pickup_location`, `drop_location`, `pickup_date`, `return_date`, `pickup_time`, `car_type`, `distance`, `total_fare`, `advance_paid`, `driver_balance`, `otp_code`, `booking_flag`, `assigned_driver_id`, `created_at`)
VALUES
  (1, 'RC-DEMO001', 'Rahul Mehta', '9876543210', 'Rahul', 'Mehta', '9876543210', 'Oneway', 'Bhopal Railway Station, Bhopal', 'Indore', '2026-06-15', NULL, '09:30:00', 'Sedan', 195, 3027.50, 500.00, 2527.50, '1234', 1, NULL, '2026-06-11 09:00:00'),
  (2, 'RC-DEMO002', 'Priya Singh', '9876543211', 'Priya', 'Singh', '9876543211', 'Roundtrip', 'Bhopal Airport, Bhopal', 'Ujjain', '2026-06-16', '2026-06-18', '07:00:00', 'SUV', 190, 7585.00, 800.00, 6785.00, '2345', 2, 3, '2026-06-11 10:15:00'),
  (3, 'RC-DEMO003', 'Ankit Jain', '9876543212', 'Ankit', 'Jain', '9876543212', 'Oneway', 'Bhopal ISBT, Bhopal', 'Sanchi', '2026-06-09', NULL, '11:45:00', 'Sedan', 48, 896.00, 500.00, 396.00, '3456', 3, 1, '2026-06-09 08:30:00'),
  (4, 'RC-DEMO004', 'Neha Gupta', '9876543213', 'Neha', 'Gupta', '9876543213', 'Oneway', 'Indore Vijay Nagar, Indore', 'Ujjain', '2026-06-12', NULL, '15:30:00', 'Hatchback', 55, 810.00, 400.00, 410.00, '4567', 1, NULL, '2026-06-11 11:20:00');

INSERT INTO `booking_rejections` (`booking_id`, `driver_id`) VALUES
  (1, 2);

INSERT INTO `cancelled_bookings`
  (`booking_id`, `booking_ref_no`, `customer_name`, `customer_phone`, `pickup_location`, `drop_location`, `pickup_date`, `pickup_time`, `car_type`, `total_fare`, `assigned_driver_id`, `cancelled_by`, `cancellation_reason`)
VALUES
  (5, 'RC-CAN001', 'Vikas Tiwari', '9876543214', 'Bhopal', 'Indore', '2026-06-10', '18:00:00', 'Sedan', 3027.50, 1, 'Admin', 'Customer requested cancellation during demo setup');

INSERT INTO `blogs` (`title`, `slug`, `excerpt`, `content`, `author`, `status`, `created_at`) VALUES
  ('How to Plan a Comfortable Bhopal to Indore Cab Ride', 'bhopal-to-indore-cab-ride', 'A practical checklist for timing, luggage, route planning, and choosing the right cab class for intercity travel.', 'A comfortable intercity cab ride starts with a clear pickup point, realistic travel time, and a vehicle class that fits your luggage and passenger count. For Bhopal to Indore, Sedan works well for compact groups, while SUV is better for extra bags or family travel. Book ahead during weekends and keep your OTP ready at pickup for faster trip start verification.', 'RanjanCabs Admin', 'published', '2026-06-11 12:00:00'),
  ('Why Verified Drivers Matter for Your Taxi Booking', 'verified-drivers-taxi-booking', 'Verified driver documents help make every trip more transparent, accountable, and safer for customers.', 'Driver verification is more than a formality. Licence, Aadhaar, and cab registration documents help the operations team confirm that a fleet partner is ready for customer duty. RanjanCabs keeps these records available to admins so only verified drivers are marked ready for live assignments.', 'RanjanCabs Admin', 'published', '2026-06-11 12:30:00');
