<?php
session_start();
if (!isset($_SESSION['driver_id'])) {
    header("Location: login.php");
    exit();
}

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $booking_id = intval($_POST['booking_id']);
    $entered_otp = trim($_POST['otp_code']);

    $conn = new mysqli("localhost", "root", "", "ranjancab");
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    // Fetch the true OTP from the database
    $sql = "SELECT otp_code FROM bookings WHERE id = ? AND booking_flag = 1 LIMIT 1";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $booking_id);
    $stmt->execute();
    $result = $stmt->get_result()->fetch_assoc();
    $stmt->close();

    if ($result && $result['otp_code'] === $entered_otp) {
        // OTP matches! Upgrade booking_flag to 2 (In Transit / Ride Matrix Mode)
        $update_sql = "UPDATE bookings SET booking_flag = 2 WHERE id = ?";
        $update_stmt = $conn->prepare($update_sql);
        $update_stmt->bind_param("i", $booking_id);
        $update_stmt->execute();
        $update_stmt->close();

        $conn->close();
        header("Location: driver_dashboard.php?status=ride_started");
        exit();
    } else {
        $conn->close();
        header("Location: driver_dashboard.php?status=invalid_otp");
        exit();
    }
}
?>