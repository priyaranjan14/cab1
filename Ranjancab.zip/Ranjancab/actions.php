<?php
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action'])) {
    
    // ACTION A: MANUALLY ALLOCATE UNASSIGNED / ACTIVE CAB LINE
    if ($_POST['action'] === 'allocate_cab') {
        $booking_id = intval($_POST['booking_id']);
        $driver_id  = intval($_POST['driver_id']);
        
        $stmt = $conn->prepare("UPDATE bookings SET assigned_driver_id = ? WHERE id = ?");
        $stmt->bind_param("ii", $driver_id, $booking_id);
        $stmt->execute();
        header("Location: admin.php?status=allocated"); exit;
    }

    // ACTION B: MARK ACTIVE TRANSIT RIDE AS COMPLETED
    if ($_POST['action'] === 'complete_booking') {
        $booking_id = intval($_POST['booking_id']);
        
        $stmt = $conn->prepare("UPDATE bookings SET booking_flag = 3 WHERE id = ?");
        $stmt->bind_param("i", $booking_id);
        $stmt->execute();
        header("Location: admin.php?status=completed"); exit;
    }
    
    // ACTION C: INTERCEPT AND CANCEL LIVE BOOKING
    if ($_POST['action'] === 'cancel_booking') {
        $booking_id = intval($_POST['booking_id']);
        $reason     = !empty($_POST['reason']) ? $_POST['reason'] : 'Terminated by Administration Command';
        
        $fetch_stmt = $conn->prepare("SELECT * FROM bookings WHERE id = ?");
        $fetch_stmt->bind_param("i", $booking_id);
        $fetch_stmt->execute();
        $booking = $fetch_stmt->get_result()->fetch_assoc();
        
        if ($booking) {
            $cancel_stmt = $conn->prepare("
                INSERT INTO cancelled_bookings 
                (booking_id, booking_ref_no, customer_name, customer_phone, pickup_location, drop_location, pickup_date, pickup_time, car_type, total_fare, assigned_driver_id, cancelled_by, cancellation_reason) 
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'Admin', ?)
            ");
            $cancel_stmt->bind_param(
                "issssssssdis", 
                $booking['id'], $booking['booking_ref_no'], $booking['customer_name'], $booking['customer_phone'], 
                $booking['pickup_location'], $booking['drop_location'], $booking['pickup_date'], $booking['pickup_time'], 
                $booking['car_type'], $booking['total_fare'], $booking['assigned_driver_id'], $reason
            );
            $cancel_stmt->execute();
            
            $delete_stmt = $conn->prepare("DELETE FROM bookings WHERE id = ?");
            $delete_stmt->bind_param("i", $booking_id);
            $delete_stmt->execute();
        }
        header("Location: admin.php?status=cancelled"); exit;
    }
    
    // ACTION D: TERMINATE / RE-COMMISSION DRIVER STATUS
    if ($_POST['action'] === 'toggle_fleet') {
        $driver_id  = intval($_POST['driver_id']);
        $new_status = intval($_POST['target_status']);
        
        $stmt = $conn->prepare("UPDATE fleet SET status = ? WHERE id = ?");
        $stmt->bind_param("ii", $new_status, $driver_id);
        $stmt->execute();
        header("Location: admin.php?status=fleet_mutated"); exit;
    }

    // ACTION E: CAR_TYPE RELATED UNIQUE TARIFF RATE UPDATE
    if ($_POST['action'] === 'update_pricing') {
        $id                 = intval($_POST['id']);
        $rate_per_km        = floatval($_POST['rate_per_km']);
        $portal_charges     = floatval($_POST['portal_charges']);
        $advance_percentage = floatval($_POST['advance_percentage']);

        $stmt = $conn->prepare("UPDATE pricing_settings SET rate_per_km = ?, portal_charges = ?, advance_percentage = ? WHERE id = ?");
        $stmt->bind_param("dddi", $rate_per_km, $portal_charges, $advance_percentage, $id);
        $stmt->execute();
        
        $car_slug = urlencode($_POST['car_type']);
        header("Location: admin.php?status=pricing_updated&variant=" . $car_slug); exit;
    }

    // ACTION F: INJECT SYSTEM ROUTE SEGMENT NODE
    if ($_POST['action'] === 'add_route') {
        $stmt = $conn->prepare("INSERT INTO routes (pickup_point, drop_point, estimated_distance) VALUES (?, ?, ?)");
        $stmt->bind_param("ssd", $_POST['pickup_point'], $_POST['drop_point'], $_POST['estimated_distance']);
        $stmt->execute();
        header("Location: admin.php?status=route_added"); exit;
    }
}
?>