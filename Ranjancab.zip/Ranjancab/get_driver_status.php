<?php
/**
 * get_driver_status.php — AJAX polling endpoint
 * Returns driver assignment status for a given booking ref.
 * Called by booking_confirmation.php every few seconds.
 */
header('Content-Type: application/json');

$ref = trim($_GET['ref'] ?? '');
if (empty($ref)) {
    echo json_encode(['assigned' => false]);
    exit;
}

$conn = new mysqli("localhost", "root", "", "ranjancab");
if ($conn->connect_error) {
    echo json_encode(['assigned' => false, 'error' => 'db']);
    exit;
}
$conn->set_charset("utf8mb4");

$stmt = $conn->prepare(
    "SELECT b.assigned_driver_id, b.booking_flag,
            f.driver_name, f.mobile_number AS driver_phone,
            f.vehicle_number, f.model_name, f.car_type, f.star_rating
     FROM bookings b
     LEFT JOIN fleet f ON b.assigned_driver_id = f.id
     WHERE b.booking_ref_no = ?
     LIMIT 1"
);
$stmt->bind_param("s", $ref);
$stmt->execute();
$row = $stmt->get_result()->fetch_assoc();
$stmt->close();
$conn->close();

if (!$row) {
    echo json_encode(['assigned' => false]);
    exit;
}

if (!empty($row['assigned_driver_id']) && !empty($row['driver_name'])) {
    echo json_encode([
        'assigned'       => true,
        'driver_name'    => $row['driver_name'],
        'driver_phone'   => $row['driver_phone'],
        'vehicle_number' => $row['vehicle_number'],
        'model_name'     => $row['model_name'],
        'car_type'       => $row['car_type'],
        'star_rating'    => $row['star_rating'],
        'booking_flag'   => intval($row['booking_flag']),
    ]);
} else {
    echo json_encode(['assigned' => false, 'booking_flag' => intval($row['booking_flag'] ?? 1)]);
}
?>
