<?php
/**
 * validate_coupon.php — AJAX endpoint
 * GET params: code, fare
 */
header('Content-Type: application/json');

$conn = new mysqli("localhost", "root", "", "ranjancab");
if ($conn->connect_error) {
    echo json_encode(['valid' => false, 'message' => 'Database error.']);
    exit;
}
$conn->set_charset("utf8mb4");

$code = strtoupper(trim($_GET['code'] ?? ''));
$fare = floatval($_GET['fare'] ?? 0);

if (empty($code) || $fare <= 0) {
    echo json_encode(['valid' => false, 'message' => 'Invalid request.']);
    exit;
}

$stmt = $conn->prepare(
    "SELECT id, code, discount_percent, description
     FROM coupon_codes
     WHERE code = ? AND is_active = 1
       AND (valid_from IS NULL OR valid_from <= CURDATE())
       AND (valid_until IS NULL OR valid_until >= CURDATE())
       AND (max_usage = 0 OR usage_count < max_usage)
     LIMIT 1"
);
$stmt->bind_param("s", $code);
$stmt->execute();
$coupon = $stmt->get_result()->fetch_assoc();
$stmt->close();
$conn->close();

if ($coupon) {
    $discount_amount = round($fare * (floatval($coupon['discount_percent']) / 100), 2);
    $new_fare = round($fare - $discount_amount, 2);
    echo json_encode([
        'valid'            => true,
        'code'             => $coupon['code'],
        'discount_percent' => floatval($coupon['discount_percent']),
        'discount_amount'  => $discount_amount,
        'new_fare'         => $new_fare,
        'description'      => $coupon['description'],
    ]);
} else {
    echo json_encode(['valid' => false, 'message' => 'Invalid or expired coupon code.']);
}
?>
