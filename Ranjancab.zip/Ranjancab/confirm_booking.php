<?php
session_start();

// 1. Establish System Database Connection
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "ranjancab"; // Synced database name

$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection stability
if ($conn->connect_error) {
    die("Database Connection Failed: " . $conn->connect_error);
}

// Check if the form was actually submitted via POST
if ($_SERVER["REQUEST_METHOD"] == "POST") {

    // 2. CAPTURE DATA FROM THE MODIFIED REVIEW PAGE FORM
    $customer_name   = isset($_POST['customer_name']) ? trim($_POST['customer_name']) : '';
    $customer_phone  = isset($_POST['customer_phone']) ? trim($_POST['customer_phone']) : '';
    
    // Fallbacks just in case session structures or old field variants slip through
    if (empty($customer_name) && isset($_SESSION['pending_booking']['customer_name'])) {
        $customer_name = $_SESSION['pending_booking']['customer_name'];
    }
    if (empty($customer_phone) && isset($_POST['customer_mobile'])) {
        $customer_phone = trim($_POST['customer_mobile']);
    }

    // Capture hidden route meta variables passed by the review page form
    $booking_ref_no   = 'RC-' . strtoupper(substr(md5(uniqid(mt_rand(), true)), 0, 8)); // Generates a clean 8-character reference ID
    $trip_type        = isset($_POST['trip_type']) ? trim($_POST['trip_type']) : 'Oneway';
    $pickup_location  = isset($_POST['pickup_location']) ? trim($_POST['pickup_location']) : '';
    $drop_location    = isset($_POST['drop_location']) ? trim($_POST['drop_location']) : '';
    $pickup_date      = isset($_POST['pickup_date']) ? trim($_POST['pickup_date']) : '';
    
    // Standardize blank strings into standard Database NULL value allocations for single trips
    $return_date      = (isset($_POST['return_date']) && !empty($_POST['return_date'])) ? trim($_POST['return_date']) : NULL;
    $pickup_time      = isset($_POST['pickup_time']) ? trim($_POST['pickup_time']) : '';
    $car_type         = isset($_POST['car_type']) ? trim($_POST['car_type']) : '';
    
    // Numeric metrics extraction conversions
    $distance         = isset($_POST['distance']) ? intval($_POST['distance']) : 0;
    $total_fare       = isset($_POST['total_fare']) ? intval($_POST['total_fare']) : 0;
    $advance_paid     = isset($_POST['advance_paid']) ? floatval($_POST['advance_paid']) : 0.00;
    
    // Compute remaining driver payout liability dynamically
    $driver_balance   = floatval($total_fare - $advance_paid);
    
    // Generate secure 4-digit verification OTP pin for ride validation
    $otp_code         = strval(rand(1000, 9999));
    $assigned_driver_id = NULL;
    $booking_flag     = 1; 

    // 3. PREPARE THE INSERT STATEMENT TO MATCH THE MODIFIED BOOKINGS SCHEMA
    $sql = "INSERT INTO bookings (
                customer_name, 
                customer_phone, 
                booking_ref_no, 
                trip_type, 
                pickup_location, 
                drop_location, 
                pickup_date, 
                return_date, 
                pickup_time, 
                car_type, 
                distance, 
                total_fare, 
                advance_paid, 
                driver_balance, 
                otp_code,
                assigned_driver_id,
                booking_flag
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";

    if ($stmt = $conn->prepare($sql)) {
        
        // 17 parameter flags bound correctly: "ssssssssssiiddsii"
        $stmt->bind_param(
            "ssssssssssiiddsii", 
            $customer_name, 
            $customer_phone, 
            $booking_ref_no, 
            $trip_type, 
            $pickup_location, 
            $drop_location, 
            $pickup_date, 
            $return_date, 
            $pickup_time, 
            $car_type, 
            $distance, 
            $total_fare, 
            $advance_paid, 
            $driver_balance, 
            $otp_code,
            $assigned_driver_id,
            $booking_flag
        );

        // Execute step tracking transaction entry logic
        if ($stmt->execute()) {
            // Clear temporary caching structures out since database step committed smoothly
            unset($_SESSION['pending_booking']);
            
            // FIX: Smooth routing forward straight to your beautiful confirmation visual page layout
            header("Location: booking_confirmation.php?ref=" . urlencode($booking_ref_no));
            exit();
        } else {
            // Execution crash diagnostics processing tracking
            die("Database Insert Failure execution stopped: " . $stmt->error);
        }
        
        $stmt->close();
    } else {
        // Query formulation layout failure tracking
        die("SQL Statement Compilation Failed: " . $conn->error);
    }
} else {
    // Drop malicious or stray direct URL hits back onto input platform dashboard panel
    header("Location: index.php");
    exit();
}

$conn->close();
?>