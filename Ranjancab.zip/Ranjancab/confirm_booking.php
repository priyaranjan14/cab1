<?php
session_start();

$conn = new mysqli("localhost", "root", "", "ranjancab");
if ($conn->connect_error) {
    die("Database Connection Failed: " . $conn->connect_error);
}
$conn->set_charset("utf8mb4");

if ($_SERVER["REQUEST_METHOD"] !== "POST") {
    header("Location: index.php");
    exit();
}

// Capture POST fields
$customer_name   = trim($_POST['customer_name']   ?? '');
$customer_phone  = trim($_POST['customer_phone']  ?? '');
$trip_type       = trim($_POST['trip_type']       ?? 'Oneway');
$pickup_location = trim($_POST['pickup_location'] ?? '');
$drop_location   = trim($_POST['drop_location']   ?? '');
$pickup_date     = trim($_POST['pickup_date']     ?? '');
$pickup_time     = trim($_POST['pickup_time']     ?? '');
$return_date     = (!empty($_POST['return_date'])) ? trim($_POST['return_date']) : null;
$car_type        = trim($_POST['car_type']        ?? '');
$distance        = floatval($_POST['distance']    ?? 0);
$coupon_code     = strtoupper(trim($_POST['coupon_code'] ?? ''));

// --- Server-side fare re-calculation (security: do not trust client-side values blindly) ---
$total_fare = floatval($_POST['total_fare'] ?? 0);

// Recalculate coupon discount server-side if coupon code provided
$coupon_discount  = 0.00;
$discounted_fare  = $total_fare;

if (!empty($coupon_code)) {
    // Check table exists first
    $tbl_chk = $conn->query("SHOW TABLES LIKE 'coupon_codes'");
    if ($tbl_chk && $tbl_chk->num_rows > 0) {
        $cpn_stmt = $conn->prepare(
            "SELECT id, discount_percent FROM coupon_codes
             WHERE code = ? AND is_active = 1
               AND (valid_from IS NULL OR valid_from <= CURDATE())
               AND (valid_until IS NULL OR valid_until >= CURDATE())
               AND (max_usage = 0 OR usage_count < max_usage)
             LIMIT 1"
        );
        $cpn_stmt->bind_param("s", $coupon_code);
        $cpn_stmt->execute();
        $cpn_row = $cpn_stmt->get_result()->fetch_assoc();
        $cpn_stmt->close();

        if ($cpn_row) {
            $coupon_discount = round($total_fare * (floatval($cpn_row['discount_percent']) / 100), 2);
            $discounted_fare = round($total_fare - $coupon_discount, 2);
        } else {
            $coupon_code = ''; // invalid coupon — ignore it
        }
    } else {
        $coupon_code = ''; // table doesn't exist yet
    }
}

// 10% advance (company margin), 90% to driver
$advance_paid   = round($discounted_fare * 0.10, 2);
$driver_balance = round($discounted_fare - $advance_paid, 2);

// Generate booking ref and OTP
$booking_ref_no = 'RC-' . strtoupper(substr(md5(uniqid(mt_rand(), true)), 0, 8));
$otp_code       = strval(rand(1000, 9999));
$booking_flag   = 1;

// Validate required fields
if (empty($customer_name) || empty($customer_phone) || empty($pickup_location) || empty($drop_location) || empty($pickup_date)) {
    die("Missing required booking fields. <a href='javascript:history.back()'>Go back</a>");
}

// Insert booking
$sql = "INSERT INTO bookings (
            customer_name, customer_phone, booking_ref_no, trip_type,
            pickup_location, drop_location, pickup_date, return_date, pickup_time,
            car_type, distance, total_fare, discounted_fare, advance_paid,
            driver_balance, coupon_code, coupon_discount, otp_code,
            assigned_driver_id, booking_flag
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, NULL, ?)";

$stmt = $conn->prepare($sql);
if (!$stmt) {
    die("SQL prepare error: " . $conn->error);
}

$coupon_code_nullable = !empty($coupon_code) ? $coupon_code : null;

$stmt->bind_param(
    "ssssssssssdddddsdsi",
    $customer_name,
    $customer_phone,
    $booking_ref_no,
    $trip_type,
    $pickup_location,
    $drop_location,
    $pickup_date,
    $return_date,
    $pickup_time,
    $car_type,
    $distance,
    $total_fare,
    $discounted_fare,
    $advance_paid,
    $driver_balance,
    $coupon_code_nullable,
    $coupon_discount,
    $otp_code,
    $booking_flag
);

if (!$stmt->execute()) {
    die("Booking insert failed: " . $stmt->error);
}
$stmt->close();

// Increment coupon usage count if coupon was applied
if (!empty($coupon_code_nullable)) {
    $inc_stmt = $conn->prepare("UPDATE coupon_codes SET usage_count = usage_count + 1 WHERE code = ?");
    $inc_stmt->bind_param("s", $coupon_code_nullable);
    $inc_stmt->execute();
    $inc_stmt->close();
}

// Create / update customer credentials (phone as default password)
$hashed_pw    = password_hash($customer_phone, PASSWORD_BCRYPT);
$ph_email     = $customer_phone . '@ranjancabs.local';

$cred_check = $conn->prepare("SELECT id FROM customer_credentials WHERE customer_phone = ? LIMIT 1");
$cred_check->bind_param("s", $customer_phone);
$cred_check->execute();
$cred_exists = $cred_check->get_result()->num_rows > 0;
$cred_check->close();

if ($cred_exists) {
    $upd = $conn->prepare("UPDATE customer_credentials SET password = ? WHERE customer_phone = ?");
    $upd->bind_param("ss", $hashed_pw, $customer_phone);
    $upd->execute();
    $upd->close();
} else {
    $ins = $conn->prepare(
        "INSERT INTO customer_credentials (customer_phone, customer_email, password) VALUES (?, ?, ?)"
    );
    $ins->bind_param("sss", $customer_phone, $ph_email, $hashed_pw);
    $ins->execute();
    $ins->close();
}

unset($_SESSION['pending_booking']);
$conn->close();

header("Location: booking_confirmation.php?ref=" . urlencode($booking_ref_no));
exit();
?>
