<div class="modal fade" id="addRouteModal" tabindex="-1" aria-labelledby="addRouteModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered modal-lg">
        <div class="modal-content overflow-hidden border-0 shadow">
            <form method="POST" action="admin.php">
                <input type="hidden" name="action" value="add_route">
                
                <div class="modal-header bg-dark text-white p-3 px-4">
                    <h5 class="modal-title h6 fw-bold mb-0 d-flex align-items-center gap-2" id="addRouteModalLabel">
                        <i class="fa-solid fa-circle-plus text-warning"></i> Commission New Logistics Corridor
                    </h5>
                    <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                
                <div class="modal-body p-4 bg-light">
                    <div class="row g-4">
                        <div class="col-12 col-lg-6">
                            <div class="bg-white p-3 rounded-3 border h-100">
                                <div class="mb-3">
                                    <label class="form-label small fw-bold text-dark">Origin Location / Landmark</label>
                                    <div class="input-group">
                                        <span class="input-group-text bg-light text-success"><i class="fa-solid fa-location-dot"></i></span>
                                        <input type="text" class="form-control text-slate-800" name="pickup_point" id="modal_pickup" placeholder="e.g., Ranchi Railway Station" required>
                                    </div>
                                </div>
                                
                                <div class="mb-3">
                                    <label class="form-label small fw-bold text-dark">Terminal Drop Location / Landmark</label>
                                    <div class="input-group">
                                        <span class="input-group-text bg-light text-danger"><i class="fa-solid fa-location-crosshairs"></i></span>
                                        <input type="text" class="form-control text-slate-800" name="drop_point" id="modal_drop" placeholder="e.g., Birsa Munda Airport (IXR)" required>
                                    </div>
                                </div>
                                
                                <div class="mb-0">
                                    <label class="form-label small fw-bold text-dark">Estimated Track Distance Matrix</label>
                                    <div class="input-group">
                                        <input type="number" step="0.1" min="0.1" class="form-control font-monospace fw-bold text-slate-800" name="estimated_distance" id="modal_distance" placeholder="0.0" required>
                                        <span class="input-group-text bg-secondary-subtle font-monospace text-dark">KILOMETERS (KM)</span>
                                    </div>
                                </div>
                            </div>
                        </div>
                        
                        <div class="col-12 col-lg-6">
                            <div class="border border-warning-subtle rounded-3 p-3 bg-warning-subtle bg-opacity-10 h-100 d-flex flex-column justify-content-between">
                                <div>
                                    <div class="text-uppercase text-warning fw-bold font-monospace small mb-2 d-flex align-items-center gap-1" style="font-size:0.7rem; letter-spacing:0.05em;">
                                        <i class="fa-solid fa-eye"></i> Live Pipeline Validation Monitor
                                    </div>
                                    <p class="text-muted mb-3" style="font-size:0.78rem; line-height:1.4;">
                                        Review the configuration below. Ensure names match physical system coordinates before committing to the live operational databases.
                                    </p>
                                    
                                    <div class="bg-white p-3 rounded-2 border shadow-inner small">
                                        <div class="mb-2 text-truncate">
                                            <span class="badge bg-success-subtle text-success me-1 font-monospace" style="font-size:0.65rem;">FROM</span>
                                            <span id="preview_pickup" class="text-secondary italic">Awaiting source node input...</span>
                                        </div>
                                        <div class="mb-2 text-truncate">
                                            <span class="badge bg-danger-subtle text-danger me-1 font-monospace" style="font-size:0.65rem;">TO</span>
                                            <span id="preview_drop" class="text-secondary italic">Awaiting terminal node input...</span>
                                        </div>
                                        <div class="mt-2 pt-2 border-top font-monospace">
                                            <span class="text-muted">Calculated Shift:</span> <strong id="preview_distance" class="text-dark">0.0</strong> <strong>KM</strong>
                                        </div>
                                    </div>
                                </div>
                                
                                <div class="alert alert-info border-0 rounded-2 p-2 mt-3 mb-0 d-flex align-items-start gap-2" style="font-size:0.75rem;">
                                    <i class="fa-solid fa-circle-info mt-0.5 text-info"></i>
                                    <div class="lh-sm text-dark">This route immediately unlocks automatic booking tariff math for corresponding car types.</div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                
                <div class="modal-footer bg-white px-4 py-3 border-top d-flex justify-content-between align-items-center">
                    <button type="button" class="btn btn-sm btn-outline-secondary px-3" data-bs-dismiss="modal">Abort Entry</button>
                    <button type="submit" class="btn btn-sm btn-primary-custom px-4 d-flex align-items-center gap-1">
                        <i class="fa-solid fa-cloud-arrow-up"></i> Save Grid Route
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>