<?php
// Initialize the session matrix context
session_start();

// Unset all active session variables assigned during authorization
$_SESSION = array();

// If the session uses cookies (standard PHP behavior), destroy the browser side tracker cookie
if (ini_get("session.use_cookies")) {
    $params = session_get_cookie_params();
    setcookie(
        session_name(), 
        '', 
        time() - 42000,
        $params["path"], 
        $params["domain"],
        $params["secure"], 
        $params["httponly"]
    );
}

// Completely purge and destroy the data session on the server engine side
session_destroy();

// Redirect back to the decoupled login interface screen cleanly
header("Location: admin_login.php");
exit();
?>