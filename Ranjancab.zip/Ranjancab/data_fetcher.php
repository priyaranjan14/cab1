<?php
$bookings_result  = $conn->query("SELECT b.*, f.driver_name FROM bookings b LEFT JOIN fleet f ON b.assigned_driver_id = f.id ORDER BY b.id DESC");
$fleet_result     = $conn->query("SELECT * FROM fleet ORDER BY id DESC");
$routes_result    = $conn->query("SELECT * FROM routes ORDER BY id DESC");

$drivers_menu = [];
$d_query = $conn->query("SELECT id, driver_name, vehicle_number, car_type FROM fleet WHERE status = 1");
while($d = $d_query->fetch_assoc()) { $drivers_menu[] = $d; }

$total_revenue = $conn->query("SELECT SUM(total_fare) as total FROM bookings WHERE booking_flag = 3")->fetch_assoc()['total'] ?? 0;
$active_rides  = $conn->query("SELECT COUNT(*) as count FROM bookings WHERE booking_flag = 1")->fetch_assoc()['count'] ?? 0;
$active_drivers = $conn->query("SELECT COUNT(*) as count FROM fleet WHERE status = 1")->fetch_assoc()['count'] ?? 0;
?>