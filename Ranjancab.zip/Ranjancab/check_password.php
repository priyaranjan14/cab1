<?php
$conn = new mysqli("localhost", "root", "", "Ranjancab");

// Adjust the mobile number here to match the driver account you are testing
$mobile = "8959158196"; 

$result = $conn->query("SELECT driver_name, password FROM fleet WHERE mobile_number = '$mobile'");
if ($driver = $result->fetch_assoc()) {
    echo "<h3>Driver Name in DB: '" . $driver['driver_name'] . "'</h3>";
    
    // Let's test what the script thinks the last name is
    $name_parts = explode(' ', trim($driver['driver_name']));
    $expected_last_name = end($name_parts);
    
    echo "Dedicated Last Name string: <b>" . $expected_last_name . "</b><br>";
    
    // Verify if that string matches the database hash
    if (password_verify($expected_last_name, $driver['password'])) {
        echo "Status: <span style='color:green;'>Match! Use the exact text above as your password. Watch for capitalization.</span>";
    } else {
        echo "Status: <span style='color:red;'>Mismatch. The hash in the database is looking for something else.</span>";
    }
} else {
    echo "No driver found with mobile number: " . $mobile;
}
$conn->close();
?>