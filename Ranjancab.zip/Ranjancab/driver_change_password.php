<?php
session_start();
if (!isset($_SESSION['driver_id'])) { 
    header("Location: driver_login.php"); 
    exit(); 
}

$message = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $conn = new mysqli("localhost", "root", "", "Ranjancab");
    
    if ($conn->connect_error) {
        die("Database connection failure: " . $conn->connect_error);
    }

    $new_password = trim($_POST['new_password']);
    $confirm_password = trim($_POST['confirm_password']);
    $driver_id = $_SESSION['driver_id'];

    if ($new_password === $confirm_password) {
        // PLAIN TEXT WRITE OPERATION FOR TESTING
        $stmt = $conn->prepare("UPDATE fleet SET password = ?, is_first_login = 0 WHERE id = ?");
        $stmt->bind_param("si", $new_password, $driver_id);
        
        if ($stmt->execute()) {
            $_SESSION['is_first_login'] = 0; // Clear state flag
            $stmt->close();
            $conn->close();
            header("Location: driver_dashboard.php?setup=complete");
            exit();
        }
        $stmt->close();
    } else {
        $message = "Passwords do not match!";
    }
    $conn->close();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Change Password | Driver Portal</title>
    <link rel="stylesheet" href="style.css">
    <style>
        .change-card { background: #ffffff; padding: 30px; border-radius: 8px; box-shadow: 0 4px 15px rgba(0,0,0,0.15); max-width: 400px; width: 100%; margin: 80px auto; }
        .input-group { margin-bottom: 15px; }
        .input-group label { display: block; margin-bottom: 5px; font-size: 13px; color: #475569; }
        .input-group input { width: 100%; padding: 10px; border: 1px solid #cbd5e1; border-radius: 6px; }
        .submit-btn { width: 100%; padding: 12px; background: #22c55e; border: none; color: #white; font-weight: 600; border-radius: 6px; cursor: pointer; color: #fff; }
        .error { color: #ef4444; font-size: 13px; margin-bottom: 10px; }
    </style>
</head>
<body>
    <div class="change-card">
        <h2>First-Time Password Update</h2>
        <p style="font-size: 13px; color: #64748b; margin-bottom: 20px;">Please update your plain-text verification key before navigating to the fleet array grid.</p>
        
        <?php if(!empty($message)): ?>
            <p class="error"><?php echo $message; ?></p>
        <?php endif; ?>

        <form action="driver_change_password.php" method="POST">
            <div class="input-group">
                <label for="new_password">New Password</label>
                <input type="password" id="new_password" name="new_password" required>
            </div>
            <div class="input-group">
                <label for="confirm_password">Confirm New Password</label>
                <input type="password" id="confirm_password" name="confirm_password" required>
            </div>
            <button type="submit" class="submit-btn">Save New Password</button>
        </form>
    </div>
</body>
</html>