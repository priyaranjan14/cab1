<?php
session_start();

// FORCE BROWSER TO DESTROY MARKUP CACHE FOR THIS PAGE (Prevents stale Active Trip views)
header("Cache-Control: no-cache, no-store, must-revalidate"); 
header("Pragma: no-cache"); 
header("Expires: 0"); 

// Strict Session Guard
if (!isset($_SESSION['driver_id'])) {
    header("Location: driver_login.php");
    exit();
}

$driver_id    = $_SESSION['driver_id'];
$driver_name  = $_SESSION['driver_name'];

$conn = new mysqli("localhost", "root", "", "ranjancab");
if ($conn->connect_error) {
    die("Database engine connectivity failure: " . $conn->connect_error);
}
$conn->set_charset("utf8mb4");

$doc_success = "";
$doc_error = "";

function handle_driver_document_upload($field_name, $driver_id, &$error_message) {
    if (!isset($_FILES[$field_name]) || $_FILES[$field_name]['error'] === UPLOAD_ERR_NO_FILE) {
        return null;
    }

    if ($_FILES[$field_name]['error'] !== UPLOAD_ERR_OK) {
        $error_message = "Upload failed for " . $field_name . ".";
        return false;
    }

    $allowed_extensions = ['pdf', 'jpg', 'jpeg', 'png'];
    $extension = strtolower(pathinfo($_FILES[$field_name]['name'], PATHINFO_EXTENSION));
    if (!in_array($extension, $allowed_extensions, true)) {
        $error_message = "Only PDF, JPG, JPEG, and PNG files are allowed.";
        return false;
    }

    if ($_FILES[$field_name]['size'] > 5 * 1024 * 1024) {
        $error_message = "Each document must be 5 MB or smaller.";
        return false;
    }

    $upload_dir = __DIR__ . DIRECTORY_SEPARATOR . "uploads" . DIRECTORY_SEPARATOR . "drivers";
    if (!is_dir($upload_dir) && !mkdir($upload_dir, 0775, true)) {
        $error_message = "Unable to prepare document upload directory.";
        return false;
    }

    $safe_name = "dr_" . intval($driver_id) . "_" . $field_name . "_" . time() . "." . $extension;
    $destination = $upload_dir . DIRECTORY_SEPARATOR . $safe_name;
    if (!move_uploaded_file($_FILES[$field_name]['tmp_name'], $destination)) {
        $error_message = "Unable to save uploaded document.";
        return false;
    }

    return "uploads/drivers/" . $safe_name;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['action'] ?? '') === 'upload_driver_documents') {
    $driver_license_no = trim($_POST['driver_license_no'] ?? '');
    $aadhaar_no = preg_replace('/\s+/', '', trim($_POST['aadhaar_no'] ?? ''));
    $rc_no = strtoupper(trim($_POST['rc_no'] ?? ''));

    if ($driver_license_no === '' || $aadhaar_no === '' || $rc_no === '') {
        $doc_error = "Please enter all document numbers before submitting.";
    } else {
        $license_path = handle_driver_document_upload('doc_license', $driver_id, $doc_error);
        $aadhaar_path = ($license_path !== false) ? handle_driver_document_upload('doc_aadhaar', $driver_id, $doc_error) : false;
        $rc_path = ($aadhaar_path !== false) ? handle_driver_document_upload('doc_rc', $driver_id, $doc_error) : false;

        if ($license_path !== false && $aadhaar_path !== false && $rc_path !== false) {
            $current_doc_stmt = $conn->prepare("SELECT doc_license_path, doc_aadhaar_path, doc_rc_path FROM fleet WHERE id = ? LIMIT 1");
            $current_doc_stmt->bind_param("i", $driver_id);
            $current_doc_stmt->execute();
            $current_docs = $current_doc_stmt->get_result()->fetch_assoc();
            $current_doc_stmt->close();

            $license_path = $license_path ?: ($current_docs['doc_license_path'] ?? null);
            $aadhaar_path = $aadhaar_path ?: ($current_docs['doc_aadhaar_path'] ?? null);
            $rc_path = $rc_path ?: ($current_docs['doc_rc_path'] ?? null);

            $update_doc_stmt = $conn->prepare("
                UPDATE fleet
                SET driver_license_no = ?, aadhaar_no = ?, rc_no = ?,
                    doc_license_path = ?, doc_aadhaar_path = ?, doc_rc_path = ?,
                    is_verified = 0
                WHERE id = ?
            ");
            $update_doc_stmt->bind_param(
                "ssssssi",
                $driver_license_no,
                $aadhaar_no,
                $rc_no,
                $license_path,
                $aadhaar_path,
                $rc_path,
                $driver_id
            );
            $update_doc_stmt->execute();
            $update_doc_stmt->close();
            $doc_success = "Documents submitted successfully. Admin verification is now pending.";
        }
    }
}

/**
 * FETCH DRIVER METADATA PROFILE
 */
$driver_query = "SELECT base_station, car_type, is_verified, driver_license_no, aadhaar_no, rc_no, doc_license_path, doc_aadhaar_path, doc_rc_path FROM fleet WHERE id = ?";
$d_stmt = $conn->prepare($driver_query);
$d_stmt->bind_param("i", $driver_id);
$d_stmt->execute();
$driver_profile = $d_stmt->get_result()->fetch_assoc();
$d_stmt->close();

$base_station = $driver_profile['base_station'] ?? 'Not Assigned';
$car_type     = $driver_profile['car_type'] ?? 'Not Assigned';
$is_verified  = intval($driver_profile['is_verified'] ?? 0);
$has_all_docs = !empty($driver_profile['driver_license_no']) && !empty($driver_profile['aadhaar_no']) && !empty($driver_profile['rc_no']) && !empty($driver_profile['doc_license_path']) && !empty($driver_profile['doc_aadhaar_path']) && !empty($driver_profile['doc_rc_path']);

/**
 * FETCH CURRENT ACTIVE ONGOING TRIP (booking_flag = 2)
 */
$active_trip_query = "SELECT id, booking_ref_no, customer_name, customer_phone, pickup_location, drop_location, 
                             pickup_date, pickup_time, distance, trip_type, driver_balance 
                      FROM bookings 
                      WHERE assigned_driver_id = ? AND booking_flag = 2 LIMIT 1";
$a_stmt = $conn->prepare($active_trip_query);
$a_stmt->bind_param("i", $driver_id);
$a_stmt->execute();
$active_trip = $a_stmt->get_result()->fetch_assoc();
$a_stmt->close();

/**
 * FETCH HISTORICAL PAST TRIPS (booking_flag = 3)
 */
$past_trips_query = "SELECT booking_ref_no, customer_name, pickup_location, drop_location, pickup_date, driver_balance 
                     FROM bookings 
                     WHERE assigned_driver_id = ? AND booking_flag = 3 
                     ORDER BY id DESC";
$p_stmt = $conn->prepare($past_trips_query);
$p_stmt->bind_param("i", $driver_id);
$p_stmt->execute();
$past_trips_result = $p_stmt->get_result();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Driver Terminal Hub | RanjanCabs</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        :root { 
            --primary: #1e293b; 
            --accent: #f59e0b; 
            --success: #10b981; 
            --danger: #ef4444; 
            --bg: #f8fafc; 
            --card: #ffffff; 
            --text-dark: #334155;
            --text-muted: #64748b;
        }

        * { box-sizing: border-box; margin: 0; padding: 0; font-family: 'Segoe UI', sans-serif; }
        body { background-color: var(--bg); color: var(--text-dark); padding: 15px; }
        .container { max-width: 1200px; margin: 0 auto; }
        
        header { 
            background-color: var(--primary); color: white; padding: 20px; border-radius: 8px; 
            margin-bottom: 25px; display: flex; justify-content: space-between; align-items: center; 
            flex-wrap: wrap; gap: 15px; box-shadow: 0 4px 6px -1px rgba(0, 0, 0, 0.1);
        }
        header h1 span { color: var(--accent); }
        .profile-badge { 
            background: rgba(255, 255, 255, 0.1); padding: 6px 12px; border-radius: 4px; 
            font-size: 13px; font-family: monospace; border: 1px solid rgba(255, 255, 255, 0.2);
        }
        .logout-btn { background: var(--danger); color: white; text-decoration: none; padding: 8px 16px; border-radius: 4px; font-size: 13px; font-weight: bold; }
        .alert { padding: 12px 14px; border-radius: 7px; margin-bottom: 16px; font-size: 14px; font-weight: 600; }
        .alert-success { background: #dcfce7; color: #166534; border: 1px solid #bbf7d0; }
        .alert-error { background: #fee2e2; color: #991b1b; border: 1px solid #fecaca; }
        .document-panel { background: var(--card); border: 1px solid #e2e8f0; border-radius: 8px; padding: 20px; box-shadow: 0 4px 6px -1px rgba(0,0,0,0.05); margin-bottom: 25px; }
        .document-panel-head { display: flex; justify-content: space-between; align-items: flex-start; gap: 14px; flex-wrap: wrap; border-bottom: 1px solid #e2e8f0; padding-bottom: 14px; margin-bottom: 16px; }
        .verification-badge { display: inline-flex; align-items: center; gap: 6px; padding: 7px 10px; border-radius: 999px; font-size: 12px; font-weight: 800; }
        .verification-badge.verified { background: #dcfce7; color: #166534; }
        .verification-badge.pending { background: #fef3c7; color: #92400e; }
        .document-grid { display: grid; grid-template-columns: repeat(3, minmax(0, 1fr)); gap: 14px; }
        .doc-field { display: flex; flex-direction: column; gap: 6px; }
        .doc-field label { font-size: 12px; font-weight: 800; color: var(--primary); text-transform: uppercase; }
        .doc-field input { width: 100%; border: 1px solid #cbd5e1; border-radius: 6px; padding: 10px; font-size: 14px; background: #fff; }
        .doc-current { min-height: 22px; font-size: 12px; color: var(--text-muted); }
        .doc-current a { color: #2563eb; font-weight: 700; text-decoration: none; }
        .doc-submit-row { display: flex; justify-content: flex-end; margin-top: 16px; }
        .btn-doc-submit { background: var(--primary); color: white; border: none; border-radius: 6px; padding: 11px 16px; font-size: 13px; font-weight: 800; cursor: pointer; display: inline-flex; align-items: center; gap: 8px; }

        .section-title { font-size: 20px; font-weight: 700; margin: 30px 0 15px; display: flex; align-items: center; gap: 10px; color: var(--primary); }
        .live-indicator { width: 10px; height: 10px; background: var(--success); border-radius: 50%; display: inline-block; animation: pulse 1.5s infinite; }
        
        @keyframes pulse {
            0% { transform: scale(0.95); box-shadow: 0 0 0 0 rgba(16, 185, 129, 0.7); }
            70% { transform: scale(1); box-shadow: 0 0 0 6px rgba(16, 185, 129, 0); }
            100% { transform: scale(0.95); box-shadow: 0 0 0 0 rgba(16, 185, 129, 0); }
        }

        /* Active Trip Persistent HUD Card */
        .active-trip-panel {
            background: linear-gradient(135deg, #1e293b 0%, #0f172a 100%);
            color: white; padding: 25px; border-radius: 8px; margin-bottom: 10px;
            box-shadow: 0 10px 25px -5px rgba(30, 41, 59, 0.3); border-left: 6px solid var(--accent);
        }
        .active-grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(240px, 1fr)); gap: 20px; margin-top: 15px; margin-bottom: 20px; }
        .active-meta-box { background: rgba(255, 255, 255, 0.05); padding: 15px; border-radius: 6px; border: 1px solid rgba(255, 255, 255, 0.1); }
        .active-meta-box h4 { color: var(--accent); font-size: 12px; text-transform: uppercase; margin-bottom: 6px; letter-spacing: 0.5px; }
        .active-meta-box p { font-size: 15px; font-weight: 600; }
        
        .btn-complete { background-color: var(--accent); color: #0f172a; font-weight: bold; width: 100%; max-width: 250px; padding: 12px; border: none; border-radius: 6px; cursor: pointer; text-transform: uppercase; letter-spacing: 0.5px; font-size: 14px; display: flex; align-items: center; justify-content: center; gap: 8px; transition: background 0.2s; }
        .btn-complete:hover { background-color: #d97706; }

        /* General Booking Stream Matrix */
        #booking-stream-desk { display: grid; grid-template-columns: repeat(auto-fill, minmax(320px, 1fr)); gap: 20px; }
        .booking-card { background: var(--card); border: 1px solid #e2e8f0; border-radius: 8px; padding: 20px; box-shadow: 0 4px 6px -1px rgba(0,0,0,0.05); transition: all 0.2s; position: relative; }
        .booking-card:hover { transform: translateY(-2px); box-shadow: 0 10px 15px -3px rgba(0, 0, 0, 0.1); }
        
        .card-header { display: flex; justify-content: space-between; align-items: center; margin-bottom: 12px; border-bottom: 1px dashed #e2e8f0; padding-bottom: 10px; }
        .ref-txt { font-family: monospace; font-weight: bold; color: var(--primary); background: #f1f5f9; padding: 2px 6px; border-radius: 4px; font-size: 13px; }
        .fare-txt { color: var(--success); font-weight: 800; font-size: 20px; }
        .route-row { margin-bottom: 10px; font-size: 14px; display: flex; gap: 10px; align-items: flex-start; }
        .route-row i { margin-top: 3px; width: 16px; text-align: center; }
        
        .action-tray { display: flex; gap: 10px; margin-top: 18px; border-top: 1px solid #f1f5f9; padding-top: 14px; }
        .btn { flex: 1; padding: 10px 14px; border: none; border-radius: 4px; font-weight: bold; font-size: 13px; cursor: pointer; display: flex; align-items: center; justify-content: center; gap: 6px; text-transform: uppercase; }
        .btn-accept { background-color: var(--success); color: white; }
        .btn-reject { background-color: #f1f5f9; color: var(--text-muted); border: 1px solid #cbd5e1; }
        .no-data { grid-column: 1 / -1; text-align: center; color: var(--text-muted); padding: 40px 20px; font-style: italic; background: white; border-radius: 8px; border: 1px dashed #cbd5e1; }

        /* Historical Past Trips Log Table UI */
        .history-card { background: var(--card); border: 1px solid #e2e8f0; border-radius: 8px; padding: 20px; box-shadow: 0 4px 6px -1px rgba(0,0,0,0.05); overflow-x: auto; }
        .history-table { width: 100%; border-collapse: collapse; text-align: left; font-size: 14px; }
        .history-table th { background: #f8fafc; color: var(--text-muted); font-weight: 600; padding: 12px; border-bottom: 2px solid #e2e8f0; }
        .history-table td { padding: 14px 12px; border-bottom: 1px solid #f1f5f9; vertical-align: middle; }
        .history-table tr:last-child td { border-bottom: none; }

        /* Modal Overlay Configuration */
        .modal-overlay { display: none; position: fixed; top: 0; left: 0; width: 100%; height: 100%; background: rgba(15, 23, 42, 0.75); backdrop-filter: blur(4px); justify-content: center; align-items: center; z-index: 1000; }
        .modal-box { background: white; padding: 30px; border-radius: 12px; width: 90%; max-width: 400px; text-align: center; }
        .otp-input { width: 100%; padding: 12px; border: 2px solid #cbd5e1; border-radius: 6px; font-size: 26px; text-align: center; font-weight: bold; letter-spacing: 6px; margin-bottom: 20px; outline: none; }
        .modal-buttons { display: flex; gap: 10px; }

        @media (max-width: 768px) {
            header { flex-direction: column; text-align: center; }
            header div { text-align: center !important; align-items: center !important; display: flex; flex-direction: column; }
            .btn-complete { max-width: 100%; }
            .document-grid { grid-template-columns: 1fr; }
            .doc-submit-row { justify-content: stretch; }
            .btn-doc-submit { width: 100%; justify-content: center; }
        }
    </style>
</head>
<body>

<div class="container">
    <header>
        <div>
            <h1>Ranjan<span>Cabs</span> Pilot Desk</h1>
            <p>Welcome back, Pilot: <strong><?= htmlspecialchars($driver_name) ?></strong></p>
        </div>
        <div style="text-align: right; display: flex; flex-direction: column; gap: 8px; align-items: flex-end;">
            <div class="profile-badge">Base Station: <?= htmlspecialchars($base_station) ?> | Vehicle: <?= htmlspecialchars($car_type) ?></div>
            <a href="driver_logout.php" class="logout-btn"><i class="fa-solid fa-right-from-bracket"></i> Log Out</a>
        </div>
    </header>

    <?php if ($doc_success): ?>
        <div class="alert alert-success"><i class="fa-solid fa-circle-check"></i> <?= htmlspecialchars($doc_success) ?></div>
    <?php endif; ?>
    <?php if ($doc_error): ?>
        <div class="alert alert-error"><i class="fa-solid fa-triangle-exclamation"></i> <?= htmlspecialchars($doc_error) ?></div>
    <?php endif; ?>

    <!-- Document panel temporarily moved below broadcast and history as requested -->

    <main>
        <h2 class="section-title" style="color: #4338ca;"><i class="fa-solid fa-route"></i> Active Operational Duty</h2>
        
        <?php if ($active_trip): ?>
            <div class="active-trip-panel">
                <div style="display: flex; justify-content: space-between; align-items: center; border-bottom: 1px solid rgba(255,255,255,0.1); padding-bottom: 12px; flex-wrap: wrap; gap: 10px;">
                    <div>
                        <span style="background: var(--accent); color: #0f172a; padding: 3px 8px; font-weight: bold; border-radius: 4px; font-size: 12px; margin-right: 10px;">IN PROGRESS</span>
                        <strong style="font-family: monospace; font-size: 16px;"><?= $active_trip['booking_ref_no'] ?></strong>
                    </div>
                    <div style="font-size: 14px; font-weight: 800; color: var(--accent);">Collect from Customer: <span style="font-size:22px; color: var(--success);">₹<?= number_format($active_trip['driver_balance'], 2) ?></span></div>
                </div>
                
                <div class="active-grid">
                    <div class="active-meta-box">
                        <h4>Passenger Profile</h4>
                        <p><i class="fa-solid fa-user"></i> <?= htmlspecialchars($active_trip['customer_name']) ?></p>
                        <p style="font-size:13px; color: #94a3b8; margin-top:4px;"><i class="fa-solid fa-phone"></i> <?= htmlspecialchars($active_trip['customer_phone']) ?></p>
                    </div>
                    <div class="active-meta-box">
                        <h4>Route Track Mapping</h4>
                        <p style="font-size: 13px; color: #f87171;"><i class="fa-solid fa-location-dot"></i> From: <?= htmlspecialchars($active_trip['pickup_location']) ?></p>
                        <p style="font-size: 13px; color: #34d399; margin-top: 6px;"><i class="fa-solid fa-flag-checkered"></i> To: <?= htmlspecialchars($active_trip['drop_location']) ?></p>
                    </div>
                    <div class="active-meta-box">
                        <h4>Operational Details</h4>
                        <p><?= htmlspecialchars($active_trip['trip_type']) ?> Plan (<?= $active_trip['distance'] ?> KM)</p>
                        <p style="font-size:13px; color: var(--accent); margin-top:4px; font-weight:800;">Collect from Customer: <strong>₹<?= number_format($active_trip['driver_balance'], 2) ?></strong></p>
                    </div>
                </div>

                <button class="btn-complete" onclick="triggerCompleteTrip(<?= $active_trip['id'] ?>)">
                    <i class="fa-solid fa-circle-check"></i> Complete Current Trip
                </button>
            </div>
        <?php else: ?>
            <div class="no-data" style="background: #f1f5f9; margin-bottom: 30px; padding: 30px;">
                <i class="fa-solid fa-moon" style="font-size: 24px; color: var(--text-muted);"></i><br>No active ongoing assignment running. Secure a broadcast request below to get started.
            </div>
        <?php endif; ?>

        <h2 class="section-title"><span class="live-indicator"></span> Broadcast Channel Queue (Live Streams)</h2>
        <div id="booking-stream-desk">
            <div class="no-data"><i class="fa-solid fa-circle-notch fa-spin"></i> Establishing streams hook connection...</div>
        </div>

        <h2 class="section-title" style="color: #64748b;"><i class="fa-solid fa-clock-rotate-left"></i> Finished Duty Log (Past Trips)</h2>
        <div class="history-card">
            <?php if ($past_trips_result->num_rows > 0): ?>
                <table class="history-table">
                    <thead>
                        <tr>
                            <th>Ref No.</th>
                            <th>Passenger</th>
                            <th>Route Detail Summary</th>
                            <th>Date</th>
                            <th>Collect from Customer</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php while ($row = $past_trips_result->fetch_assoc()): ?>
                            <tr>
                                <td><strong style="font-family: monospace; color:#1e293b;"><?= $row['booking_ref_no'] ?></strong></td>
                                <td><?= htmlspecialchars($row['customer_name']) ?></td>
                                <td>
                                    <div style="font-size:12px; color: var(--danger);"><i class="fa-solid fa-location-dot"></i> <?= htmlspecialchars($row['pickup_location']) ?></div>
                                    <div style="font-size:12px; color: var(--success); margin-top:3px;"><i class="fa-solid fa-flag-checkered"></i> <?= htmlspecialchars($row['drop_location']) ?></div>
                                </td>
                                <td><?= date("d M Y", strtotime($row['pickup_date'])) ?></td>
                                <td>
                                    <strong style="color: var(--success);">₹<?= number_format(floatval($row['driver_balance']), 2) ?></strong>
                                </td>
                            </tr>
                        <?php endwhile; ?>
                    </tbody>
                </table>
            <?php else: ?>
                <div style="text-align: center; color: var(--text-muted); padding: 20px 0; font-style: italic;">
                    No closed historical logs found in your pilot profile registry.
                </div>
            <?php endif; ?>
        </div>

        <!-- Statutory Document Verification (moved below live streams and past trips) -->
        <section class="document-panel">
            <div class="document-panel-head">
                <div>
                    <h2 style="font-size: 18px; margin-bottom: 5px; color: var(--primary);"><i class="fa-solid fa-file-shield"></i> Statutory Document Verification</h2>
                    <p style="font-size: 13px; color: var(--text-muted);">Upload your driving licence, Aadhaar, and cab registration card for admin approval.</p>
                </div>
                <?php if ($is_verified): ?>
                    <span class="verification-badge verified"><i class="fa-solid fa-circle-check"></i> Verified by Admin</span>
                <?php elseif ($has_all_docs): ?>
                    <span class="verification-badge pending"><i class="fa-solid fa-clock"></i> Pending Admin Verification</span>
                <?php else: ?>
                    <span class="verification-badge pending"><i class="fa-solid fa-file-circle-exclamation"></i> Documents Required</span>
                <?php endif; ?>
            </div>

            <form method="POST" action="driver_dashboard.php" enctype="multipart/form-data">
                <input type="hidden" name="action" value="upload_driver_documents">
                <div class="document-grid">
                    <div class="doc-field">
                        <label>Driving Licence Number</label>
                        <input type="text" name="driver_license_no" value="<?= htmlspecialchars($driver_profile['driver_license_no'] ?? '') ?>" placeholder="E.g. MP0420260001" required>
                        <input type="file" name="doc_license" accept=".pdf,.jpg,.jpeg,.png" <?= empty($driver_profile['doc_license_path']) ? 'required' : '' ?>>
                        <div class="doc-current">
                            <?php if (!empty($driver_profile['doc_license_path'])): ?>
                                <a href="<?= htmlspecialchars($driver_profile['doc_license_path']) ?>" target="_blank"><i class="fa-solid fa-up-right-from-square"></i> View uploaded licence</a>
                            <?php else: ?>
                                No licence file uploaded
                            <?php endif; ?>
                        </div>
                    </div>

                    <div class="doc-field">
                        <label>Aadhaar Number</label>
                        <input type="text" name="aadhaar_no" value="<?= htmlspecialchars($driver_profile['aadhaar_no'] ?? '') ?>" maxlength="12" pattern="[0-9]{12}|X{4}-X{4}-[0-9]{4}" placeholder="12-digit Aadhaar number" required>
                        <input type="file" name="doc_aadhaar" accept=".pdf,.jpg,.jpeg,.png" <?= empty($driver_profile['doc_aadhaar_path']) ? 'required' : '' ?>>
                        <div class="doc-current">
                            <?php if (!empty($driver_profile['doc_aadhaar_path'])): ?>
                                <a href="<?= htmlspecialchars($driver_profile['doc_aadhaar_path']) ?>" target="_blank"><i class="fa-solid fa-up-right-from-square"></i> View uploaded Aadhaar</a>
                            <?php else: ?>
                                No Aadhaar file uploaded
                            <?php endif; ?>
                        </div>
                    </div>

                    <div class="doc-field">
                        <label>Cab Registration Card Number</label>
                        <input type="text" name="rc_no" value="<?= htmlspecialchars($driver_profile['rc_no'] ?? '') ?>" placeholder="E.g. MP04HE1234RC" required>
                        <input type="file" name="doc_rc" accept=".pdf,.jpg,.jpeg,.png" <?= empty($driver_profile['doc_rc_path']) ? 'required' : '' ?>>
                        <div class="doc-current">
                            <?php if (!empty($driver_profile['doc_rc_path'])): ?>
                                <a href="<?= htmlspecialchars($driver_profile['doc_rc_path']) ?>" target="_blank"><i class="fa-solid fa-up-right-from-square"></i> View uploaded RC</a>
                            <?php else: ?>
                                No registration card uploaded
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
                <div class="doc-submit-row">
                    <button type="submit" class="btn-doc-submit"><i class="fa-solid fa-cloud-arrow-up"></i> Submit Documents for Verification</button>
                </div>
            </form>
        </section>
    </main>
</div>

<div class="modal-overlay" id="otpModal">
    <div class="modal-box">
        <i class="fa-solid fa-key" style="font-size: 28px; color: var(--accent); margin-bottom: 12px;"></i>
        <h3>Trip Start Verification</h3>
        <p>Input passenger security OTP to clear assignment validation blocks.</p>
        <input type="hidden" id="target_booking_id">
        <input type="text" class="otp-input" id="otp_entry" placeholder="0000" maxlength="6" inputmode="numeric">
        <div class="modal-buttons">
            <button class="btn btn-modal-cancel" onclick="closeOtpModal()">Cancel</button>
            <button class="btn btn-modal-submit" onclick="submitOtpVerification()">Verify & Start Trip</button>
        </div>
    </div>
</div>

<script>
const hiddenBookings = new Set();

function fetchLiveBookings() {
    fetch('fetch_live_bookings.php')
        .then(response => response.json())
        .then(data => {
            const container = document.getElementById('booking-stream-desk');
            const visibleData = data.filter(booking => !hiddenBookings.has(booking.id));
            
            if (visibleData.length === 0) {
                container.innerHTML = '<div class="no-data">No unassigned active trip alerts matching your location profile right now.</div>';
                return;
            }
            
            let cardHTML = '';
            visibleData.forEach(booking => {
                cardHTML += `
                    <div class="booking-card" id="card-${booking.id}">
                        <div class="card-header">
                            <span class="ref-txt"><i class="fa-solid fa-hashtag"></i> ${booking.booking_ref_no}</span>
                            <span class="fare-txt" title="Your collection amount">₹${parseFloat(booking.driver_balance).toFixed(2)}</span>
                        </div>
                        <div class="route-row" style="color: #4f46e5; font-weight: 600;">
                            <i class="fa-solid fa-car"></i>
                            <span>${booking.car_type} (${booking.trip_type})</span>
                        </div>
                        <div class="route-row">
                            <i class="fa-solid fa-user" style="color: var(--text-muted);"></i>
                            <span><strong>Customer:</strong> ${booking.customer_name}</span>
                        </div>
                        <div class="route-row">
                            <i class="fa-solid fa-location-dot" style="color: var(--danger);"></i>
                            <span><strong>Pickup:</strong> ${booking.pickup_location}</span>
                        </div>
                        <div class="route-row">
                            <i class="fa-solid fa-flag-checkered" style="color: var(--success);"></i>
                            <span><strong>Drop:</strong> ${booking.drop_location}</span>
                        </div>
                        <div class="route-row">
                            <i class="fa-solid fa-clock" style="color: var(--text-muted);"></i>
                            <span>${booking.pickup_date} @ ${booking.pickup_time}</span>
                        </div>
                        <div class="route-row" style="background: #f8fafc; padding: 6px; border-radius: 4px; font-size: 12px; margin-top: 8px;">
                            <i class="fa-solid fa-arrows-left-right" style="color: var(--text-muted);"></i>
                            <span>Distance: <strong>${booking.distance} KM</strong> &nbsp;|&nbsp; <i class="fa-solid fa-hand-holding-dollar" style="color: var(--success);"></i> Collect: <strong>₹${parseFloat(booking.driver_balance).toFixed(2)}</strong></span>
                        </div>
                        
                        <div class="action-tray">
                            <button class="btn btn-reject" onclick="rejectBooking(${booking.id})"><i class="fa-solid fa-xmark"></i> Reject</button>
                            <button class="btn btn-accept" onclick="openOtpModal(${booking.id})"><i class="fa-solid fa-taxi"></i> Accept</button>
                        </div>
                    </div>
                `;
            });
            container.innerHTML = cardHTML;
        })
        .catch(err => console.error("AJAX Fetch Intercept Failure:", err));
}

function triggerCompleteTrip(bookingId) {
    if (!confirm("Are you sure you want to mark this trip as completed?")) {
        return;
    }
    
    const payload = new URLSearchParams();
    payload.append('booking_id', bookingId);
    
    fetch('complete_trip.php', {
        method: 'POST',
        headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
        body: payload.toString()
    })
    .then(response => response.json())
    .then(result => {
        if (result.success) {
            alert('Trip status finalized! Returning to standby mode.');
            
            // HARD HARD RESET: Append timestamps parameter so browser renders database modifications instantly
            window.location.href = 'driver_dashboard.php?v=' + new Date().getTime();
        } else {
            alert('Operation Fault: ' + result.message);
        }
    })
    .catch(err => console.error("Completion request failure:", err));
}

function rejectBooking(bookingId) {
    hiddenBookings.add(bookingId);
    const element = document.getElementById(`card-${bookingId}`);
    if(element) {
        element.style.transition = 'all 0.3s ease';
        element.style.opacity = '0';
        element.style.transform = 'scale(0.9)';
        setTimeout(() => { fetchLiveBookings(); }, 300);
    }
}

function openOtpModal(bookingId) {
    document.getElementById('target_booking_id').value = bookingId;
    document.getElementById('otp_entry').value = '';
    document.getElementById('otpModal').style.display = 'flex';
    document.getElementById('otp_entry').focus();
}

function closeOtpModal() { document.getElementById('otpModal').style.display = 'none'; }

function submitOtpVerification() {
    const bookingId = document.getElementById('target_booking_id').value;
    const otpCode   = document.getElementById('otp_entry').value.trim();
    
    if(otpCode === '') {
        alert('Please specify the verification sequence code.');
        return;
    }
    
    const payload = new URLSearchParams();
    payload.append('booking_id', bookingId);
    payload.append('otp_code', otpCode);
    
    fetch('verify_trip_otp.php', {
        method: 'POST',
        headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
        body: payload.toString()
    })
    .then(response => response.json())
    .then(result => {
        if(result.success) {
            alert('Security Clear! Trip status verified and locked to your log.');
            closeOtpModal();
            window.location.href = 'driver_dashboard.php?v=' + new Date().getTime();
        } else {
            alert('Verification Fault: ' + result.message);
        }
    })
    .catch(err => console.error("Error updating system:", err));
}

fetchLiveBookings();
setInterval(fetchLiveBookings, 3000);
</script>
</body>
</html>
<?php 
$conn->close(); 
?>
