<?php
// Initialize database connection
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "ranjancab";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Database Connection Failed: " . $conn->connect_error);
}

// Get the booking reference number from the URL parameter
$booking_ref_no = isset($_GET['ref']) ? trim($_GET['ref']) : '';

$booking = null;

if (!empty($booking_ref_no)) {
    // Fetch booking details securely using a prepared statement
    $stmt = $conn->prepare("SELECT * FROM bookings WHERE booking_ref_no = ? LIMIT 1");
    $stmt->bind_param("s", $booking_ref_no);
    $stmt->execute();
    $result = $stmt->get_result();
    $booking = $result->fetch_assoc();
    $stmt->close();
}

// If no valid booking is found, redirect them back to the home page
if (!$booking) {
    header("Location: index.php");
    exit();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Booking Confirmed | RanjanCabs</title>
    <link rel="stylesheet" href="style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        .confirmation-container {
            max-width: 600px;
            margin: 120px auto 40px auto;
            padding: 20px;
        }
        .success-card {
            background: #ffffff;
            border-radius: 8px;
            padding: 40px 30px;
            text-align: center;
            box-shadow: 0 10px 30px rgba(0,0,0,0.1);
        }
        .success-icon {
            font-size: 64px;
            color: #22c55e;
            margin-bottom: 20px;
        }
        .success-card h1 {
            color: var(--secondary-color);
            font-size: 28px;
            margin-bottom: 10px;
        }
        .ref-badge {
            display: inline-block;
            background: #f1f5f9;
            color: #334155;
            padding: 8px 16px;
            border-radius: 20px;
            font-weight: 700;
            font-size: 16px;
            margin-bottom: 30px;
            border: 1px solid #cbd5e1;
        }
        .summary-title {
            text-align: left;
            font-size: 16px;
            color: var(--secondary-color);
            margin-bottom: 15px;
            font-weight: 700;
            text-transform: uppercase;
            border-bottom: 2px solid var(--primary-color);
            padding-bottom: 5px;
        }
        .action-buttons {
            display: flex;
            gap: 15px;
            margin-top: 30px;
        }
        .btn-secondary {
            flex: 1;
            background-color: #f1f5f9;
            color: #334155;
            border: 1px solid #cbd5e1;
            padding: 14px;
            font-size: 15px;
            font-weight: 700;
            border-radius: 4px;
            text-decoration: none;
            text-transform: uppercase;
            transition: all var(--transition-speed);
        }
        .btn-secondary:hover {
            background-color: #e2e8f0;
        }
        .action-buttons .submit-btn {
            flex: 1;
            margin-top: 0;
            text-decoration: none;
            display: inline-block;
        }
    </style>
</head>
<body>

    <header class="navbar">
        <div class="nav-container">
            <div class="logo"><a href="index.php"><i class="fa-solid fa-taxi"></i> Ranjan<span>Cabs</span></a></div>
            <nav class="nav-menu" id="navMenu">
                <a href="index.php">Home</a>
                <a href="#">Our Fleet</a>
                <a href="#">Services</a>
                <a href="#">Contact</a>
            </nav>
            <div class="menu-toggle" id="mobileMenuBtn"><i class="fa-solid fa-bars"></i></div>
        </div>
    </header>

    <main class="confirmation-container">
        <div class="success-card">
            <div class="success-icon">
                <i class="fa-solid fa-circle-check"></i>
            </div>
            <h1>Ride Confirmed!</h1>
            <p style="color: #64748b; margin-bottom: 10px;">Thank you for choosing RanjanCabs. Your trip details are listed below.</p>
            <div class="ref-badge">REF NO: <?php echo htmlspecialchars($booking['booking_ref_no']); ?></div>

            <div class="summary-title">Trip Summary</div>
            <table class="review-table">
                <tr>
                    <td><strong>Customer Name:</strong></td>
                    <td><?php echo htmlspecialchars($booking['customer_name']); ?></td>
                </tr>
                <tr>
                    <td><strong>Phone Number:</strong></td>
                    <td><?php echo htmlspecialchars($booking['customer_phone']); ?></td>
                </tr>
                <tr>
                    <td><strong>Trip Type:</strong></td>
                    <td><span class="badge"><?php echo htmlspecialchars($booking['trip_type']); ?></span></td>
                </tr>
                <tr>
                    <td><strong>Pickup Point:</strong></td>
                    <td><?php echo htmlspecialchars($booking['pickup_location']); ?></td>
                </tr>
                <tr>
                    <td><strong>Drop Point:</strong></td>
                    <td><?php echo htmlspecialchars($booking['drop_location']); ?></td>
                </tr>
                <tr>
                    <td><strong>Date & Time:</strong></td>
                    <td><?php echo htmlspecialchars($booking['pickup_date']) . ' at ' . htmlspecialchars($booking['pickup_time']); ?></td>
                </tr>
                <?php if (!empty($booking['return_date'])): ?>
                <tr>
                    <td><strong>Return Date:</strong></td>
                    <td><?php echo htmlspecialchars($booking['return_date']); ?></td>
                </tr>
                <?php endif; ?>
                <tr>
                    <td><strong>Vehicle Class:</strong></td>
                    <td><?php echo htmlspecialchars($booking['car_type']); ?></td>
                </tr>
                <tr class="highlight-row">
                    <td><strong>Total Estimated Fare:</strong></td>
                    <td><strong>₹<?php echo htmlspecialchars($booking['total_fare']); ?></strong></td>
                </tr>
            </table>

            <div class="payment-split-box" style="text-align: left;">
                <h3><i class="fa-solid fa-wallet"></i> Payment Split Details</h3>
                <div class="split-row">
                    <span>Advance Amount Paid:</span>
                    <span class="price-tag">₹<?php echo htmlspecialchars($booking['advance_paid']); ?></span>
                </div>
                <div class="split-row">
                    <span>Remaining Balance to Driver:</span>
                    <span class="price-tag gray">₹<?php echo htmlspecialchars($booking['driver_balance']); ?></span>
                </div>
            </div>

            <div class="account-credential-banner" style="text-align: left; margin-top: 20px;">
                <h4><i class="fa-solid fa-shield-halved"></i> Secure Ride Verification</h4>
                <p style="font-size: 13px; color: #0d47a1;">Please share this secure OTP code with your driver only at the time of pickup to start your trip:</p>
                <div style="font-size: 22px; font-weight: 800; color: #0d47a1; letter-spacing: 2px; margin-top: 8px; text-align: center;">
                    <?php echo htmlspecialchars($booking['otp_code']); ?>
                </div>
            </div>

            <div class="action-buttons">
                <a href="index.php" class="btn-secondary">Back to Home</a>
                <a href="#" onclick="window.print(); return false;" class="submit-btn" style="text-align: center; line-height: 18px;">Print Receipt</a>
            </div>
        </div>
    </main>

    <script>
        const mobileMenuBtn = document.getElementById('mobileMenuBtn');
        const navMenu = document.getElementById('navMenu');
        mobileMenuBtn.addEventListener('click', () => { navMenu.classList.toggle('active'); });
    </script>
</body>
</html>
<?php $conn->close(); ?>