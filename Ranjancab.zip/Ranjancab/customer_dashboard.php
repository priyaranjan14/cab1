<?php
session_start();

// Strict Session Guard: Protect customer data layout matrix
if (!isset($_SESSION['customer_id']) || !isset($_SESSION['customer_phone'])) {
    header("Location: customer_login.php");
    exit();
}

$customer_id    = $_SESSION['customer_id'];
$customer_name  = $_SESSION['customer_name'];
$customer_phone = $_SESSION['customer_phone'];

$conn = new mysqli("localhost", "root", "", "ranjancab");
if ($conn->connect_error) {
    die("Database engine connectivity failure: " . $conn->connect_error);
}

// 1. Fetch Active/Live Bookings (booking_flag = 1 [Broadcast/Assigned] or 2 [In Transit])
// FIXED: Changed b.mobile_number to b.customer_phone to match database schema
$active_sql = "SELECT b.*, f.driver_name, f.vehicle_number, f.model_name, f.star_rating 
               FROM bookings b 
               LEFT JOIN fleet f ON b.assigned_driver_id = f.id 
               WHERE b.customer_phone = ? AND b.booking_flag IN (1, 2) 
               ORDER BY b.id DESC LIMIT 1";

$active_stmt = $conn->prepare($active_sql);
$active_stmt->bind_param("s", $customer_phone);
$active_stmt->execute();
$active_booking = $active_stmt->get_result()->fetch_assoc();
$active_stmt->close();

// 2. Fetch Past Bookings History Matrix (booking_flag = 3 [Completed] or -1 [Cancelled/Failed])
// FIXED: Changed b.mobile_number to b.customer_phone to match database schema
$history_sql = "SELECT b.*, f.driver_name, f.vehicle_number 
                 FROM bookings b 
                 LEFT JOIN fleet f ON b.assigned_driver_id = f.id 
                 WHERE b.customer_phone = ? AND b.booking_flag IN (3, -1) 
                 ORDER BY b.id DESC";

$history_stmt = $conn->prepare($history_sql);
$history_stmt->bind_param("s", $customer_phone);
$history_stmt->execute();
$past_bookings = $history_stmt->get_result();
$history_stmt->close();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Customer Dashboard - RanjanCabs</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        :root { --primary: #2c3e50; --accent: #f1c40f; --success: #2ecc71; --info: #3498db; --danger: #e74c3c; --bg: #f4f6f9; --card-bg: #ffffff; --text-main: #333333; }
        * { box-sizing: border-box; margin: 0; padding: 0; font-family: 'Segoe UI', sans-serif; }
        body { background-color: var(--bg); color: var(--text-main); padding: 15px; }
        .container { max-width: 1200px; margin: 0 auto; }
        
        header { background-color: var(--primary); color: white; padding: 20px; border-radius: 8px; margin-bottom: 25px; display: flex; justify-content: space-between; align-items: center; flex-wrap: wrap; gap: 15px; }
        header h1 span { color: var(--accent); }
        .logout-btn { display: inline-block; background: rgba(255,255,255,0.15); color: white; text-decoration: none; padding: 8px 15px; border-radius: 4px; font-size: 13px; font-weight: bold; margin-top: 5px; transition: background 0.2s; }
        .logout-btn:hover { background: var(--danger); }
        
        .dashboard-grid { display: grid; grid-template-columns: 1fr; gap: 25px; }
        .card { background: var(--card-bg); border-radius: 8px; padding: 20px; box-shadow: 0 2px 4px rgba(0,0,0,0.05); }
        .card-title { font-size: 18px; font-weight: bold; margin-bottom: 15px; border-bottom: 2px solid #eee; padding-bottom: 8px; color: var(--primary); display: flex; align-items: center; gap: 10px; }
        
        .badge { padding: 4px 8px; border-radius: 4px; font-weight: bold; font-size: 11px; display: inline-block; margin-top: 5px; }
        .badge-broadcast { background-color: #fff3cd; color: #856404; }
        .badge-assigned { background-color: #d1ecf1; color: #0c5460; }
        .badge-transit { background-color: #d4edda; color: #155724; }
        .badge-completed { background-color: #e2e3e5; color: #383d41; }
        .badge-cancelled { background-color: #f8d7da; color: #721c24; }
        
        /* Mobile-responsive grid auto-breaks into single rows on smaller viewpoints */
        .active-layout { display: grid; grid-template-columns: repeat(auto-fit, minmax(250px, 1fr)); gap: 20px; margin-top: 15px; }
        .info-group { margin-bottom: 12px; }
        .info-group strong { display: block; font-size: 11px; color: #777; text-transform: uppercase; margin-bottom: 2px; }
        .info-group p { font-size: 14.5px; line-height: 1.4; }
        
        .otp-box { background: #e8f4fd; border: 1px dashed var(--info); padding: 15px; border-radius: 6px; text-align: center; margin-top: 10px; }
        .otp-code { font-size: 26px; font-weight: bold; letter-spacing: 3px; color: var(--info); }
        .driver-profile { display: flex; align-items: center; gap: 12px; background: #f8f9fa; padding: 12px; border-radius: 6px; border-left: 4px solid var(--success); margin-bottom: 10px; }
        
        /* Smooth table wrap configuration preventing screen clipping */
        .table-responsive { width: 100%; overflow-x: auto; -webkit-overflow-scrolling: touch; margin-top: 10px; }
        table { width: 100%; border-collapse: collapse; min-width: 600px; }
        table th, table td { padding: 12px; border-bottom: 1px solid #e2e8f0; font-size: 14px; text-align: left; }
        table th { background-color: #f8f9fa; color: #555; }

        /* Responsive Breakpoints */
        @media (max-width: 600px) {
            header { flex-direction: column; text-align: center; }
            header div style { text-align: center !important; }
            .active-layout { grid-template-columns: 1fr; }
        }
    </style>
</head>
<body>

<div class="container">
    <header>
        <div>
            <h1>Ranjan<span>Cabs</span></h1>
            <p>Welcome back, <strong><?= htmlspecialchars($customer_name) ?></strong></p>
        </div>
        <div style="text-align: right;">
            <p><i class="fa-solid fa-phone"></i> <?= htmlspecialchars($customer_phone) ?></p>
            <p><a href="customer_logout.php" class="logout-btn">Log Out</a></p>
        </div>
    </header>

    <div class="dashboard-grid">
        
        <div class="card">
            <div class="card-title"><i class="fa-solid fa-satellite-dish" style="color: var(--info);"></i> Current Trip Monitor</div>
            <?php if (!$active_booking): ?>
                <p style="color:#888; text-align:center; padding:30px; font-style: italic;">You do not have any active trip bookings right now.</p>
            <?php else: ?>
                <div style="background: #f8fafc; padding: 10px 15px; border-radius: 6px; display: flex; justify-content: space-between; align-items: center; flex-wrap: wrap; gap: 10px;">
                    <div><strong>Ref No:</strong> <span style="font-family: monospace; font-weight: bold; font-size: 15px;"><?= htmlspecialchars($active_booking['booking_ref_no']) ?></span></div>
                    <div>
                        <?php if ($active_booking['booking_flag'] == 1 && empty($active_booking['assigned_driver_id'])): ?>
                            <span class="badge badge-broadcast"><i class="fa-solid fa-spinner fa-spin"></i> Finding Your Pilot...</span>
                        <?php elseif ($active_booking['booking_flag'] == 1 && !empty($active_booking['assigned_driver_id'])): ?>
                            <span class="badge badge-assigned"><i class="fa-solid fa-car-side"></i> Driver Dispatched</span>
                        <?php elseif ($active_booking['booking_flag'] == 2): ?>
                            <span class="badge badge-transit"><i class="fa-solid fa-street-view"></i> On Trip</span>
                        <?php endif; ?>
                    </div>
                </div>

                <div class="active-layout">
                    <div>
                        <div class="info-group"><strong>From</strong><p><?= htmlspecialchars($active_booking['pickup_location']) ?></p></div>
                        <div class="info-group"><strong>To</strong><p><?= htmlspecialchars($active_booking['drop_location']) ?></p></div>
                        <div class="info-group"><strong>Pickup Schedule</strong><p><?= htmlspecialchars($active_booking['pickup_date']) ?> @ <?= htmlspecialchars($active_booking['pickup_time']) ?></p></div>
                    </div>
                    <div>
                        <div class="info-group"><strong>Distance</strong><p><?= htmlspecialchars($active_booking['distance']) ?> KM</p></div>
                        <div class="info-group"><strong>Advance Paid</strong><p>₹<?= htmlspecialchars($active_booking['advance_paid']) ?></p></div>
                        <div class="info-group"><strong>Collectible Cash by Driver</strong><p style="color:var(--success); font-weight:bold; font-size:20px;">₹<?= htmlspecialchars($active_booking['driver_balance']) ?></p></div>
                    </div>
                    <div>
                        <?php if (!empty($active_booking['assigned_driver_id'])): ?>
                            <div class="driver-profile">
                                <div>
                                    <strong style="font-size: 11px; color: #666; text-transform: uppercase;">Assigned Pilot</strong>
                                    <p style="font-weight:bold; color: var(--primary); margin-top: 2px;"><i class="fa-solid fa-user-tie"></i> <?= htmlspecialchars($active_booking['driver_name']) ?></p>
                                    <p style="font-size:12px; font-family:monospace; color:#555; margin-top: 2px; background: #e2e8f0; padding: 2px 6px; border-radius: 4px; display: inline-block;"><?= htmlspecialchars($active_booking['vehicle_number']) ?></p>
                                    <p style="font-size:12px; color:#666; margin-top: 2px;"><?= htmlspecialchars($active_booking['model_name']) ?></p>
                                </div>
                            </div>
                        <?php endif; ?>
                        <div class="otp-box">
                            <strong>Trip Verification OTP</strong>
                            <div class="otp-code"><?= htmlspecialchars($active_booking['otp_code']) ?></div>
                        </div>
                    </div>
                </div>
            <?php endif; ?>
        </div>

        <div class="card">
            <div class="card-title"><i class="fa-solid fa-clock-rotate-left"></i> Ride History</div>
            <div class="table-responsive">
                <?php if ($past_bookings->num_rows === 0): ?>
                    <p style="color: #888; padding: 30px; text-align:center; font-style: italic;">No past trip logs records found.</p>
                <?php else: ?>
                    <table>
                        <thead>
                            <tr>
                                <th>Ref No.</th>
                                <th>Schedule Date</th>
                                <th>Route Summary</th>
                                <th>Vehicle Class</th>
                                <th>Total Fare</th>
                                <th>Status</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php while ($row = $past_bookings->fetch_assoc()): ?>
                                <tr>
                                    <td style="font-family: monospace; font-weight: bold; color: var(--primary);"><?= htmlspecialchars($row['booking_ref_no']) ?></td>
                                    <td><?= htmlspecialchars($row['pickup_date']) ?></td>
                                    <td><?= htmlspecialchars($row['pickup_location']) ?> ➔ <?= htmlspecialchars($row['drop_location']) ?></td>
                                    <td><?= htmlspecialchars($row['car_type']) ?></td>
                                    <td style="font-weight: bold;">₹<?= htmlspecialchars($row['total_fare']) ?></td>
                                    <td>
                                        <?= ($row['booking_flag'] == 3) ? '<span class="badge badge-completed">Completed</span>' : '<span class="badge badge-cancelled">Cancelled</span>' ?>
                                    </td>
                                </tr>
                            <?php endwhile; ?>
                        </tbody>
                    </table>
                <?php endif; ?>
            </div>
        </div>

    </div>
</div>

</body>
</html>
<?php $conn->close(); ?>