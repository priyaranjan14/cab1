<?php
session_start();

if (!isset($_SESSION['customer_id']) || !isset($_SESSION['customer_phone'])) {
    header("Location: customer_login.php");
    exit();
}

$customer_name  = $_SESSION['customer_name'];
$customer_phone = $_SESSION['customer_phone'];
$success_msg = "";
$error_msg = "";

$conn = new mysqli("localhost", "root", "", "ranjancab");
if ($conn->connect_error) {
    die("Database engine connectivity failure: " . $conn->connect_error);
}
$conn->set_charset("utf8mb4");

if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['action'] ?? '') === 'cancel_current_booking') {
    $booking_id = intval($_POST['booking_id'] ?? 0);
    $reason = trim($_POST['cancellation_reason'] ?? 'Cancelled by customer');
    if ($reason === '') {
        $reason = 'Cancelled by customer';
    }

    try {
        $conn->begin_transaction();

        $fetch_stmt = $conn->prepare("
            SELECT *
            FROM bookings
            WHERE id = ? AND customer_phone = ? AND booking_flag IN (1, 2)
            LIMIT 1
        ");
        $fetch_stmt->bind_param("is", $booking_id, $customer_phone);
        $fetch_stmt->execute();
        $booking = $fetch_stmt->get_result()->fetch_assoc();
        $fetch_stmt->close();

        if (!$booking) {
            throw new Exception("This booking is no longer available for cancellation.");
        }

        $disc_fare = floatval($booking['discounted_fare'] ?: $booking['total_fare']);
        $adv_paid  = floatval($booking['advance_paid'] ?? 0);
        $cpn_code  = $booking['coupon_code'] ?? null;

        $cancel_stmt = $conn->prepare("
            INSERT INTO cancelled_bookings
                (booking_id, booking_ref_no, customer_name, customer_phone, pickup_location, drop_location,
                 pickup_date, pickup_time, car_type, total_fare, discounted_fare, advance_paid, coupon_code,
                 assigned_driver_id, cancelled_by, cancellation_reason)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'Customer', ?)
        ");
        $cancel_stmt->bind_param(
            "issssssssdddsis",
            $booking['id'],
            $booking['booking_ref_no'],
            $booking['customer_name'],
            $booking['customer_phone'],
            $booking['pickup_location'],
            $booking['drop_location'],
            $booking['pickup_date'],
            $booking['pickup_time'],
            $booking['car_type'],
            $booking['total_fare'],
            $disc_fare,
            $adv_paid,
            $cpn_code,
            $booking['assigned_driver_id'],
            $reason
        );
        $cancel_stmt->execute();
        $cancel_stmt->close();

        $delete_stmt = $conn->prepare("DELETE FROM bookings WHERE id = ?");
        $delete_stmt->bind_param("i", $booking_id);
        $delete_stmt->execute();
        $delete_stmt->close();

        $conn->commit();
        $success_msg = "Your booking has been cancelled and moved to ride history.";
    } catch (Exception $e) {
        $conn->rollback();
        $error_msg = $e->getMessage();
    }
}

$active_sql = "
    SELECT b.id, b.booking_ref_no, b.trip_type, b.pickup_location, b.drop_location,
           b.pickup_date, b.pickup_time, b.car_type, b.distance, b.total_fare,
           b.discounted_fare, b.advance_paid, b.driver_balance,
           b.coupon_code, b.coupon_discount, b.otp_code, b.booking_flag,
           b.assigned_driver_id,
           f.driver_name, f.mobile_number AS driver_phone, f.vehicle_number, f.model_name, f.star_rating
    FROM bookings b
    LEFT JOIN fleet f ON b.assigned_driver_id = f.id
    WHERE b.customer_phone = ? AND b.booking_flag IN (1, 2)
    ORDER BY b.id DESC
    LIMIT 1
";
$active_stmt = $conn->prepare($active_sql);
$active_stmt->bind_param("s", $customer_phone);
$active_stmt->execute();
$active_booking = $active_stmt->get_result()->fetch_assoc();
$active_stmt->close();

$history_sql = "
    SELECT
        'booking' AS record_source,
        b.id,
        b.booking_ref_no,
        b.trip_type,
        b.pickup_location,
        b.drop_location,
        b.pickup_date,
        b.pickup_time,
        b.car_type,
        b.distance,
        b.total_fare,
        b.discounted_fare,
        b.coupon_code,
        b.coupon_discount,
        b.advance_paid,
        b.driver_balance,
        b.booking_flag,
        b.created_at AS record_date,
        f.driver_name,
        f.vehicle_number,
        NULL AS cancelled_by,
        NULL AS cancellation_reason
    FROM bookings b
    LEFT JOIN fleet f ON b.assigned_driver_id = f.id
    WHERE b.customer_phone = ? AND b.booking_flag IN (3, -1)

    UNION ALL

    SELECT
        'cancelled' AS record_source,
        cb.id,
        cb.booking_ref_no,
        'Oneway' AS trip_type,
        cb.pickup_location,
        cb.drop_location,
        cb.pickup_date,
        cb.pickup_time,
        cb.car_type,
        0 AS distance,
        cb.total_fare,
        cb.total_fare AS discounted_fare,
        NULL AS coupon_code,
        0 AS coupon_discount,
        0 AS advance_paid,
        cb.total_fare AS driver_balance,
        -1 AS booking_flag,
        cb.cancelled_at AS record_date,
        f.driver_name,
        f.vehicle_number,
        cb.cancelled_by,
        cb.cancellation_reason
    FROM cancelled_bookings cb
    LEFT JOIN fleet f ON cb.assigned_driver_id = f.id
    WHERE cb.customer_phone = ?

    ORDER BY record_date DESC
";
$history_stmt = $conn->prepare($history_sql);
$history_stmt->bind_param("ss", $customer_phone, $customer_phone);
$history_stmt->execute();
$past_bookings = $history_stmt->get_result();
$history_stmt->close();

$history_rows = [];
while ($row = $past_bookings->fetch_assoc()) {
    $history_rows[] = $row;
}

function money_fmt($amount) {
    return "Rs. " . number_format((float)$amount, 2);
}

function date_fmt($date) {
    if (!$date) {
        return "Not set";
    }
    return date("d M Y", strtotime($date));
}

function time_fmt($time) {
    if (!$time) {
        return "Not set";
    }
    return date("h:i A", strtotime($time));
}

function status_label($booking) {
    if (!$booking) {
        return ["No active ride", "muted", "fa-circle-info"];
    }
    if ((int)$booking['booking_flag'] === 2) {
        return ["On trip", "live", "fa-route"];
    }
    if (!empty($booking['assigned_driver_id'])) {
        return ["Driver assigned", "assigned", "fa-car-side"];
    }
    return ["Finding driver", "searching", "fa-spinner"];
}

$active_status = status_label($active_booking);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Customer Dashboard | RanjanCabs</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        :root {
            --ink: #172033;
            --muted: #64748b;
            --line: #dbe3ee;
            --surface: #ffffff;
            --soft: #f6f8fb;
            --brand: #f4b63f;
            --brand-dark: #1d2738;
            --success: #12805c;
            --info: #2563eb;
            --danger: #d92d20;
            --warning: #b7791f;
        }

        * { box-sizing: border-box; }
        body {
            margin: 0;
            font-family: "Segoe UI", Arial, sans-serif;
            color: var(--ink);
            background: #eef2f7;
        }
        .topbar {
            background: var(--brand-dark);
            color: #fff;
            padding: 18px 22px;
        }
        .topbar-inner {
            max-width: 1180px;
            margin: 0 auto;
            display: flex;
            justify-content: space-between;
            align-items: center;
            gap: 16px;
            flex-wrap: wrap;
        }
        .brand {
            font-weight: 800;
            font-size: 22px;
            letter-spacing: 0;
        }
        .brand span { color: var(--brand); }
        .profile-line {
            color: #cbd5e1;
            font-size: 13px;
            margin-top: 4px;
        }
        .logout-btn {
            color: #fff;
            text-decoration: none;
            background: rgba(255,255,255,0.12);
            border: 1px solid rgba(255,255,255,0.16);
            padding: 9px 13px;
            border-radius: 7px;
            font-size: 13px;
            font-weight: 700;
        }
        .wrap {
            max-width: 1180px;
            margin: 24px auto 42px;
            padding: 0 18px;
        }
        .notice {
            border-radius: 8px;
            padding: 12px 14px;
            margin-bottom: 16px;
            font-size: 14px;
            font-weight: 600;
        }
        .notice.success { background: #dcfce7; color: #166534; border: 1px solid #bbf7d0; }
        .notice.error { background: #fee2e2; color: #991b1b; border: 1px solid #fecaca; }
        .summary-grid {
            display: grid;
            grid-template-columns: repeat(4, minmax(0, 1fr));
            gap: 14px;
            margin-bottom: 18px;
        }
        .metric {
            background: var(--surface);
            border: 1px solid var(--line);
            border-radius: 8px;
            padding: 15px;
        }
        .metric small {
            display: block;
            color: var(--muted);
            font-size: 11px;
            font-weight: 800;
            text-transform: uppercase;
            margin-bottom: 8px;
        }
        .metric strong {
            font-size: 20px;
            display: block;
        }
        .panel {
            background: var(--surface);
            border: 1px solid var(--line);
            border-radius: 8px;
            overflow: hidden;
            margin-bottom: 18px;
            box-shadow: 0 8px 24px rgba(15, 23, 42, 0.04);
        }
        .panel-head {
            padding: 18px 20px;
            border-bottom: 1px solid var(--line);
            display: flex;
            align-items: center;
            justify-content: space-between;
            gap: 14px;
            flex-wrap: wrap;
            background: #fbfcfe;
        }
        .panel-title {
            display: flex;
            gap: 10px;
            align-items: center;
            font-weight: 800;
            font-size: 18px;
        }
        .badge {
            display: inline-flex;
            align-items: center;
            gap: 6px;
            padding: 7px 10px;
            border-radius: 999px;
            font-size: 12px;
            font-weight: 800;
        }
        .badge.searching { background: #fef3c7; color: var(--warning); }
        .badge.assigned { background: #dbeafe; color: var(--info); }
        .badge.live { background: #dcfce7; color: var(--success); }
        .badge.done { background: #e2e8f0; color: #334155; }
        .badge.cancelled { background: #fee2e2; color: var(--danger); }
        .panel-body { padding: 20px; }
        .empty-state {
            padding: 36px 20px;
            text-align: center;
            color: var(--muted);
            background: var(--soft);
            border-radius: 8px;
        }
        .ride-grid {
            display: grid;
            grid-template-columns: minmax(0, 1.5fr) minmax(260px, 0.9fr);
            gap: 18px;
        }
        .route-card {
            border: 1px solid var(--line);
            border-radius: 8px;
            padding: 18px;
            background: var(--soft);
        }
        .ref-line {
            display: flex;
            justify-content: space-between;
            gap: 10px;
            flex-wrap: wrap;
            margin-bottom: 18px;
        }
        .ref-code {
            font-family: Consolas, monospace;
            font-weight: 800;
            background: #172033;
            color: #fff;
            border-radius: 6px;
            padding: 6px 9px;
            font-size: 13px;
        }
        .route-step {
            display: grid;
            grid-template-columns: 24px 1fr;
            gap: 12px;
            margin-bottom: 14px;
        }
        .route-dot {
            width: 14px;
            height: 14px;
            border-radius: 50%;
            margin-top: 3px;
            background: var(--info);
        }
        .route-dot.drop { background: var(--danger); }
        .route-step small,
        .detail small {
            display: block;
            color: var(--muted);
            font-size: 11px;
            font-weight: 800;
            text-transform: uppercase;
            margin-bottom: 4px;
        }
        .route-step strong {
            font-size: 15px;
            line-height: 1.35;
        }
        .detail-grid {
            display: grid;
            grid-template-columns: repeat(3, minmax(0, 1fr));
            gap: 12px;
            margin-top: 18px;
        }
        .detail {
            background: #fff;
            border: 1px solid var(--line);
            border-radius: 8px;
            padding: 12px;
        }
        .detail strong { font-size: 15px; }
        .side-stack {
            display: grid;
            gap: 14px;
        }
        .otp-card {
            background: #172033;
            color: #fff;
            border-radius: 8px;
            padding: 18px;
            text-align: center;
        }
        .otp-card small {
            color: #cbd5e1;
            font-size: 11px;
            font-weight: 800;
            text-transform: uppercase;
        }
        .otp-code {
            font-size: 38px;
            letter-spacing: 8px;
            font-weight: 900;
            margin-top: 6px;
        }
        .driver-card {
            border: 1px solid var(--line);
            border-radius: 8px;
            padding: 16px;
        }
        .driver-name {
            font-size: 17px;
            font-weight: 800;
            margin: 8px 0 4px;
        }
        .action-row {
            display: flex;
            gap: 10px;
            flex-wrap: wrap;
            margin-top: 14px;
        }
        .btn {
            border: 0;
            border-radius: 7px;
            padding: 10px 13px;
            font-size: 13px;
            font-weight: 800;
            text-decoration: none;
            cursor: pointer;
            display: inline-flex;
            align-items: center;
            gap: 8px;
        }
        .btn-danger { background: var(--danger); color: #fff; }
        .btn-invoice { background: var(--brand-dark); color: #fff; }
        .cancel-form {
            border-top: 1px solid var(--line);
            margin-top: 16px;
            padding-top: 16px;
            display: grid;
            gap: 10px;
        }
        .cancel-form textarea {
            width: 100%;
            min-height: 76px;
            resize: vertical;
            border: 1px solid var(--line);
            border-radius: 7px;
            padding: 10px;
            font: inherit;
        }
        .history-list {
            display: grid;
            gap: 12px;
        }
        .history-item {
            border: 1px solid var(--line);
            border-radius: 8px;
            padding: 15px;
            display: grid;
            grid-template-columns: minmax(0, 1.4fr) minmax(180px, 0.6fr) auto;
            gap: 16px;
            align-items: center;
        }
        .history-route {
            font-weight: 800;
            margin: 6px 0;
            line-height: 1.35;
        }
        .history-meta {
            color: var(--muted);
            font-size: 13px;
            line-height: 1.55;
        }
        .fare {
            font-size: 20px;
            font-weight: 900;
        }
        @media (max-width: 900px) {
            .summary-grid { grid-template-columns: repeat(2, minmax(0, 1fr)); }
            .ride-grid { grid-template-columns: 1fr; }
            .history-item { grid-template-columns: 1fr; }
        }
        @media (max-width: 560px) {
            .summary-grid, .detail-grid { grid-template-columns: 1fr; }
            .otp-code { font-size: 32px; letter-spacing: 5px; }
            .panel-head { align-items: flex-start; }
        }
    </style>
</head>
<body>
    <header class="topbar">
        <div class="topbar-inner">
            <div>
                <div class="brand"><i class="fa-solid fa-taxi"></i> Ranjan<span>Cabs</span></div>
                <div class="profile-line">Welcome, <?= htmlspecialchars($customer_name) ?> &middot; <?= htmlspecialchars($customer_phone) ?></div>
            </div>
            <a href="customer_logout.php" class="logout-btn"><i class="fa-solid fa-right-from-bracket"></i> Log Out</a>
        </div>
    </header>

    <main class="wrap">
        <?php if ($success_msg): ?>
            <div class="notice success"><i class="fa-solid fa-circle-check"></i> <?= htmlspecialchars($success_msg) ?></div>
        <?php endif; ?>
        <?php if ($error_msg): ?>
            <div class="notice error"><i class="fa-solid fa-triangle-exclamation"></i> <?= htmlspecialchars($error_msg) ?></div>
        <?php endif; ?>

        <section class="summary-grid">
            <div class="metric">
                <small>Current Status</small>
                <strong><?= htmlspecialchars($active_status[0]) ?></strong>
            </div>
            <div class="metric">
                <small>Active Reference</small>
                <strong><?= $active_booking ? htmlspecialchars($active_booking['booking_ref_no']) : "None" ?></strong>
            </div>
            <div class="metric">
                <small>Ride History</small>
                <strong><?= count($history_rows) ?> Trips</strong>
            </div>
            <div class="metric">
                <small>Active Fare</small>
                <strong><?= $active_booking ? money_fmt($active_booking['discounted_fare'] ?? $active_booking['total_fare']) : "Rs. 0.00" ?></strong>
            </div>
        </section>

        <section class="panel">
            <div class="panel-head">
                <div class="panel-title"><i class="fa-solid fa-location-crosshairs"></i> Current Ride</div>
                <span class="badge <?= htmlspecialchars($active_status[1]) ?>">
                    <i class="fa-solid <?= htmlspecialchars($active_status[2]) ?> <?= $active_status[1] === 'searching' ? 'fa-spin' : '' ?>"></i>
                    <?= htmlspecialchars($active_status[0]) ?>
                </span>
            </div>
            <div class="panel-body">
                <?php if (!$active_booking): ?>
                    <div class="empty-state">
                        <i class="fa-solid fa-calendar-plus" style="font-size: 28px; margin-bottom: 10px;"></i>
                        <div>No current booking is active for this account.</div>
                    </div>
                <?php else: ?>
                    <div class="ride-grid">
                        <div class="route-card">
                            <div class="ref-line">
                                <div>
                                    <small style="color: var(--muted); font-weight: 800; text-transform: uppercase;">Booking Reference</small>
                                    <div class="ref-code"><?= htmlspecialchars($active_booking['booking_ref_no']) ?></div>
                                </div>
                                <div style="text-align: right;">
                                    <small style="color: var(--muted); font-weight: 800; text-transform: uppercase;">Trip Type</small>
                                    <div style="font-weight: 800;"><?= htmlspecialchars($active_booking['trip_type'] ?? 'Oneway') ?></div>
                                </div>
                            </div>

                            <div class="route-step">
                                <span class="route-dot"></span>
                                <div>
                                    <small>Pickup</small>
                                    <strong><?= htmlspecialchars($active_booking['pickup_location']) ?></strong>
                                </div>
                            </div>
                            <div class="route-step">
                                <span class="route-dot drop"></span>
                                <div>
                                    <small>Drop</small>
                                    <strong><?= htmlspecialchars($active_booking['drop_location']) ?></strong>
                                </div>
                            </div>

                            <div class="detail-grid">
                                <div class="detail">
                                    <small>Pickup Date</small>
                                    <strong><?= date_fmt($active_booking['pickup_date']) ?></strong>
                                </div>
                                <div class="detail">
                                    <small>Pickup Time</small>
                                    <strong><?= time_fmt($active_booking['pickup_time']) ?></strong>
                                </div>
                                <div class="detail">
                                    <small>Vehicle Class</small>
                                    <strong><?= htmlspecialchars($active_booking['car_type']) ?></strong>
                                </div>
                                <div class="detail">
                                    <small>Distance</small>
                                    <strong><?= number_format((float)$active_booking['distance'], 1) ?> km</strong>
                                </div>
                                <div class="detail">
                                    <small>Original Fare</small>
                                    <strong><?= money_fmt($active_booking['total_fare']) ?></strong>
                                </div>
                                <?php
                                $ab_disc = floatval($active_booking['discounted_fare'] ?? $active_booking['total_fare']);
                                $ab_cpn  = $active_booking['coupon_code'] ?? '';
                                $ab_cpnamt = floatval($active_booking['coupon_discount'] ?? 0);
                                ?>
                                <?php if ($ab_cpnamt > 0 && !empty($ab_cpn)): ?>
                                <div class="detail" style="background:#dcfce7;">
                                    <small>Coupon (<?= htmlspecialchars($ab_cpn) ?>)</small>
                                    <strong style="color:#16a34a;">- <?= money_fmt($ab_cpnamt) ?></strong>
                                </div>
                                <div class="detail" style="background:#eff6ff;">
                                    <small>Final Fare</small>
                                    <strong style="color:#0369a1;"><?= money_fmt($ab_disc) ?></strong>
                                </div>
                                <?php endif; ?>
                                <div class="detail">
                                    <small>Advance Paid (10%)</small>
                                    <strong><?= money_fmt($active_booking['advance_paid']) ?></strong>
                                </div>
                                <div class="detail">
                                    <small>Balance Due to Driver (90%)</small>
                                    <strong><?= money_fmt($active_booking['driver_balance']) ?></strong>
                                </div>
                            </div>
                        </div>

                        <aside class="side-stack">
                            <div class="otp-card">
                                <small>Trip Verification OTP</small>
                                <div class="otp-code"><?= htmlspecialchars($active_booking['otp_code']) ?></div>
                            </div>

                            <div class="driver-card">
                                <small style="color: var(--muted); font-weight: 800; text-transform: uppercase;">Assigned Driver</small>
                                <?php if (!empty($active_booking['assigned_driver_id'])): ?>
                                    <div class="driver-name"><i class="fa-solid fa-user-tie"></i> <?= htmlspecialchars($active_booking['driver_name']) ?></div>
                                    <div class="history-meta">
                                        <?= htmlspecialchars($active_booking['vehicle_number']) ?> &middot; <?= htmlspecialchars($active_booking['model_name']) ?><br>
                                        <?= htmlspecialchars($active_booking['driver_phone'] ?? '') ?><br>
                                        Rating: <?= htmlspecialchars($active_booking['star_rating'] ?? '5.00') ?>/5
                                    </div>
                                <?php else: ?>
                                    <div class="driver-name">Driver matching in progress</div>
                                    <div class="history-meta">Your request is visible to eligible drivers near the pickup station.</div>
                                <?php endif; ?>

                                <form method="POST" action="customer_dashboard.php" class="cancel-form" onsubmit="return confirm('Cancel this booking now?');">
                                    <input type="hidden" name="action" value="cancel_current_booking">
                                    <input type="hidden" name="booking_id" value="<?= intval($active_booking['id']) ?>">
                                    <textarea name="cancellation_reason" placeholder="Optional cancellation reason"></textarea>
                                    <button type="submit" class="btn btn-danger"><i class="fa-solid fa-ban"></i> Cancel Current Booking</button>
                                </form>
                            </div>
                        </aside>
                    </div>
                <?php endif; ?>
            </div>
        </section>

        <section class="panel">
            <div class="panel-head">
                <div class="panel-title"><i class="fa-solid fa-clock-rotate-left"></i> Past Rides</div>
                <span class="badge done"><?= count($history_rows) ?> Records</span>
            </div>
            <div class="panel-body">
                <?php if (count($history_rows) === 0): ?>
                    <div class="empty-state">No completed or cancelled rides found yet.</div>
                <?php else: ?>
                    <div class="history-list">
                        <?php foreach ($history_rows as $row): ?>
                            <?php $is_cancelled = $row['record_source'] === 'cancelled' || (int)$row['booking_flag'] !== 3; ?>
                            <article class="history-item">
                                <div>
                                    <span class="ref-code"><?= htmlspecialchars($row['booking_ref_no']) ?></span>
                                    <div class="history-route">
                                        <?= htmlspecialchars($row['pickup_location']) ?> <i class="fa-solid fa-arrow-right-long" style="color: var(--muted);"></i> <?= htmlspecialchars($row['drop_location']) ?>
                                    </div>
                                    <div class="history-meta">
                                        <?= date_fmt($row['pickup_date']) ?> at <?= time_fmt($row['pickup_time']) ?> &middot; <?= htmlspecialchars($row['car_type']) ?> &middot; <?= htmlspecialchars($row['trip_type']) ?><br>
                                        Driver: <?= htmlspecialchars($row['driver_name'] ?: 'Not assigned') ?> <?= $row['vehicle_number'] ? '(' . htmlspecialchars($row['vehicle_number']) . ')' : '' ?>
                                        <?php if ($is_cancelled && !empty($row['cancellation_reason'])): ?>
                                            <br>Reason: <?= htmlspecialchars($row['cancellation_reason']) ?>
                                        <?php endif; ?>
                                    </div>
                                </div>
                                <div>
                                    <?php
                                    $h_disc    = floatval($row['discounted_fare'] ?? $row['total_fare']);
                                    $h_cpnamt  = floatval($row['coupon_discount'] ?? 0);
                                    $h_cpn     = $row['coupon_code'] ?? '';
                                    ?>
                                    <div class="fare"><?= money_fmt($h_disc) ?></div>
                                    <?php if ($h_cpnamt > 0 && !empty($h_cpn)): ?>
                                    <div style="font-size:11px; color:#16a34a; font-weight:700;">Coupon <?= htmlspecialchars($h_cpn) ?>: -<?= money_fmt($h_cpnamt) ?></div>
                                    <?php endif; ?>
                                    <div style="font-size:11px; color:var(--muted); margin-top:2px;">Advance: <?= money_fmt($row['advance_paid']) ?> | Bal: <?= money_fmt($row['driver_balance']) ?></div>
                                    <div style="margin-top: 8px;">
                                        <?php if ($is_cancelled): ?>
                                            <span class="badge cancelled"><i class="fa-solid fa-circle-xmark"></i> Cancelled</span>
                                        <?php else: ?>
                                            <span class="badge done"><i class="fa-solid fa-circle-check"></i> Completed</span>
                                        <?php endif; ?>
                                    </div>
                                </div>
                                <div style="display:flex; flex-direction:column; gap:8px;">
                                    <a class="btn btn-invoice" href="generate_invoice.php?ref=<?= urlencode($row['booking_ref_no']) ?>" target="_blank">
                                        <i class="fa-solid fa-file-arrow-down"></i> Download Invoice
                                    </a>
                                    <a class="btn btn-invoice" href="generate_invoice.php?ref=<?= urlencode($row['booking_ref_no']) ?>" target="_blank" style="background:#16a34a;">
                                        <i class="fa-solid fa-receipt"></i> Payment Receipt
                                    </a>
                                </div>
                            </article>
                        <?php endforeach; ?>
                    </div>
                <?php endif; ?>
            </div>
        </section>
    </main>
</body>
</html>
<?php $conn->close(); ?>
