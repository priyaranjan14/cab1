<?php
session_start();
header('Content-Type: application/json');

if (!isset($_SESSION['driver_id'])) {
    echo json_encode(['success' => false, 'message' => 'Session Timeout. Re-authenticate profile workspace.']);
    exit();
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo json_encode(['success' => false, 'message' => 'Invalid Request Execution Frame.']);
    exit();
}

$driver_id  = intval($_SESSION['driver_id']);
$booking_id = isset($_POST['booking_id']) ? intval($_POST['booking_id']) : 0;
$otp_code   = isset($_POST['otp_code']) ? trim($_POST['otp_code']) : '';

$conn = new mysqli("localhost", "root", "", "ranjancab");
if ($conn->connect_error) {
    echo json_encode(['success' => false, 'message' => 'Database Engine Communication Failure.']);
    exit();
}

// 1. Structural cross-verification match check
$check_sql = "SELECT otp_code, booking_flag, assigned_driver_id FROM bookings WHERE id = ? LIMIT 1";
$stmt = $conn->prepare($check_sql);
$stmt->bind_param("i", $booking_id);
$stmt->execute();
$booking = $stmt->get_result()->fetch_assoc();
$stmt->close();

if (!$booking) {
    echo json_encode(['success' => false, 'message' => 'Target reservation ID data model not found.']);
    $conn->close();
    exit();
}

// 2. State Validation Pipeline Checks
if ($booking['assigned_driver_id'] !== NULL) {
    echo json_encode(['success' => false, 'message' => 'This request was already accepted by another driver.']);
    $conn->close();
    exit();
}

if ($booking['otp_code'] !== $otp_code) {
    echo json_encode(['success' => false, 'message' => 'The provided OTP code does not match our records. Please verify with passenger.']);
    $conn->close();
    exit();
}

// 3. Atomically claim trip and change state status flag (e.g., set booking_flag to 2 for an active trip)
$update_sql = "UPDATE bookings SET assigned_driver_id = ?, booking_flag = 2 WHERE id = ? AND assigned_driver_id IS NULL";
$u_stmt = $conn->prepare($update_sql);
$u_stmt->bind_param("ii", $driver_id, $booking_id);
$u_stmt->execute();

if ($u_stmt->affected_rows > 0) {
    echo json_encode(['success' => true, 'message' => 'Trip started successfully.']);
} else {
    echo json_encode(['success' => false, 'message' => 'Race Condition Conflict: Order state updated mid-flight.']);
}

$u_stmt->close();
$conn->close();
exit();
?>