<?php
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $conn = new mysqli("localhost", "root", "", "ranjancab");
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }
    
    $stmt = $conn->prepare("INSERT INTO fleet (driver_name, mobile_number, vehicle_number, model_name, car_type, base_station, password) VALUES (?, ?, ?, ?, ?, ?, ?)");
    
    // Hash a default password for the new driver
    $default_pass = password_hash("Default123", PASSWORD_DEFAULT);
    
    $stmt->bind_param("sssssss", 
        $_POST['driver_name'], 
        $_POST['mobile_number'], 
        $_POST['vehicle_number'], 
        $_POST['model_name'], 
        $_POST['car_type'], 
        $_POST['base_station'],
        $default_pass
    );

    if ($stmt->execute()) {
        // Redirect to your newly styled success page
        header("Location: registration_success.php");
        exit();
    } else {
        echo "Error: " . $stmt->error;
    }
    
    $stmt->close();
    $conn->close();
}
?>