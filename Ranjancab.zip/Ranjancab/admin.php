<?php
session_start();

// Redirect to login if not authenticated
if (!isset($_SESSION['admin_logged_in']) || $_SESSION['admin_logged_in'] !== true) {
    header("Location: admin_login.php");
    exit();
}

// Database Connection
$conn = new mysqli("localhost", "root", "", "ranjancab");
if ($conn->connect_error) {
    die("<div style='padding:24px;font-family:sans-serif;color:red;'>Database connection failed: " . htmlspecialchars($conn->connect_error) . "</div>");
}
$conn->set_charset("utf8mb4");

// ==========================================================================
// CENTRAL PROCESSING ENGINE: ONE-POINT STATE MUTATIONS (POST ACTIONS)
// ==========================================================================
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action'])) {
    
    // ACTION A: MANUALLY ALLOCATE UNASSIGNED / ACTIVE CAB LINE
    if ($_POST['action'] === 'allocate_cab') {
        $booking_id = intval($_POST['booking_id']);
        $driver_id  = intval($_POST['driver_id']);
        $stmt = $conn->prepare("UPDATE bookings SET assigned_driver_id = ? WHERE id = ?");
        $stmt->bind_param("ii", $driver_id, $booking_id);
        $stmt->execute();
        header("Location: admin.php?status=allocated&tab=live-ops"); exit;
    }

    // ACTION B: MARK ACTIVE TRANSIT RIDE AS COMPLETED
    if ($_POST['action'] === 'complete_booking') {
        $booking_id = intval($_POST['booking_id']);
        $stmt = $conn->prepare("UPDATE bookings SET booking_flag = 3 WHERE id = ?");
        $stmt->bind_param("i", $booking_id);
        $stmt->execute();
        header("Location: admin.php?status=completed&tab=live-ops"); exit;
    }

    // ACTION C: INTERCEPT AND CANCEL LIVE BOOKING
    if ($_POST['action'] === 'cancel_booking') {
        $booking_id = intval($_POST['booking_id']);
        $reason     = !empty($_POST['reason']) ? $_POST['reason'] : 'Terminated by Administration';

        $fetch_stmt = $conn->prepare("SELECT * FROM bookings WHERE id = ?");
        $fetch_stmt->bind_param("i", $booking_id);
        $fetch_stmt->execute();
        $booking = $fetch_stmt->get_result()->fetch_assoc();

        if ($booking) {
            $disc_fare = floatval($booking['discounted_fare'] ?? $booking['total_fare']);
            $adv_paid  = floatval($booking['advance_paid'] ?? 0);
            $cpn_code  = $booking['coupon_code'] ?? null;

            $cancel_stmt = $conn->prepare("
                INSERT INTO cancelled_bookings
                (booking_id, booking_ref_no, customer_name, customer_phone, pickup_location, drop_location,
                 pickup_date, pickup_time, car_type, total_fare, discounted_fare, advance_paid, coupon_code,
                 assigned_driver_id, cancelled_by, cancellation_reason)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'Admin', ?)
            ");
            $cancel_stmt->bind_param(
                "issssssssdddsis",
                $booking['id'], $booking['booking_ref_no'], $booking['customer_name'], $booking['customer_phone'],
                $booking['pickup_location'], $booking['drop_location'], $booking['pickup_date'], $booking['pickup_time'],
                $booking['car_type'], $booking['total_fare'], $disc_fare, $adv_paid, $cpn_code,
                $booking['assigned_driver_id'], $reason
            );
            $cancel_stmt->execute();

            $delete_stmt = $conn->prepare("DELETE FROM bookings WHERE id = ?");
            $delete_stmt->bind_param("i", $booking_id);
            $delete_stmt->execute();
        }
        // Check which tab the cancel came from (live-ops or bookings)
        $from_tab = in_array($_POST['from_tab'] ?? '', ['live-ops','bookings']) ? $_POST['from_tab'] : 'live-ops';
        header("Location: admin.php?status=cancelled&tab=" . $from_tab); exit;
    }

    // ACTION D: TOGGLE DRIVER STATUS
    if ($_POST['action'] === 'toggle_fleet') {
        $driver_id  = intval($_POST['driver_id']);
        $new_status = ($_POST['target_status'] === 'Active') ? 'Active' : 'Inactive';
        $stmt = $conn->prepare("UPDATE fleet SET status = ? WHERE id = ?");
        $stmt->bind_param("si", $new_status, $driver_id);
        $stmt->execute();
        header("Location: admin.php?status=fleet_updated&tab=fleet"); exit;
    }

    // ACTION E: ADD NEW DRIVER
    if ($_POST['action'] === 'add_fleet') {
        $driver_name       = trim($_POST['driver_name']);
        $mobile_number     = trim($_POST['mobile_number']);
        $vehicle_number    = strtoupper(trim($_POST['vehicle_number']));
        $model_name        = trim($_POST['model_name']);
        $car_type          = trim($_POST['car_type']);
        $base_station      = trim($_POST['base_station']);
        $driver_license_no = trim($_POST['driver_license_no'] ?? '');
        $aadhaar_no        = preg_replace('/\s+/', '', trim($_POST['aadhaar_no'] ?? ''));
        $password          = trim($_POST['password'] ?? '');
        if ($password === '') {
            $name_parts = preg_split('/\s+/', $driver_name);
            $password   = end($name_parts) ?: $mobile_number;
        }
        $stmt = $conn->prepare("
            INSERT INTO fleet
                (driver_name, mobile_number, password, is_first_login, vehicle_number, model_name,
                 car_type, base_station, star_rating, rating, is_verified, status, driver_license_no, aadhaar_no)
            VALUES (?, ?, ?, 1, ?, ?, ?, ?, 5.00, 5.00, 0, 'Active', ?, ?)
        ");
        $stmt->bind_param("sssssssss",
            $driver_name, $mobile_number, $password,
            $vehicle_number, $model_name, $car_type, $base_station,
            $driver_license_no, $aadhaar_no
        );
        $stmt->execute();
        header("Location: admin.php?status=fleet_added&tab=fleet"); exit;
    }

    // ACTION F: VERIFY DRIVER DOCUMENTS
    if ($_POST['action'] === 'verify_driver_documents') {
        $driver_id = intval($_POST['driver_id']);
        $stmt = $conn->prepare("UPDATE fleet SET is_verified = 1 WHERE id = ?");
        $stmt->bind_param("i", $driver_id);
        $stmt->execute();
        header("Location: admin.php?status=driver_verified&tab=fleet"); exit;
    }

    // ACTION G: CREATE BLOG POST
    if ($_POST['action'] === 'create_blog') {
        $title     = trim($_POST['title']);
        $excerpt   = trim($_POST['excerpt']);
        $content   = trim($_POST['content']);
        $author    = trim($_POST['author'] ?: 'RanjanCabs Admin');
        $status    = ($_POST['status'] === 'draft') ? 'draft' : 'published';
        $base_slug = strtolower(trim(preg_replace('/[^a-z0-9]+/i', '-', $title), '-'));
        if ($base_slug === '') $base_slug = 'blog-post';
        $slug   = $base_slug;
        $suffix = 2;
        $slug_stmt = $conn->prepare("SELECT id FROM blogs WHERE slug = ? LIMIT 1");
        while (true) {
            $slug_stmt->bind_param("s", $slug);
            $slug_stmt->execute();
            if ($slug_stmt->get_result()->num_rows === 0) break;
            $slug = $base_slug . '-' . $suffix++;
        }
        $slug_stmt->close();
        $stmt = $conn->prepare("INSERT INTO blogs (title, slug, excerpt, content, author, status) VALUES (?, ?, ?, ?, ?, ?)");
        $stmt->bind_param("ssssss", $title, $slug, $excerpt, $content, $author, $status);
        $stmt->execute();
        header("Location: admin.php?status=blog_created&tab=blogs"); exit;
    }

    // ACTION H: DELETE BLOG POST
    if ($_POST['action'] === 'delete_blog') {
        $blog_id = intval($_POST['blog_id']);
        $stmt = $conn->prepare("DELETE FROM blogs WHERE id = ?");
        $stmt->bind_param("i", $blog_id);
        $stmt->execute();
        header("Location: admin.php?status=blog_deleted&tab=blogs"); exit;
    }

    // ACTION I: CREATE COUPON CODE
    if ($_POST['action'] === 'create_coupon') {
        $code             = strtoupper(trim($_POST['coupon_code'] ?? ''));
        $discount_percent = floatval($_POST['discount_percent'] ?? 10);
        $description      = trim($_POST['coupon_description'] ?? '');
        $max_usage        = intval($_POST['max_usage'] ?? 100);
        $valid_until      = !empty($_POST['valid_until']) ? trim($_POST['valid_until']) : null;
        $tbl = $conn->query("SHOW TABLES LIKE 'coupon_codes'");
        if ($tbl && $tbl->num_rows > 0 && !empty($code) && $discount_percent > 0) {
            $stmt = $conn->prepare("INSERT IGNORE INTO coupon_codes (code, discount_percent, description, max_usage, valid_until) VALUES (?, ?, ?, ?, ?)");
            $stmt->bind_param("sdsis", $code, $discount_percent, $description, $max_usage, $valid_until);
            $stmt->execute();
        }
        header("Location: admin.php?status=coupon_created&tab=coupons"); exit;
    }

    // ACTION J: TOGGLE COUPON STATUS
    if ($_POST['action'] === 'toggle_coupon') {
        $coupon_id  = intval($_POST['coupon_id']);
        $new_status = intval($_POST['new_status']);
        $tbl = $conn->query("SHOW TABLES LIKE 'coupon_codes'");
        if ($tbl && $tbl->num_rows > 0) {
            $stmt = $conn->prepare("UPDATE coupon_codes SET is_active = ? WHERE id = ?");
            $stmt->bind_param("ii", $new_status, $coupon_id);
            $stmt->execute();
        }
        header("Location: admin.php?status=coupon_updated&tab=coupons"); exit;
    }

    // ACTION K: DELETE COUPON CODE
    if ($_POST['action'] === 'delete_coupon') {
        $coupon_id = intval($_POST['coupon_id']);
        $tbl = $conn->query("SHOW TABLES LIKE 'coupon_codes'");
        if ($tbl && $tbl->num_rows > 0) {
            $stmt = $conn->prepare("DELETE FROM coupon_codes WHERE id = ?");
            $stmt->bind_param("i", $coupon_id);
            $stmt->execute();
        }
        header("Location: admin.php?status=coupon_deleted&tab=coupons"); exit;
    }

    // ACTION L: UPDATE PRICING
    if ($_POST['action'] === 'update_pricing') {
        $id                 = intval($_POST['id']);
        $rate_per_km        = floatval($_POST['rate_per_km']);
        $portal_charges     = floatval($_POST['portal_charges']);
        $advance_percentage = floatval($_POST['advance_percentage']);
        $stmt = $conn->prepare("UPDATE pricing_settings SET rate_per_km = ?, portal_charges = ?, advance_percentage = ? WHERE id = ?");
        $stmt->bind_param("dddi", $rate_per_km, $portal_charges, $advance_percentage, $id);
        $stmt->execute();
        header("Location: admin.php?status=pricing_updated&tab=tariffs"); exit;
    }

    // ACTION M: ADD ROUTE
    if ($_POST['action'] === 'add_route') {
        $stmt = $conn->prepare("INSERT INTO routes (pickup_point, drop_point, estimated_distance) VALUES (?, ?, ?)");
        $stmt->bind_param("ssd", $_POST['pickup_point'], $_POST['drop_point'], $_POST['estimated_distance']);
        $stmt->execute();
        header("Location: admin.php?status=route_added&tab=routes"); exit;
    }

    // ACTION N: DELETE ROUTE
    if ($_POST['action'] === 'delete_route') {
        $route_id = intval($_POST['route_id']);
        $stmt = $conn->prepare("DELETE FROM routes WHERE id = ?");
        $stmt->bind_param("i", $route_id);
        $stmt->execute();
        header("Location: admin.php?status=route_deleted&tab=routes"); exit;
    }
}

// ==========================================================================
// MASTER EXPOSURE DATA STREAMS (FETCH EVERYTHING)
// ==========================================================================
// Check if migration has been run
$migration_needed = false;
$tbl_check = $conn->query("SHOW TABLES LIKE 'coupon_codes'");
if (!$tbl_check || $tbl_check->num_rows === 0) {
    $migration_needed = true;
}

$bookings_result  = $conn->query("SELECT b.*, f.driver_name, f.vehicle_number FROM bookings b LEFT JOIN fleet f ON b.assigned_driver_id = f.id ORDER BY b.id DESC");
$cancelled_result = $conn->query("SELECT cb.*, f.driver_name, f.vehicle_number FROM cancelled_bookings cb LEFT JOIN fleet f ON cb.assigned_driver_id = f.id ORDER BY cb.id DESC");
$fleet_result     = $conn->query("SELECT * FROM fleet ORDER BY id DESC");
$pricing_result   = $conn->query("SELECT * FROM pricing_settings ORDER BY id ASC");
$routes_result    = $conn->query("SELECT * FROM routes ORDER BY id DESC");
$blogs_result     = $conn->query("SELECT * FROM blogs ORDER BY created_at DESC, id DESC");

// Safe fetch for coupons (table may not exist before migration)
$coupons_result = null;
if (!$migration_needed) {
    $coupons_result = $conn->query("SELECT * FROM coupon_codes ORDER BY id DESC");
}

$drivers_menu = [];
$drivers_fetch = $conn->query("SELECT id, driver_name, vehicle_number, car_type FROM fleet WHERE status IN ('Active', '1')");
while($d = $drivers_fetch->fetch_assoc()) { $drivers_menu[] = $d; }

$total_revenue      = $conn->query("SELECT SUM(total_fare) as total FROM bookings WHERE booking_flag = 3")->fetch_assoc()['total'] ?? 0;
$total_advance      = $conn->query("SELECT SUM(advance_paid) as total FROM bookings WHERE booking_flag = 3")->fetch_assoc()['total'] ?? 0;
$active_rides       = $conn->query("SELECT COUNT(*) as count FROM bookings WHERE booking_flag = 1")->fetch_assoc()['count'] ?? 0;
$completed_rides    = $conn->query("SELECT COUNT(*) as count FROM bookings WHERE booking_flag = 3")->fetch_assoc()['count'] ?? 0;
$active_drivers     = $conn->query("SELECT COUNT(*) as count FROM fleet WHERE status IN ('Active', '1')")->fetch_assoc()['count'] ?? 0;
$total_cancelled    = $conn->query("SELECT COUNT(*) as count FROM cancelled_bookings")->fetch_assoc()['count'] ?? 0;
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Master Command & Control Suite | Admin</title>
    
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    
    <style>
        :root {
            --brand-primary: #f59e0b;    
            --brand-dark: #0f172a;        
            --brand-bg: #f8fafc;          
            --panel-bg: #ffffff;          
            --text-dark: #1e293b;         
            --text-light: #64748b;        
            --border-subtle: #e2e8f0;     
        }

        body { 
            font-family: 'Plus Jakarta Sans', sans-serif; 
            font-size: 0.875rem;          
            background-color: var(--brand-bg); 
            color: var(--text-dark); 
            overflow-x: hidden;
        }
        
        .app-container { display: flex; min-height: 100vh; }
        
        .sidebar { 
            width: 280px; 
            background-color: var(--brand-dark); 
            padding: 24px 20px; 
            display: flex; 
            flex-direction: column;
            z-index: 100;
            position: fixed;
            top: 0;
            bottom: 0;
            left: 0;
            transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
        }
        
        .sidebar .brand { 
            font-size: 1.25rem; 
            font-weight: 700; 
            color: #ffffff; 
            margin-bottom: 32px; 
            display: flex; 
            align-items: center; 
            gap: 10px;
            letter-spacing: -0.5px;
        }
        
        .sidebar-menu .nav-link { 
            color: #94a3b8; 
            padding: 12px 16px; 
            border-radius: 8px; 
            font-weight: 500; 
            font-size: 0.875rem;
            display: flex; 
            align-items: center; 
            gap: 12px;
            width: 100%; 
            background: none; 
            border: none; 
            text-align: left;
            transition: all 0.2s ease;
            margin-bottom: 6px;
        }
        
        .sidebar-menu .nav-link:hover { 
            background-color: rgba(255, 255, 255, 0.04); 
            color: #f8fafc; 
        }
        
        .sidebar-menu .nav-link.active { 
            background-color: var(--brand-primary);
            color: var(--brand-dark);
            font-weight: 600;
        }

        .main-content { 
            flex: 1; 
            padding: 40px; 
            margin-left: 280px;
            min-width: 0;
            transition: all 0.3s ease;
        }
        
        .metric-widget { 
            background: var(--panel-bg); 
            border: 1px solid var(--border-subtle); 
            border-radius: 14px; 
            padding: 24px; 
            box-shadow: 0 1px 3px 0 rgba(0, 0, 0, 0.05);
            position: relative;
            overflow: hidden;
            transition: transform 0.2s ease, box-shadow 0.2s ease;
        }

        .metric-widget:hover {
            transform: translateY(-2px);
            box-shadow: 0 10px 15px -3px rgba(0, 0, 0, 0.05);
        }

        .metric-icon-bg {
            position: absolute;
            right: -10px;
            bottom: -10px;
            font-size: 4.5rem;
            opacity: 0.06;
            transform: rotate(-15deg);
        }
        
        .data-panel { 
            background: var(--panel-bg); 
            border: 1px solid var(--border-subtle); 
            border-radius: 16px; 
            padding: 28px; 
            box-shadow: 0 4px 6px -1px rgba(0, 0, 0, 0.02), 0 2px 4px -1px rgba(0, 0, 0, 0.02); 
            margin-bottom: 24px;
        }
        
        .table { color: var(--text-dark); margin-bottom: 0; font-size: 0.875rem; }
        .table thead th { 
            background-color: #f1f5f9; 
            color: var(--text-light); 
            font-weight: 600; 
            text-transform: uppercase; 
            font-size: 0.75rem; 
            letter-spacing: 0.05em; 
            padding: 14px 16px; 
            border-bottom: 1px solid var(--border-subtle);
        }
        .table tbody td { padding: 16px; border-bottom: 1px solid var(--border-subtle); vertical-align: middle; }
        .table-hover tbody tr:hover td { background-color: #f8fafc !important; }
        
        .badge-custom { font-weight: 600; padding: 6px 12px; border-radius: 20px; font-size: 0.75rem; display: inline-flex; align-items: center; gap: 6px; }
        .badge-active { background: #dbeafe; color: #1e40af; }
        .badge-completed { background: #d1fae5; color: #065f46; }
        .badge-cancelled { background: #fee2e2; color: #991b1b; }
        
        .form-control, .form-select { 
            background-color: #ffffff; 
            border: 1px solid var(--border-subtle); 
            color: var(--text-dark);
            padding: 10px 14px;
            border-radius: 8px;
            font-size: 0.875rem;
        }
        .form-control:focus, .form-select:focus { 
            border-color: var(--brand-primary); 
            box-shadow: 0 0 0 4px rgba(245, 158, 11, 0.12); 
            outline: none;
        }

        .input-group-text {
            background-color: #e2e8f0 !important;
            color: var(--text-dark) !important;
            border: 1px solid var(--border-subtle);
            font-weight: 600;
        }
        
        .btn { font-size: 0.875rem; padding: 10px 20px; border-radius: 8px; font-weight: 500; transition: all 0.2s ease; }
        .btn-sm { font-size: 0.815rem; padding: 6px 12px; border-radius: 6px; }
        .btn-dark { background-color: var(--brand-dark); border-color: var(--brand-dark); }
        .btn-dark:hover { background-color: #1e293b; border-color: #1e293b; }
        .btn-primary-custom { background-color: var(--brand-primary); border-color: var(--brand-primary); color: var(--brand-dark); font-weight: 600; }
        .btn-primary-custom:hover { background-color: #d97706; border-color: #d97706; color: white; }

        .modal-content { border-radius: 16px; border: none; box-shadow: 0 20px 25px -5px rgba(0,0,0,0.1); }
        .invoice-link { text-decoration: none; transition: opacity 0.2s ease; }
        .invoice-link:hover { opacity: 0.85; }

        .tariff-editing-card {
            border: 2px dashed var(--brand-primary) !important;
            background-color: #fffbeb !important;
        }

        @media (max-width: 1199.98px) {
            .sidebar { width: 72px; padding: 20px 10px; align-items: center; }
            .sidebar .brand span:not(:first-child), .sidebar-menu .nav-link span { display: none; }
            .sidebar .brand { margin-bottom: 24px; justify-content: center; }
            .sidebar-menu .nav-link { justify-content: center; padding: 12px; }
            .main-content { margin-left: 72px; padding: 24px; }
        }
    </style>
</head>
<body>

<div class="app-container w-100">
    <aside class="sidebar">
        <div class="brand">
            <span class="text-warning"><i class="fa-solid fa-square-rss"></i></span>
            <span>RANJAN CAB HQ</span>
        </div>
        <ul class="nav flex-column sidebar-menu list-unstyled w-100" id="controlDeckTabs" role="tablist">
            <li class="nav-item">
                <button class="nav-link active" id="live-ops-tab" data-bs-toggle="tab" data-bs-target="#live-ops-pane" type="button" role="tab">
                    <i class="fa-solid fa-tower-broadcast"></i> <span>Live Terminal</span>
                </button>
            </li>
            <li class="nav-item">
                <button class="nav-link" id="bookings-tab" data-bs-toggle="tab" data-bs-target="#bookings-pane" type="button" role="tab">
                    <i class="fa-solid fa-list-check"></i> <span>Bookings Matrix (<?= $bookings_result->num_rows ?>)</span>
                </button>
            </li>
            <li class="nav-item">
                <button class="nav-link" id="cancelled-tab" data-bs-toggle="tab" data-bs-target="#cancelled-pane" type="button" role="tab">
                    <i class="fa-solid fa-ban"></i> <span>Cancellation Logs (<?= $cancelled_result->num_rows ?>)</span>
                </button>
            </li>
            <li class="nav-item">
                <button class="nav-link" id="fleet-tab" data-bs-toggle="tab" data-bs-target="#fleet-pane" type="button" role="tab">
                    <i class="fa-solid fa-id-card-clip"></i> <span>Fleet Operators (<?= $fleet_result->num_rows ?>)</span>
                </button>
            </li>
            <li class="nav-item">
                <button class="nav-link" id="tariffs-tab" data-bs-toggle="tab" data-bs-target="#tariffs-pane" type="button" role="tab">
                    <i class="fa-solid fa-coins"></i> <span>Tariff Systems</span>
                </button>
            </li>
            <li class="nav-item">
                <button class="nav-link" id="routes-tab" data-bs-toggle="tab" data-bs-target="#routes-pane" type="button" role="tab">
                    <i class="fa-solid fa-route"></i> <span>Active Corridors</span>
                </button>
            </li>
            <li class="nav-item">
                <button class="nav-link" id="blogs-tab" data-bs-toggle="tab" data-bs-target="#blogs-pane" type="button" role="tab">
                    <i class="fa-solid fa-newspaper"></i> <span>Blogs (<?= $blogs_result->num_rows ?>)</span>
                </button>
            </li>
            <li class="nav-item">
                <button class="nav-link" id="coupons-tab" data-bs-toggle="tab" data-bs-target="#coupons-pane" type="button" role="tab">
                    <i class="fa-solid fa-ticket"></i> <span>Coupon Codes</span>
                </button>
            </li>
        </ul>
    </aside>

    <main class="main-content">
        <div class="d-flex flex-column flex-sm-row justify-content-between align-items-start align-items-sm-center mb-4 pb-4 border-bottom gap-3">
            <div>
                <h1 class="h3 mb-1 fw-bold text-slate-900">Control Deck Architecture</h1>
                <p class="text-muted mb-0">High-fidelity structural executive pipeline over live operational records.</p>
            </div>
            <div class="d-flex flex-column flex-sm-row gap-2">
                <button class="btn btn-primary-custom d-flex align-items-center gap-2" data-bs-toggle="modal" data-bs-target="#addFleetModal">
                    <i class="fa-solid fa-car-side"></i> Add Fleet
                </button>
                <button class="btn btn-dark d-flex align-items-center gap-2" data-bs-toggle="modal" data-bs-target="#addRouteModal">
                    <i class="fa-solid fa-plus-circle"></i> Deploy System Route
                </button>
            </div>
        </div>

        <?php if (isset($_GET['status'])): ?>
            <?php
            $statusMap = [
                'allocated'       => ['success', 'Driver allocated successfully.'],
                'completed'       => ['success', 'Booking marked as completed.'],
                'cancelled'       => ['warning', 'Booking cancelled and archived.'],
                'fleet_added'     => ['success', 'New driver added to fleet.'],
                'fleet_updated'   => ['success', 'Driver status updated.'],
                'driver_verified' => ['success', 'Driver documents verified.'],
                'blog_created'    => ['success', 'Blog post published.'],
                'blog_deleted'    => ['warning', 'Blog post deleted.'],
                'coupon_created'  => ['success', 'Coupon code created.'],
                'coupon_updated'  => ['success', 'Coupon status updated.'],
                'coupon_deleted'  => ['warning', 'Coupon code deleted.'],
                'pricing_updated' => ['success', 'Tariff rates updated.'],
                'route_added'     => ['success', 'Route added successfully.'],
                'route_deleted'   => ['warning', 'Route deleted.'],
            ];
            $s      = htmlspecialchars($_GET['status']);
            $type   = $statusMap[$s][0] ?? 'info';
            $msg    = $statusMap[$s][1] ?? 'Operation completed.';
            $icon   = ($type === 'success') ? 'fa-circle-check text-success' : 'fa-triangle-exclamation text-warning';
            $bgCls  = ($type === 'success') ? 'alert-success' : 'alert-warning';
            ?>
            <div class="alert <?= $bgCls ?> alert-dismissible fade show border-0 shadow-sm mb-4" role="alert">
                <div class="d-flex align-items-center gap-2 small">
                    <i class="fa-solid <?= $icon ?> fs-5"></i>
                    <strong><?= htmlspecialchars($msg) ?></strong>
                </div>
                <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
            </div>
        <?php endif; ?>

        <?php if ($migration_needed): ?>
        <div class="alert alert-warning border-warning mb-4" role="alert">
            <div class="d-flex align-items-center gap-2">
                <i class="fa-solid fa-triangle-exclamation fs-5"></i>
                <div>
                    <strong>Database migration required.</strong>
                    New tables (coupon_codes) and columns need to be created.
                    <a href="run_migration.php" target="_blank" class="alert-link fw-bold ms-2">
                        Run Migration Now →
                    </a>
                </div>
            </div>
        </div>
        <?php endif; ?>

        <div class="tab-content" id="controlDeckTabsContent">
            
            <div class="tab-pane fade show active" id="live-ops-pane" role="tabpanel">
                <div class="row g-4 mb-4">
                    <div class="col-12 col-sm-6 col-xl-3">
                        <div class="metric-widget">
                            <small class="text-muted text-uppercase fw-bold d-block mb-2" style="font-size: 0.75rem; letter-spacing: 0.05em;">Settled Revenue</small>
                            <h3 class="fw-bold mb-0 text-success">₹<?= number_format($total_revenue, 2) ?></h3>
                            <i class="fa-solid fa-wallet text-success metric-icon-bg"></i>
                        </div>
                    </div>
                    <div class="col-12 col-sm-6 col-xl-3">
                        <div class="metric-widget">
                            <small class="text-muted text-uppercase fw-bold d-block mb-2" style="font-size: 0.75rem; letter-spacing: 0.05em;">Advance Collected</small>
                            <h3 class="fw-bold mb-0 text-warning">₹<?= number_format($total_advance, 2) ?></h3>
                            <i class="fa-solid fa-money-bill-wave text-warning metric-icon-bg"></i>
                        </div>
                    </div>
                    <div class="col-12 col-sm-6 col-xl-3">
                        <div class="metric-widget">
                            <small class="text-muted text-uppercase fw-bold d-block mb-2" style="font-size: 0.75rem; letter-spacing: 0.05em;">Active Transits</small>
                            <h3 class="fw-bold mb-0 text-primary"><?= $active_rides ?> Rides</h3>
                            <i class="fa-solid fa-car-tunnel text-primary metric-icon-bg"></i>
                        </div>
                    </div>
                    <div class="col-12 col-sm-6 col-xl-3">
                        <div class="metric-widget">
                            <small class="text-muted text-uppercase fw-bold d-block mb-2" style="font-size: 0.75rem; letter-spacing: 0.05em;">Compliant Fleet</small>
                            <h3 class="fw-bold mb-0 text-dark"><?= $active_drivers ?> Operators</h3>
                            <i class="fa-solid fa-user-shield text-dark metric-icon-bg"></i>
                        </div>
                    </div>
                </div>

                <div class="data-panel">
                    <div class="d-flex align-items-center gap-2 mb-3">
                        <span class="text-warning"><i class="fa-solid fa-chart-line fs-5"></i></span>
                        <h4 class="h5 mb-0 fw-bold text-dark">Operational Pipeline Overview</h4>
                    </div>
                    <canvas id="operationalChart" style="max-height: 230px;"></canvas>
                </div>

                <div class="data-panel">
                    <div class="d-flex align-items-center gap-2 mb-4">
                        <span class="text-warning"><i class="fa-solid fa-bolt fs-5"></i></span>
                        <h4 class="h5 mb-0 fw-bold text-dark">Live Allocation & Interception Deck</h4>
                    </div>
                    <div class="table-responsive">
                        <table class="table table-hover align-middle">
                            <thead>
                                <tr>
                                    <th>Ref ID</th>
                                    <th>Passenger Engine Vector</th>
                                    <th>Segment Details</th>
                                    <th>Assigned Unit</th>
                                    <th class="text-end">Command Center Matrix</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php 
                                $priority_fetch = $conn->query("SELECT b.*, f.driver_name FROM bookings b LEFT JOIN fleet f ON b.assigned_driver_id = f.id WHERE b.booking_flag = 1 ORDER BY b.id DESC");
                                if($priority_fetch->num_rows > 0): while($p = $priority_fetch->fetch_assoc()): ?>
                                    <tr>
                                        <td><span class="badge bg-dark text-white font-monospace py-2 px-3">#<?= htmlspecialchars($p['booking_ref_no']) ?></span></td>
                                        <td>
                                            <div class="fw-bold text-dark"><?= htmlspecialchars($p['customer_name']) ?></div>
                                            <div class="text-muted small"><i class="fa-solid fa-phone-flip me-1"></i><?= htmlspecialchars($p['customer_phone']) ?></div>
                                        </td>
                                        <td>
                                            <div class="text-dark fw-semibold small"><?= htmlspecialchars($p['pickup_location']) ?></div>
                                            <div class="text-muted mx-0 my-1 small"><i class="fa-solid fa-arrow-down-long ms-2"></i></div>
                                            <div class="text-secondary fw-semibold small"><?= htmlspecialchars($p['drop_location']) ?></div>
                                        </td>
                                        <td>
                                            <?= $p['driver_name'] ? '<span class="badge-custom badge-completed"><i class="fa-solid fa-circle-check"></i> '.htmlspecialchars($p['driver_name']).'</span>' : '<span class="badge-custom badge-active text-warning bg-warning-subtle"><i class="fa-solid fa-circle-notch fa-spin"></i> Handshake Pending</span>' ?>
                                        </td>
                                        <td class="text-end">
                                            <div class="d-inline-flex gap-2">
                                                <form method="POST" action="admin.php" onsubmit="return confirm('Commit operational closure sequence?');">
                                                    <input type="hidden" name="action" value="complete_booking">
                                                    <input type="hidden" name="booking_id" value="<?= $p['id'] ?>">
                                                    <button type="submit" class="btn btn-success btn-sm d-flex align-items-center gap-1"><i class="fa-solid fa-check"></i> Complete</button>
                                                </form>
                                                <button class="btn btn-dark btn-sm d-flex align-items-center gap-1" data-bs-toggle="modal" data-bs-target="#allocateModal<?= $p['id'] ?>"><i class="fa-solid fa-user-plus"></i> Assign</button>
                                                <button class="btn btn-outline-danger btn-sm d-flex align-items-center gap-1" data-bs-toggle="modal" data-bs-target="#cancelModal<?= $p['id'] ?>"><i class="fa-solid fa-handshake-slash"></i> Drop</button>
                                            </div>
                                        </td>
                                    </tr>

                                    <div class="modal fade" id="allocateModal<?= $p['id'] ?>" tabindex="-1">
                                        <div class="modal-dialog modal-dialog-centered">
                                            <form method="POST" action="admin.php" class="w-100">
                                                <div class="modal-content">
                                                    <div class="modal-header">
                                                        <h5 class="modal-title fw-bold h6"><i class="fa-solid fa-link me-2 text-warning"></i>Bind Active Operator Profile</h5>
                                                        <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                                                    </div>
                                                    <div class="modal-body">
                                                        <input type="hidden" name="action" value="allocate_cab">
                                                        <input type="hidden" name="booking_id" value="<?= $p['id'] ?>">
                                                        <div class="mb-3">
                                                            <label class="form-label small fw-semibold">Select Available Driver Infrastructure</label>
                                                            <select class="form-select text-slate-800" name="driver_id" required>
                                                                <option value="">-- Choose Operator Fleet Line --</option>
                                                                <?php foreach($drivers_menu as $driver): ?>
                                                                    <option value="<?= $driver['id'] ?>"><?= htmlspecialchars($driver['driver_name']) ?> [<?= htmlspecialchars($driver['vehicle_number']) ?>] (<?= htmlspecialchars($driver['car_type']) ?>)</option>
                                                                <?php endforeach; ?>
                                                            </select>
                                                        </div>
                                                    </div>
                                                    <div class="modal-footer">
                                                        <button type="button" class="btn btn-light btn-sm" data-bs-dismiss="modal">Close</button>
                                                        <button type="submit" class="btn btn-primary-custom btn-sm">Confirm Allocation</button>
                                                    </div>
                                                </div>
                                            </form>
                                        </div>
                                    </div>

                                    <div class="modal fade" id="cancelModal<?= $p['id'] ?>" tabindex="-1">
                                        <div class="modal-dialog modal-dialog-centered">
                                            <form method="POST" action="admin.php" class="w-100">
                                                <div class="modal-content">
                                                    <div class="modal-header">
                                                        <h5 class="modal-title fw-bold h6 text-danger"><i class="fa-solid fa-triangle-exclamation me-2"></i>Execute Booking Revocation</h5>
                                                        <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                                                    </div>
                                                    <div class="modal-body">
                                                        <input type="hidden" name="action" value="cancel_booking">
                                                        <input type="hidden" name="booking_id" value="<?= $p['id'] ?>">
                                                        <input type="hidden" name="from_tab" value="live-ops">
                                                        <div class="mb-3">
                                                            <label class="form-label small fw-semibold">Cancellation Reason</label>
                                                            <textarea class="form-control" name="reason" rows="3" placeholder="Enter reason for trip termination..." required></textarea>
                                                        </div>
                                                    </div>
                                                    <div class="modal-footer">
                                                        <button type="button" class="btn btn-light btn-sm" data-bs-dismiss="modal">Abort</button>
                                                        <button type="submit" class="btn btn-danger btn-sm">Execute Revocation</button>
                                                    </div>
                                                </div>
                                            </form>
                                        </div>
                                    </div>
                                <?php endwhile; else: ?>
                                    <tr><td colspan="5" class="text-center py-5 text-muted">No operational entries active inside primary runtime queue.</td></tr>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>

            <div class="tab-pane fade" id="bookings-pane" role="tabpanel">
                <div class="data-panel">
                    <div class="d-flex align-items-center gap-2 mb-4">
                        <i class="fa-solid fa-database text-primary fs-5"></i>
                        <h4 class="h5 mb-0 fw-bold text-dark">`bookings` Central Registry Ledger</h4>
                    </div>
                    <div class="table-responsive">
                        <table class="table table-hover align-middle">
                            <thead>
                                <tr>
                                    <th>Ref No</th>
                                    <th>Customer Vector</th>
                                    <th>Routing Class</th>
                                    <th>Schedules</th>
                                    <th>Financial Metrics</th>
                                    <th>Assigned Fleet Node</th>
                                    <th>Operational State</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php if($bookings_result->num_rows > 0): while($row = $bookings_result->fetch_assoc()): ?>
                                    <tr>
                                        <td>
                                            <?php if (intval($row['booking_flag']) === 3): ?>
                                                <a href="generate_invoice.php?ref=<?= urlencode($row['booking_ref_no']) ?>" target="_blank" class="invoice-link text-primary d-inline-flex align-items-center gap-1">
                                                    <span class="font-monospace fw-bold">#<?= htmlspecialchars($row['booking_ref_no']) ?></span>
                                                    <i class="fa-solid fa-file-pdf small text-danger"></i>
                                                </a>
                                            <?php else: ?>
                                                <span class="font-monospace fw-bold text-dark">#<?= htmlspecialchars($row['booking_ref_no']) ?></span>
                                            <?php endif; ?>
                                        </td>
                                        <td>
                                            <div class="fw-bold text-dark"><?= htmlspecialchars($row['customer_name']) ?></div>
                                            <div class="text-muted small"><?= htmlspecialchars($row['customer_phone']) ?></div>
                                        </td>
                                        <td>
                                            <span class="badge bg-secondary-subtle text-secondary px-2 py-1 mb-2 rounded border" style="font-size:0.7rem; font-weight:600;"><?= htmlspecialchars($row['car_type']) ?></span>
                                            <div class="small"><?= htmlspecialchars($row['pickup_location']) ?> &rarr; <?= htmlspecialchars($row['drop_location']) ?></div>
                                        </td>
                                        <td>
                                            <div class="fw-semibold small"><?= date('d-M-Y', strtotime($row['pickup_date'])) ?></div>
                                            <div class="text-muted small mt-1"><?= htmlspecialchars($row['pickup_time']) ?></div>
                                        </td>
                                        <td>
                                            <div class="fw-bold text-dark">₹<?= number_format($row['total_fare'], 2) ?></div>
                                            <?php
                                            $b_disc = floatval($row['discounted_fare'] ?? $row['total_fare']);
                                            $b_cpn  = $row['coupon_code'] ?? '';
                                            $b_cdis = floatval($row['coupon_discount'] ?? 0);
                                            if ($b_cdis > 0 && !empty($b_cpn)):
                                            ?>
                                            <div class="text-success small fw-semibold"><i class="fa-solid fa-tag"></i> <?= htmlspecialchars($b_cpn) ?> (-₹<?= number_format($b_cdis, 2) ?>)</div>
                                            <div class="text-primary small fw-bold">Final: ₹<?= number_format($b_disc, 2) ?></div>
                                            <?php endif; ?>
                                            <div class="text-muted small">Adv: ₹<?= number_format($row['advance_paid'], 2) ?></div>
                                        </td>
                                        <td><?= htmlspecialchars($row['driver_name'] ?? 'Unallocated') ?></td>
                                        <td>
                                            <?php 
                                            if ($row['booking_flag'] == 1) {
                                                echo '<span class="badge-custom badge-active"><i class="fa-solid fa-circle-dot"></i> Active</span>';
                                            } elseif ($row['booking_flag'] == 3) {
                                                echo '<span class="badge-custom badge-completed"><i class="fa-solid fa-circle-check"></i> Settled</span>';
                                            } else {
                                                echo '<span class="badge-custom badge-cancelled"><i class="fa-solid fa-circle-exclamation"></i> Unknown</span>';
                                            }
                                            ?>
                                        </td>
                                    </tr>
                                <?php endwhile; else: ?>
                                    <tr><td colspan="7" class="text-center py-4 text-muted">Registry Empty.</td></tr>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>

            <div class="tab-pane fade" id="cancelled-pane" role="tabpanel">
                <div class="data-panel">
                    <div class="d-flex align-items-center gap-2 mb-4">
                        <i class="fa-solid fa-ban text-danger fs-5"></i>
                        <h4 class="h5 mb-0 fw-bold text-dark">Revocation Log Ledger</h4>
                    </div>
                    <div class="table-responsive">
                        <table class="table table-hover align-middle">
                            <thead>
                                <tr>
                                    <th>Ref ID</th>
                                    <th>Passenger Engine</th>
                                    <th>Segment Details</th>
                                    <th>Tariff / Original Node</th>
                                    <th>Revocation Motive</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php if($cancelled_result->num_rows > 0): while($crow = $cancelled_result->fetch_assoc()): ?>
                                    <tr>
                                        <td><span class="badge bg-dark font-monospace">#<?= htmlspecialchars($crow['booking_ref_no']) ?></span></td>
                                        <td>
                                            <div class="fw-bold"><?= htmlspecialchars($crow['customer_name']) ?></div>
                                            <small class="text-muted"><?= htmlspecialchars($crow['customer_phone']) ?></small>
                                        </td>
                                        <td>
                                            <div class="small"><?= htmlspecialchars($crow['pickup_location']) ?> &rarr; <?= htmlspecialchars($crow['drop_location']) ?></div>
                                        </td>
                                        <td>
                                            <div class="fw-semibold small">₹<?= number_format($crow['total_fare'], 2) ?></div>
                                            <small class="text-muted">Node: <?= htmlspecialchars($crow['driver_name'] ?? 'Unassigned') ?></small>
                                        </td>
                                        <td>
                                            <div class="badge-custom badge-cancelled"><?= htmlspecialchars($crow['cancellation_reason']) ?></div>
                                        </td>
                                    </tr>
                                <?php endwhile; else: ?>
                                    <tr><td colspan="5" class="text-center py-4 text-muted">Zero revocations logged securely.</td></tr>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>

            <div class="tab-pane fade" id="fleet-pane" role="tabpanel">
                <div class="data-panel">
                    <div class="d-flex flex-column flex-sm-row align-items-start align-items-sm-center justify-content-between gap-3 mb-4">
                        <div class="d-flex align-items-center gap-2">
                            <i class="fa-solid fa-id-card-clip text-dark fs-5"></i>
                            <h4 class="h5 mb-0 fw-bold text-dark">Fleet Infrastructure Registry</h4>
                        </div>
                        <button class="btn btn-primary-custom btn-sm d-flex align-items-center gap-2" data-bs-toggle="modal" data-bs-target="#addFleetModal">
                            <i class="fa-solid fa-plus"></i> New Fleet Entry
                        </button>
                    </div>
                    <div class="table-responsive">
                        <table class="table table-hover align-middle">
                            <thead>
                                <tr>
                                    <th>Operator Profile</th>
                                    <th>Vehicle Details</th>
                                    <th>Car Type</th>
                                    <th>Statutory Documents</th>
                                    <th>Verification</th>
                                    <th>Current Commision Status</th>
                                    <th class="text-end">Commission Mutator Deck</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php if($fleet_result->num_rows > 0): while($f = $fleet_result->fetch_assoc()): ?>
                                    <tr>
                                        <td>
                                            <div class="fw-bold text-dark"><?= htmlspecialchars($f['driver_name']) ?></div>
                                            <small class="text-muted font-monospace"><?= htmlspecialchars($f['mobile_number'] ?? '') ?></small>
                                        </td>
                                        <td><span class="font-monospace fw-semibold"><?= htmlspecialchars($f['vehicle_number']) ?></span></td>
                                        <td><span class="badge bg-light text-dark border"><?= htmlspecialchars($f['car_type']) ?></span></td>
                                        <td>
                                            <div class="small text-muted mb-2">
                                                <div><strong>DL:</strong> <?= htmlspecialchars($f['driver_license_no'] ?: 'Not submitted') ?></div>
                                                <div><strong>Aadhaar:</strong> <?= htmlspecialchars($f['aadhaar_no'] ?: 'Not submitted') ?></div>
                                                <div><strong>RC:</strong> <?= htmlspecialchars($f['rc_no'] ?: 'Not submitted') ?></div>
                                            </div>
                                            <div class="d-flex flex-wrap gap-1">
                                                <?php if (!empty($f['doc_license_path'])): ?>
                                                    <a class="btn btn-outline-secondary btn-sm py-1 px-2" href="<?= htmlspecialchars($f['doc_license_path']) ?>" target="_blank"><i class="fa-solid fa-id-card"></i> DL</a>
                                                <?php endif; ?>
                                                <?php if (!empty($f['doc_aadhaar_path'])): ?>
                                                    <a class="btn btn-outline-secondary btn-sm py-1 px-2" href="<?= htmlspecialchars($f['doc_aadhaar_path']) ?>" target="_blank"><i class="fa-solid fa-address-card"></i> Aadhaar</a>
                                                <?php endif; ?>
                                                <?php if (!empty($f['doc_rc_path'])): ?>
                                                    <a class="btn btn-outline-secondary btn-sm py-1 px-2" href="<?= htmlspecialchars($f['doc_rc_path']) ?>" target="_blank"><i class="fa-solid fa-file-contract"></i> RC</a>
                                                <?php endif; ?>
                                            </div>
                                        </td>
                                        <td>
                                            <?php
                                                $fleet_docs_ready = !empty($f['driver_license_no']) && !empty($f['aadhaar_no']) && !empty($f['rc_no']) && !empty($f['doc_license_path']) && !empty($f['doc_aadhaar_path']) && !empty($f['doc_rc_path']);
                                            ?>
                                            <?php if (intval($f['is_verified']) === 1 && $fleet_docs_ready): ?>
                                                <span class="badge-custom badge-completed"><i class="fa-solid fa-shield-check"></i> Verified</span>
                                            <?php elseif ($fleet_docs_ready): ?>
                                                <span class="badge-custom badge-active"><i class="fa-solid fa-hourglass-half"></i> Review Pending</span>
                                                <form method="POST" action="admin.php" class="mt-2">
                                                    <input type="hidden" name="action" value="verify_driver_documents">
                                                    <input type="hidden" name="driver_id" value="<?= intval($f['id']) ?>">
                                                    <button type="submit" class="btn btn-success btn-sm">Verify Documents</button>
                                                </form>
                                            <?php else: ?>
                                                <span class="badge-custom badge-cancelled"><i class="fa-solid fa-file-circle-exclamation"></i> Incomplete</span>
                                            <?php endif; ?>
                                        </td>
                                        <td>
                                            <?php if ($f['status'] == 1 || $f['status'] === 'Active'): ?>
                                                <span class="badge-custom badge-completed"><i class="fa-solid fa-circle-check"></i> Commissioned</span>
                                            <?php else: ?>
                                                <span class="badge-custom badge-cancelled"><i class="fa-solid fa-triangle-exclamation"></i> Terminated/Idle</span>
                                            <?php endif; ?>
                                        </td>
                                        <td class="text-end">
                                            <form method="POST" action="admin.php" class="d-inline-flex gap-2">
                                                <input type="hidden" name="action" value="toggle_fleet">
                                                <input type="hidden" name="driver_id" value="<?= $f['id'] ?>">
                                                <?php if ($f['status'] == 1 || $f['status'] === 'Active'): ?>
                                                    <input type="hidden" name="target_status" value="Inactive">
                                                    <button type="submit" class="btn btn-outline-danger btn-sm">Terminate Line</button>
                                                <?php else: ?>
                                                    <input type="hidden" name="target_status" value="Active">
                                                    <button type="submit" class="btn btn-success btn-sm">Re-Commission</button>
                                                <?php endif; ?>
                                            </form>
                                        </td>
                                    </tr>
                                <?php endwhile; else: ?>
                                    <tr><td colspan="7" class="text-center py-4 text-muted">No fleet drivers registered.</td></tr>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>

            <div class="tab-pane fade" id="tariffs-pane" role="tabpanel">
                <div class="row g-4">
                    <?php if($pricing_result->num_rows > 0): while($p_row = $pricing_result->fetch_assoc()): ?>
                        <div class="col-12 col-md-6">
                            <form method="POST" action="admin.php" class="data-panel h-100 mb-0">
                                <div class="d-flex align-items-center justify-content-between mb-3">
                                    <div class="d-flex align-items-center gap-2">
                                        <i class="fa-solid fa-coins text-warning fs-5"></i>
                                        <h4 class="h5 mb-0 fw-bold text-dark text-uppercase"><?= htmlspecialchars($p_row['car_type']) ?> Rates</h4>
                                    </div>
                                    <span class="badge bg-dark font-monospace">ID: #<?= $p_row['id'] ?></span>
                                </div>
                                <input type="hidden" name="action" value="update_pricing">
                                <input type="hidden" name="id" value="<?= $p_row['id'] ?>">
                                <input type="hidden" name="car_type" value="<?= htmlspecialchars($p_row['car_type']) ?>">
                                
                                <div class="mb-3">
                                    <label class="form-label small fw-semibold">Rate Per Kilometer (₹)</label>
                                    <input type="number" step="0.01" class="form-control" name="rate_per_km" value="<?= htmlspecialchars($p_row['rate_per_km']) ?>" required>
                                </div>
                                <div class="mb-3">
                                    <label class="form-label small fw-semibold">Portal / Base Charges (₹)</label>
                                    <input type="number" step="0.01" class="form-control" name="portal_charges" value="<?= htmlspecialchars($p_row['portal_charges']) ?>" required>
                                </div>
                                <div class="mb-3">
                                    <label class="form-label small fw-semibold">Advance Payment Percentage (%)</label>
                                    <input type="number" step="0.1" class="form-control" name="advance_percentage" value="<?= htmlspecialchars($p_row['advance_percentage']) ?>" required>
                                </div>
                                <div class="text-end mt-3">
                                    <button type="submit" class="btn btn-primary-custom w-100 w-sm-auto"><i class="fa-solid fa-floppy-disk me-1"></i> Commit Parameter Updates</button>
                                </div>
                            </form>
                        </div>
                    <?php endwhile; else: ?>
                        <div class="col-12"><div class="alert alert-warning">No pricing structures defined.</div></div>
                    <?php endif; ?>
                </div>
            </div>

            <div class="tab-pane fade" id="routes-pane" role="tabpanel">
                <div class="data-panel">
                    <div class="d-flex align-items-center gap-2 mb-4">
                        <i class="fa-solid fa-route text-secondary fs-5"></i>
                        <h4 class="h5 mb-0 fw-bold text-dark">System Defined Route Map Matrix</h4>
                    </div>
                    <div class="table-responsive">
                        <table class="table table-hover align-middle">
                            <thead>
                                <tr>
                                    <th>Pickup Vector</th>
                                    <th>Drop Vector</th>
                                    <th>Distance</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php if($routes_result->num_rows > 0): while($r = $routes_result->fetch_assoc()): ?>
                                    <tr>
                                        <td><div class="fw-bold text-dark"><?= htmlspecialchars($r['pickup_point']) ?></div></td>
                                        <td><div class="fw-semibold text-secondary"><?= htmlspecialchars($r['drop_point']) ?></div></td>
                                        <td><span class="badge bg-light border text-dark font-monospace"><?= htmlspecialchars($r['estimated_distance']) ?> KM</span></td>
                                    </tr>
                                <?php endwhile; else: ?>
                                    <tr><td colspan="3" class="text-center py-4 text-muted">No corridors have been deployed.</td></tr>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>

            <div class="tab-pane fade" id="blogs-pane" role="tabpanel">
                <div class="row g-4">
                    <!-- Write / Edit Blog Post -->
                    <div class="col-12">
                        <div class="data-panel">
                            <div class="d-flex align-items-center justify-content-between flex-wrap gap-3 mb-4">
                                <div class="d-flex align-items-center gap-2">
                                    <i class="fa-solid fa-pen-nib text-warning fs-5"></i>
                                    <h4 class="h5 mb-0 fw-bold text-dark">Write New Blog Post</h4>
                                </div>
                                <div class="text-muted small">
                                    <i class="fa-solid fa-circle-info me-1"></i>
                                    Use the editor below — supports headings, bold, italic, lists, links, images and tables.
                                </div>
                            </div>

                            <!-- Quill rich text editor CSS -->
                            <link href="https://cdn.jsdelivr.net/npm/quill@2.0.2/dist/quill.snow.css" rel="stylesheet">

                            <form method="POST" action="admin.php" id="blogForm">
                                <input type="hidden" name="action" value="create_blog">
                                <!-- Hidden field populated by JS before submit -->
                                <input type="hidden" name="content" id="blog_content_field">

                                <div class="row g-3 mb-3">
                                    <div class="col-12 col-md-8">
                                        <label class="form-label small fw-semibold">Post Title <span class="text-danger">*</span></label>
                                        <input type="text" name="title" id="blog_title"
                                               class="form-control form-control-lg fw-bold"
                                               maxlength="180"
                                               placeholder="Enter a clear, descriptive title"
                                               required>
                                    </div>
                                    <div class="col-6 col-md-2">
                                        <label class="form-label small fw-semibold">Author</label>
                                        <input type="text" name="author" class="form-control" value="RanjanCabs Admin">
                                    </div>
                                    <div class="col-6 col-md-2">
                                        <label class="form-label small fw-semibold">Status</label>
                                        <select name="status" class="form-select">
                                            <option value="published">Published</option>
                                            <option value="draft">Draft</option>
                                        </select>
                                    </div>
                                </div>

                                <div class="mb-3">
                                    <label class="form-label small fw-semibold">Short Excerpt <span class="text-danger">*</span></label>
                                    <textarea name="excerpt" class="form-control" rows="2"
                                              maxlength="300"
                                              placeholder="One or two sentences shown on the blog listing and homepage"
                                              required></textarea>
                                    <div class="form-text">Max 300 characters. Shown as a preview on the homepage and blog index.</div>
                                </div>

                                <div class="mb-3">
                                    <label class="form-label small fw-semibold">
                                        Full Article Content <span class="text-danger">*</span>
                                        <span class="text-muted fw-normal ms-2">— Use the toolbar for headings, images, tables, links, etc.</span>
                                    </label>

                                    <!-- Quill editor container -->
                                    <div id="quill-editor"
                                         style="min-height:420px; background:#fff; border:1px solid #dee2e6; border-radius:0 0 6px 6px; font-size:15px; line-height:1.7;">
                                    </div>
                                    <div class="form-text mt-1">
                                        <i class="fa-solid fa-image me-1 text-muted"></i> For images, use the image button in the toolbar and paste a URL.
                                        &nbsp;|&nbsp;
                                        <i class="fa-solid fa-table me-1 text-muted"></i> Tables: Insert → Table icon.
                                    </div>
                                </div>

                                <div class="d-flex gap-2 flex-wrap">
                                    <button type="submit" class="btn btn-dark px-5">
                                        <i class="fa-solid fa-paper-plane me-1"></i> Publish Blog Post
                                    </button>
                                    <button type="button" class="btn btn-outline-secondary" onclick="previewBlog()">
                                        <i class="fa-solid fa-eye me-1"></i> Preview
                                    </button>
                                    <button type="button" class="btn btn-outline-danger" onclick="clearEditor()">
                                        <i class="fa-solid fa-trash me-1"></i> Clear
                                    </button>
                                </div>
                            </form>
                        </div>
                    </div>

                    <!-- Blog Library -->
                    <div class="col-12">
                        <div class="data-panel">
                            <div class="d-flex align-items-center justify-content-between gap-2 mb-4 flex-wrap">
                                <div class="d-flex align-items-center gap-2">
                                    <i class="fa-solid fa-newspaper text-secondary fs-5"></i>
                                    <h4 class="h5 mb-0 fw-bold text-dark">Published Blog Posts</h4>
                                </div>
                                <a href="blog.php" target="_blank" class="btn btn-outline-secondary btn-sm">
                                    <i class="fa-solid fa-up-right-from-square me-1"></i> View Blog
                                </a>
                            </div>
                            <div class="table-responsive">
                                <table class="table table-hover align-middle">
                                    <thead>
                                        <tr>
                                            <th style="width:45%;">Post Title &amp; Excerpt</th>
                                            <th>Author</th>
                                            <th>Status</th>
                                            <th>Date</th>
                                            <th class="text-end">Actions</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php if ($blogs_result->num_rows > 0): while ($blog = $blogs_result->fetch_assoc()): ?>
                                        <tr>
                                            <td>
                                                <div class="fw-bold text-dark"><?= htmlspecialchars($blog['title']) ?></div>
                                                <div class="text-muted small mt-1" style="line-height:1.4;"><?= htmlspecialchars(mb_strimwidth($blog['excerpt'] ?? '', 0, 120, '…')) ?></div>
                                            </td>
                                            <td class="small text-muted"><?= htmlspecialchars($blog['author']) ?></td>
                                            <td>
                                                <?php if ($blog['status'] === 'published'): ?>
                                                    <span class="badge bg-success">Published</span>
                                                <?php else: ?>
                                                    <span class="badge bg-secondary">Draft</span>
                                                <?php endif; ?>
                                            </td>
                                            <td class="small text-muted"><?= date("d M Y", strtotime($blog['created_at'])) ?></td>
                                            <td class="text-end">
                                                <?php if ($blog['status'] === 'published'): ?>
                                                    <a href="blog.php?slug=<?= urlencode($blog['slug']) ?>"
                                                       target="_blank"
                                                       class="btn btn-outline-primary btn-sm me-1">
                                                        <i class="fa-solid fa-eye"></i> View
                                                    </a>
                                                <?php endif; ?>
                                                <form method="POST" action="admin.php" class="d-inline"
                                                      onsubmit="return confirm('Delete \'<?= htmlspecialchars(addslashes($blog['title'])) ?>\'? This cannot be undone.');">
                                                    <input type="hidden" name="action" value="delete_blog">
                                                    <input type="hidden" name="blog_id" value="<?= intval($blog['id']) ?>">
                                                    <button type="submit" class="btn btn-outline-danger btn-sm">
                                                        <i class="fa-solid fa-trash-can"></i> Delete
                                                    </button>
                                                </form>
                                            </td>
                                        </tr>
                                        <?php endwhile; else: ?>
                                            <tr>
                                                <td colspan="5" class="text-center py-5 text-muted">
                                                    <i class="fa-solid fa-pen-to-square fs-3 d-block mb-2 opacity-25"></i>
                                                    No blog posts written yet. Use the editor above to publish your first post.
                                                </td>
                                            </tr>
                                        <?php endif; ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            
            <!-- COUPONS PANE -->
            <div class="tab-pane fade" id="coupons-pane" role="tabpanel">
                <div class="row g-4">
                    <div class="col-12 col-xl-5">
                        <div class="data-panel">
                            <div class="d-flex align-items-center gap-2 mb-4">
                                <i class="fa-solid fa-ticket text-warning fs-5"></i>
                                <h4 class="h5 mb-0 fw-bold text-dark">Create Coupon Code</h4>
                            </div>
                            <form method="POST" action="admin.php">
                                <input type="hidden" name="action" value="create_coupon">
                                <div class="mb-3">
                                    <label class="form-label small fw-semibold">Coupon Code</label>
                                    <input type="text" name="coupon_code" class="form-control font-monospace text-uppercase fw-bold"
                                           placeholder="E.g. SAVE10" maxlength="30" style="letter-spacing:2px;" required>
                                    <div class="form-text">Capital letters and numbers only. Will be auto-uppercased.</div>
                                </div>
                                <div class="mb-3">
                                    <label class="form-label small fw-semibold">Discount Percentage (%)</label>
                                    <input type="number" name="discount_percent" class="form-control" placeholder="10" min="1" max="50" step="0.5" value="10" required>
                                </div>
                                <div class="mb-3">
                                    <label class="form-label small fw-semibold">Description</label>
                                    <input type="text" name="coupon_description" class="form-control" placeholder="E.g. Welcome offer — 10% off your first ride">
                                </div>
                                <div class="row g-3 mb-3">
                                    <div class="col-6">
                                        <label class="form-label small fw-semibold">Max Usage</label>
                                        <input type="number" name="max_usage" class="form-control" value="100" min="0">
                                        <div class="form-text">0 = unlimited</div>
                                    </div>
                                    <div class="col-6">
                                        <label class="form-label small fw-semibold">Valid Until</label>
                                        <input type="date" name="valid_until" class="form-control">
                                        <div class="form-text">Leave blank = no expiry</div>
                                    </div>
                                </div>
                                <button type="submit" class="btn btn-dark w-100">
                                    <i class="fa-solid fa-plus-circle me-1"></i> Create Coupon
                                </button>
                            </form>
                        </div>
                    </div>
                    <div class="col-12 col-xl-7">
                        <div class="data-panel h-100">
                            <div class="d-flex align-items-center gap-2 mb-4">
                                <i class="fa-solid fa-tags text-secondary fs-5"></i>
                                <h4 class="h5 mb-0 fw-bold text-dark">Active Coupon Codes</h4>
                            </div>
                            <div class="table-responsive">
                                <table class="table table-hover align-middle">
                                    <thead>
                                        <tr>
                                            <th>Code</th>
                                            <th>Discount</th>
                                            <th>Used / Max</th>
                                            <th>Expires</th>
                                            <th>Status</th>
                                            <th class="text-end">Action</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php
                                        if ($coupons_result && $coupons_result->num_rows > 0):
                                            while ($cpn = $coupons_result->fetch_assoc()):
                                        ?>
                                        <tr>
                                            <td>
                                                <span class="font-monospace fw-bold text-dark" style="letter-spacing:1px;">
                                                    <?= htmlspecialchars($cpn['code']) ?>
                                                </span>
                                                <div class="text-muted small"><?= htmlspecialchars($cpn['description'] ?? '') ?></div>
                                            </td>
                                            <td><span class="badge bg-success"><?= number_format($cpn['discount_percent'], 0) ?>% OFF</span></td>
                                            <td>
                                                <span class="fw-bold"><?= intval($cpn['usage_count']) ?></span>
                                                <span class="text-muted"> / <?= $cpn['max_usage'] == 0 ? '∞' : intval($cpn['max_usage']) ?></span>
                                            </td>
                                            <td class="small text-muted">
                                                <?= $cpn['valid_until'] ? date('d M Y', strtotime($cpn['valid_until'])) : 'No expiry' ?>
                                            </td>
                                            <td>
                                                <?php if ($cpn['is_active']): ?>
                                                    <span class="badge bg-success">Active</span>
                                                <?php else: ?>
                                                    <span class="badge bg-secondary">Inactive</span>
                                                <?php endif; ?>
                                            </td>
                                            <td class="text-end">
                                                <form method="POST" action="admin.php" class="d-inline">
                                                    <input type="hidden" name="action" value="toggle_coupon">
                                                    <input type="hidden" name="coupon_id" value="<?= intval($cpn['id']) ?>">
                                                    <input type="hidden" name="new_status" value="<?= $cpn['is_active'] ? 0 : 1 ?>">
                                                    <button type="submit" class="btn btn-sm <?= $cpn['is_active'] ? 'btn-outline-warning' : 'btn-outline-success' ?>">
                                                        <?= $cpn['is_active'] ? 'Disable' : 'Enable' ?>
                                                    </button>
                                                </form>
                                                <form method="POST" action="admin.php" class="d-inline ms-1"
                                                      onsubmit="return confirm('Delete coupon <?= htmlspecialchars($cpn['code'], ENT_QUOTES) ?>? This cannot be undone.');">
                                                    <input type="hidden" name="action" value="delete_coupon">
                                                    <input type="hidden" name="coupon_id" value="<?= intval($cpn['id']) ?>">
                                                    <button type="submit" class="btn btn-sm btn-outline-danger">
                                                        <i class="fa-solid fa-trash-can"></i> Delete
                                                    </button>
                                                </form>
                                            </td>
                                        </tr>
                                        <?php endwhile; else: ?>
                                            <tr><td colspan="6" class="text-center py-4 text-muted">No coupon codes created yet.</td></tr>
                                        <?php endif; ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

        </div>
    </main>
</div>

<div class="modal fade" id="addFleetModal" tabindex="-1">
    <div class="modal-dialog modal-dialog-centered modal-lg">
        <form method="POST" action="admin.php" class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title fw-bold h6"><i class="fa-solid fa-car-side me-2 text-dark"></i>Register Fleet Infrastructure</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body">
                <input type="hidden" name="action" value="add_fleet">
                <div class="row g-3">
                    <div class="col-12 col-md-6">
                        <label class="form-label small fw-semibold">Driver Full Name</label>
                        <input type="text" name="driver_name" class="form-control" placeholder="E.g. Ramesh Kumar" required>
                    </div>
                    <div class="col-12 col-md-6">
                        <label class="form-label small fw-semibold">Mobile Number</label>
                        <input type="tel" name="mobile_number" class="form-control" maxlength="10" pattern="[0-9]{10}" placeholder="10-digit mobile number" required>
                    </div>
                    <div class="col-12 col-md-6">
                        <label class="form-label small fw-semibold">Login Password</label>
                        <input type="text" name="password" class="form-control" placeholder="Leave blank to use driver last name">
                    </div>
                    <div class="col-12 col-md-6">
                        <label class="form-label small fw-semibold">Base Station</label>
                        <input type="text" name="base_station" class="form-control" placeholder="E.g. Bhopal" required>
                    </div>
                    <div class="col-12 col-md-4">
                        <label class="form-label small fw-semibold">Vehicle Number</label>
                        <input type="text" name="vehicle_number" class="form-control" placeholder="E.g. MP-04-AB-1234" required>
                    </div>
                    <div class="col-12 col-md-4">
                        <label class="form-label small fw-semibold">Vehicle Model</label>
                        <input type="text" name="model_name" class="form-control" placeholder="E.g. Maruti Dzire" required>
                    </div>
                    <div class="col-12 col-md-4">
                        <label class="form-label small fw-semibold">Car Type</label>
                        <select name="car_type" class="form-select" required>
                            <option value="">Select type</option>
                            <option value="Sedan">Sedan</option>
                            <option value="SUV">SUV</option>
                            <option value="Hatchback">Hatchback</option>
                        </select>
                    </div>
                    <div class="col-12 col-md-6">
                        <label class="form-label small fw-semibold">Driving License Number</label>
                        <input type="text" name="driver_license_no" class="form-control" placeholder="E.g. MP0420260001">
                    </div>
                    <div class="col-12 col-md-6">
                        <label class="form-label small fw-semibold">Aadhaar Number</label>
                        <input type="text" name="aadhaar_no" class="form-control" maxlength="12" pattern="[0-9]{12}" placeholder="12-digit Aadhaar number">
                    </div>
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-light btn-sm" data-bs-dismiss="modal">Cancel</button>
                <button type="submit" class="btn btn-dark btn-sm">Save Fleet Entry</button>
            </div>
        </form>
    </div>
</div>

<div class="modal fade" id="addRouteModal" tabindex="-1">
    <div class="modal-dialog modal-dialog-centered">
        <form method="POST" action="admin.php" class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title fw-bold h6"><i class="fa-solid fa-plus-circle me-2 text-dark"></i>Register New Corridor</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body">
                <input type="hidden" name="action" value="add_route">
                <div class="mb-3">
                    <label class="form-label small fw-semibold">Pickup Base Station</label>
                    <input type="text" name="pickup_point" class="form-control" placeholder="E.g. Hyderabad Main Terminal" required>
                </div>
                <div class="mb-3">
                    <label class="form-label small fw-semibold">Drop / Destination Station</label>
                    <input type="text" name="drop_point" class="form-control" placeholder="E.g. Vijayawada Airport Drop" required>
                </div>
                <div class="mb-3">
                    <label class="form-label small fw-semibold">Estimated Distance (KM)</label>
                    <input type="number" step="0.1" name="estimated_distance" class="form-control" placeholder="E.g. 280.5" required>
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-light btn-sm" data-bs-dismiss="modal">Cancel</button>
                <button type="submit" class="btn btn-dark btn-sm">Deploy Route Segment</button>
            </div>
        </form>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>

<script>
// ── Restore the correct tab after a POST redirect ──────────────────────────
(function () {
    // Map of ?tab= values → Bootstrap tab button IDs
    var tabMap = {
        'live-ops'  : 'live-ops-tab',
        'bookings'  : 'bookings-tab',
        'cancelled' : 'cancelled-tab',
        'fleet'     : 'fleet-tab',
        'tariffs'   : 'tariffs-tab',
        'routes'    : 'routes-tab',
        'blogs'     : 'blogs-tab',
        'coupons'   : 'coupons-tab',
    };

    var params  = new URLSearchParams(window.location.search);
    var tabKey  = params.get('tab');
    var btnId   = tabMap[tabKey];

    if (btnId) {
        var btn = document.getElementById(btnId);
        if (btn) {
            // Use Bootstrap 5 Tab API to show the pane
            var bsTab = new bootstrap.Tab(btn);
            bsTab.show();
        }
    }
})();
    document.addEventListener("DOMContentLoaded", function() {
        const ctx = document.getElementById('operationalChart').getContext('2d');        const operationalChart = new Chart(ctx, {
            type: 'bar',
            data: {
                labels: ['Active Transits', 'Settled Transits', 'Revocation Records'],
                datasets: [{
                    label: 'Pipeline Items Count',
                    data: [<?= $active_rides ?>, <?= $completed_rides ?>, <?= $total_cancelled ?>],
                    backgroundColor: [
                        'rgba(59, 130, 246, 0.85)',
                        'rgba(16, 185, 129, 0.85)',
                        'rgba(239, 68, 68, 0.85)'
                    ],
                    borderColor: [
                        '#1d4ed8',
                        '#047857',
                        '#b91c1c'
                    ],
                    borderWidth: 1,
                    borderRadius: 8
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                scales: {
                    y: {
                        beginAtZero: true,
                        ticks: {
                            stepSize: 1
                        }
                    }
                }
            }
        });
    });
</script>
</body>
</html>
