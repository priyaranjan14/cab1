<?php
// 1. Force strict error reporting during core operational maintenance
mysqli_report(MYSQLI_REPORT_ERROR | MYSQLI_REPORT_STRICT);

// 2. Database Connection Configuration
$servername = "localhost";
$username   = "root";
$password   = "";
$dbname     = "ranjancab";

try {
    $conn = new mysqli($servername, $username, $password, $dbname);
    $conn->set_charset("utf8mb4");
} catch (Exception $e) {
    die("<div class='alert alert-danger m-3'>HQ Database Engine Connection Failure: " . $e->getMessage() . "</div>");
}

// ==========================================================================
// CENTRAL PROCESSING ENGINE: ONE-POINT STATE MUTATIONS (POST ACTIONS)
// ==========================================================================
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action'])) {
    
    // ACTION A: MANUALLY ALLOCATE UNASSIGNED / ACTIVE CAB LINE
    if ($_POST['action'] === 'allocate_cab') {
        $booking_id = intval($_POST['booking_id']);
        $driver_id  = intval($_POST['driver_id']);
        
        $stmt = $conn->prepare("UPDATE bookings SET assigned_driver_id = ? WHERE id = ?");
        $stmt->bind_param("ii", $driver_id, $booking_id);
        $stmt->execute();
        header("Location: admin.php?status=allocated"); exit;
    }

    // ACTION B: MARK ACTIVE TRANSIT RIDE AS COMPLETED
    if ($_POST['action'] === 'complete_booking') {
        $booking_id = intval($_POST['booking_id']);
        
        $stmt = $conn->prepare("UPDATE bookings SET booking_flag = 3 WHERE id = ?");
        $stmt->bind_param("i", $booking_id);
        $stmt->execute();
        header("Location: admin.php?status=completed"); exit;
    }
    
    // ACTION C: INTERCEPT AND CANCEL LIVE BOOKING
    if ($_POST['action'] === 'cancel_booking') {
        $booking_id = intval($_POST['booking_id']);
        $reason     = !empty($_POST['reason']) ? $_POST['reason'] : 'Terminated by Administration Command';
        
        $fetch_stmt = $conn->prepare("SELECT * FROM bookings WHERE id = ?");
        $fetch_stmt->bind_param("i", $booking_id);
        $fetch_stmt->execute();
        $booking = $fetch_stmt->get_result()->fetch_assoc();
        
        if ($booking) {
            $cancel_stmt = $conn->prepare("
                INSERT INTO cancelled_bookings 
                (booking_id, booking_ref_no, customer_name, customer_phone, pickup_location, drop_location, pickup_date, pickup_time, car_type, total_fare, assigned_driver_id, cancelled_by, cancellation_reason) 
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'Admin', ?)
            ");
            $cancel_stmt->bind_param(
                "issssssssdid", 
                $booking['id'], $booking['booking_ref_no'], $booking['customer_name'], $booking['customer_phone'], 
                $booking['pickup_location'], $booking['drop_location'], $booking['pickup_date'], $booking['pickup_time'], 
                $booking['car_type'], $booking['total_fare'], $booking['assigned_driver_id'], $reason
            );
            $cancel_stmt->execute();
            
            $delete_stmt = $conn->prepare("DELETE FROM bookings WHERE id = ?");
            $delete_stmt->bind_param("i", $booking_id);
            $delete_stmt->execute();
        }
        header("Location: admin.php?status=cancelled"); exit;
    }
    
    // ACTION D: TERMINATE / RE-COMMISSION DRIVER STATUS
    if ($_POST['action'] === 'toggle_fleet') {
        $driver_id  = intval($_POST['driver_id']);
        $new_status = ($_POST['target_status'] === 'Active') ? 'Active' : 'Inactive';
        
        $stmt = $conn->prepare("UPDATE fleet SET status = ? WHERE id = ?");
        $stmt->bind_param("si", $new_status, $driver_id);
        $stmt->execute();
        header("Location: admin.php?status=fleet_mutated"); exit;
    }

    // ACTION E: PROVISION NEW DRIVER / VEHICLE ASSET
    if ($_POST['action'] === 'add_fleet') {
        $driver_name       = trim($_POST['driver_name']);
        $mobile_number     = trim($_POST['mobile_number']);
        $vehicle_number    = strtoupper(trim($_POST['vehicle_number']));
        $model_name        = trim($_POST['model_name']);
        $car_type          = trim($_POST['car_type']);
        $base_station      = trim($_POST['base_station']);
        $driver_license_no = trim($_POST['driver_license_no'] ?? '');
        $aadhaar_no        = preg_replace('/\s+/', '', trim($_POST['aadhaar_no'] ?? ''));
        $password          = trim($_POST['password'] ?? '');

        if ($password === '') {
            $name_parts = preg_split('/\s+/', $driver_name);
            $password = end($name_parts) ?: $mobile_number;
        }

        $stmt = $conn->prepare("
            INSERT INTO fleet
                (driver_name, mobile_number, password, is_first_login, vehicle_number, model_name, car_type, base_station, star_rating, rating, is_verified, status, driver_license_no, aadhaar_no)
            VALUES
                (?, ?, ?, 1, ?, ?, ?, ?, 5.00, 5.00, 1, 'Active', ?, ?)
        ");
        $stmt->bind_param(
            "sssssssss",
            $driver_name,
            $mobile_number,
            $password,
            $vehicle_number,
            $model_name,
            $car_type,
            $base_station,
            $driver_license_no,
            $aadhaar_no
        );
        $stmt->execute();
        header("Location: admin.php?status=fleet_added"); exit;
    }

    // UPDATED ACTION E: REFACTORED CAR_TYPE RELATED UNIQUE TARIFF RATE UPDATE
    if ($_POST['action'] === 'update_pricing') {
        $id                 = intval($_POST['id']);
        $rate_per_km        = floatval($_POST['rate_per_km']);
        $portal_charges     = floatval($_POST['portal_charges']);
        $advance_percentage = floatval($_POST['advance_percentage']);

        $stmt = $conn->prepare("UPDATE pricing_settings SET rate_per_km = ?, portal_charges = ?, advance_percentage = ? WHERE id = ?");
        $stmt->bind_param("dddi", $rate_per_km, $portal_charges, $advance_percentage, $id);
        $stmt->execute();
        
        $car_slug = urlencode($_POST['car_type']);
        header("Location: admin.php?status=pricing_updated&variant=" . $car_slug); exit;
    }

    // ACTION F: INJECT SYSTEM ROUTE SEGMENT NODE
    if ($_POST['action'] === 'add_route') {
        $stmt = $conn->prepare("INSERT INTO routes (pickup_point, drop_point, estimated_distance) VALUES (?, ?, ?)");
        $stmt->bind_param("ssd", $_POST['pickup_point'], $_POST['drop_point'], $_POST['estimated_distance']);
        $stmt->execute();
        header("Location: admin.php?status=route_added"); exit;
    }
}

// ==========================================================================
// MASTER EXPOSURE DATA STREAMS (FETCH EVERYTHING)
// ==========================================================================
$bookings_result  = $conn->query("SELECT b.*, f.driver_name, f.vehicle_number FROM bookings b LEFT JOIN fleet f ON b.assigned_driver_id = f.id ORDER BY b.id DESC");
$cancelled_result = $conn->query("SELECT cb.*, f.driver_name, f.vehicle_number FROM cancelled_bookings cb LEFT JOIN fleet f ON cb.assigned_driver_id = f.id ORDER BY cb.id DESC");
$fleet_result     = $conn->query("SELECT * FROM fleet ORDER BY id DESC");
$pricing_result   = $conn->query("SELECT * FROM pricing_settings ORDER BY id ASC"); 
$routes_result    = $conn->query("SELECT * FROM routes ORDER BY id DESC");

$drivers_menu = [];
$drivers_fetch = $conn->query("SELECT id, driver_name, vehicle_number, car_type FROM fleet WHERE status IN ('Active', '1')");
while($d = $drivers_fetch->fetch_assoc()) { $drivers_menu[] = $d; }

$total_revenue   = $conn->query("SELECT SUM(total_fare) as total FROM bookings WHERE booking_flag = 3")->fetch_assoc()['total'] ?? 0;
$active_rides    = $conn->query("SELECT COUNT(*) as count FROM bookings WHERE booking_flag = 1")->fetch_assoc()['count'] ?? 0;
$completed_rides = $conn->query("SELECT COUNT(*) as count FROM bookings WHERE booking_flag = 3")->fetch_assoc()['count'] ?? 0;
$active_drivers  = $conn->query("SELECT COUNT(*) as count FROM fleet WHERE status IN ('Active', '1')")->fetch_assoc()['count'] ?? 0;
$total_cancelled = $conn->query("SELECT COUNT(*) as count FROM cancelled_bookings")->fetch_assoc()['count'] ?? 0;
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Master Command & Control Suite | Admin</title>
    
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    
    <style>
        :root {
            --brand-primary: #f59e0b;    
            --brand-dark: #0f172a;        
            --brand-bg: #f8fafc;          
            --panel-bg: #ffffff;          
            --text-dark: #1e293b;         
            --text-light: #64748b;        
            --border-subtle: #e2e8f0;     
        }

        body { 
            font-family: 'Plus Jakarta Sans', sans-serif; 
            font-size: 0.875rem;          
            background-color: var(--brand-bg); 
            color: var(--text-dark); 
            overflow-x: hidden;
        }
        
        .app-container { display: flex; min-height: 100vh; }
        
        .sidebar { 
            width: 280px; 
            background-color: var(--brand-dark); 
            padding: 24px 20px; 
            display: flex; 
            flex-direction: column;
            z-index: 100;
            position: fixed;
            top: 0;
            bottom: 0;
            left: 0;
            transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
        }
        
        .sidebar .brand { 
            font-size: 1.25rem; 
            font-weight: 700; 
            color: #ffffff; 
            margin-bottom: 32px; 
            display: flex; 
            align-items: center; 
            gap: 10px;
            letter-spacing: -0.5px;
        }
        
        .sidebar-menu .nav-link { 
            color: #94a3b8; 
            padding: 12px 16px; 
            border-radius: 8px; 
            font-weight: 500; 
            font-size: 0.875rem;
            display: flex; 
            align-items: center; 
            gap: 12px;
            width: 100%; 
            background: none; 
            border: none; 
            text-align: left;
            transition: all 0.2s ease;
            margin-bottom: 6px;
        }
        
        .sidebar-menu .nav-link:hover { 
            background-color: rgba(255, 255, 255, 0.04); 
            color: #f8fafc; 
        }
        
        .sidebar-menu .nav-link.active { 
            background-color: var(--brand-primary);
            color: var(--brand-dark);
            font-weight: 600;
        }

        .main-content { 
            flex: 1; 
            padding: 40px; 
            margin-left: 280px;
            min-width: 0;
            transition: all 0.3s ease;
        }
        
        .metric-widget { 
            background: var(--panel-bg); 
            border: 1px solid var(--border-subtle); 
            border-radius: 14px; 
            padding: 24px; 
            box-shadow: 0 1px 3px 0 rgba(0, 0, 0, 0.05);
            position: relative;
            overflow: hidden;
            transition: transform 0.2s ease, box-shadow 0.2s ease;
        }

        .metric-widget:hover {
            transform: translateY(-2px);
            box-shadow: 0 10px 15px -3px rgba(0, 0, 0, 0.05);
        }

        .metric-icon-bg {
            position: absolute;
            right: -10px;
            bottom: -10px;
            font-size: 4.5rem;
            opacity: 0.06;
            transform: rotate(-15deg);
        }
        
        .data-panel { 
            background: var(--panel-bg); 
            border: 1px solid var(--border-subtle); 
            border-radius: 16px; 
            padding: 28px; 
            box-shadow: 0 4px 6px -1px rgba(0, 0, 0, 0.02), 0 2px 4px -1px rgba(0, 0, 0, 0.02); 
            margin-bottom: 24px;
        }
        
        .table { color: var(--text-dark); margin-bottom: 0; font-size: 0.875rem; }
        .table thead th { 
            background-color: #f1f5f9; 
            color: var(--text-light); 
            font-weight: 600; 
            text-transform: uppercase; 
            font-size: 0.75rem; 
            letter-spacing: 0.05em; 
            padding: 14px 16px; 
            border-bottom: 1px solid var(--border-subtle);
        }
        .table tbody td { padding: 16px; border-bottom: 1px solid var(--border-subtle); vertical-align: middle; }
        .table-hover tbody tr:hover td { background-color: #f8fafc !important; }
        
        .badge-custom { font-weight: 600; padding: 6px 12px; border-radius: 20px; font-size: 0.75rem; display: inline-flex; align-items: center; gap: 6px; }
        .badge-active { background: #dbeafe; color: #1e40af; }
        .badge-completed { background: #d1fae5; color: #065f46; }
        .badge-cancelled { background: #fee2e2; color: #991b1b; }
        
        .form-control, .form-select { 
            background-color: #ffffff; 
            border: 1px solid var(--border-subtle); 
            color: var(--text-dark);
            padding: 10px 14px;
            border-radius: 8px;
            font-size: 0.875rem;
        }
        .form-control:focus, .form-select:focus { 
            border-color: var(--brand-primary); 
            box-shadow: 0 0 0 4px rgba(245, 158, 11, 0.12); 
            outline: none;
        }

        .input-group-text {
            background-color: #e2e8f0 !important;
            color: var(--text-dark) !important;
            border: 1px solid var(--border-subtle);
            font-weight: 600;
        }
        
        .btn { font-size: 0.875rem; padding: 10px 20px; border-radius: 8px; font-weight: 500; transition: all 0.2s ease; }
        .btn-sm { font-size: 0.815rem; padding: 6px 12px; border-radius: 6px; }
        .btn-dark { background-color: var(--brand-dark); border-color: var(--brand-dark); }
        .btn-dark:hover { background-color: #1e293b; border-color: #1e293b; }
        .btn-primary-custom { background-color: var(--brand-primary); border-color: var(--brand-primary); color: var(--brand-dark); font-weight: 600; }
        .btn-primary-custom:hover { background-color: #d97706; border-color: #d97706; color: white; }

        .modal-content { border-radius: 16px; border: none; box-shadow: 0 20px 25px -5px rgba(0,0,0,0.1); }
        .invoice-link { text-decoration: none; transition: opacity 0.2s ease; }
        .invoice-link:hover { opacity: 0.85; }

        .tariff-editing-card {
            border: 2px dashed var(--brand-primary) !important;
            background-color: #fffbeb !important;
        }

        @media (max-width: 1199.98px) {
            .sidebar { width: 72px; padding: 20px 10px; align-items: center; }
            .sidebar .brand span:not(:first-child), .sidebar-menu .nav-link span { display: none; }
            .sidebar .brand { margin-bottom: 24px; justify-content: center; }
            .sidebar-menu .nav-link { justify-content: center; padding: 12px; }
            .main-content { margin-left: 72px; padding: 24px; }
        }
    </style>
</head>
<body>

<div class="app-container w-100">
    <aside class="sidebar">
        <div class="brand">
            <span class="text-warning"><i class="fa-solid fa-square-rss"></i></span>
            <span>RANJAN CAB HQ</span>
        </div>
        <ul class="nav flex-column sidebar-menu list-unstyled w-100" id="controlDeckTabs" role="tablist">
            <li class="nav-item">
                <button class="nav-link active" id="live-ops-tab" data-bs-toggle="tab" data-bs-target="#live-ops-pane" type="button" role="tab">
                    <i class="fa-solid fa-tower-broadcast"></i> <span>Live Terminal</span>
                </button>
            </li>
            <li class="nav-item">
                <button class="nav-link" id="bookings-tab" data-bs-toggle="tab" data-bs-target="#bookings-pane" type="button" role="tab">
                    <i class="fa-solid fa-list-check"></i> <span>Bookings Matrix (<?= $bookings_result->num_rows ?>)</span>
                </button>
            </li>
            <li class="nav-item">
                <button class="nav-link" id="cancelled-tab" data-bs-toggle="tab" data-bs-target="#cancelled-pane" type="button" role="tab">
                    <i class="fa-solid fa-ban"></i> <span>Cancellation Logs (<?= $cancelled_result->num_rows ?>)</span>
                </button>
            </li>
            <li class="nav-item">
                <button class="nav-link" id="fleet-tab" data-bs-toggle="tab" data-bs-target="#fleet-pane" type="button" role="tab">
                    <i class="fa-solid fa-id-card-clip"></i> <span>Fleet Operators (<?= $fleet_result->num_rows ?>)</span>
                </button>
            </li>
            <li class="nav-item">
                <button class="nav-link" id="tariffs-tab" data-bs-toggle="tab" data-bs-target="#tariffs-pane" type="button" role="tab">
                    <i class="fa-solid fa-coins"></i> <span>Tariff Systems</span>
                </button>
            </li>
            <li class="nav-item">
                <button class="nav-link" id="routes-tab" data-bs-toggle="tab" data-bs-target="#routes-pane" type="button" role="tab">
                    <i class="fa-solid fa-route"></i> <span>Active Corridors</span>
                </button>
            </li>
        </ul>
    </aside>

    <main class="main-content">
        <div class="d-flex flex-column flex-sm-row justify-content-between align-items-start align-items-sm-center mb-4 pb-4 border-bottom gap-3">
            <div>
                <h1 class="h3 mb-1 fw-bold text-slate-900">Control Deck Architecture</h1>
                <p class="text-muted mb-0">High-fidelity structural executive pipeline over live operational records.</p>
            </div>
            <div class="d-flex flex-column flex-sm-row gap-2">
                <button class="btn btn-primary-custom d-flex align-items-center gap-2" data-bs-toggle="modal" data-bs-target="#addFleetModal">
                    <i class="fa-solid fa-car-side"></i> Add Fleet
                </button>
                <button class="btn btn-dark d-flex align-items-center gap-2" data-bs-toggle="modal" data-bs-target="#addRouteModal">
                    <i class="fa-solid fa-plus-circle"></i> Deploy System Route
                </button>
            </div>
        </div>

        <?php if (isset($_GET['status'])): ?>
            <div class="alert alert-success alert-dismissible fade show border-0 shadow-sm mb-4" role="alert">
                <div class="d-flex align-items-center gap-2 small">
                    <i class="fa-solid fa-circle-check fs-5 text-success"></i>
                    <div>
                        <strong>Operations Frame Mutated:</strong> Master transactions updated successfully.
                        <?php if($_GET['status'] === 'pricing_updated' && isset($_GET['variant'])): ?>
                            [Tariff modified for: <strong class="text-uppercase"><?= htmlspecialchars($_GET['variant']) ?></strong>]
                        <?php endif; ?>
                    </div>
                </div>
                <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
            </div>
        <?php endif; ?>

        <div class="tab-content" id="controlDeckTabsContent">
            
            <div class="tab-pane fade show active" id="live-ops-pane" role="tabpanel">
                <div class="row g-4 mb-4">
                    <div class="col-12 col-sm-6 col-xl-3">
                        <div class="metric-widget">
                            <small class="text-muted text-uppercase fw-bold d-block mb-2" style="font-size: 0.75rem; letter-spacing: 0.05em;">Settled Revenue</small>
                            <h3 class="fw-bold mb-0 text-success">₹<?= number_format($total_revenue, 2) ?></h3>
                            <i class="fa-solid fa-wallet text-success metric-icon-bg"></i>
                        </div>
                    </div>
                    <div class="col-12 col-sm-6 col-xl-3">
                        <div class="metric-widget">
                            <small class="text-muted text-uppercase fw-bold d-block mb-2" style="font-size: 0.75rem; letter-spacing: 0.05em;">Active Transits</small>
                            <h3 class="fw-bold mb-0 text-primary"><?= $active_rides ?> Rides</h3>
                            <i class="fa-solid fa-car-tunnel text-primary metric-icon-bg"></i>
                        </div>
                    </div>
                    <div class="col-12 col-sm-6 col-xl-3">
                        <div class="metric-widget">
                            <small class="text-muted text-uppercase fw-bold d-block mb-2" style="font-size: 0.75rem; letter-spacing: 0.05em;">Compliant Fleet</small>
                            <h3 class="fw-bold mb-0 text-dark"><?= $active_drivers ?> Operators</h3>
                            <i class="fa-solid fa-user-shield text-dark metric-icon-bg"></i>
                        </div>
                    </div>
                    <div class="col-12 col-sm-6 col-xl-3">
                        <div class="metric-widget">
                            <small class="text-muted text-uppercase fw-bold d-block mb-2" style="font-size: 0.75rem; letter-spacing: 0.05em;">Revocation Log</small>
                            <h3 class="fw-bold mb-0 text-danger"><?= $total_cancelled ?> Drops</h3>
                            <i class="fa-solid fa-triangle-exclamation text-danger metric-icon-bg"></i>
                        </div>
                    </div>
                </div>

                <div class="data-panel">
                    <div class="d-flex align-items-center gap-2 mb-3">
                        <span class="text-warning"><i class="fa-solid fa-chart-line fs-5"></i></span>
                        <h4 class="h5 mb-0 fw-bold text-dark">Operational Pipeline Overview</h4>
                    </div>
                    <canvas id="operationalChart" style="max-height: 230px;"></canvas>
                </div>

                <div class="data-panel">
                    <div class="d-flex align-items-center gap-2 mb-4">
                        <span class="text-warning"><i class="fa-solid fa-bolt fs-5"></i></span>
                        <h4 class="h5 mb-0 fw-bold text-dark">Live Allocation & Interception Deck</h4>
                    </div>
                    <div class="table-responsive">
                        <table class="table table-hover align-middle">
                            <thead>
                                <tr>
                                    <th>Ref ID</th>
                                    <th>Passenger Engine Vector</th>
                                    <th>Segment Details</th>
                                    <th>Assigned Unit</th>
                                    <th class="text-end">Command Center Matrix</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php 
                                $priority_fetch = $conn->query("SELECT b.*, f.driver_name FROM bookings b LEFT JOIN fleet f ON b.assigned_driver_id = f.id WHERE b.booking_flag = 1 ORDER BY b.id DESC");
                                if($priority_fetch->num_rows > 0): while($p = $priority_fetch->fetch_assoc()): ?>
                                    <tr>
                                        <td><span class="badge bg-dark text-white font-monospace py-2 px-3">#<?= htmlspecialchars($p['booking_ref_no']) ?></span></td>
                                        <td>
                                            <div class="fw-bold text-dark"><?= htmlspecialchars($p['customer_name']) ?></div>
                                            <div class="text-muted small"><i class="fa-solid fa-phone-flip me-1"></i><?= htmlspecialchars($p['customer_phone']) ?></div>
                                        </td>
                                        <td>
                                            <div class="text-dark fw-semibold small"><?= htmlspecialchars($p['pickup_location']) ?></div>
                                            <div class="text-muted mx-0 my-1 small"><i class="fa-solid fa-arrow-down-long ms-2"></i></div>
                                            <div class="text-secondary fw-semibold small"><?= htmlspecialchars($p['drop_location']) ?></div>
                                        </td>
                                        <td>
                                            <?= $p['driver_name'] ? '<span class="badge-custom badge-completed"><i class="fa-solid fa-circle-check"></i> '.htmlspecialchars($p['driver_name']).'</span>' : '<span class="badge-custom badge-active text-warning bg-warning-subtle"><i class="fa-solid fa-circle-notch fa-spin"></i> Handshake Pending</span>' ?>
                                        </td>
                                        <td class="text-end">
                                            <div class="d-inline-flex gap-2">
                                                <form method="POST" action="admin.php" onsubmit="return confirm('Commit operational closure sequence?');">
                                                    <input type="hidden" name="action" value="complete_booking">
                                                    <input type="hidden" name="booking_id" value="<?= $p['id'] ?>">
                                                    <button type="submit" class="btn btn-success btn-sm d-flex align-items-center gap-1"><i class="fa-solid fa-check"></i> Complete</button>
                                                </form>
                                                <button class="btn btn-dark btn-sm d-flex align-items-center gap-1" data-bs-toggle="modal" data-bs-target="#allocateModal<?= $p['id'] ?>"><i class="fa-solid fa-user-plus"></i> Assign</button>
                                                <button class="btn btn-outline-danger btn-sm d-flex align-items-center gap-1" data-bs-toggle="modal" data-bs-target="#cancelModal<?= $p['id'] ?>"><i class="fa-solid fa-handshake-slash"></i> Drop</button>
                                            </div>
                                        </td>
                                    </tr>

                                    <div class="modal fade" id="allocateModal<?= $p['id'] ?>" tabindex="-1">
                                        <div class="modal-dialog modal-dialog-centered">
                                            <form method="POST" action="admin.php" class="w-100">
                                                <div class="modal-content">
                                                    <div class="modal-header">
                                                        <h5 class="modal-title fw-bold h6"><i class="fa-solid fa-link me-2 text-warning"></i>Bind Active Operator Profile</h5>
                                                        <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                                                    </div>
                                                    <div class="modal-body">
                                                        <input type="hidden" name="action" value="allocate_cab">
                                                        <input type="hidden" name="booking_id" value="<?= $p['id'] ?>">
                                                        <div class="mb-3">
                                                            <label class="form-label small fw-semibold">Select Available Driver Infrastructure</label>
                                                            <select class="form-select text-slate-800" name="driver_id" required>
                                                                <option value="">-- Choose Operator Fleet Line --</option>
                                                                <?php foreach($drivers_menu as $driver): ?>
                                                                    <option value="<?= $driver['id'] ?>"><?= htmlspecialchars($driver['driver_name']) ?> [<?= htmlspecialchars($driver['vehicle_number']) ?>] (<?= htmlspecialchars($driver['car_type']) ?>)</option>
                                                                <?php endforeach; ?>
                                                            </select>
                                                        </div>
                                                    </div>
                                                    <div class="modal-footer">
                                                        <button type="button" class="btn btn-light btn-sm" data-bs-dismiss="modal">Close</button>
                                                        <button type="submit" class="btn btn-primary-custom btn-sm">Confirm Allocation</button>
                                                    </div>
                                                </div>
                                            </form>
                                        </div>
                                    </div>

                                    <div class="modal fade" id="cancelModal<?= $p['id'] ?>" tabindex="-1">
                                        <div class="modal-dialog modal-dialog-centered">
                                            <form method="POST" action="admin.php" class="w-100">
                                                <div class="modal-content">
                                                    <div class="modal-header">
                                                        <h5 class="modal-title fw-bold h6 text-danger"><i class="fa-solid fa-triangle-exclamation me-2"></i>Execute Booking Revocation</h5>
                                                        <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                                                    </div>
                                                    <div class="modal-body">
                                                        <input type="hidden" name="action" value="cancel_booking">
                                                        <input type="hidden" name="booking_id" value="<?= $p['id'] ?>">
                                                        <div class="mb-3">
                                                            <label class="form-label small fw-semibold">Cancellation Reason</label>
                                                            <textarea class="form-control" name="reason" rows="3" placeholder="Enter reason for trip termination..." required></textarea>
                                                        </div>
                                                    </div>
                                                    <div class="modal-footer">
                                                        <button type="button" class="btn btn-light btn-sm" data-bs-dismiss="modal">Abort</button>
                                                        <button type="submit" class="btn btn-danger btn-sm">Execute Revocation</button>
                                                    </div>
                                                </div>
                                            </form>
                                        </div>
                                    </div>
                                <?php endwhile; else: ?>
                                    <tr><td colspan="5" class="text-center py-5 text-muted">No operational entries active inside primary runtime queue.</td></tr>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>

            <div class="tab-pane fade" id="bookings-pane" role="tabpanel">
                <div class="data-panel">
                    <div class="d-flex align-items-center gap-2 mb-4">
                        <i class="fa-solid fa-database text-primary fs-5"></i>
                        <h4 class="h5 mb-0 fw-bold text-dark">`bookings` Central Registry Ledger</h4>
                    </div>
                    <div class="table-responsive">
                        <table class="table table-hover align-middle">
                            <thead>
                                <tr>
                                    <th>Ref No</th>
                                    <th>Customer Vector</th>
                                    <th>Routing Class</th>
                                    <th>Schedules</th>
                                    <th>Financial Metrics</th>
                                    <th>Assigned Fleet Node</th>
                                    <th>Operational State</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php if($bookings_result->num_rows > 0): while($row = $bookings_result->fetch_assoc()): ?>
                                    <tr>
                                        <td>
                                            <?php if (intval($row['booking_flag']) === 3): ?>
                                                <a href="generate_invoice.php?ref=<?= urlencode($row['booking_ref_no']) ?>" target="_blank" class="invoice-link text-primary d-inline-flex align-items-center gap-1">
                                                    <span class="font-monospace fw-bold">#<?= htmlspecialchars($row['booking_ref_no']) ?></span>
                                                    <i class="fa-solid fa-file-pdf small text-danger"></i>
                                                </a>
                                            <?php else: ?>
                                                <span class="font-monospace fw-bold text-dark">#<?= htmlspecialchars($row['booking_ref_no']) ?></span>
                                            <?php endif; ?>
                                        </td>
                                        <td>
                                            <div class="fw-bold text-dark"><?= htmlspecialchars($row['customer_name']) ?></div>
                                            <div class="text-muted small"><?= htmlspecialchars($row['customer_phone']) ?></div>
                                        </td>
                                        <td>
                                            <span class="badge bg-secondary-subtle text-secondary px-2 py-1 mb-2 rounded border" style="font-size:0.7rem; font-weight:600;"><?= htmlspecialchars($row['car_type']) ?></span>
                                            <div class="small"><?= htmlspecialchars($row['pickup_location']) ?> &rarr; <?= htmlspecialchars($row['drop_location']) ?></div>
                                        </td>
                                        <td>
                                            <div class="fw-semibold small"><?= date('d-M-Y', strtotime($row['pickup_date'])) ?></div>
                                            <div class="text-muted small mt-1"><?= htmlspecialchars($row['pickup_time']) ?></div>
                                        </td>
                                        <td>
                                            <div class="fw-bold text-dark">₹<?= number_format($row['total_fare'], 2) ?></div>
                                        </td>
                                        <td><?= htmlspecialchars($row['driver_name'] ?? 'Unallocated') ?></td>
                                        <td>
                                            <?php 
                                            if ($row['booking_flag'] == 1) {
                                                echo '<span class="badge-custom badge-active"><i class="fa-solid fa-circle-dot"></i> Active</span>';
                                            } elseif ($row['booking_flag'] == 3) {
                                                echo '<span class="badge-custom badge-completed"><i class="fa-solid fa-circle-check"></i> Settled</span>';
                                            } else {
                                                echo '<span class="badge-custom badge-cancelled"><i class="fa-solid fa-circle-exclamation"></i> Unknown</span>';
                                            }
                                            ?>
                                        </td>
                                    </tr>
                                <?php endwhile; else: ?>
                                    <tr><td colspan="7" class="text-center py-4 text-muted">Registry Empty.</td></tr>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>

            <div class="tab-pane fade" id="cancelled-pane" role="tabpanel">
                <div class="data-panel">
                    <div class="d-flex align-items-center gap-2 mb-4">
                        <i class="fa-solid fa-ban text-danger fs-5"></i>
                        <h4 class="h5 mb-0 fw-bold text-dark">Revocation Log Ledger</h4>
                    </div>
                    <div class="table-responsive">
                        <table class="table table-hover align-middle">
                            <thead>
                                <tr>
                                    <th>Ref ID</th>
                                    <th>Passenger Engine</th>
                                    <th>Segment Details</th>
                                    <th>Tariff / Original Node</th>
                                    <th>Revocation Motive</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php if($cancelled_result->num_rows > 0): while($crow = $cancelled_result->fetch_assoc()): ?>
                                    <tr>
                                        <td><span class="badge bg-dark font-monospace">#<?= htmlspecialchars($crow['booking_ref_no']) ?></span></td>
                                        <td>
                                            <div class="fw-bold"><?= htmlspecialchars($crow['customer_name']) ?></div>
                                            <small class="text-muted"><?= htmlspecialchars($crow['customer_phone']) ?></small>
                                        </td>
                                        <td>
                                            <div class="small"><?= htmlspecialchars($crow['pickup_location']) ?> &rarr; <?= htmlspecialchars($crow['drop_location']) ?></div>
                                        </td>
                                        <td>
                                            <div class="fw-semibold small">₹<?= number_format($crow['total_fare'], 2) ?></div>
                                            <small class="text-muted">Node: <?= htmlspecialchars($crow['driver_name'] ?? 'Unassigned') ?></small>
                                        </td>
                                        <td>
                                            <div class="badge-custom badge-cancelled"><?= htmlspecialchars($crow['cancellation_reason']) ?></div>
                                        </td>
                                    </tr>
                                <?php endwhile; else: ?>
                                    <tr><td colspan="5" class="text-center py-4 text-muted">Zero revocations logged securely.</td></tr>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>

            <div class="tab-pane fade" id="fleet-pane" role="tabpanel">
                <div class="data-panel">
                    <div class="d-flex flex-column flex-sm-row align-items-start align-items-sm-center justify-content-between gap-3 mb-4">
                        <div class="d-flex align-items-center gap-2">
                            <i class="fa-solid fa-id-card-clip text-dark fs-5"></i>
                            <h4 class="h5 mb-0 fw-bold text-dark">Fleet Infrastructure Registry</h4>
                        </div>
                        <button class="btn btn-primary-custom btn-sm d-flex align-items-center gap-2" data-bs-toggle="modal" data-bs-target="#addFleetModal">
                            <i class="fa-solid fa-plus"></i> New Fleet Entry
                        </button>
                    </div>
                    <div class="table-responsive">
                        <table class="table table-hover align-middle">
                            <thead>
                                <tr>
                                    <th>Operator Profile</th>
                                    <th>Vehicle Details</th>
                                    <th>Car Type</th>
                                    <th>Current Commision Status</th>
                                    <th class="text-end">Commission Mutator Deck</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php if($fleet_result->num_rows > 0): while($f = $fleet_result->fetch_assoc()): ?>
                                    <tr>
                                        <td>
                                            <div class="fw-bold text-dark"><?= htmlspecialchars($f['driver_name']) ?></div>
                                            <small class="text-muted font-monospace"><?= htmlspecialchars($f['mobile_number'] ?? '') ?></small>
                                        </td>
                                        <td><span class="font-monospace fw-semibold"><?= htmlspecialchars($f['vehicle_number']) ?></span></td>
                                        <td><span class="badge bg-light text-dark border"><?= htmlspecialchars($f['car_type']) ?></span></td>
                                        <td>
                                            <?php if ($f['status'] == 1 || $f['status'] === 'Active'): ?>
                                                <span class="badge-custom badge-completed"><i class="fa-solid fa-circle-check"></i> Commissioned</span>
                                            <?php else: ?>
                                                <span class="badge-custom badge-cancelled"><i class="fa-solid fa-triangle-exclamation"></i> Terminated/Idle</span>
                                            <?php endif; ?>
                                        </td>
                                        <td class="text-end">
                                            <form method="POST" action="admin.php" class="d-inline-flex gap-2">
                                                <input type="hidden" name="action" value="toggle_fleet">
                                                <input type="hidden" name="driver_id" value="<?= $f['id'] ?>">
                                                <?php if ($f['status'] == 1 || $f['status'] === 'Active'): ?>
                                                    <input type="hidden" name="target_status" value="Inactive">
                                                    <button type="submit" class="btn btn-outline-danger btn-sm">Terminate Line</button>
                                                <?php else: ?>
                                                    <input type="hidden" name="target_status" value="Active">
                                                    <button type="submit" class="btn btn-success btn-sm">Re-Commission</button>
                                                <?php endif; ?>
                                            </form>
                                        </td>
                                    </tr>
                                <?php endwhile; else: ?>
                                    <tr><td colspan="5" class="text-center py-4 text-muted">No fleet drivers registered.</td></tr>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>

            <div class="tab-pane fade" id="tariffs-pane" role="tabpanel">
                <div class="row g-4">
                    <?php if($pricing_result->num_rows > 0): while($p_row = $pricing_result->fetch_assoc()): ?>
                        <div class="col-12 col-md-6">
                            <form method="POST" action="admin.php" class="data-panel h-100 mb-0">
                                <div class="d-flex align-items-center justify-content-between mb-3">
                                    <div class="d-flex align-items-center gap-2">
                                        <i class="fa-solid fa-coins text-warning fs-5"></i>
                                        <h4 class="h5 mb-0 fw-bold text-dark text-uppercase"><?= htmlspecialchars($p_row['car_type']) ?> Rates</h4>
                                    </div>
                                    <span class="badge bg-dark font-monospace">ID: #<?= $p_row['id'] ?></span>
                                </div>
                                <input type="hidden" name="action" value="update_pricing">
                                <input type="hidden" name="id" value="<?= $p_row['id'] ?>">
                                <input type="hidden" name="car_type" value="<?= htmlspecialchars($p_row['car_type']) ?>">
                                
                                <div class="mb-3">
                                    <label class="form-label small fw-semibold">Rate Per Kilometer (₹)</label>
                                    <input type="number" step="0.01" class="form-control" name="rate_per_km" value="<?= htmlspecialchars($p_row['rate_per_km']) ?>" required>
                                </div>
                                <div class="mb-3">
                                    <label class="form-label small fw-semibold">Portal / Base Charges (₹)</label>
                                    <input type="number" step="0.01" class="form-control" name="portal_charges" value="<?= htmlspecialchars($p_row['portal_charges']) ?>" required>
                                </div>
                                <div class="mb-3">
                                    <label class="form-label small fw-semibold">Advance Payment Percentage (%)</label>
                                    <input type="number" step="0.1" class="form-control" name="advance_percentage" value="<?= htmlspecialchars($p_row['advance_percentage']) ?>" required>
                                </div>
                                <div class="text-end mt-3">
                                    <button type="submit" class="btn btn-primary-custom w-100 w-sm-auto"><i class="fa-solid fa-floppy-disk me-1"></i> Commit Parameter Updates</button>
                                </div>
                            </form>
                        </div>
                    <?php endwhile; else: ?>
                        <div class="col-12"><div class="alert alert-warning">No pricing structures defined.</div></div>
                    <?php endif; ?>
                </div>
            </div>

            <div class="tab-pane fade" id="routes-pane" role="tabpanel">
                <div class="data-panel">
                    <div class="d-flex align-items-center gap-2 mb-4">
                        <i class="fa-solid fa-route text-secondary fs-5"></i>
                        <h4 class="h5 mb-0 fw-bold text-dark">System Defined Route Map Matrix</h4>
                    </div>
                    <div class="table-responsive">
                        <table class="table table-hover align-middle">
                            <thead>
                                <tr>
                                    <th>Pickup Vector</th>
                                    <th>Drop Vector</th>
                                    <th>Distance</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php if($routes_result->num_rows > 0): while($r = $routes_result->fetch_assoc()): ?>
                                    <tr>
                                        <td><div class="fw-bold text-dark"><?= htmlspecialchars($r['pickup_point']) ?></div></td>
                                        <td><div class="fw-semibold text-secondary"><?= htmlspecialchars($r['drop_point']) ?></div></td>
                                        <td><span class="badge bg-light border text-dark font-monospace"><?= htmlspecialchars($r['estimated_distance']) ?> KM</span></td>
                                    </tr>
                                <?php endwhile; else: ?>
                                    <tr><td colspan="3" class="text-center py-4 text-muted">No corridors have been deployed.</td></tr>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
            
        </div>
    </main>
</div>

<div class="modal fade" id="addFleetModal" tabindex="-1">
    <div class="modal-dialog modal-dialog-centered modal-lg">
        <form method="POST" action="admin.php" class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title fw-bold h6"><i class="fa-solid fa-car-side me-2 text-dark"></i>Register Fleet Infrastructure</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body">
                <input type="hidden" name="action" value="add_fleet">
                <div class="row g-3">
                    <div class="col-12 col-md-6">
                        <label class="form-label small fw-semibold">Driver Full Name</label>
                        <input type="text" name="driver_name" class="form-control" placeholder="E.g. Ramesh Kumar" required>
                    </div>
                    <div class="col-12 col-md-6">
                        <label class="form-label small fw-semibold">Mobile Number</label>
                        <input type="tel" name="mobile_number" class="form-control" maxlength="10" pattern="[0-9]{10}" placeholder="10-digit mobile number" required>
                    </div>
                    <div class="col-12 col-md-6">
                        <label class="form-label small fw-semibold">Login Password</label>
                        <input type="text" name="password" class="form-control" placeholder="Leave blank to use driver last name">
                    </div>
                    <div class="col-12 col-md-6">
                        <label class="form-label small fw-semibold">Base Station</label>
                        <input type="text" name="base_station" class="form-control" placeholder="E.g. Bhopal" required>
                    </div>
                    <div class="col-12 col-md-4">
                        <label class="form-label small fw-semibold">Vehicle Number</label>
                        <input type="text" name="vehicle_number" class="form-control" placeholder="E.g. MP-04-AB-1234" required>
                    </div>
                    <div class="col-12 col-md-4">
                        <label class="form-label small fw-semibold">Vehicle Model</label>
                        <input type="text" name="model_name" class="form-control" placeholder="E.g. Maruti Dzire" required>
                    </div>
                    <div class="col-12 col-md-4">
                        <label class="form-label small fw-semibold">Car Type</label>
                        <select name="car_type" class="form-select" required>
                            <option value="">Select type</option>
                            <option value="Sedan">Sedan</option>
                            <option value="SUV">SUV</option>
                            <option value="Hatchback">Hatchback</option>
                        </select>
                    </div>
                    <div class="col-12 col-md-6">
                        <label class="form-label small fw-semibold">Driving License Number</label>
                        <input type="text" name="driver_license_no" class="form-control" placeholder="E.g. MP0420260001">
                    </div>
                    <div class="col-12 col-md-6">
                        <label class="form-label small fw-semibold">Aadhaar Number</label>
                        <input type="text" name="aadhaar_no" class="form-control" maxlength="12" pattern="[0-9]{12}" placeholder="12-digit Aadhaar number">
                    </div>
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-light btn-sm" data-bs-dismiss="modal">Cancel</button>
                <button type="submit" class="btn btn-dark btn-sm">Save Fleet Entry</button>
            </div>
        </form>
    </div>
</div>

<div class="modal fade" id="addRouteModal" tabindex="-1">
    <div class="modal-dialog modal-dialog-centered">
        <form method="POST" action="admin.php" class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title fw-bold h6"><i class="fa-solid fa-plus-circle me-2 text-dark"></i>Register New Corridor</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body">
                <input type="hidden" name="action" value="add_route">
                <div class="mb-3">
                    <label class="form-label small fw-semibold">Pickup Base Station</label>
                    <input type="text" name="pickup_point" class="form-control" placeholder="E.g. Hyderabad Main Terminal" required>
                </div>
                <div class="mb-3">
                    <label class="form-label small fw-semibold">Drop / Destination Station</label>
                    <input type="text" name="drop_point" class="form-control" placeholder="E.g. Vijayawada Airport Drop" required>
                </div>
                <div class="mb-3">
                    <label class="form-label small fw-semibold">Estimated Distance (KM)</label>
                    <input type="number" step="0.1" name="estimated_distance" class="form-control" placeholder="E.g. 280.5" required>
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-light btn-sm" data-bs-dismiss="modal">Cancel</button>
                <button type="submit" class="btn btn-dark btn-sm">Deploy Route Segment</button>
            </div>
        </form>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>

<script>
    document.addEventListener("DOMContentLoaded", function() {
        const ctx = document.getElementById('operationalChart').getContext('2d');
        const operationalChart = new Chart(ctx, {
            type: 'bar',
            data: {
                labels: ['Active Transits', 'Settled Transits', 'Revocation Records'],
                datasets: [{
                    label: 'Pipeline Items Count',
                    data: [<?= $active_rides ?>, <?= $completed_rides ?>, <?= $total_cancelled ?>],
                    backgroundColor: [
                        'rgba(59, 130, 246, 0.85)',
                        'rgba(16, 185, 129, 0.85)',
                        'rgba(239, 68, 68, 0.85)'
                    ],
                    borderColor: [
                        '#1d4ed8',
                        '#047857',
                        '#b91c1c'
                    ],
                    borderWidth: 1,
                    borderRadius: 8
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                scales: {
                    y: {
                        beginAtZero: true,
                        ticks: {
                            stepSize: 1
                        }
                    }
                }
            }
        });
    });
</script>
</body>
</html>
