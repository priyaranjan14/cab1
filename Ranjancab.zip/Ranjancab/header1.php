    <header class="navbar">
        <div class="nav-container">
            <div class="logo"><a href="index.php"><i class="fa-solid fa-taxi"></i> Ranjan<span>Cabs</span></a></div>
            <nav class="nav-menu" id="navMenu">
                <a href="index.php" class="active">Home</a>
                <a href="index.php#services">Services</a>
                <a href="index.php#reviews">Reviews</a>
                <a href="blog.php">Blog</a>
                <a href="driver_registration.php">Driver Registration</a>
                <a href="index.php#contact">Contact</a>
            </nav>
            <div class="nav-actions">
                <div class="dropdown">
                    <button class="login-btn"><i class="fa-solid fa-user"></i> Login <i class="fa-solid fa-caret-down"></i></button>
                    <div class="dropdown-content">
                        <a href="login.php"><i class="fa-solid fa-user-tie"></i> Customer Login</a>
                        <a href="driver_login.php?role=driver"><i class="fa-solid fa-id-card"></i> Driver Login</a>
                        <a href="admin_login.php?role=admin"><i class="fa-solid fa-user-gear"></i> Admin Portal</a>
                    </div>
                </div>
                <button class="menu-toggle" id="mobileMenuBtn"><i class="fa-solid fa-bars"></i></button>
            </div>
        </div>
    </header>
