    <header class="navbar">
        <div class="nav-container">
            <div class="logo"><a href="#"><i class="fa-solid fa-taxi"></i> Ranjan<span>Cabs</span></a></div>
            <nav class="nav-menu" id="navMenu">
                <a href="#" class="active">Home</a>
                <a href="#">Our Fleet</a>
                <a href="#">Services</a>
                <a href="#">Contact</a>
            </nav>
            <div class="nav-actions">
                <div class="dropdown">
                    <button class="login-btn"><i class="fa-solid fa-user"></i> Login <i class="fa-solid fa-caret-down"></i></button>
                    <div class="dropdown-content">
                        <a href="login.php"><i class="fa-solid fa-user-tie"></i> Customer Login</a>
                        <a href="driver_login.php?role=driver"><i class="fa-solid fa-id-card"></i> Driver Login</a>
                        <a href="admin_login.php?role=admin"><i class="fa-solid fa-user-gear"></i> Admin Portal</a>
                    </div>
                </div>
                <button class="menu-toggle" id="mobileMenuBtn"><i class="fa-solid fa-bars"></i></button>
            </div>
        </div>
    </header>