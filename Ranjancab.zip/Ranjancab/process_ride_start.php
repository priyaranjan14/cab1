<?php
session_start();

// 1. Session Authentication Check
if (!isset($_SESSION['driver_id'])) {
    header("Location: driver_login.php");
    exit();
}

$conn = new mysqli("localhost", "root", "", "Ranjancab");

if ($conn->connect_error) {
    die("Database link failure: " . $conn->connect_error);
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'start_trip') {
    
    $booking_id  = intval($_POST['booking_id']);
    $entered_otp = trim($_POST['entered_otp']);
    $driver_id   = intval($_SESSION['driver_id']);

    // 2. Extract OTP matching this exact assignment context
    // We remove the booking_flag strict check here to allow verification flexibility
    $stmt = $conn->prepare("SELECT otp_code, booking_flag FROM bookings WHERE id = ? AND assigned_driver_id = ?");
    $stmt->bind_param("ii", $booking_id, $driver_id);
    $stmt->execute();
    $result = $stmt->get_result()->fetch_assoc();
    $stmt->close();

    if ($result) {
        // 3. String Type-Safe Comparison (Prevents leading-zero dropping bugs like '0123' == 123)
        if ((string)$result['otp_code'] === (string)$entered_otp) {
            
            // 4. Update the Flag to Active Status (Matches your dashboard configuration view)
            $update_stmt = $conn->prepare("UPDATE bookings SET booking_flag = 1 WHERE id = ?");
            $update_stmt->bind_param("i", $booking_id);
            
            if ($update_stmt->execute()) {
                $update_stmt->close();
                $conn->close();
                header("Location: driver_dashboard.php?status=ride_started");
                exit();
            } else {
                $update_stmt->close();
                header("Location: driver_dashboard.php?status=error");
                exit();
            }
        } else {
            // OTP entered does not match database record string
            $conn->close();
            header("Location: driver_dashboard.php?status=wrong_otp");
            exit();
        }
    } else {
        // No matching reservation instance found for this specific asset assignment block
        $conn->close();
        header("Location: driver_dashboard.php?status=error");
        exit();
    }
} else {
    header("Location: driver_dashboard.php");
    exit();
}
?>