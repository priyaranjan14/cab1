<?php
session_start();
header('Content-Type: application/json');

if (!isset($_SESSION['driver_id'])) {
    echo json_encode([]);
    exit();
}

$driver_id = $_SESSION['driver_id'];

$conn = new mysqli("localhost", "root", "", "ranjancab");
if ($conn->connect_error) {
    echo json_encode([]);
    exit();
}

// Fetch this specific driver's profile using the database column 'car_type'
$driver_query = "SELECT base_station, car_type FROM fleet WHERE id = ?";
$d_stmt = $conn->prepare($driver_query);
$d_stmt->bind_param("i", $driver_id);
$d_stmt->execute();
$driver_profile = $d_stmt->get_result()->fetch_assoc();
$d_stmt->close();

if (!$driver_profile) {
    echo json_encode([]);
    exit();
}

$base_station = trim($driver_profile['base_station']);
$car_type     = trim($driver_profile['car_type']);

/**
 * SYNC ENGINE QUERY EXECUTION
 * Filters where booking_flag = 1 (unassigned) and car_type matches exactly
 */
$sql = "SELECT id, booking_ref_no, customer_name, pickup_location, drop_location, 
               pickup_date, pickup_time, car_type, distance, driver_balance, trip_type 
        FROM bookings 
        WHERE booking_flag = 1 
          AND assigned_driver_id IS NULL 
          AND LOWER(car_type) = LOWER(?) 
          AND pickup_location LIKE ?
        ORDER BY id DESC";

// FIX: Wraps wildcards on both sides so "Bhopal" matches "ISBT Bhopal" flawlessly
$location_param = "%" . $base_station . "%";

$stmt = $conn->prepare($sql);
$stmt->bind_param("ss", $car_type, $location_param);
$stmt->execute();
$result = $stmt->get_result();

$bookings = [];
while ($row = $result->fetch_assoc()) {
    $bookings[] = $row;
}

$stmt->close();
$conn->close();

echo json_encode($bookings);
exit();
?>