<?php
// Suppress connection errors (@ suppressor) — safe for homepage
$latest_posts  = [];
$offer_coupons = [];

$conn = @new mysqli("localhost", "root", "", "ranjancab");
if (!$conn->connect_error) {
    $conn->set_charset("utf8mb4");

    // Blog posts
    $blog_res = $conn->query(
        "SELECT title, slug, excerpt, created_at
         FROM blogs WHERE status = 'published'
         ORDER BY created_at DESC LIMIT 3"
    );
    if ($blog_res) {
        while ($p = $blog_res->fetch_assoc()) $latest_posts[] = $p;
    }

    // Coupon codes — only if table exists (safe before migration)
    $tbl = $conn->query("SHOW TABLES LIKE 'coupon_codes'");
    if ($tbl && $tbl->num_rows > 0) {
        $cpn_res = $conn->query(
            "SELECT code, description, discount_percent FROM coupon_codes
             WHERE is_active = 1
               AND (valid_from  IS NULL OR valid_from  <= CURDATE())
               AND (valid_until IS NULL OR valid_until >= CURDATE())
               AND (max_usage = 0 OR usage_count < max_usage)
             ORDER BY id"
        );
        if ($cpn_res) {
            while ($r = $cpn_res->fetch_assoc()) $offer_coupons[] = $r;
        }
    }

    $conn->close();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>RanjanCabs | Reliable Taxi Booking</title>
    <link rel="stylesheet" href="style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        .hero-section {
            min-height: auto;
            padding: 112px 0 46px;
            background: url('https://images.unsplash.com/photo-1503376780353-7e6692767b70?q=80&w=1920') no-repeat center center/cover;
            align-items: stretch;
        }
        .hero-overlay {
            background: linear-gradient(115deg, rgba(12,18,32,0.92) 0%, rgba(12,18,32,0.76) 52%, rgba(12,18,32,0.42) 100%);
        }
        .hero-container { align-items: center; gap: 36px; }
        .hero-text h1 { font-size: clamp(38px,6vw,68px); line-height: 1.05; margin-bottom: 18px; }
        .hero-text p  { font-size: 17px; color: #e2e8f0; }
        .hero-pills   { display: flex; flex-wrap: wrap; gap: 10px; margin: 24px 0; }
        .hero-pill {
            display: inline-flex; align-items: center; gap: 8px; color: #fff;
            background: rgba(255,255,255,0.12); border: 1px solid rgba(255,255,255,0.18);
            padding: 9px 12px; border-radius: 999px; font-size: 13px; font-weight: 700;
        }
        .hero-stats { display: grid; grid-template-columns: repeat(3,minmax(0,1fr)); gap: 12px; max-width: 540px; }
        .hero-stat {
            background: rgba(255,255,255,0.09); border: 1px solid rgba(255,255,255,0.14);
            border-radius: 8px; padding: 14px; color: #fff;
        }
        .hero-stat strong { display: block; color: var(--primary-color); font-size: 24px; }
        .hero-stat span   { font-size: 12px; color: #cbd5e1; font-weight: 700; text-transform: uppercase; }
        .booking-card { border: 1px solid rgba(255,255,255,0.24); }
        .trip-tab { color: var(--secondary-color); border-color: #e5e7eb; background: #f8fafc; }
        .trip-tab.active { background: var(--secondary-color); color: var(--primary-color); border-color: var(--secondary-color); }

        /* Shared section styles */
        .page-section { padding: 70px 20px; }
        .section-inner { max-width: 1200px; margin: 0 auto; }
        .section-kicker { color: #b7791f; font-size: 12px; font-weight: 900; text-transform: uppercase; margin-bottom: 8px; }
        .section-title  { font-size: clamp(28px,4vw,42px); color: #172033; margin-bottom: 12px; line-height: 1.15; }
        .section-copy   { max-width: 680px; color: #64748b; line-height: 1.7; font-size: 16px; }

        /* Services */
        .service-grid {
            display: grid; grid-template-columns: repeat(3,minmax(0,1fr));
            gap: 18px; margin-top: 30px;
        }
        .service-item, .review-card, .blog-card {
            background: #fff; border: 1px solid #e2e8f0; border-radius: 8px;
            padding: 22px; box-shadow: 0 12px 30px rgba(15,23,42,0.05);
        }
        .service-icon {
            width: 44px; height: 44px; border-radius: 8px; background: #fff7df;
            color: #b7791f; display: grid; place-items: center; font-size: 20px; margin-bottom: 16px;
        }
        .service-item h3, .blog-card h3 { color: #172033; margin-bottom: 8px; font-size: 19px; }
        .service-item p, .blog-card p, .review-card p { color: #64748b; line-height: 1.65; font-size: 14px; }

        /* Reviews */
        .reviews-section { background: #172033; color: #fff; }
        .reviews-section .section-title { color: #fff; }
        .reviews-section .section-copy  { color: #cbd5e1; }
        .review-grid {
            display: grid; grid-template-columns: repeat(3,minmax(0,1fr));
            gap: 18px; margin-top: 30px;
        }
        .review-card { background: rgba(255,255,255,0.08); border-color: rgba(255,255,255,0.14); box-shadow: none; }
        .review-card p { color: #e2e8f0; }
        .review-stars { color: var(--primary-color); margin-bottom: 14px; font-size: 14px; }
        .review-person { display: flex; align-items: center; gap: 12px; margin-top: 18px; }
        .avatar {
            width: 40px; height: 40px; border-radius: 50%; background: var(--primary-color);
            color: #172033; display: grid; place-items: center; font-weight: 900;
        }
        .review-person strong { display: block; color: #fff; }
        .review-person span   { color: #cbd5e1; font-size: 12px; }

        /* Coupon offers */
        .offers-section { background: #fffbeb; }
        .coupon-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(min(100%, 260px), 1fr));
            gap: 18px; margin-top: 28px;
        }
        .coupon-card {
            background: #fff; border: 2px dashed #f59e0b; border-radius: 12px;
            padding: 24px; box-shadow: 0 4px 16px rgba(245,158,11,0.1);
        }
        .coupon-label { font-size: 11px; font-weight: 900; text-transform: uppercase; color: #b7791f; margin-bottom: 8px; letter-spacing: 1px; }
        .coupon-code  { font-size: 26px; font-weight: 900; color: #172033; letter-spacing: 3px; font-family: monospace; margin-bottom: 6px; }
        .coupon-pct   { font-size: 20px; font-weight: 800; color: #16a34a; margin-bottom: 8px; }
        .coupon-desc  { font-size: 13px; color: #64748b; margin: 0 0 16px; line-height: 1.5; }
        .btn-copy {
            background: #172033; color: #fff; border: none;
            padding: 10px 18px; border-radius: 6px; font-weight: 700;
            font-size: 13px; cursor: pointer; width: 100%; transition: background 0.2s;
        }
        .btn-copy:hover { background: #0f172a; }

        /* Blog */
        .blog-grid { display: grid; grid-template-columns: repeat(3,minmax(0,1fr)); gap: 18px; margin-top: 30px; }
        .blog-date { color: #b7791f; font-size: 12px; font-weight: 900; text-transform: uppercase; margin-bottom: 10px; }
        .blog-link { display: inline-flex; align-items: center; gap: 8px; margin-top: 14px; color: #172033; font-weight: 800; text-decoration: none; }

        /* Footer */
        .site-footer { background: #101827; color: #cbd5e1; padding: 46px 20px 22px; }
        .footer-grid { max-width: 1200px; margin: 0 auto; display: grid; grid-template-columns: 1.4fr 1fr 1fr 1fr; gap: 24px; }
        .footer-brand { color: #fff; font-size: 24px; font-weight: 900; margin-bottom: 10px; }
        .footer-brand span { color: var(--primary-color); }
        .footer-col h3 { color: #fff; font-size: 15px; margin-bottom: 12px; }
        .footer-col p, .footer-col a { color: #cbd5e1; text-decoration: none; display: block; margin-bottom: 8px; font-size: 14px; line-height: 1.6; }
        .footer-col a:hover { color: var(--primary-color); }
        .footer-bottom { max-width: 1200px; margin: 28px auto 0; border-top: 1px solid rgba(255,255,255,0.1); padding-top: 18px; font-size: 13px; color: #94a3b8; }

        /* Responsive */
        @media (max-width: 900px) {
            .hero-stats, .service-grid, .review-grid, .blog-grid, .footer-grid { grid-template-columns: 1fr; }
        }
        @media (max-width: 600px) {
            .page-section { padding: 48px 16px; }
        }
    </style>
</head>
<body>
<?php include 'header1.php'; ?>

<!-- ===== HERO + BOOKING FORM ===== -->
<main class="hero-section">
    <div class="hero-overlay"></div>
    <div class="hero-container">
        <div class="hero-text">
            <h1>Book clean, reliable cabs across your city routes.</h1>
            <p>RanjanCabs connects customers with verified drivers, transparent fares, OTP-secured trips, and fast intercity ride dispatch.</p>
            <div class="hero-pills">
                <span class="hero-pill"><i class="fa-solid fa-shield-halved"></i> Verified drivers</span>
                <span class="hero-pill"><i class="fa-solid fa-receipt"></i> Invoice-ready rides</span>
                <span class="hero-pill"><i class="fa-solid fa-tag"></i> Coupon discounts</span>
            </div>
            <div class="hero-stats">
                <div class="hero-stat"><strong>24/7</strong><span>Booking Desk</span></div>
                <div class="hero-stat"><strong>4.8★</strong><span>Fleet Rating</span></div>
                <div class="hero-stat"><strong>OTP</strong><span>Trip Security</span></div>
            </div>
        </div>

        <div class="booking-card" id="book">
            <h2><i class="fa-solid fa-map-location-dot"></i> Book a Taxi</h2>

            <?php if (isset($_GET['status'])): ?>
                <?php if ($_GET['status'] === 'success'): ?>
                    <p class="alert success"><i class="fa-solid fa-circle-check"></i> Ride booked successfully!</p>
                <?php elseif ($_GET['status'] === 'error'): ?>
                    <p class="alert error">
                        <i class="fa-solid fa-circle-exclamation"></i>
                        <?php
                        $r = htmlspecialchars($_GET['reason'] ?? '');
                        if ($r === 'no_mapped_route') echo 'No route found between these cities.';
                        elseif ($r === 'missing_locations') echo 'Please enter both pickup and drop locations.';
                        else echo 'Error processing booking. Try again.';
                        ?>
                    </p>
                <?php endif; ?>
            <?php endif; ?>

            <?php if (!empty($offer_coupons)): ?>
            <div style="background:#fffbeb; border:1px solid #fde68a; border-radius:6px; padding:10px 12px; margin-bottom:14px; font-size:13px; color:#92400e;">
                <i class="fa-solid fa-tag"></i> <strong>Active offers:</strong>
                <?php foreach ($offer_coupons as $oc): ?>
                    <span style="background:#fff3d0; border-radius:4px; padding:2px 8px; font-family:monospace; font-weight:800; margin-left:4px; cursor:pointer;"
                          onclick="copyCode('<?= htmlspecialchars($oc['code'], ENT_QUOTES) ?>', this)"
                          title="<?= htmlspecialchars($oc['description'] ?? '') ?>">
                        <?= htmlspecialchars($oc['code']) ?>
                    </span>
                <?php endforeach; ?>
                <span style="color:#b7791f; font-size:11px; margin-left:6px;">— Click to copy</span>
            </div>
            <?php endif; ?>

            <div class="trip-type-tabs">
                <button type="button" id="tab-oneway" class="trip-tab active" onclick="updateJourneyLayout('Oneway')">One-Way</button>
                <button type="button" id="tab-roundtrip" class="trip-tab" onclick="updateJourneyLayout('Roundtrip')">Round-Trip</button>
            </div>

            <form action="review.php" method="POST" id="bookingForm" autocomplete="off">
                <input type="hidden" name="trip_type" id="trip_type_input" value="Oneway">

                <div class="input-group">
                    <label for="pickup">Pickup Location</label>
                    <input type="text" id="pickup" name="pickup_location" placeholder="Enter pickup city" required>
                    <div id="pickupSuggest" class="autosuggest-panel"></div>
                    <div id="pickup_custom_container" class="custom-address-field">
                        <label id="pickup_custom_label" for="pickup_manual_address">Specify Address</label>
                        <input type="text" id="pickup_manual_address" placeholder="House no, landmark, area">
                    </div>
                </div>

                <div class="input-group">
                    <label for="drop">Drop Location</label>
                    <input type="text" id="drop" name="drop_location" placeholder="Enter destination city" required>
                    <div id="dropSuggest" class="autosuggest-panel"></div>
                    <div id="drop_custom_container" class="custom-address-field">
                        <label id="drop_custom_label" for="drop_manual_address">Specify Address</label>
                        <input type="text" id="drop_manual_address" placeholder="House no, landmark, area">
                    </div>
                </div>

                <div class="row">
                    <div class="input-group">
                        <label for="date">Pickup Date</label>
                        <input type="date" id="date" name="pickup_date" required>
                    </div>
                    <div class="input-group">
                        <label for="time">Pickup Time</label>
                        <input type="time" id="time" name="pickup_time" required>
                    </div>
                </div>

                <div id="return_date_wrapper" class="input-group" style="display:none;">
                    <label for="return_date">Return Date</label>
                    <input type="date" id="return_date" name="return_date">
                </div>

                <div class="input-group">
                    <label for="car_type">Select Vehicle Class</label>
                    <select id="car_type" name="car_type" required>
                        <option value="" disabled selected>Choose a car type</option>
                        <option value="Hatchback">Hatchback</option>
                        <option value="Sedan">Sedan</option>
                        <option value="SUV">SUV</option>
                    </select>
                </div>

                <button type="submit" class="submit-btn">Check Fare &amp; Review Details</button>
            </form>
        </div>
    </div>
</main>

<!-- ===== SERVICES ===== -->
<section class="page-section" id="services">
    <div class="section-inner">
        <div class="section-kicker">Why Choose Us</div>
        <h2 class="section-title">A taxi workflow built for real daily travel.</h2>
        <p class="section-copy">Transparent fares, verified drivers, OTP-secured trips, downloadable invoices, and coupon discounts — all in one platform.</p>
        <div class="service-grid">
            <div class="service-item">
                <div class="service-icon"><i class="fa-solid fa-route"></i></div>
                <h3>Mapped Intercity Routes</h3>
                <p>Choose supported pickup and drop corridors with distance-backed fare calculation before confirming the ride.</p>
            </div>
            <div class="service-item">
                <div class="service-icon"><i class="fa-solid fa-user-shield"></i></div>
                <h3>Verified Fleet</h3>
                <p>Drivers submit licence, Aadhaar, and RC records. Admins verify statutory readiness before live assignments.</p>
            </div>
            <div class="service-item">
                <div class="service-icon"><i class="fa-solid fa-file-invoice"></i></div>
                <h3>Invoices &amp; Receipts</h3>
                <p>Customers can track bookings, view OTP, cancel rides, and download payment invoices from their dashboard.</p>
            </div>
        </div>
    </div>
</section>

<!-- ===== REVIEWS ===== -->
<section class="page-section reviews-section" id="reviews">
    <div class="section-inner">
        <div class="section-kicker">Customer Reviews</div>
        <h2 class="section-title">Reliable rides, calmer travel days.</h2>
        <p class="section-copy">A few words from passengers who use RanjanCabs for city and intercity trips.</p>
        <div class="review-grid">
            <div class="review-card">
                <div class="review-stars"><i class="fa-solid fa-star"></i><i class="fa-solid fa-star"></i><i class="fa-solid fa-star"></i><i class="fa-solid fa-star"></i><i class="fa-solid fa-star"></i></div>
                <p>The fare review step made the booking clear before payment. Driver details and OTP were easy to find.</p>
                <div class="review-person"><div class="avatar">R</div><div><strong>Rahul Mehta</strong><span>Bhopal to Indore</span></div></div>
            </div>
            <div class="review-card">
                <div class="review-stars"><i class="fa-solid fa-star"></i><i class="fa-solid fa-star"></i><i class="fa-solid fa-star"></i><i class="fa-solid fa-star"></i><i class="fa-solid fa-star-half-stroke"></i></div>
                <p>I liked that the dashboard showed the OTP and driver vehicle number in one place. Very practical.</p>
                <div class="review-person"><div class="avatar">P</div><div><strong>Priya Singh</strong><span>Airport pickup</span></div></div>
            </div>
            <div class="review-card">
                <div class="review-stars"><i class="fa-solid fa-star"></i><i class="fa-solid fa-star"></i><i class="fa-solid fa-star"></i><i class="fa-solid fa-star"></i><i class="fa-solid fa-star"></i></div>
                <p>The invoice download helped with office reimbursement. Used the coupon code too — saved money.</p>
                <div class="review-person"><div class="avatar">A</div><div><strong>Ankit Jain</strong><span>Business travel</span></div></div>
            </div>
        </div>
    </div>
</section>

<!-- ===== COUPON OFFERS ===== -->
<section class="page-section offers-section" id="offers">
    <div class="section-inner">
        <div class="section-kicker">Limited Offers</div>
        <h2 class="section-title">Save on your next ride.</h2>
        <p class="section-copy">Use these coupon codes at checkout (Step 2) to get a discount on your fare. Click any code to copy it.</p>

        <?php if (!empty($offer_coupons)): ?>
        <div class="coupon-grid">
            <?php foreach ($offer_coupons as $offer): ?>
            <div class="coupon-card">
                <div class="coupon-label"><i class="fa-solid fa-tag"></i> Promo Code</div>
                <div class="coupon-code"><?= htmlspecialchars($offer['code']) ?></div>
                <div class="coupon-pct">Save <?= number_format(floatval($offer['discount_percent']), 0) ?>% OFF</div>
                <p class="coupon-desc"><?= htmlspecialchars($offer['description'] ?? '') ?></p>
                <button class="btn-copy"
                        onclick="copyCode('<?= htmlspecialchars($offer['code'], ENT_QUOTES) ?>', this)">
                    <i class="fa-solid fa-copy"></i> Copy Code
                </button>
            </div>
            <?php endforeach; ?>
        </div>
        <?php else: ?>
        <div style="background:#fff; border:1px solid #fde68a; border-radius:8px; padding:24px; margin-top:20px; text-align:center; color:#92400e;">
            <i class="fa-solid fa-ticket" style="font-size:28px; margin-bottom:10px; display:block;"></i>
            New promotional offers coming soon. Check back here for discount codes.
        </div>
        <?php endif; ?>
    </div>
</section>

<!-- ===== BLOG ===== -->
<section class="page-section" id="blog">
    <div class="section-inner">
        <div class="section-kicker">Travel Notes</div>
        <h2 class="section-title">Latest from the RanjanCabs blog.</h2>
        <p class="section-copy">Useful updates, travel planning notes, and cab booking guidance from the operations team.</p>
        <div class="blog-grid">
            <?php if (!empty($latest_posts)): ?>
                <?php foreach ($latest_posts as $post): ?>
                    <article class="blog-card">
                        <div class="blog-date"><?= date("d M Y", strtotime($post['created_at'])) ?></div>
                        <h3><?= htmlspecialchars($post['title']) ?></h3>
                        <p><?= htmlspecialchars($post['excerpt']) ?></p>
                        <a class="blog-link" href="blog.php?slug=<?= urlencode($post['slug']) ?>">
                            Read More <i class="fa-solid fa-arrow-right"></i>
                        </a>
                    </article>
                <?php endforeach; ?>
            <?php else: ?>
                <article class="blog-card">
                    <h3>Blog posts coming soon</h3>
                    <p>The admin team can publish customer travel updates from the admin dashboard.</p>
                    <a class="blog-link" href="blog.php">Visit Blog <i class="fa-solid fa-arrow-right"></i></a>
                </article>
            <?php endif; ?>
        </div>
    </div>
</section>

<!-- ===== FOOTER ===== -->
<footer class="site-footer" id="contact">
    <div class="footer-grid">
        <div class="footer-col">
            <div class="footer-brand"><i class="fa-solid fa-taxi"></i> Ranjan<span>Cabs</span></div>
            <p>Reliable cab booking with verified drivers, clear fares, live dashboards, and invoice-ready trip records.</p>
        </div>
        <div class="footer-col">
            <h3>Quick Links</h3>
            <a href="index.php#book">Book a Taxi</a>
            <a href="customer_login.php">Customer Login</a>
            <a href="driver_login.php">Driver Login</a>
            <a href="blog.php">Blog</a>
        </div>
        <div class="footer-col">
            <h3>Services</h3>
            <p>One-way rides</p>
            <p>Round trips</p>
            <p>Intercity routes</p>
            <p>Verified fleet dispatch</p>
        </div>
        <div class="footer-col">
            <h3>Contact</h3>
            <p><i class="fa-solid fa-location-dot"></i> Bhopal, Madhya Pradesh</p>
            <p><i class="fa-solid fa-phone"></i> +91 89591 58195</p>
            <p><i class="fa-solid fa-envelope"></i> support@ranjancabs.local</p>
        </div>
    </div>
    <div class="footer-bottom">Copyright <?= date('Y') ?> RanjanCabs. All rights reserved.</div>
</footer>

<script>
/* ---- Mobile nav ---- */
const mobileMenuBtn = document.getElementById('mobileMenuBtn');
const navMenu = document.getElementById('navMenu');
if (mobileMenuBtn && navMenu) {
    mobileMenuBtn.addEventListener('click', function() { navMenu.classList.toggle('active'); });
}

/* ---- Date min ---- */
const dateInput = document.getElementById('date');
const returnDateInput = document.getElementById('return_date');
const today = new Date();
const todayStr = today.getFullYear() + '-'
    + String(today.getMonth() + 1).padStart(2, '0') + '-'
    + String(today.getDate()).padStart(2, '0');
dateInput.min = todayStr;

/* ---- Trip type tabs ---- */
function updateJourneyLayout(type) {
    document.getElementById('tab-oneway').classList.toggle('active', type === 'Oneway');
    document.getElementById('tab-roundtrip').classList.toggle('active', type === 'Roundtrip');
    document.getElementById('trip_type_input').value = type;
    const wrap = document.getElementById('return_date_wrapper');
    if (type === 'Roundtrip') {
        wrap.style.display = 'block';
        returnDateInput.setAttribute('required', 'required');
        returnDateInput.min = dateInput.value || todayStr;
    } else {
        wrap.style.display = 'none';
        returnDateInput.removeAttribute('required');
    }
}

/* ---- Custom address sub-field ---- */
function evalCustom(inputEl, containerId, fieldId, labelId) {
    var show = inputEl.value.includes('(Other Location)');
    var container = document.getElementById(containerId);
    var field = document.getElementById(fieldId);
    var label = document.getElementById(labelId);
    if (show) {
        var city = inputEl.value.split('(')[0].trim();
        label.innerText = 'Specify address in ' + city;
        container.style.display = 'block';
        field.setAttribute('required', 'required');
    } else {
        container.style.display = 'none';
        field.removeAttribute('required');
        field.value = '';
    }
}
document.getElementById('pickup').addEventListener('input', function() {
    evalCustom(this, 'pickup_custom_container', 'pickup_manual_address', 'pickup_custom_label');
});
document.getElementById('drop').addEventListener('input', function() {
    evalCustom(this, 'drop_custom_container', 'drop_manual_address', 'drop_custom_label');
});

/* ---- Merge custom address on submit ---- */
document.getElementById('bookingForm').addEventListener('submit', function() {
    var pInput  = document.getElementById('pickup');
    var pManual = document.getElementById('pickup_manual_address');
    var dInput  = document.getElementById('drop');
    var dManual = document.getElementById('drop_manual_address');
    if (pInput.value.includes('(Other Location)') && pManual.value.trim()) {
        pInput.value = pInput.value.split('(')[0].trim() + ', ' + pManual.value.trim();
    }
    if (dInput.value.includes('(Other Location)') && dManual.value.trim()) {
        dInput.value = dInput.value.split('(')[0].trim() + ', ' + dManual.value.trim();
    }
});

/* ---- Location autocomplete ---- */
var masterLocations = [];
fetch('get_routes.php')
    .then(function(r) { return r.json(); })
    .then(function(data) { masterLocations = data.locations || []; })
    .catch(function() {});

function setupAutocomplete(inputId, panelId, containerId, fieldId, labelId) {
    var input = document.getElementById(inputId);
    var panel = document.getElementById(panelId);
    input.addEventListener('input', function() {
        var q = this.value.toLowerCase().trim();
        panel.innerHTML = '';
        if (!q) { panel.style.display = 'none'; return; }
        var matches = masterLocations.filter(function(l) { return l.toLowerCase().includes(q); });
        if (matches.length) {
            matches.forEach(function(m) {
                var div = document.createElement('div');
                div.className = 'suggest-item';
                div.innerHTML = '<i class="fa-solid fa-location-dot"></i> <span>' + m + '</span>';
                div.addEventListener('click', function() {
                    input.value = m;
                    panel.style.display = 'none';
                    evalCustom(input, containerId, fieldId, labelId);
                });
                panel.appendChild(div);
            });
            panel.style.display = 'block';
        } else {
            panel.style.display = 'none';
        }
    });
    document.addEventListener('click', function(e) {
        if (!input.contains(e.target)) panel.style.display = 'none';
    });
}
setupAutocomplete('pickup', 'pickupSuggest', 'pickup_custom_container', 'pickup_manual_address', 'pickup_custom_label');
setupAutocomplete('drop',   'dropSuggest',   'drop_custom_container',   'drop_manual_address',   'drop_custom_label');

/* ---- Copy coupon code ---- */
function copyCode(code, btn) {
    navigator.clipboard.writeText(code).then(function() {
        var orig = btn.innerHTML;
        btn.innerHTML = '<i class="fa-solid fa-check"></i> Copied!';
        btn.style.background = '#16a34a';
        setTimeout(function() { btn.innerHTML = orig; btn.style.background = btn.classList.contains('btn-copy') ? '#172033' : ''; }, 2000);
    }).catch(function() {
        window.prompt('Copy this code:', code);
    });
}
</script>
</body>
</html>
