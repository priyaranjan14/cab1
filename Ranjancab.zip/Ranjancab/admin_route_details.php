<?php
// Deployed System Routes Module
if (!defined('ADMIN_SHIELD_ACTIVE')) { die('Direct system access restricted.'); }
?>
<div class="data-table-frame" style="border-top: 4px solid #10b981;">
    <h3 style="margin: 0 0 20px 0; color: #0f172a; font-size: 16px;"><i class="fa-solid fa-route" style="color:#10b981;"></i> Established Network Transit Routes</h3>
    <table class="transit-table">
        <thead>
            <tr>
                <th>Route ID</th>
                <th>Pickup Point Station</th>
                <th>Drop Target Point</th>
                <th>Estimated Metric Distance</th>
            </tr>
        </thead>
        <tbody>
            <?php if($route_result && $route_result->num_rows > 0): ?>
                <?php while($r_row = $route_result->fetch_assoc()): ?>
                    <tr>
                        <td><code>#RT-<?php echo htmlspecialchars($r_row['id']); ?></code></td>
                        <td><strong><?php echo htmlspecialchars($r_row['pickup_point']); ?></strong></td>
                        <td><strong><?php echo htmlspecialchars($r_row['drop_point']); ?></strong></td>
                        <td><span style="font-weight: 600; color:#065f46;"><?php echo htmlspecialchars($r_row['estimated_distance']); ?> km</span></td>
                    </tr>
                <?php endwhile; ?>
            <?php else: ?>
                <tr><td colspan="4" style="text-align: center; color: #94a3b8; padding: 25px 0;">No active system paths mapped.</td></tr>
            <?php endif; ?>
        </tbody>
    </table>
</div>