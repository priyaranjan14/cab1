<?php
// ── PHP helper functions — must be defined BEFORE they are called ───────────

function buildDriverHTML($booking) {
    $html  = '<div class="driver-assigned">';
    $html .= '<div class="driver-header">';
    $html .= '<div class="driver-avatar"><i class="fa-solid fa-user-tie"></i></div>';
    $html .= '<div>';
    $html .= '<div class="driver-name-line">' . htmlspecialchars($booking['driver_name']) . '</div>';
    $html .= '<div class="driver-sub" style="color:#16a34a;font-weight:700;"><i class="fa-solid fa-circle-check"></i> Driver Assigned</div>';
    $html .= '</div></div>';
    $html .= '<div class="driver-details">';
    $html .= '<div class="driver-detail-item"><small>Phone</small><strong>' . htmlspecialchars($booking['driver_phone']) . '</strong></div>';
    $html .= '<div class="driver-detail-item"><small>Vehicle No.</small><strong style="font-family:monospace;">' . htmlspecialchars($booking['vehicle_no']) . '</strong></div>';
    $html .= '<div class="driver-detail-item"><small>Model</small><strong>' . htmlspecialchars($booking['model_name']) . '</strong></div>';
    $rating = floatval($booking['star_rating'] ?? 5);
    $stars  = str_repeat('★', (int)round($rating)) . str_repeat('☆', 5 - (int)round($rating));
    $html .= '<div class="driver-detail-item"><small>Rating</small><strong style="color:#f59e0b;">' . $stars . ' ' . number_format($rating, 1) . '</strong></div>';
    $html .= '</div></div>';
    return $html;
}

function buildWaitingHTML() {
    return '<div class="driver-waiting">
        <div><span class="pulse-ring"></span><strong style="color:#92400e;">Finding your driver...</strong></div>
        <p>Your booking is live. A nearby verified driver will accept it shortly.</p>
        <small id="poll-status">Checking every 5 seconds automatically.</small>
        <div class="poll-bar"><span class="poll-dot"></span> Live — updating automatically</div>
    </div>';
}

// ── Database & booking fetch ─────────────────────────────────────────────────
$conn = new mysqli("localhost", "root", "", "ranjancab");
if ($conn->connect_error) {
    die("Database Connection Failed: " . $conn->connect_error);
}
$conn->set_charset("utf8mb4");

$booking_ref_no = isset($_GET['ref']) ? trim($_GET['ref']) : '';
$booking = null;

if (!empty($booking_ref_no)) {
    $stmt = $conn->prepare(
        "SELECT b.id, b.customer_name, b.customer_phone, b.booking_ref_no, b.trip_type,
                b.pickup_location, b.drop_location, b.pickup_date, b.return_date,
                b.pickup_time, b.car_type, b.distance, b.total_fare, b.discounted_fare,
                b.advance_paid, b.driver_balance, b.coupon_code, b.coupon_discount,
                b.otp_code, b.assigned_driver_id, b.booking_flag,
                f.driver_name, f.mobile_number AS driver_phone,
                f.vehicle_number AS vehicle_no, f.model_name, f.star_rating
         FROM bookings b
         LEFT JOIN fleet f ON b.assigned_driver_id = f.id
         WHERE b.booking_ref_no = ?
         LIMIT 1"
    );
    $stmt->bind_param("s", $booking_ref_no);
    $stmt->execute();
    $booking = $stmt->get_result()->fetch_assoc();
    $stmt->close();
}

if (!$booking) {
    echo "<div style='max-width:480px;margin:100px auto;text-align:center;font-family:sans-serif;padding:24px;border:1px solid #e2e8f0;border-radius:8px;'>
            <h3 style='color:#b91c1c;'>Booking Not Found</h3>
            <p style='color:#64748b;'>The reference is missing or invalid.</p>
            <a href='index.php' style='display:inline-block;padding:10px 20px;background:#172033;color:#fff;text-decoration:none;border-radius:6px;'>Return Home</a>
          </div>";
    exit;
}

// Is this a new customer?
$is_new_customer = true;
$h_stmt = $conn->prepare("SELECT COUNT(*) AS cnt FROM bookings WHERE customer_phone = ?");
$h_stmt->bind_param("s", $booking['customer_phone']);
$h_stmt->execute();
$h_stmt->bind_result($cnt);
$h_stmt->fetch();
$h_stmt->close();
if ($cnt > 1) $is_new_customer = false;

$conn->close();

$discounted_fare  = floatval($booking['discounted_fare'] ?: $booking['total_fare']);
$coupon_applied   = !empty($booking['coupon_code']);
$driver_assigned  = !empty($booking['assigned_driver_id']) && !empty($booking['driver_name']);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Booking Confirmed | RanjanCabs</title>
    <link rel="stylesheet" href="style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        body { background: #f8fafc; }

        .confirm-wrap {
            max-width: 1100px;
            margin: 0 auto;
            padding: 50px 20px 80px;
        }

        /* Success banner */
        .success-banner { text-align: center; margin-bottom: 36px; }
        .success-banner .icon { font-size: 64px; color: #22c55e; }
        .success-banner h1 { font-size: clamp(26px,5vw,42px); color: #172033; margin: 14px 0 8px; }
        .success-banner p  { color: #64748b; font-size: 15px; }

        .ref-badge {
            display: inline-block;
            background: linear-gradient(135deg,#f59e0b,#f97316);
            color: #fff;
            padding: 10px 22px;
            border-radius: 24px;
            font-weight: 800;
            font-size: 14px;
            margin-bottom: 30px;
            letter-spacing: 0.5px;
        }

        /* Cards */
        .cards-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(min(100%,440px),1fr));
            gap: 22px;
        }
        .card {
            background: #fff;
            border: 1px solid #e2e8f0;
            border-radius: 10px;
            padding: 24px;
            box-shadow: 0 6px 20px rgba(15,23,42,0.05);
        }
        .card-title {
            font-size: 16px;
            font-weight: 800;
            color: #172033;
            display: flex;
            align-items: center;
            gap: 10px;
            padding-bottom: 12px;
            border-bottom: 2px solid #f59e0b;
            margin-bottom: 16px;
        }
        .card-title i { color: #f59e0b; }

        .info-row {
            display: flex;
            justify-content: space-between;
            align-items: flex-start;
            padding: 10px 0;
            border-bottom: 1px solid #f1f5f9;
            font-size: 14px;
            gap: 10px;
        }
        .info-row:last-child { border-bottom: none; }
        .info-lbl { color: #64748b; font-weight: 600; flex-shrink: 0; }
        .info-val { color: #172033; font-weight: 700; text-align: right; }

        /* Driver section */
        .driver-waiting {
            background: #fff7ed;
            border: 1px solid #fed7aa;
            border-radius: 8px;
            padding: 20px;
            text-align: center;
        }
        .driver-waiting .pulse-ring {
            display: inline-block;
            width: 14px; height: 14px;
            background: #f59e0b;
            border-radius: 50%;
            margin-right: 8px;
            animation: pulse 1.5s infinite;
            vertical-align: middle;
        }
        @keyframes pulse {
            0%   { box-shadow: 0 0 0 0 rgba(245,158,11,0.6); }
            70%  { box-shadow: 0 0 0 10px rgba(245,158,11,0); }
            100% { box-shadow: 0 0 0 0 rgba(245,158,11,0); }
        }
        .driver-waiting p { color: #92400e; font-size: 14px; font-weight: 600; margin: 10px 0 4px; }
        .driver-waiting small { color: #b45309; font-size: 12px; }

        .driver-assigned {
            background: #f0fdf4;
            border: 1px solid #bbf7d0;
            border-radius: 8px;
            padding: 16px;
        }
        .driver-assigned .driver-header {
            display: flex;
            align-items: center;
            gap: 12px;
            margin-bottom: 12px;
        }
        .driver-avatar {
            width: 46px; height: 46px;
            background: #172033;
            color: #f59e0b;
            border-radius: 50%;
            display: flex; align-items: center; justify-content: center;
            font-size: 20px; font-weight: 900; flex-shrink: 0;
        }
        .driver-name-line { font-size: 17px; font-weight: 800; color: #172033; }
        .driver-sub      { font-size: 13px; color: #64748b; margin-top: 2px; }
        .driver-details  { display: grid; grid-template-columns: 1fr 1fr; gap: 10px; margin-top: 10px; }
        .driver-detail-item { background: #fff; border: 1px solid #dcfce7; border-radius: 6px; padding: 10px; }
        .driver-detail-item small { display: block; font-size: 11px; font-weight: 800; text-transform: uppercase; color: #64748b; margin-bottom: 4px; }
        .driver-detail-item strong { font-size: 14px; color: #172033; }

        /* Payment table */
        .pay-table { width: 100%; border-collapse: collapse; font-size: 14px; margin-top: 16px; }
        .pay-table td { padding: 10px 12px; }
        .pay-table tr { border-bottom: 1px solid #f1f5f9; }
        .pay-table tr:last-child { border-bottom: none; border-top: 2px solid #cbd5e1; font-weight: 800; }
        .pay-table .lbl { color: #64748b; font-weight: 600; }
        .pay-table .val { text-align: right; font-weight: 700; color: #172033; }
        .pay-table .green { color: #16a34a; }
        .pay-table .amber { color: #b45309; }

        /* OTP */
        .otp-box {
            background: linear-gradient(135deg,#eff6ff,#f0fdf4);
            border: 2px solid #3b82f6;
            border-radius: 10px;
            padding: 22px;
            text-align: center;
            margin-bottom: 18px;
        }
        .otp-box h3    { font-size: 13px; color: #1e40af; font-weight: 800; margin-bottom: 10px; }
        .otp-number    { font-size: 42px; font-weight: 900; color: #1d4ed8; letter-spacing: 10px; font-family: monospace; }
        .otp-note      { font-size: 12px; color: #1e40af; margin-top: 10px; }

        /* Credentials */
        .cred-box {
            background: #fffbeb;
            border: 1px solid #fde68a;
            border-radius: 8px;
            padding: 16px;
        }
        .cred-box h3 { font-size: 13px; color: #92400e; font-weight: 800; margin: 0 0 10px; }
        .cred-row {
            display: flex;
            justify-content: space-between;
            padding: 8px 0;
            border-bottom: 1px dashed #fde68a;
            font-size: 13px;
        }
        .cred-row:last-child { border-bottom: none; }
        .cred-row strong { color: #78350f; }
        .cred-row code {
            background: #fef08a;
            padding: 3px 8px;
            border-radius: 4px;
            font-family: monospace;
            font-weight: 700;
        }

        /* Action buttons */
        .action-row {
            display: flex;
            flex-wrap: wrap;
            gap: 14px;
            margin-top: 32px;
        }
        .btn-primary {
            flex: 1; min-width: 180px;
            background: linear-gradient(135deg,#f59e0b,#f97316);
            color: #fff; padding: 14px 20px; font-size: 15px; font-weight: 700;
            border-radius: 6px; text-decoration: none; text-align: center;
            border: none; cursor: pointer; transition: all 0.2s;
        }
        .btn-primary:hover { opacity: 0.9; transform: translateY(-1px); }
        .btn-secondary {
            flex: 1; min-width: 180px;
            background: #f1f5f9; color: #334155;
            border: 1px solid #cbd5e1; padding: 14px 20px; font-size: 15px;
            font-weight: 700; border-radius: 6px; text-decoration: none;
            text-align: center; cursor: pointer; transition: background 0.2s;
        }
        .btn-secondary:hover { background: #e2e8f0; }

        /* Polling status bar */
        .poll-bar {
            display: flex;
            align-items: center;
            gap: 8px;
            font-size: 12px;
            color: #64748b;
            margin-top: 10px;
            justify-content: center;
        }
        .poll-dot {
            width: 8px; height: 8px;
            background: #22c55e;
            border-radius: 50%;
            animation: pulse 1.5s infinite;
        }

        @media (max-width: 600px) {
            .confirm-wrap { padding: 28px 14px 60px; }
            .action-row { flex-direction: column; }
            .btn-primary, .btn-secondary { min-width: 100%; flex: none; }
            .driver-details { grid-template-columns: 1fr; }
            .otp-number { font-size: 32px; letter-spacing: 6px; }
        }

        @media print {
            .no-print { display: none !important; }
        }

        /* ── Footer ── */
        .site-footer {
            background: #101827;
            color: #cbd5e1;
            padding: 46px 20px 22px;
            margin-top: 60px;
        }
        .footer-grid {
            max-width: 1200px;
            margin: 0 auto;
            display: grid;
            grid-template-columns: 1.4fr 1fr 1fr 1fr;
            gap: 24px;
        }
        .footer-brand {
            color: #fff;
            font-size: 22px;
            font-weight: 900;
            margin-bottom: 10px;
        }
        .footer-brand span { color: #f59e0b; }
        .footer-col h3 {
            color: #fff;
            font-size: 14px;
            font-weight: 700;
            margin-bottom: 12px;
        }
        .footer-col p,
        .footer-col a {
            color: #94a3b8;
            text-decoration: none;
            display: block;
            margin-bottom: 7px;
            font-size: 13px;
            line-height: 1.6;
        }
        .footer-col a:hover { color: #f59e0b; }
        .footer-bottom {
            max-width: 1200px;
            margin: 24px auto 0;
            border-top: 1px solid rgba(255,255,255,0.08);
            padding-top: 16px;
            font-size: 12px;
            color: #64748b;
            text-align: center;
        }
        @media (max-width: 768px) {
            .footer-grid { grid-template-columns: 1fr 1fr; gap: 20px; }
        }
        @media (max-width: 480px) {
            .footer-grid { grid-template-columns: 1fr; }
        }
    </style>
</head>
<body>
    <?php include 'header1.php'; ?>

    <div class="confirm-wrap">

        <!-- Success Header -->
        <div class="success-banner">
            <div class="icon"><i class="fa-solid fa-circle-check"></i></div>
            <h1>Booking Confirmed!</h1>
            <p>Your trip is recorded. A verified driver will be assigned shortly.</p>
        </div>
        <div style="text-align:center;">
            <div class="ref-badge">
                <i class="fa-solid fa-ticket"></i> REF: <?php echo htmlspecialchars($booking['booking_ref_no']); ?>
            </div>
        </div>

        <div class="cards-grid">

            <!-- ── Trip Details ── -->
            <div class="card">
                <div class="card-title"><i class="fa-solid fa-route"></i> Trip Summary</div>
                <div class="info-row">
                    <span class="info-lbl">Passenger</span>
                    <span class="info-val"><?php echo htmlspecialchars($booking['customer_name']); ?></span>
                </div>
                <div class="info-row">
                    <span class="info-lbl">Phone</span>
                    <span class="info-val"><?php echo htmlspecialchars($booking['customer_phone']); ?></span>
                </div>
                <div class="info-row">
                    <span class="info-lbl">Trip Type</span>
                    <span class="info-val"><?php echo htmlspecialchars($booking['trip_type']); ?></span>
                </div>
                <div class="info-row">
                    <span class="info-lbl">Pickup</span>
                    <span class="info-val"><?php echo htmlspecialchars($booking['pickup_location']); ?></span>
                </div>
                <div class="info-row">
                    <span class="info-lbl">Drop</span>
                    <span class="info-val"><?php echo htmlspecialchars($booking['drop_location']); ?></span>
                </div>
                <div class="info-row">
                    <span class="info-lbl">Date &amp; Time</span>
                    <span class="info-val">
                        <?php echo date("d M Y", strtotime($booking['pickup_date'])); ?>
                        @ <?php echo htmlspecialchars($booking['pickup_time']); ?>
                    </span>
                </div>
                <?php if (!empty($booking['return_date'])): ?>
                <div class="info-row">
                    <span class="info-lbl">Return Date</span>
                    <span class="info-val"><?php echo date("d M Y", strtotime($booking['return_date'])); ?></span>
                </div>
                <?php endif; ?>
                <div class="info-row">
                    <span class="info-lbl">Vehicle</span>
                    <span class="info-val"><?php echo htmlspecialchars($booking['car_type']); ?></span>
                </div>
                <div class="info-row">
                    <span class="info-lbl">Distance</span>
                    <span class="info-val"><?php echo number_format(floatval($booking['distance']), 0); ?> km</span>
                </div>
            </div>

            <!-- ── Driver & Payment ── -->
            <div class="card">
                <div class="card-title"><i class="fa-solid fa-id-card"></i> Driver &amp; Payment</div>

                <!-- DRIVER SECTION — updated live by JS polling -->
                <div id="driver-section">
                    <?php if ($driver_assigned): ?>
                        <?php echo buildDriverHTML($booking); ?>
                    <?php else: ?>
                        <?php echo buildWaitingHTML(); ?>
                    <?php endif; ?>
                </div>

                <!-- Payment Breakdown — static, no polling needed -->
                <table class="pay-table">
                    <?php if ($coupon_applied): ?>
                    <tr>
                        <td class="lbl"><i class="fa-solid fa-calculator"></i> Estimated Fare</td>
                        <td class="val">₹<?php echo number_format(floatval($booking['total_fare']), 2); ?></td>
                    </tr>
                    <tr>
                        <td class="lbl green"><i class="fa-solid fa-tag"></i> Coupon (<?php echo htmlspecialchars($booking['coupon_code']); ?>)</td>
                        <td class="val green">- ₹<?php echo number_format(floatval($booking['coupon_discount']), 2); ?></td>
                    </tr>
                    <?php endif; ?>
                    <tr>
                        <td class="lbl"><i class="fa-solid fa-receipt"></i>
                            <?php echo $coupon_applied ? 'Fare After Discount' : 'Total Fare'; ?>
                        </td>
                        <td class="val">₹<?php echo number_format($discounted_fare, 2); ?></td>
                    </tr>
                    <tr>
                        <td class="lbl amber"><i class="fa-solid fa-money-bill-wave"></i> Advance Paid (10%)</td>
                        <td class="val amber">₹<?php echo number_format(floatval($booking['advance_paid']), 2); ?></td>
                    </tr>
                    <tr>
                        <td class="lbl"><i class="fa-solid fa-handshake"></i> Balance to Driver (90%)</td>
                        <td class="val">₹<?php echo number_format(floatval($booking['driver_balance']), 2); ?></td>
                    </tr>
                </table>
            </div>

            <!-- ── OTP & Portal Access ── -->
            <div class="card" style="grid-column: 1 / -1;">
                <div class="card-title"><i class="fa-solid fa-shield-halved"></i> OTP &amp; Portal Access</div>

                <div class="otp-box">
                    <h3><i class="fa-solid fa-lock"></i> Share this OTP with your driver at pickup to start the trip</h3>
                    <div class="otp-number"><?php echo htmlspecialchars($booking['otp_code']); ?></div>
                    <p class="otp-note">
                        <i class="fa-solid fa-circle-info"></i>
                        This 4-digit code verifies the trip start. Do not share it with anyone other than your driver.
                    </p>
                </div>

                <div class="cred-box">
                    <h3><i class="fa-solid fa-user-lock"></i> Customer Portal Login</h3>
                    <?php if ($is_new_customer): ?>
                        <p style="font-size:13px;color:#78350f;margin:0 0 10px;">
                            Your account has been created. Use these credentials to log in and track your ride.
                        </p>
                        <div class="cred-row">
                            <strong>Login ID (Mobile)</strong>
                            <code><?php echo htmlspecialchars($booking['customer_phone']); ?></code>
                        </div>
                        <div class="cred-row">
                            <strong>Default Password</strong>
                            <code><?php echo htmlspecialchars($booking['customer_phone']); ?></code>
                        </div>
                        <p style="font-size:12px;color:#b45309;margin:10px 0 0;">
                            <i class="fa-solid fa-triangle-exclamation"></i> Change your password after first login.
                        </p>
                    <?php else: ?>
                        <p style="font-size:13px;color:#78350f;margin:0;">
                            Welcome back! Log in with your existing credentials to manage this booking.
                        </p>
                    <?php endif; ?>
                </div>
            </div>

        </div><!-- /.cards-grid -->

        <div class="action-row no-print">
            <a href="customer_login.php" class="btn-primary">
                <i class="fa-solid fa-gauge"></i> Go to My Dashboard
            </a>
            <a href="index.php" class="btn-secondary">
                <i class="fa-solid fa-home"></i> Back to Home
            </a>
            <button onclick="window.print();" class="btn-secondary">
                <i class="fa-solid fa-print"></i> Print Receipt
            </button>
        </div>

    </div><!-- /.confirm-wrap -->

    <!-- Footer -->
    <footer class="site-footer">
        <div class="footer-grid">
            <div class="footer-col">
                <div class="footer-brand"><i class="fa-solid fa-taxi"></i> Ranjan<span>Cabs</span></div>
                <p>Reliable cab booking with verified drivers, clear fares, live dashboards, and invoice-ready trip records.</p>
            </div>
            <div class="footer-col">
                <h3>Quick Links</h3>
                <a href="index.php#book">Book a Taxi</a>
                <a href="customer_login.php">Customer Login</a>
                <a href="driver_login.php">Driver Login</a>
                <a href="blog.php">Blog</a>
            </div>
            <div class="footer-col">
                <h3>Services</h3>
                <p>One-way rides</p>
                <p>Round trips</p>
                <p>Intercity routes</p>
                <p>Verified fleet</p>
            </div>
            <div class="footer-col">
                <h3>Contact</h3>
                <p><i class="fa-solid fa-location-dot"></i> Bhopal, Madhya Pradesh</p>
                <p><i class="fa-solid fa-phone"></i> +91 89591 58195</p>
                <p><i class="fa-solid fa-envelope"></i> support@ranjancabs.local</p>
            </div>
        </div>
        <div class="footer-bottom">Copyright <?= date('Y') ?> RanjanCabs. All rights reserved.</div>
    </footer>

<script>
// ── Driver section polling ──────────────────────────────────────────────────
var BOOKING_REF     = <?php echo json_encode($booking['booking_ref_no']); ?>;
var DRIVER_ASSIGNED = <?php echo $driver_assigned ? 'true' : 'false'; ?>;
var pollTimer       = null;
var pollCount       = 0;
var MAX_POLLS       = 120; // stop after 10 minutes (120 × 5 s)

function pollDriverStatus() {
    if (DRIVER_ASSIGNED) return; // already assigned — no need to poll

    fetch('get_driver_status.php?ref=' + encodeURIComponent(BOOKING_REF))
        .then(function(r) { return r.json(); })
        .then(function(data) {
            pollCount++;

            if (data.assigned) {
                // Stop polling
                clearInterval(pollTimer);
                DRIVER_ASSIGNED = true;

                // Build and inject driver card HTML
                var html = buildDriverCard(data);
                document.getElementById('driver-section').innerHTML = html;

                // Subtle highlight animation
                var section = document.getElementById('driver-section');
                section.style.transition = 'background 0.6s';
                section.style.background = '#f0fdf4';
                setTimeout(function() { section.style.background = ''; }, 2000);
            }

            // Stop polling after max attempts
            if (pollCount >= MAX_POLLS) {
                clearInterval(pollTimer);
                updatePollStatus('Stopped — refresh the page to check again.');
            } else {
                updatePollStatus('Checking for driver... (' + pollCount + ')');
            }
        })
        .catch(function() {
            // Network error — keep trying silently
        });
}

function buildDriverCard(d) {
    var stars = '';
    var rating = parseFloat(d.star_rating || 5).toFixed(1);
    for (var i = 0; i < 5; i++) {
        stars += i < Math.round(d.star_rating) ? '★' : '☆';
    }
    return '<div class="driver-assigned">' +
        '<div class="driver-header">' +
            '<div class="driver-avatar"><i class="fa-solid fa-user-tie"></i></div>' +
            '<div>' +
                '<div class="driver-name-line">' + escHtml(d.driver_name) + '</div>' +
                '<div class="driver-sub" style="color:#16a34a;font-weight:700;">' +
                    '<i class="fa-solid fa-circle-check"></i> Driver Assigned' +
                '</div>' +
            '</div>' +
        '</div>' +
        '<div class="driver-details">' +
            '<div class="driver-detail-item"><small>Phone</small><strong>' + escHtml(d.driver_phone) + '</strong></div>' +
            '<div class="driver-detail-item"><small>Vehicle No.</small><strong style="font-family:monospace;">' + escHtml(d.vehicle_number) + '</strong></div>' +
            '<div class="driver-detail-item"><small>Model</small><strong>' + escHtml(d.model_name) + '</strong></div>' +
            '<div class="driver-detail-item"><small>Rating</small><strong style="color:#f59e0b;">' + stars + ' ' + rating + '</strong></div>' +
        '</div>' +
        '</div>';
}

function escHtml(str) {
    return String(str || '')
        .replace(/&/g,'&amp;').replace(/</g,'&lt;')
        .replace(/>/g,'&gt;').replace(/"/g,'&quot;');
}

function updatePollStatus(msg) {
    var el = document.getElementById('poll-status');
    if (el) el.textContent = msg;
}

// Start polling only if driver not yet assigned
if (!DRIVER_ASSIGNED) {
    pollTimer = setInterval(pollDriverStatus, 5000); // every 5 seconds
}
</script>
</body>
</html>

