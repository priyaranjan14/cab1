<?php
// 1. Enable error reporting to instantly catch system exceptions or anomalies
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

// 2. Initialize database connection
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "ranjancab"; 

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("<div style='color:red; padding:20px; font-weight:bold;'>Database Connection Failed: " . $conn->connect_error . "</div>");
}

// 3. Get the booking reference number safely from URL route properties
$booking_ref_no = isset($_GET['ref']) ? trim($_GET['ref']) : '';

$booking = null;
$is_new_customer = true;

if (!empty($booking_ref_no)) {
    /**
     * MASTER SELECTION JOIN ENGINE
     * Uses explicit column names tracking your structural updates across bookings and fleet tables.
     */
    $sql = "SELECT b.id, b.customer_name, b.customer_phone, b.booking_ref_no, b.trip_type, 
                   b.pickup_location, b.drop_location, b.pickup_date, b.return_date, 
                   b.pickup_time, b.car_type, b.distance, b.total_fare, b.advance_paid, 
                   b.driver_balance, b.otp_code, b.assigned_driver_id, b.booking_flag,
                   f.driver_name, f.mobile_number AS driver_phone, f.vehicle_number AS vehicle_no, f.model_name 
            FROM bookings b 
            LEFT JOIN fleet f ON b.assigned_driver_id = f.id 
            WHERE b.booking_ref_no = ? 
            LIMIT 1";
            
    $stmt = $conn->prepare($sql);
    if ($stmt) {
        $stmt->bind_param("s", $booking_ref_no);
        $stmt->execute();
        $result = $stmt->get_result();
        $booking = $result->fetch_assoc();
        $stmt->close();
    } else {
        die("<div style='color:red; padding:20px;'>SQL Prepare Error: " . $conn->error . "</div>");
    }
}

// Fallback safety redirect: If 'ref' parameter is wrong or missing, drop operational flow cleanly
if (!$booking) {
    die("<div style='max-width:500px; margin:100px auto; text-align:center; font-family:sans-serif; padding:20px; border:1px solid #cbd5e1; border-radius:8px;'>
            <h3 style='color:#b91c1c;'>No Active Booking Found</h3>
            <p style='color:#64748b;'>The reference token is missing or invalid.</p>
            <a href='index.php' style='display:inline-block; padding:10px 20px; background:#0f172a; color:#fff; text-decoration:none; border-radius:4px;'>Return to Dashboard</a>
         </div>");
}

// 4. CHECK CUSTOMER HISTORY BY COUNTING PHONE NUMBERS INSIDE `bookings`
$customer_phone = $booking['customer_phone'];
$history_sql = "SELECT COUNT(*) as total_bookings FROM bookings WHERE customer_phone = ?";
$h_stmt = $conn->prepare($history_sql);
if ($h_stmt) {
    $h_stmt->bind_param("s", $customer_phone);
    $h_stmt->execute();
    $h_res = $h_stmt->get_result()->fetch_assoc();
    
    // If phone count is greater than 1, they are returning customer records
    if ($h_res && intval($h_res['total_bookings']) > 1) {
        $is_new_customer = false;
    }
    $h_stmt->close();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Booking Confirmed | RanjanCabs</title>
    <link rel="stylesheet" href="style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        .confirmation-container {
            max-width: 600px;
            margin: 120px auto 40px auto;
            padding: 20px;
        }
        .success-card {
            background: #ffffff;
            border-radius: 8px;
            padding: 40px 30px;
            text-align: center;
            box-shadow: 0 10px 30px rgba(0,0,0,0.1);
            font-family: sans-serif;
        }
        .success-icon {
            font-size: 64px;
            color: #22c55e;
            margin-bottom: 20px;
        }
        .success-card h1 {
            color: #0f172a;
            font-size: 28px;
            margin-bottom: 10px;
        }
        .ref-badge {
            display: inline-block;
            background: #f1f5f9;
            color: #334155;
            padding: 8px 16px;
            border-radius: 20px;
            font-weight: 700;
            font-size: 16px;
            margin-bottom: 30px;
            border: 1px solid #cbd5e1;
        }
        .summary-title {
            text-align: left;
            font-size: 16px;
            color: #0f172a;
            margin-bottom: 15px;
            font-weight: 700;
            text-transform: uppercase;
            border-bottom: 2px solid #f59e0b;
            padding-bottom: 5px;
            display: flex;
            align-items: center;
            gap: 8px;
        }
        .review-table {
            width: 100%;
            border-collapse: collapse;
            text-align: left;
            margin-bottom: 20px;
        }
        .review-table td {
            padding: 10px 4px;
            border-bottom: 1px solid #f1f5f9;
            font-size: 14px;
        }
        .fleet-allocation-box {
            background: #f8fafc;
            border: 1px dashed #cbd5e1;
            border-radius: 6px;
            padding: 15px;
            margin-top: 25px;
            margin-bottom: 25px;
        }
        .payment-split-box {
            background: #f8fafc;
            border: 1px solid #e2e8f0;
            border-radius: 6px;
            padding: 15px;
            margin-top: 25px;
            margin-bottom: 25px;
        }
        .split-row {
            display: flex;
            justify-content: space-between;
            padding: 6px 0;
            font-size: 14px;
        }
        .price-tag { font-weight: 700; color: #16a34a; }
        .price-tag.gray { color: #475569; }
        
        .action-buttons {
            display: flex;
            gap: 15px;
            margin-top: 30px;
        }
        .btn-secondary {
            flex: 1;
            background-color: #f1f5f9;
            color: #334155;
            border: 1px solid #cbd5e1;
            padding: 14px;
            font-size: 15px;
            font-weight: 700;
            border-radius: 4px;
            text-decoration: none;
            text-transform: uppercase;
            text-align: center;
        }
        .submit-btn {
            flex: 1;
            background-color: #f59e0b;
            color: #fff;
            padding: 14px;
            font-size: 15px;
            font-weight: 700;
            border-radius: 4px;
            text-decoration: none;
            text-transform: uppercase;
            text-align: center;
            border: none;
            cursor: pointer;
        }
        
        /* Account Portal Credentials Box Styling */
        .login-details-box {
            background: #fffbeb;
            border: 1px solid #fef3c7;
            border-radius: 6px;
            padding: 15px;
            margin-top: 20px;
            margin-bottom: 20px;
            text-align: left;
        }
        .login-details-box h3 {
            font-size: 15px;
            color: #92400e;
            margin-top: 0;
            margin-bottom: 8px;
            font-weight: 700;
        }
        .login-data-row {
            display: flex;
            justify-content: space-between;
            padding: 6px 0;
            font-size: 13.5px;
            border-bottom: 1px dashed #fde68a;
        }
        .login-data-row:last-child { border-bottom: none; }
    </style>
</head>
<body>

    <main class="confirmation-container">
        <div class="success-card">
            <div class="success-icon">
                <i class="fa-solid fa-circle-check"></i>
            </div>
            <h1>Ride Confirmed!</h1>
            <p style="color: #64748b; margin-bottom: 10px;">Your trip setup configuration was recorded successfully.</p>
            <div class="ref-badge">REF NO: <?php echo htmlspecialchars($booking['booking_ref_no']); ?></div>

            <div class="summary-title"><i class="fa-solid fa-route"></i> Trip Summary</div>
            <table class="review-table">
                <tr>
                    <td><strong>Customer Name:</strong></td>
                    <td><?php echo htmlspecialchars($booking['customer_name']); ?></td>
                </tr>
                <tr>
                    <td><strong>Phone Number:</strong></td>
                    <td><?php echo htmlspecialchars($booking['customer_phone']); ?></td>
                </tr>
                <tr>
                    <td><strong>Trip Type:</strong></td>
                    <td><?php echo htmlspecialchars($booking['trip_type']); ?></td>
                </tr>
                <tr>
                    <td><strong>Pickup Point:</strong></td>
                    <td><?php echo htmlspecialchars($booking['pickup_location']); ?></td>
                </tr>
                <tr>
                    <td><strong>Drop Point:</strong></td>
                    <td><?php echo htmlspecialchars($booking['drop_location']); ?></td>
                </tr>
                <tr>
                    <td><strong>Date & Time:</strong></td>
                    <td><?php echo htmlspecialchars($booking['pickup_date']) . ' at ' . htmlspecialchars($booking['pickup_time']); ?></td>
                </tr>
                <tr>
                    <td><strong>Vehicle Class:</strong></td>
                    <td><?php echo htmlspecialchars($booking['car_type']); ?></td>
                </tr>
                <tr>
                    <td><strong>Total Estimated Fare:</strong></td>
                    <td><strong>₹<?php echo number_format($booking['total_fare'], 2); ?></strong></td>
                </tr>
            </table>

            <div class="fleet-allocation-box">
                <div class="summary-title" style="border-bottom: 2px solid #0f172a; margin-bottom: 10px;"><i class="fa-solid fa-id-card"></i> Driver & Vehicle Fleet Details</div>
                <?php if (!empty($booking['driver_name'])): ?>
                    <table class="review-table" style="margin-bottom: 0;">
                        <tr>
                            <td><strong>Name of Driver:</strong></td>
                            <td><i class="fa-solid fa-user-tie" style="color: #64748b; margin-right: 4px;"></i> <?php echo htmlspecialchars($booking['driver_name']); ?></td>
                        </tr>
                        <tr>
                            <td><strong>Phone No. of Driver:</strong></td>
                            <td><i class="fa-solid fa-phone" style="color: #64748b; margin-right: 4px;"></i> <?php echo htmlspecialchars($booking['driver_phone']); ?></td>
                        </tr>
                        <tr>
                            <td><strong>Vehicle No.:</strong></td>
                            <td><span style="background: #e2e8f0; padding: 2px 6px; border-radius: 4px; font-family: monospace; font-weight: 700; border: 1px solid #cbd5e1;"><?php echo htmlspecialchars($booking['vehicle_no']); ?></span></td>
                        </tr>
                        <tr>
                            <td><strong>Model Name:</strong></td>
                            <td><i class="fa-solid fa-car" style="color: #64748b; margin-right: 4px;"></i> <?php echo htmlspecialchars($booking['model_name']); ?></td>
                        </tr>
                    </table>
                <?php else: ?>
                    <p style="text-align: left; font-size: 13px; color: #64748b; margin: 5px 0 0 0; font-style: italic;">
                        <i class="fa-solid fa-clock-rotate-left" style="color: #eab308; margin-right: 4px;"></i> Driver allocation processing. Details will be updated and shared via SMS before your trip setup.
                    </p>
                <?php endif; ?>
            </div>

            <div class="payment-split-box">
                <h3 class="summary-title" style="border-bottom:none; margin-bottom:10px;"><i class="fa-solid fa-wallet"></i> Payment Split</h3>
                <div class="split-row">
                    <span>Advance Paid Upfront:</span>
                    <span class="price-tag">₹<?php echo number_format($booking['advance_paid'], 2); ?></span>
                </div>
                <div class="split-row">
                    <span>Remaining Balance to Driver:</span>
                    <span class="price-tag gray">₹<?php echo number_format($booking['driver_balance'], 2); ?></span>
                </div>
            </div>

            <div class="login-details-box">
                <h3><i class="fa-solid fa-user-lock"></i> Customer Account Portal</h3>
                <?php if ($is_new_customer): ?>
                    <p style="font-size: 13px; color: #78350f; margin-top: 0; margin-bottom: 10px;">
                        Welcome! Use your mobile credentials below to sign in and track your live ride state.
                    </p>
                    <div class="login-data-row">
                        <span><strong>Login ID:</strong></span>
                        <span><code><?php echo htmlspecialchars($booking['customer_phone']); ?></code></span>
                    </div>
                    <div class="login-data-row">
                        <span><strong>Password:</strong></span>
                        <span><code><?php echo htmlspecialchars($booking['customer_phone']); ?></code></span>
                    </div>
                <?php else: ?>
                    <p style="font-size: 13px; color: #78350f; margin: 0;">
                        Welcome back! Log into your existing customer dashboard using your registered mobile number to manage this booking.
                    </p>
                <?php endif; ?>
            </div>

            <div class="account-credential-banner" style="text-align: left; margin-top: 20px; background: #eff6ff; border: 1px solid #bfdbfe; padding: 15px; border-radius: 6px;">
                <h4 style="font-size: 15px; color: #1e40af; margin-top: 0; margin-bottom: 8px; font-weight: 700;"><i class="fa-solid fa-shield-halved"></i> Secure Ride Verification</h4>
                <p style="font-size: 13px; color: #1e3a8a; margin: 0;">Please share this secure OTP code with your driver only at the time of pickup to start your trip:</p>
                <div style="font-size: 24px; font-weight: 800; color: #1d4ed8; letter-spacing: 4px; margin-top: 10px; text-align: center; font-family: monospace;">
                    <?php echo htmlspecialchars($booking['otp_code']); ?>
                </div>
            </div>

            <div class="action-buttons">
                <a href="index.php" class="btn-secondary">Back to Home</a>
                <button onclick="window.print();" class="submit-btn">Print Receipt</button>
            </div>
        </div>
    </main>

</body>
</html>
<?php $conn->close(); ?>