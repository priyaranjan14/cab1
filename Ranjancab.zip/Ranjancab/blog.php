<?php
mysqli_report(MYSQLI_REPORT_ERROR | MYSQLI_REPORT_STRICT);

$conn = new mysqli("localhost", "root", "", "ranjancab");
$conn->set_charset("utf8mb4");

$slug = trim($_GET['slug'] ?? '');
$single_post = null;
$posts = [];

if ($slug !== '') {
    $stmt = $conn->prepare("SELECT * FROM blogs WHERE slug = ? AND status = 'published' LIMIT 1");
    $stmt->bind_param("s", $slug);
    $stmt->execute();
    $single_post = $stmt->get_result()->fetch_assoc();
    $stmt->close();
} else {
    $result = $conn->query("SELECT title, slug, excerpt, author, created_at FROM blogs WHERE status = 'published' ORDER BY created_at DESC");
    while ($row = $result->fetch_assoc()) {
        $posts[] = $row;
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= $single_post ? htmlspecialchars($single_post['title']) : 'Blog' ?> | RanjanCabs</title>
    <link rel="stylesheet" href="style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        body { background: #f4f6f9; }
        .blog-hero {
            background: #172033;
            color: #fff;
            padding: 118px 20px 54px;
        }
        .blog-hero-inner,
        .blog-wrap {
            max-width: 1100px;
            margin: 0 auto;
        }
        .blog-hero h1 {
            font-size: clamp(34px, 5vw, 56px);
            line-height: 1.08;
            margin-bottom: 12px;
        }
        .blog-hero p {
            max-width: 700px;
            color: #cbd5e1;
            line-height: 1.7;
        }
        .blog-wrap { padding: 34px 20px 64px; }
        .blog-list {
            display: grid;
            grid-template-columns: repeat(3, minmax(0, 1fr));
            gap: 18px;
        }
        .post-card,
        .post-full {
            background: #fff;
            border: 1px solid #e2e8f0;
            border-radius: 8px;
            padding: 22px;
            box-shadow: 0 12px 30px rgba(15,23,42,0.05);
        }
        .post-date {
            color: #b7791f;
            font-size: 12px;
            font-weight: 900;
            text-transform: uppercase;
            margin-bottom: 10px;
        }
        .post-card h2 {
            font-size: 21px;
            color: #172033;
            margin-bottom: 10px;
            line-height: 1.25;
        }
        .post-card p,
        .post-full p {
            color: #64748b;
            line-height: 1.75;
            font-size: 15px;
        }
        .read-link,
        .back-link {
            display: inline-flex;
            align-items: center;
            gap: 8px;
            margin-top: 16px;
            color: #172033;
            font-weight: 800;
            text-decoration: none;
        }
        .post-full {
            max-width: 820px;
            margin: 0 auto;
        }
        .post-full h2 {
            font-size: clamp(28px, 4vw, 42px);
            color: #172033;
            margin: 10px 0 18px;
            line-height: 1.18;
        }
        .empty-blog {
            background: #fff;
            border: 1px dashed #cbd5e1;
            border-radius: 8px;
            padding: 34px;
            color: #64748b;
            text-align: center;
        }
        @media (max-width: 900px) {
            .blog-list { grid-template-columns: 1fr; }
        }
    </style>
</head>
<body>
<?php include 'header1.php'; ?>

<section class="blog-hero">
    <div class="blog-hero-inner">
        <h1><?= $single_post ? htmlspecialchars($single_post['title']) : 'RanjanCabs Blog' ?></h1>
        <p><?= $single_post ? htmlspecialchars($single_post['excerpt']) : 'Travel notes, route tips, fleet updates, and cab booking guidance from the RanjanCabs operations team.' ?></p>
    </div>
</section>

<main class="blog-wrap">
    <?php if ($slug !== ''): ?>
        <?php if (!$single_post): ?>
            <div class="empty-blog">
                <h2>Post not found</h2>
                <p>This blog post is unavailable or unpublished.</p>
                <a class="back-link" href="blog.php"><i class="fa-solid fa-arrow-left"></i> Back to Blog</a>
            </div>
        <?php else: ?>
            <article class="post-full">
                <a class="back-link" href="blog.php"><i class="fa-solid fa-arrow-left"></i> Back to Blog</a>
                <div class="post-date"><?= date("d M Y", strtotime($single_post['created_at'])) ?> · <?= htmlspecialchars($single_post['author']) ?></div>
                <h2><?= htmlspecialchars($single_post['title']) ?></h2>
                <?php foreach (preg_split('/\R+/', trim($single_post['content'])) as $paragraph): ?>
                    <?php if (trim($paragraph) !== ''): ?>
                        <p><?= nl2br(htmlspecialchars($paragraph)) ?></p>
                    <?php endif; ?>
                <?php endforeach; ?>
            </article>
        <?php endif; ?>
    <?php else: ?>
        <?php if (count($posts) === 0): ?>
            <div class="empty-blog">No published blog posts yet.</div>
        <?php else: ?>
            <div class="blog-list">
                <?php foreach ($posts as $post): ?>
                    <article class="post-card">
                        <div class="post-date"><?= date("d M Y", strtotime($post['created_at'])) ?> · <?= htmlspecialchars($post['author']) ?></div>
                        <h2><?= htmlspecialchars($post['title']) ?></h2>
                        <p><?= htmlspecialchars($post['excerpt']) ?></p>
                        <a class="read-link" href="blog.php?slug=<?= urlencode($post['slug']) ?>">Read Post <i class="fa-solid fa-arrow-right"></i></a>
                    </article>
                <?php endforeach; ?>
            </div>
        <?php endif; ?>
    <?php endif; ?>
</main>
</body>
</html>
<?php $conn->close(); ?>
