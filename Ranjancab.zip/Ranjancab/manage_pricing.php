<?php
// Ensure a database connection exists. 
// If your main admin dashboard already defines $conn, this step will skip gracefully.
if (!isset($conn)) {
    $servername = "localhost";
    $username = "root";
    $password = "";
    $dbname = "ranjancab"; // Synced database name

    $conn = new mysqli($servername, $username, $password, $dbname);
    if ($conn->connect_error) {
        die("<div class='alert error'>Database connectivity failure: " . $conn->connect_error . "</div>");
    }
}

$message = "";
$message_type = "";

// --- HANDLE ADMIN UPDATE SUBMISSION ---
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['update_pricing'])) {
    $setting_id = intval($_POST['setting_id']);
    $rate = floatval($_POST['rate_per_km']);
    $portal_charges = floatval($_POST['portal_charges']);
    $advance_pct = floatval($_POST['advance_percentage']);

    $update_sql = "UPDATE pricing_settings 
                   SET rate_per_km = ?, portal_charges = ?, advance_percentage = ? 
                   WHERE id = ?";
    
    if ($stmt = $conn->prepare($update_sql)) {
        $stmt->bind_param("dddi", $rate, $portal_charges, $advance_pct, $setting_id);
        if ($stmt->execute()) {
            $message = "Pricing configurations updated successfully!";
            $message_type = "success";
        } else {
            $message = "Database update execution failure: " . $stmt->error;
            $message_type = "error";
        }
        $stmt->close();
    } else {
        $message = "SQL Statement Preparation Failed: " . $conn->error;
        $message_type = "error";
    }
}

// --- FETCH CURRENT SETTINGS DATA ---
$pricing_data = [];
$query = "SELECT * FROM pricing_settings ORDER BY id ASC";
$result = $conn->query($query);
if ($result && $result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $pricing_data[] = $row;
    }
}
?>

<style>
    .pricing-manager-wrapper {
        background: #ffffff;
        padding: 20px;
        border-radius: 6px;
        box-shadow: 0 4px 12px rgba(0,0,0,0.05);
        margin-top: 15px;
        font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
    }
    .pricing-manager-wrapper h3 {
        margin-top: 0;
        color: #1e293b;
        font-size: 18px;
        border-bottom: 2px solid #e2e8f0;
        padding-bottom: 10px;
        margin-bottom: 20px;
    }
    .alert {
        padding: 12px 15px;
        border-radius: 4px;
        margin-bottom: 20px;
        font-size: 14px;
        font-weight: 500;
    }
    .alert.success {
        background-color: #d1fae5;
        color: #065f46;
        border: 1px solid #a7f3d0;
    }
    .alert.error {
        background-color: #fee2e2;
        color: #991b1b;
        border: 1px solid #fca5a5;
    }
    .pricing-table {
        width: 100%;
        border-collapse: collapse;
        text-align: left;
    }
    .pricing-table th {
        background-color: #f8fafc;
        color: #64748b;
        font-weight: 600;
        font-size: 13px;
        text-transform: uppercase;
        padding: 12px;
        border-bottom: 2px solid #e2e8f0;
    }
    .pricing-table td {
        padding: 12px;
        border-bottom: 1px solid #e2e8f0;
        vertical-align: middle;
    }
    .pricing-table tr:hover {
        background-color: #f8fafc;
    }
    .badge-car {
        background: #e2e8f0;
        color: #1e293b;
        padding: 4px 8px;
        border-radius: 4px;
        font-weight: 700;
        font-size: 13px;
    }
    .pricing-input {
        width: 90px;
        padding: 6px 10px;
        border: 1px solid #cbd5e1;
        border-radius: 4px;
        font-size: 14px;
        color: #334155;
        transition: border-color 0.2s;
    }
    .pricing-input:focus {
        outline: none;
        border-color: #3b82f6;
        box-shadow: 0 0 0 2px rgba(59, 130, 246, 0.1);
    }
    .input-symbol-wrapper {
        position: relative;
        display: inline-block;
    }
    .input-symbol-wrapper::before {
        position: absolute;
        left: 8px;
        top: 50%;
        transform: translateY(-50%);
        color: #94a3b8;
        font-size: 13px;
        font-weight: 500;
    }
    .currency::before { content: "₹"; }
    .percent::after { 
        content: "%"; 
        position: absolute; 
        right: 8px; 
        top: 50%; 
        transform: translateY(-50%); 
        color: #94a3b8;
        font-size: 13px;
    }
    .currency .pricing-input { padding-left: 20px; }
    .percent .pricing-input { padding-right: 20px; }
    
    .btn-update-inline {
        background-color: var(--secondary-color, #0f172a);
        color: var(--primary-color, #f59e0b);
        border: none;
        padding: 8px 12px;
        font-size: 12px;
        font-weight: 700;
        text-transform: uppercase;
        border-radius: 4px;
        cursor: pointer;
        transition: opacity 0.2s;
    }
    .btn-update-inline:hover {
        opacity: 0.9;
    }
</style>

<div class="pricing-manager-wrapper">
    <h3><i class="fa-solid fa-sliders" style="margin-right: 6px;"></i> Manage Fleet Pricing Rules</h3>

    <?php if (!empty($message)): ?>
        <div class="alert <?php echo $message_type; ?>">
            <?php echo htmlspecialchars($message); ?>
        </div>
    <?php endif; ?>

    <?php if (!empty($pricing_data)): ?>
        <table class="pricing-table">
            <thead>
                <tr>
                    <th>Vehicle Category</th>
                    <th>Rate per KM</th>
                    <th>Fixed Portal Charges</th>
                    <th>Advance Required</th>
                    <th style="text-align: center;">Action</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($pricing_data as $row): ?>
                    <tr>
                        <form method="POST" action="">
                            <input type="hidden" name="setting_id" value="<?php echo $row['id']; ?>">
                            
                            <td>
                                <span class="badge-car"><?php echo htmlspecialchars($row['car_type']); ?></span>
                            </td>
                            
                            <td>
                                <div class="input-symbol-wrapper currency">
                                    <input type="number" step="0.01" min="0" class="pricing-input" name="rate_per_km" value="<?php echo htmlspecialchars($row['rate_per_km']); ?>" required>
                                </div>
                            </td>
                            
                            <td>
                                <div class="input-symbol-wrapper currency">
                                    <input type="number" step="0.01" min="0" class="pricing-input" name="portal_charges" value="<?php echo htmlspecialchars($row['portal_charges']); ?>" required>
                                </div>
                            </td>
                            
                            <td>
                                <div class="input-symbol-wrapper percent">
                                    <input type="number" step="0.01" min="0" max="100" class="pricing-input" name="advance_percentage" value="<?php echo htmlspecialchars($row['advance_percentage']); ?>" required>
                                </div>
                            </td>
                            
                            <td style="text-align: center;">
                                <button type="submit" name="update_pricing" class="btn-update-inline">
                                    <i class="fa-solid fa-floppy-disk"></i> Save
                                </button>
                            </td>
                        </form>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    <?php else: ?>
        <p style="color: #64748b; font-style: italic;">No configuration records found in the table. Run the default baseline values script insertions.</p>
    <?php endif; ?>
</div>