<?php
session_start();

// Admin Authentication Shield
if (!isset($_SESSION['admin_logged_in']) || $_SESSION['admin_logged_in'] !== true || !isset($_SESSION['admin_id'])) {
    header("Location: admin_login.php");
    exit();
}

// Database Connection
$conn = new mysqli("localhost", "root", "", "ranjancab");

if ($conn->connect_error) {
    die("Database connection failed: " . $conn->connect_error);
}

$success_msg = "";
$error_msg = "";

// Handle administrative log purging if requested
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action'])) {
    if ($_POST['action'] === 'purge_cancellation_log') {
        $log_id = intval($_POST['log_id']);
        
        $del_stmt = $conn->prepare("DELETE FROM cancelled_bookings WHERE id = ?");
        if ($del_stmt) {
            $del_stmt->bind_param("i", $log_id);
            if ($del_stmt->execute()) {
                $success_msg = "Cancellation log entry permanently removed from history storage.";
            } else {
                $error_msg = "Failed to drop log row entry from database.";
            }
            $del_stmt->close();
        }
    }
}

// Extract cancellation data with driver information details
$cancelled_logs_result = $conn->query("
    SELECT cb.*, f.driver_name, f.vehicle_number 
    FROM cancelled_bookings cb 
    LEFT JOIN fleet f ON cb.assigned_driver_id = f.id 
    ORDER BY cb.cancelled_at DESC
");
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Cancellation History Logs | RanjanCabs Engine</title>
    <link rel="stylesheet" href="style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        .log-container { max-width: 1600px; margin: 40px auto; padding: 0 20px; }
        .data-table-frame { background: #fff; padding: 25px; border-radius: 8px; box-shadow: 0 4px 12px rgba(0,0,0,0.05); border-top: 4px solid #ef4444; overflow-x: auto; }
        .log-table { width: 100%; border-collapse: collapse; text-align: left; font-size: 13px; }
        .log-table th { background: #0f172a; color: #fff; padding: 14px 12px; font-weight: 500; white-space: nowrap; }
        .log-table td { padding: 14px 12px; border-bottom: 1px solid #e2e8f0; color: #334155; vertical-align: middle; white-space: nowrap; }
        .log-table tr:hover { background: #fff1f2; }
        .agent-badge { padding: 4px 10px; border-radius: 12px; font-weight: 600; font-size: 11px; text-transform: uppercase; letter-spacing: 0.3px; }
        .badge-admin { background: #fee2e2; color: #991b1b; }
        .badge-driver { background: #fef3c7; color: #92400e; }
        .badge-customer { background: #e0f2fe; color: #0369a1; }
        .purge-btn { background: none; border: none; color: #ef4444; cursor: pointer; font-size: 14px; padding: 5px; transition: color 0.2s; }
        .purge-btn:hover { color: #991b1b; }
    </style>
</head>
<body style="background-color: #f1f5f9; margin: 0; font-family: system-ui, -apple-system, sans-serif;">

    <header class="navbar" style="background-color: #0f172a; padding: 15px 30px;">
        <div style="display: flex; justify-content: space-between; align-items: center; max-width: 1600px; margin: 0 auto;">
            <div class="logo">
                <a href="admin.php" style="color:#fff; text-decoration: none; font-weight: 700; font-size: 20px;">
                    <i class="fa-solid fa-arrow-left" style="color:#ef4444; margin-right: 10px;"></i> Admin<span style="color:#ef4444;">Console</span>
                </a>
            </div>
            <div style="color: #94a3b8; font-size: 14px; font-weight: 500;">
                <i class="fa-solid fa-clock-rotate-left"></i> Cancellation Audit Log Registry
            </div>
        </div>
    </header>

    <div class="log-container">
        
        <div style="margin-bottom: 20px;">
            <a href="admin.php" style="text-decoration: none; color: #3b82f6; font-size: 13px; font-weight: 600;">
                <i class="fa-solid fa-circle-chevron-left"></i> Return to Main Operations Center
            </a>
        </div>

        <?php if(!empty($success_msg)): ?>
            <div style="background:#dcfce7; color:#15803d; padding:12px; border-radius:4px; font-size:13px; font-weight:500; border-left:4px solid #15803d; margin-bottom: 20px;">
                <i class="fa-solid fa-circle-check"></i> <?php echo htmlspecialchars($success_msg); ?>
            </div>
        <?php endif; ?>
        
        <?php if(!empty($error_msg)): ?>
            <div style="background:#fee2e2; color:#991b1b; padding:12px; border-radius:4px; font-size:13px; font-weight:500; border-left:4px solid #991b1b; margin-bottom: 20px;">
                <i class="fa-solid fa-circle-exclamation"></i> <?php echo htmlspecialchars($error_msg); ?>
            </div>
        <?php endif; ?>

        <div class="data-table-frame">
            <h3 style="margin: 0 0 20px 0; color: #0f172a; font-size: 16px;">
                <i class="fa-solid fa-folder-open" style="color:#ef4444;"></i> Archived System Cancellations Stack
            </h3>

            <table class="log-table">
                <thead>
                    <tr>
                        <th>Ref No</th>
                        <th>Customer Details</th>
                        <th>Route Context</th>
                        <th>Trip Profile</th>
                        <th>Assigned Driver</th>
                        <th>Cancelled By</th>
                        <th>Reason Log Exception</th>
                        <th>Timestamp (IST)</th>
                        <th style="text-align: center;">Purge</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if($cancelled_logs_result && $cancelled_logs_result->num_rows > 0): ?>
                        <?php while($row = $cancelled_logs_result->fetch_assoc()): ?>
                            <?php 
                                // Dynamic CSS Selector class configuration depending on ENUM text value mappings
                                $badge_class = 'badge-admin';
                                if($row['cancelled_by'] === 'Driver') $badge_class = 'badge-driver';
                                if($row['cancelled_by'] === 'Customer') $badge_class = 'badge-customer';
                            ?>
                            <tr>
                                <td><strong style="color:#dc2626;"><?php echo htmlspecialchars($row['booking_ref_no']); ?></strong></td>
                                <td>
                                    <strong><?php echo htmlspecialchars($row['customer_name']); ?></strong><br>
                                    <small style="color: #64748b;"><?php echo htmlspecialchars($row['customer_phone']); ?></small>
                                </td>
                                <td>
                                    <small style="font-weight: 600;"><?php echo htmlspecialchars($row['pickup_location']); ?></small><br>
                                    <small style="color:#64748b;">➔ <?php echo htmlspecialchars($row['drop_location']); ?></small>
                                </td>
                                <td>
                                    <small><?php echo date("d-M-Y", strtotime($row['pickup_date'])); ?></small><br>
                                    <small style="color:#64748b;"><?php echo date("g:i A", strtotime($row['pickup_time'])); ?> | <?php echo htmlspecialchars($row['car_type']); ?></small>
                                </td>
                                <td>
                                    <?php if(!empty($row['driver_name'])): ?>
                                        <strong><?php echo htmlspecialchars($row['driver_name']); ?></strong><br>
                                        <small style="color:#64748b;"><?php echo htmlspecialchars($row['vehicle_number']); ?></small>
                                    <?php else: ?>
                                        <span style="color: #94a3b8; font-style: italic;">None Assigned</span>
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <span class="agent-badge <?php echo $badge_class; ?>">
                                        <?php echo htmlspecialchars($row['cancelled_by']); ?>
                                    </span>
                                </td>
                                <td>
                                    <span style="color:#475569; font-size:12px; white-space: normal; display: block; max-width: 250px;">
                                        <?php echo htmlspecialchars($row['cancellation_reason']); ?>
                                    </span>
                                </td>
                                <td>
                                    <small style="font-weight: 500; color: #0f172a;"><?php echo date("d-M-y H:i", strtotime($row['cancelled_at'])); ?></small>
                                </td>
                                <td style="text-align: center;">
                                    <form action="cancelled_booking.php" method="POST" onsubmit="return confirm('Warning: Permanently delete this historical file from storage? This cannot be undone.');" style="margin:0;">
                                        <input type="hidden" name="action" value="purge_cancellation_log">
                                        <input type="hidden" name="log_id" value="<?php echo $row['id']; ?>">
                                        <button type="submit" class="purge-btn" title="Purge Log"><i class="fa-solid fa-trash-can"></i></button>
                                    </form>
                                </td>
                            </tr>
                        <?php endwhile; ?>
                    <?php else: ?>
                        <tr>
                            <td colspan="9" style="text-align: center; color: #94a3b8; padding: 40px 0;">
                                <i class="fa-solid fa-box-open" style="font-size: 24px; margin-bottom: 10px; display: block;"></i>
                                No logs found inside the historical cancellation tracking repository.
                            </td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>

</body>
</html>