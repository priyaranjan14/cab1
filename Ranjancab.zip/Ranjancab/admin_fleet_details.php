<?php
// Active Registered Fleet Assets Module
if (!defined('ADMIN_SHIELD_ACTIVE')) { die('Direct system access restricted.'); }
?>
<div class="data-table-frame" style="border-top: 4px solid #3b82f6;">
    <h3 style="margin: 0 0 20px 0; color: #0f172a; font-size: 16px;"><i class="fa-solid fa-car" style="color:#3b82f6;"></i> Active Registered Fleet Assets</h3>
    <table class="transit-table" style="width:100%; border-collapse: collapse;">
        <thead>
            <tr>
                <th>Vehicle Number</th>
                <th>Model / Variant</th>
                <th>Class</th>
                <th>Driver Name</th>
                <th>Mobile Phone</th>
                <th>Commercial License</th>
                <th>Verification Map ID</th>
                <th>Base Station</th>
            </tr>
        </thead>
        <tbody>
            <?php if($fleet_result && $fleet_result->num_rows > 0): ?>
                <?php while($f_row = $fleet_result->fetch_assoc()): ?>
                    <tr>
                        <td><strong style="color:#1e40af;"><?php echo htmlspecialchars($f_row['vehicle_number']); ?></strong></td>
                        <td><?php echo htmlspecialchars($f_row['model_name']); ?></td>
                        <td><span class="status-badge" style="background:#eff6ff; color:#1e40af; padding: 2px 6px; border-radius: 4px; font-size: 11px;"><?php echo htmlspecialchars($f_row['car_type']); ?></span></td>
                        <td><strong><?php echo htmlspecialchars($f_row['driver_name']); ?></strong></td>
                        <td><?php echo htmlspecialchars($f_row['mobile_number']); ?></td>
                        <td><code style="font-size:12px;"><?php echo htmlspecialchars($f_row['driver_license_no']); ?></code></td>
                        <td>
                            <small style="color:#64748b; font-family: monospace; font-size: 12px;">
                                <?php 
                                $raw_id = preg_replace('/\s+/', '', $f_row['aadhaar_no']);
                                if (strlen($raw_id) >= 4) {
                                    echo "********" . htmlspecialchars(substr($raw_id, -4));
                                } else {
                                    echo "[Masked Security ID]";
                                }
                                ?>
                            </small>
                        </td>
                        <td><small><?php echo htmlspecialchars($f_row['base_station']); ?></small></td>
                    </tr>
                <?php endwhile; ?>
            <?php else: ?>
                <tr><td colspan="8" style="text-align: center; color: #94a3b8; padding: 25px 0;">No operational assets registered in inventory.</td></tr>
            <?php endif; ?>
        </tbody>
    </table>
</div>