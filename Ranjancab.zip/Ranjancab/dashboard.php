<?php
session_start();

// 1. SESSION GUARD: Force login if driver session context is missing
if (!isset($_SESSION['driver_id'])) {
    // For testing purposes, uncomment the lines below to mock a session if you haven't built login.php yet:
    /*
    $_SESSION['driver_id'] = 1;
    $_SESSION['driver_name'] = "Rajesh Kumar";
    $_SESSION['base_station'] = "Bhopal";
    $_SESSION['car_type'] = "Sedan";
    */
    
    header("Location: login.php");
    exit();
}

$driver_id           = $_SESSION['driver_id'];
$driver_name         = $_SESSION['driver_name'];
$driver_base_station = $_SESSION['base_station'];
$driver_car_type     = $_SESSION['car_type'];

// Initialize Database Connection
$conn = new mysqli("localhost", "root", "", "Ranjancab");
if ($conn->connect_error) {
    die("Database connectivity failure: " . $conn->connect_error);
}

// 2. FETCH ACTIVE ASSIGNED RIDE (If this driver has already claimed an open booking)
$assigned_sql = "SELECT * FROM bookings WHERE assigned_driver_id = ? AND booking_flag = 1 LIMIT 1";
$assigned_stmt = $conn->prepare($assigned_sql);
$assigned_stmt->bind_param("i", $driver_id);
$assigned_stmt->execute();
$active_ride = $assigned_stmt->get_result()->fetch_assoc();
$assigned_stmt->close();

// 3. FETCH OPEN POOL REQUESTS MATCHING BASE STATION & CAR TYPE (Excluding Rejections)
// Uses REGEXP to find the base station keyword within the customer's pickup address string
$pool_sql = "SELECT b.* FROM bookings b
             WHERE b.booking_flag = 1 
               AND b.assigned_driver_id IS NULL
               AND b.car_type = ?
               AND LOWER(b.pickup_location) REGEXP ?
               AND b.id NOT IN (SELECT booking_id FROM booking_rejections WHERE driver_id = ?)";

$pool_stmt = $conn->prepare($pool_sql);
$regex_pattern = '[[:<:]]' . preg_quote(strtolower($driver_base_station), '/') . '[[:>:]]';
$pool_stmt->bind_param("ssi", $driver_car_type, $regex_pattern, $driver_id);
$pool_stmt->execute();
$live_requests = $pool_stmt->get_result();
$pool_stmt->close();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Driver Dispatch Dashboard - Ranjancab</title>
    <style>
        :root {
            --primary: #2c3e50;
            --accent: #f1c40f;
            --success: #2ecc71;
            --danger: #e74c3c;
            --bg: #f8f9fa;
            --card-bg: #ffffff;
            --text: #333333;
        }

        * { box-sizing: border-box; margin: 0; padding: 0; font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; }
        body { background-color: var(--bg); color: var(--text); padding: 20px; }
        
        header {
            background-color: var(--primary);
            color: white;
            padding: 20px;
            border-radius: 8px;
            margin-bottom: 25px;
            display: flex;
            justify-content: space-between;
            align-items: center;
            box-shadow: 0 4px 6px rgba(0,0,0,0.1);
        }
        header h1 { font-size: 24px; }
        .driver-meta { font-size: 14px; text-align: right; }
        .badge { background: var(--accent); color: var(--primary); padding: 3px 8px; font-weight: bold; border-radius: 4px; }

        .container { max-width: 1200px; margin: 0 auto; }
        
        /* Status Alerts */
        .alert { padding: 15px; border-radius: 6px; margin-bottom: 20px; font-weight: 600; }
        .alert-success { background-color: #d4edda; color: #155724; border: 1px solid #c3e6cb; }
        .alert-danger { background-color: #f8d7da; color: #721c24; border: 1px solid #f5c6cb; }
        .alert-warning { background-color: #fff3cd; color: #856404; border: 1px solid #ffeeba; }

        h2 { margin-bottom: 15px; color: var(--primary); border-bottom: 2px solid #ddd; padding-bottom: 5px; }
        
        /* Layout Grid */
        .dashboard-grid { display: grid; grid-template-columns: 1fr; gap: 25px; }
        
        .card {
            background: var(--card-bg);
            border-radius: 8px;
            padding: 20px;
            box-shadow: 0 2px 4px rgba(0,0,0,0.05);
            border-left: 5px solid var(--primary);
        }

        .active-ride-card { border-left-color: var(--success); background: #fdfefe; }
        
        .booking-item {
            background: #fff;
            border: 1px solid #e2e8f0;
            border-radius: 6px;
            padding: 15px;
            margin-bottom: 15px;
            display: flex;
            justify-content: space-between;
            align-items: center;
            flex-wrap: wrap;
            gap: 15px;
        }
        
        .booking-details p { margin-bottom: 5px; font-size: 15px; }
        .route-highlight { font-weight: bold; color: var(--primary); font-size: 16px; }
        
        .btn-group { display: flex; gap: 10px; }
        button {
            padding: 10px 20px;
            border: none;
            border-radius: 4px;
            font-weight: bold;
            cursor: pointer;
            transition: background 0.2s;
        }
        .btn-accept { background-color: var(--success); color: white; }
        .btn-accept:hover { background-color: #27ae60; }
        .btn-reject { background-color: var(--danger); color: white; }
        .btn-reject:hover { background-color: #c0392b; }
        
        .logout-btn { color: #fff; text-decoration: none; background: rgba(255,255,255,0.1); padding: 8px 15px; border-radius: 4px; font-size: 13px; }
        .logout-btn:hover { background: rgba(255,255,255,0.2); }

        @media (max-width: 768px) {
            .booking-item { flex-direction: column; align-items: flex-start; }
            .btn-group { width: 100%; }
            button { flex: 1; text-align: center; }
        }
    </style>
</head>
<body>

<div class="container">
    <header>
        <div>
            <h1>Ranjancab Pilot Portal</h1>
            <p>Welcome back, <strong><?= htmlspecialchars($driver_name) ?></strong></p>
        </div>
        <div class="driver-meta">
            <p>Station Pool: <span class="badge"><?= htmlspecialchars($driver_base_station) ?></span></p>
            <p>Vehicle Class: <span class="badge"><?= htmlspecialchars($driver_car_type) ?></span></p>
            <p style="margin-top: 8px;"><a href="logout.php" class="logout-btn">Log Out</a></p>
        </div>
    </header>

    <?php if (isset($_GET['status'])): ?>
        <?php if ($_GET['status'] === 'assigned'): ?>
            <div class="alert alert-success">Ride assigned successfully! Secure the OTP upon boarding.</div>
        <?php elseif ($_GET['status'] === 'missed'): ?>
            <div class="alert alert-danger">Too slow! That ride assignment was just secured by another pilot.</div>
        <?php elseif ($_GET['status'] === 'rejected'): ?>
            <div class="alert alert-warning">Request discarded. Removed from your active terminal pool.</div>
        <?php endif; ?>
    <?php endif; ?>

    <div class="dashboard-grid">
        
        <?php if ($active_ride): ?>
            <div class="card active-ride-card">
                <h2>Current Assigned Duty</h2>
                <div class="booking-details">
                    <p class="route-highlight">From: <?= htmlspecialchars($active_ride['pickup_location']) ?></p>
                    <p class="route-highlight">To: <?= htmlspecialchars($active_ride['drop_location']) ?></p>
                    <hr style="margin: 10px 0; border: 0; border-top: 1px solid #eee;">
                    <p><strong>Passenger:</strong> <?= htmlspecialchars($active_ride['first_name'] . ' ' . $active_ride['last_name']) ?></p>
                    <p><strong>Contact:</strong> <?= htmlspecialchars($active_ride['mobile_number']) ?></p>
                    <p><strong>Schedule:</strong> <?= htmlspecialchars($active_ride['pickup_date']) ?> @ <?= htmlspecialchars($active_ride['pickup_time']) ?></p>
                    <p><strong>Total Fare Value:</strong> ₹<?= htmlspecialchars($active_ride['total_fare']) ?></p>
                    <p><strong>Advance Deposited:</strong> ₹<?= htmlspecialchars($active_ride['advance_paid']) ?></p>
                    <p style="font-size: 18px; color: var(--success); margin-top: 10px;">
                        <strong>Collect from Customer: ₹<?= htmlspecialchars($active_ride['driver_balance']) ?></strong>
                    </p>
                    <div style="background: #fff3cd; padding: 10px; border-radius: 4px; margin-top: 15px; border-left: 4px solid var(--accent);">
                        <strong>Ride Start Verification PIN:</strong> Enter code given by customer to process drop completion metrics.
                    </div>
                </div>
            </div>
        <?php endif; ?>

        <div class="card">
            <h2>Live Match Stream Requests</h2>
            <p style="margin-bottom: 15px; font-size: 13px; color: #666;">Showing available rides matching your base station keyword filtering matrix.</p>
            
            <?php if ($live_requests->num_rows === 0): ?>
                <div style="text-align: center; padding: 30px; color: #888;">
                    <p>No new ride requests waiting in your zone right now.</p>
                </div>
            <?php else: ?>
                <?php while ($row = $live_requests->fetch_assoc()): ?>
                    <div class="booking-item">
                        <div class="booking-details">
                            <p class="route-highlight"><?= htmlspecialchars($row['pickup_location']) ?> ➔ <?= htmlspecialchars($row['drop_location']) ?></p>
                            <p><strong>Schedule:</strong> <?= htmlspecialchars($row['pickup_date']) ?> | <?= htmlspecialchars($row['pickup_time']) ?> | <strong>Est. Distance:</strong> <?= htmlspecialchars($row['distance']) ?> KM</p>
                            <p><strong>Gross Fare:</strong> ₹<?= htmlspecialchars($row['total_fare']) ?> | <strong>On-Trip Collectible Balance:</strong> <strong style="color: #27ae60;">₹<?= htmlspecialchars($row['driver_balance']) ?></strong></p>
                        </div>
                        
                        <div class="btn-group">
                            <form action="process_booking_action.php" method="POST" style="display: inline;">
                                <input type="hidden" name="booking_id" value="<?= $row['id'] ?>">
                                <button type="submit" name="action" value="accept" class="btn-accept">Accept</button>
                            </form>
                            
                            <form action="process_booking_action.php" method="POST" style="display: inline;">
                                <input type="hidden" name="booking_id" value="<?= $row['id'] ?>">
                                <button type="submit" name="action" value="reject" class="btn-reject">Reject</button>
                            </form>
                        </div>
                    </div>
                <?php endwhile; ?>
            <?php endif; ?>
        </div>

    </div>
</div>

</body>
</html>
<?php $conn->close(); ?>