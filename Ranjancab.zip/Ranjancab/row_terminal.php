<tr>
    <td><span class="badge bg-dark">#<?= htmlspecialchars($p['booking_ref_no']) ?></span></td>
    <td><?= htmlspecialchars($p['customer_name']) ?></td>
    <td><?= htmlspecialchars($p['pickup_location']) ?> → <?= htmlspecialchars($p['drop_location']) ?></td>
    <td><?= $p['driver_name'] ?? 'Pending' ?></td>
    <td class="text-end">
        <form method="POST" action="admin.php" class="d-inline">
            <input type="hidden" name="action" value="complete_booking">
            <input type="hidden" name="booking_id" value="<?= $p['id'] ?>">
            <button type="submit" class="btn btn-success btn-sm">Complete</button>
        </form>
    </td>
</tr>