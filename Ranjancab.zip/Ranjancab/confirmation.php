<?php
session_start();

// 1. Establish System Database Connection
$conn = new mysqli("localhost", "root", "", "ranjancab");
if ($conn->connect_error) {
    die("Database connectivity failure: " . $conn->connect_error);
}

// 2. Determine target booking identification token safely
$booking_id = null;

if (isset($_SESSION['confirmed_booking_id'])) {
    $booking_id = $_SESSION['confirmed_booking_id'];
} else if (isset($_GET['id'])) {
    $booking_id = intval($_GET['id']);
}

// Redirect back home if accessed directly with no reference keys
if (!$booking_id) {
    header("Location: index.php");
    exit();
}

// 3. Query Real-Time Booking Matrix & Consolidated Fleet Allocation States
// Note: We are using a SINGLE join on the fleet table since it holds all assets
$sql = "SELECT b.booking_ref_no, b.first_name, b.last_name, b.mobile_number, b.pickup_location, 
               b.drop_location, b.driver_balance, b.otp_code, b.assigned_driver_id,
               f.driver_name, f.mobile_number AS driver_phone, f.model_name, f.vehicle_number
        FROM bookings b
        LEFT JOIN fleet f ON b.assigned_driver_id = f.id
        WHERE b.id = ? LIMIT 1";

$stmt = $conn->prepare($sql);
$booking_data = null;

if ($stmt) {
    $stmt->bind_param("i", $booking_id);
    $stmt->execute();
    $result = $stmt->get_result();
    if ($result && $result->num_rows > 0) {
        $booking_data = $result->fetch_assoc();
    }
    $stmt->close();
}

if (!$booking_data) {
    die("Error tracking transactional booking logs reference state.");
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Booking Summary | RanjanCabs</title>
    <link rel="stylesheet" href="style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        .success-card { background: #ffffff; border-radius: 8px; padding: 35px 25px; text-align: center; box-shadow: 0 10px 25px rgba(0,0,0,0.05); }
        .success-icon { font-size: 55px; color: #22c55e; margin-bottom: 15px; }
        .success-card h2 { color: #0f172a; font-size: 22px; margin-top: 0; margin-bottom: 8px; }
        .success-card p { color: #64748b; font-size: 13px; line-height: 1.5; margin-top: 0; margin-bottom: 25px; }
        .ticket-box { background: #f8fafc; border: 1px solid #e2e8f0; border-radius: 6px; padding: 15px; margin-bottom: 22px; text-align: left; }
        .ticket-row { display: flex; justify-content: space-between; padding: 9px 0; border-bottom: 1px dashed #e2e8f0; font-size: 13px; }
        .ticket-row:last-child { border-bottom: none; }
        .ticket-row span:first-child { color: #64748b; font-weight: 500; }
        .ticket-row span:last-child { color: #0f172a; font-weight: 600; text-align: right; max-width: 60%; }
        .id-badge { background: #e0f2fe; color: #0369a1; padding: 2px 8px; border-radius: 4px; font-family: monospace; font-size: 13px; }

        .otp-security-panel { background: #fffbeb; border: 1px dashed #fcd34d; border-radius: 6px; padding: 14px; margin-bottom: 22px; text-align: center; }
        .otp-security-panel .otp-title { font-size: 11px; text-transform: uppercase; color: #b45309; font-weight: 700; letter-spacing: 0.5px; display: flex; align-items: center; justify-content: center; gap: 5px; }
        .otp-security-panel .otp-code-string { font-size: 32px; font-weight: 900; color: #b45309; letter-spacing: 6px; margin: 4px 0; font-family: monospace; }
        .otp-security-panel .otp-instruction { font-size: 11px; color: #d97706; margin: 0; font-weight: 500; }

        .allocation-block { background: #f0fdf4; border: 1px solid #bbf7d0; border-radius: 6px; padding: 14px; margin-bottom: 22px; text-align: left; }
        .allocation-block h4 { margin: 0 0 10px 0; color: #166534; font-size: 13px; display: flex; align-items: center; gap: 6px; border-bottom: 1px solid #bbf7d0; padding-bottom: 6px; }
        .pending-allocation { background: #f8fafc; border: 1px solid #e2e8f0; color: #64748b; padding: 14px; border-radius: 6px; font-size: 12px; margin-bottom: 22px; display: flex; align-items: center; justify-content: center; gap: 8px; font-weight: 500; }

        .btn-home-return { display: inline-block; background: #0f172a; color: #ffffff; text-decoration: none; padding: 12px 24px; border-radius: 6px; font-size: 14px; font-weight: 600; width: 100%; box-sizing: border-box; text-align: center; }
        .btn-home-return:hover { background: #1e293b; }
    </style>
</head>
<body>

    <header class="navbar">
        <div class="nav-container">
            <div class="logo"><a href="index.php"><i class="fa-solid fa-taxi"></i> Ranjan<span>Cabs</span></a></div>
            <nav class="nav-menu" id="navMenu">
                <a href="index.php" class="active">Home</a>
                <a href="#">Our Fleet</a>
                <a href="#">Services</a>
                <a href="#">Contact</a>
            </nav>
            <div class="nav-actions">
                <button class="menu-toggle" id="mobileMenuBtn"><i class="fa-solid fa-bars"></i></button>
            </div>
        </div>
    </header>

    <main class="hero-section">
        <div class="hero-overlay"></div>
        <div class="hero-container">
            
            <div class="hero-text">
                <h1>Booking Summary <br>& Dispatch Status</h1>
                <p>Track live vehicle assignments, driver routing, and security credentials for your scheduled premium journey.</p>
            </div>

            <div class="booking-card">
                <div class="success-card">
                    <div class="success-icon"><i class="fa-solid fa-circle-check"></i></div>
                    <h2>Ride Confirmed!</h2>
                    <p>Your taxi assignment processing request is safely logged.</p>
                    
                    <div class="otp-security-panel">
                        <div class="otp-title"><i class="fa-solid fa-shield-halved"></i> Ride Activation Verification OTP</div>
                        <div class="otp-code-string"><?php echo htmlspecialchars($booking_data['otp_code']); ?></div>
                        <p class="otp-instruction">Provide this code to your assigned driver to start the trip journey.</p>
                    </div>

                    <?php if (!empty($booking_data['assigned_driver_id'])): ?>
                        <div class="allocation-block">
                            <h4><i class="fa-solid fa-id-card-clip"></i> Assigned Driver & Vehicle Details</h4>
                            <div class="ticket-row" style="padding: 4px 0;">
                                <span>Pilot Chauffeur</span>
                                <strong><?php echo htmlspecialchars($booking_data['driver_name']); ?></strong>
                            </div>
                            <div class="ticket-row" style="padding: 4px 0;">
                                <span>Contact Mobile</span>
                                <strong><?php echo htmlspecialchars($booking_data['driver_phone']); ?></strong>
                            </div>
                            <div class="ticket-row" style="padding: 4px 0;">
                                <span>Vehicle Model</span>
                                <strong><?php echo htmlspecialchars($booking_data['model_name']); ?></strong>
                            </div>
                            <div class="ticket-row" style="padding: 4px 0; border-bottom: none;">
                                <span>Registration Number</span>
                                <span class="id-badge" style="background: #dcfce7; color: #15803d; font-weight: 700;"><?php echo htmlspecialchars($booking_data['vehicle_number']); ?></span>
                            </div>
                        </div>
                    <?php else: ?>
                        <div class="pending-allocation">
                            <i class="fa-solid fa-spinner fa-spin" style="color: #3b82f6;"></i>
                            <span>Awaiting Driver and Vehicle details assignment...</span>
                        </div>
                    <?php endif; ?>

                    <div class="ticket-box">
                        <div class="ticket-row">
                            <span>Reference Tracker No.</span>
                            <span class="id-badge"><?php echo htmlspecialchars($booking_data['booking_ref_no']); ?></span>
                        </div>
                        <div class="ticket-row">
                            <span>Passenger Identity</span>
                            <span><?php echo htmlspecialchars($booking_data['first_name'] . ' ' . $booking_data['last_name']); ?></span>
                        </div>
                        <div class="ticket-row">
                            <span>Pickup Location Hub</span>
                            <span><?php echo htmlspecialchars($booking_data['pickup_location']); ?></span>
                        </div>
                        <div class="ticket-row">
                            <span>Drop Destination Hub</span>
                            <span><?php echo htmlspecialchars($booking_data['drop_location']); ?></span>
                        </div>
                        <div class="ticket-row" style="background: #e0f2fe; margin: 8px -15px -15px -15px; padding: 12px 15px; border-radius: 0 0 6px 6px;">
                            <span style="color: #0369a1; font-weight: 700;">Final Charged Fare</span>
                            <span style="color: #0369a1; font-weight: 800; font-size: 16px;">₹<?php echo number_format($booking_data['driver_balance'], 2); ?></span>
                        </div>
                    </div>

                    <a href="index.php" class="btn-home-return"><i class="fa-solid fa-house" style="margin-right: 4px;"></i> Return to Dashboard</a>
                </div>
            </div>

        </div>
    </main>

<script>
    const mobileMenuBtn = document.getElementById('mobileMenuBtn');
    const navMenu = document.getElementById('navMenu');
    mobileMenuBtn.addEventListener('click', () => { navMenu.classList.toggle('active'); });
</script>
</body>
</html>
<?php $conn->close(); ?>