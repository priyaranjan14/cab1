<?php
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action'])) {
    if ($_POST['action'] === 'allocate_cab') {
        $stmt = $conn->prepare("UPDATE bookings SET assigned_driver_id = ? WHERE id = ?");
        $stmt->bind_param("ii", $_POST['driver_id'], $_POST['booking_id']);
        $stmt->execute();
        header("Location: admin.php?status=allocated"); exit;
    }
    if ($_POST['action'] === 'complete_booking') {
        $stmt = $conn->prepare("UPDATE bookings SET booking_flag = 3 WHERE id = ?");
        $stmt->bind_param("i", $_POST['booking_id']);
        $stmt->execute();
        header("Location: admin.php?status=completed"); exit;
    }
    // Add other actions (cancel_booking, toggle_fleet, update_pricing, add_route) here...
}
?>