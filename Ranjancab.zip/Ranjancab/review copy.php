<?php
session_start();

// 1. Establish System Database Connection
$conn = new mysqli("localhost", "root", "", "ranjancab");
if ($conn->connect_error) {
    die("Database connectivity failure: " . $conn->connect_error);
}

// 2. Parse Inbound Form Payload Data
$pickup_raw = isset($_POST['pickup_location']) ? trim($_POST['pickup_location']) : '';
$drop_raw   = isset($_POST['drop_location']) ? trim($_POST['drop_location']) : '';

if (empty($pickup_raw) || empty($drop_raw)) {
    header("Location: index.php?status=error");
    exit();
}

/**
 * Robust Core Extraction Utility:
 * Isolates the anchor base city whether it contains a joined comma list or standard values.
 */
function extractBaseCity($locationString) {
    if (strpos($locationString, ',') !== false) {
        $parts = explode(',', $locationString);
        return trim($parts[0]);
    }
    return $locationString;
}

$final_pickup_search = extractBaseCity($pickup_raw); // Extracts "Bhopal"
$final_drop_search   = extractBaseCity($drop_raw);   // Extracts "Indore"

// 3. REQUIREMENT ALIGNMENT: Validate booking solely by evaluating the Routes Matrix entries
$distance = 0.00;
$route_stmt = $conn->prepare("SELECT estimated_distance FROM routes WHERE LOWER(pickup_point) = LOWER(?) AND LOWER(drop_point) = LOWER(?) LIMIT 1");

if ($route_stmt) {
    $route_stmt->bind_param("ss", $final_pickup_search, $final_drop_search);
    $route_stmt->execute();
    $route_stmt->bind_result($estimated_distance);
    
    if ($route_stmt->fetch()) {
        $distance = floatval($estimated_distance);
    } else {
        // Fallback execution check: Evaluate invert paths in case database has it logged as Indore -> Bhopal
        $route_stmt->free_result();
        $reverse_stmt = $conn->prepare("SELECT estimated_distance FROM routes WHERE LOWER(pickup_point) = LOWER(?) AND LOWER(drop_point) = LOWER(?) LIMIT 1");
        $reverse_stmt->bind_param("ss", $final_drop_search, $final_pickup_search);
        $reverse_stmt->execute();
        $reverse_stmt->bind_result($rev_distance);
        
        if ($reverse_stmt->fetch()) {
            $distance = floatval($rev_distance);
        } else {
            // No direct route pairing exists between these clean anchor vectors
            header("Location: index.php?status=error&reason=no_mapped_route");
            exit();
        }
        $reverse_stmt->close();
    }
    $route_stmt->close();
}

// 4. Financial Calculations Array Processing
$rate_per_km = 14.50; 
$computed_fare = $distance * $rate_per_km;

if (isset($_POST['trip_type']) && $_POST['trip_type'] === 'Roundtrip') {
    $computed_fare = $computed_fare * 1.85; 
}

$_SESSION['pending_booking'] = [
    'pickup_location' => $pickup_raw, // Stores "Bhopal, Arera Colony"
    'drop_location'   => $drop_raw,   // Stores "Indore, Vijay Nagar"
    'pickup_date'     => $_POST['pickup_date'],
    'pickup_time'     => $_POST['pickup_time'],
    'trip_type'       => $_POST['trip_type'] ?? 'Oneway',
    'return_date'     => $_POST['return_date'] ?? null,
    'car_type'        => $_POST['car_type'],
    'distance_km'     => $distance,
    'driver_balance'  => round($computed_fare, 2)
];
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Review Your Ride | RanjanCabs</title>
    <link rel="stylesheet" href="style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        .review-card { max-width: 600px; margin: 60px auto; background: #ffffff; padding: 30px; border-radius: 8px; box-shadow: 0 4px 15px rgba(0,0,0,0.06); }
        .review-title { border-bottom: 2px solid #f1f5f9; padding-bottom: 15px; margin-bottom: 20px; color: #0f172a; display: flex; align-items: center; gap: 10px; }
        .detail-row { display: flex; justify-content: space-between; padding: 12px 0; border-bottom: 1px dashed #e2e8f0; font-size: 14px; }
        .detail-row span:first-child { color: #64748b; font-weight: 500; }
        .detail-row span:last-child { color: #0f172a; font-weight: 600; text-align: right; max-width: 60%; }
        .fare-box { background: #f0f9ff; border: 1px solid #bae6fd; border-radius: 6px; padding: 15px; margin: 20px 0; text-align: center; }
        .fare-amount { font-size: 28px; font-weight: 800; color: #0369a1; margin-top: 5px; }
        .btn-container { display: flex; gap: 15px; margin-top: 25px; }
        .btn-review { flex: 1; padding: 12px; border: none; border-radius: 4px; font-weight: 600; text-align: center; cursor: pointer; text-decoration: none; font-size: 14px; }
        .btn-confirm { background: #22c55e; color: #ffffff; }
        .btn-back { background: #cbd5e1; color: #334155; }
    </style>
</head>
<body style="background: #f1f5f9; font-family: system-ui, -apple-system, sans-serif; margin: 0;">

    <div class="review-card">
        <h2 class="review-title"><i class="fa-solid fa-clipboard-check" style="color: #3b82f6;"></i> Journey Verification Summary</h2>
        
        <div class="detail-row"><span>Journey Classification</span><span><?php echo htmlspecialchars($_SESSION['pending_booking']['trip_type']); ?></span></div>
        <div class="detail-row"><span>Custom Pickup Address</span><span><?php echo htmlspecialchars($_SESSION['pending_booking']['pickup_location']); ?></span></div>
        <div class="detail-row"><span>Custom Drop Address</span><span><?php echo htmlspecialchars($_SESSION['pending_booking']['drop_location']); ?></span></div>
        <div class="detail-row"><span>Scheduled Timeline</span><span><?php echo date("d-M-Y", strtotime($_SESSION['pending_booking']['pickup_date'])); ?> @ <?php echo htmlspecialchars($_SESSION['pending_booking']['pickup_time']); ?></span></div>
        <div class="detail-row"><span>Selected Logistical Car</span><span><?php echo htmlspecialchars($_SESSION['pending_booking']['car_type']); ?></span></div>
        <div class="detail-row"><span>Routes Vector Base Distance</span><span><?php echo $_SESSION['pending_booking']['distance_km']; ?> km</span></div>

        <div class="fare-box">
            <span style="font-size: 12px; color: #0369a1; font-weight: 600; text-transform: uppercase;">Computational Fare Sum</span>
            <div class="fare-amount">₹<?php echo number_format($_SESSION['pending_booking']['driver_balance'], 2); ?></div>
        </div>

        <form action="confirm_booking.php" method="POST">
            <div class="btn-container">
                <a href="index.php" class="btn-review btn-back">Modify</a>
                <button type="submit" class="btn-review btn-confirm">Confirm Booking</button>
            </div>
        </form>
    </div>

</body>
</html>
<?php $conn->close(); ?>