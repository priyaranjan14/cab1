<?php
/**
 * RanjanCabs — Database Migration Script
 * Visit: http://localhost/Ranjancab/run_migration.php
 * Safe to run multiple times (uses IF NOT EXISTS / IGNORE).
 */
error_reporting(E_ALL);
ini_set('display_errors', 1);

$conn = new mysqli("localhost", "root", "", "ranjancab");
if ($conn->connect_error) {
    die("<p style='color:red;font-family:sans-serif;padding:20px;'>Connection failed: " . htmlspecialchars($conn->connect_error) . "</p>");
}
$conn->set_charset("utf8mb4");

$steps = [];

function run_sql($conn, $label, $sql) {
    $ok = $conn->query($sql);
    if (!$ok) {
        // ignore "Duplicate column" errors — column already exists
        if (strpos($conn->error, 'Duplicate column') !== false || strpos($conn->error, 'already exists') !== false) {
            return ["$label (already exists — skipped)", true];
        }
        return ["$label — ERROR: " . $conn->error, false];
    }
    return [$label, true];
}

// 1. Add new columns to bookings
$steps[] = run_sql($conn, "bookings: add coupon_code",
    "ALTER TABLE bookings ADD COLUMN coupon_code VARCHAR(30) NULL DEFAULT NULL");

$steps[] = run_sql($conn, "bookings: add coupon_discount",
    "ALTER TABLE bookings ADD COLUMN coupon_discount DOUBLE NOT NULL DEFAULT 0");

$steps[] = run_sql($conn, "bookings: add discounted_fare",
    "ALTER TABLE bookings ADD COLUMN discounted_fare DOUBLE NOT NULL DEFAULT 0");

// Backfill discounted_fare for existing rows
$steps[] = run_sql($conn, "bookings: backfill discounted_fare",
    "UPDATE bookings SET discounted_fare = total_fare WHERE discounted_fare = 0");

// 2. Add new columns to cancelled_bookings
$steps[] = run_sql($conn, "cancelled_bookings: add advance_paid",
    "ALTER TABLE cancelled_bookings ADD COLUMN advance_paid DOUBLE NOT NULL DEFAULT 0");

$steps[] = run_sql($conn, "cancelled_bookings: add discounted_fare",
    "ALTER TABLE cancelled_bookings ADD COLUMN discounted_fare DOUBLE NOT NULL DEFAULT 0");

$steps[] = run_sql($conn, "cancelled_bookings: add coupon_code",
    "ALTER TABLE cancelled_bookings ADD COLUMN coupon_code VARCHAR(30) NULL DEFAULT NULL");

// Backfill
$steps[] = run_sql($conn, "cancelled_bookings: backfill discounted_fare",
    "UPDATE cancelled_bookings SET discounted_fare = total_fare WHERE discounted_fare = 0");

// 3. Create coupon_codes table
$steps[] = run_sql($conn, "Create coupon_codes table",
    "CREATE TABLE IF NOT EXISTS coupon_codes (
        id INT NOT NULL AUTO_INCREMENT,
        code VARCHAR(30) NOT NULL,
        discount_percent DECIMAL(5,2) NOT NULL DEFAULT 10.00,
        description VARCHAR(200) DEFAULT NULL,
        is_active TINYINT(1) NOT NULL DEFAULT 1,
        valid_from DATE DEFAULT NULL,
        valid_until DATE DEFAULT NULL,
        usage_count INT NOT NULL DEFAULT 0,
        max_usage INT NOT NULL DEFAULT 100,
        created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
        PRIMARY KEY (id),
        UNIQUE KEY uk_coupon_code (code)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");

// 4. Insert sample coupon codes
$coupons = [
    ['RANJAN10',  10.00, 'Welcome offer — 10% off your first ride'],
    ['SUMMER25',  10.00, 'Summer special — 10% discount on all routes'],
    ['FESTIVE10', 10.00, 'Festival season offer — 10% off'],
];
foreach ($coupons as $c) {
    $stmt = $conn->prepare("INSERT IGNORE INTO coupon_codes (code, discount_percent, description) VALUES (?, ?, ?)");
    $stmt->bind_param("sds", $c[0], $c[1], $c[2]);
    $ok = $stmt->execute();
    $stmt->close();
    $steps[] = ["Insert coupon " . $c[0], $ok];
}

// 5. Also update existing bookings advance to be 10% (optional — recalculate advance for demo data)
$steps[] = run_sql($conn, "Recalculate advance_paid to 10% for existing bookings",
    "UPDATE bookings SET
        advance_paid   = ROUND(discounted_fare * 0.10, 2),
        driver_balance = ROUND(discounted_fare * 0.90, 2)
     WHERE booking_flag IN (1, 2)");

$conn->close();
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Migration — RanjanCabs</title>
<style>
* { box-sizing: border-box; }
body { font-family: 'Segoe UI', sans-serif; max-width: 720px; margin: 50px auto; padding: 20px; background: #f8fafc; color: #172033; }
h1 { font-size: 24px; margin-bottom: 4px; }
p.sub { color: #64748b; margin-bottom: 24px; }
table { width: 100%; border-collapse: collapse; }
th { background: #172033; color: #fff; text-align: left; padding: 10px 14px; font-size: 13px; }
td { padding: 10px 14px; border-bottom: 1px solid #e2e8f0; font-size: 14px; }
.ok   { color: #16a34a; font-weight: 700; }
.fail { color: #dc2626; font-weight: 700; }
.note { background: #fffbeb; border: 1px solid #f59e0b; border-radius: 8px; padding: 16px; margin-top: 24px; font-size: 14px; line-height: 1.6; }
.note strong { color: #b45309; }
a.btn { display: inline-block; margin-top: 20px; background: #172033; color: #fff; text-decoration: none; padding: 10px 22px; border-radius: 6px; font-weight: 700; font-size: 14px; }
</style>
</head>
<body>
<h1>🛠 RanjanCabs — Migration Results</h1>
<p class="sub">Run once. Safe to re-run (duplicate steps are skipped automatically).</p>
<table>
<tr><th>Step</th><th>Result</th></tr>
<?php foreach ($steps as $s): ?>
<tr>
    <td><?= htmlspecialchars($s[0]) ?></td>
    <td class="<?= $s[1] ? 'ok' : 'fail' ?>"><?= $s[1] ? '✓ Done' : '✗ Failed' ?></td>
</tr>
<?php endforeach; ?>
</table>
<div class="note">
    <strong>✅ Migration complete!</strong><br>
    You can now delete <code>run_migration.php</code> from your server (optional — it's safe to keep for reference).<br><br>
    Next steps: <a href="index.php">Go to Homepage →</a>
</div>
<a class="btn" href="index.php">→ Go to Homepage</a>
</body>
</html>
