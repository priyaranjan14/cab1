<?php
session_start();

// If already logged in, bypass login screen directly to dashboard
if (isset($_SESSION['admin_logged_in']) && $_SESSION['admin_logged_in'] === true) {
    header("Location: admin.php");
    exit();
}

$error = "";

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = trim($_POST['username']);
    $password = trim($_POST['password']);

    // Hardcoded demo credentials - replace this with your secure DB validation logic later
    if ($username === "admin" && $password === "admin123") {
        $_SESSION['admin_logged_in'] = true;
        $_SESSION['admin_id'] = 1;
        $_SESSION['admin_username'] = $username;
        
        header("Location: admin.php");
        exit();
    } else {
        $error = "Invalid administrative access credentials.";
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login | RanjanCabs Engine</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        body { background-color: #f1f5f9; font-family: system-ui, -apple-system, sans-serif; display: flex; justify-content: center; align-items: center; height: 100vh; margin: 0; }
        .login-card { background: #fff; padding: 40px; border-radius: 8px; box-shadow: 0 4px 12px rgba(0,0,0,0.05); width: 100%; max-width: 400px; box-sizing: border-box; }
        .brand-header { text-align: center; margin-bottom: 30px; }
        .brand-header h2 { margin: 5px 0; color: #0f172a; font-size: 24px; }
        .form-group { margin-bottom: 20px; }
        .form-group label { display: block; font-size: 11px; font-weight: 600; color: #334155; margin-bottom: 6px; text-transform: uppercase; letter-spacing: 0.5px; }
        .form-group input { width: 100%; padding: 12px; border: 1px solid #cbd5e1; border-radius: 4px; font-size: 14px; box-sizing: border-box; }
        .btn-login { width: 100%; background: #3b82f6; color: #fff; border: none; padding: 12px; font-weight: 600; border-radius: 4px; cursor: pointer; font-size: 14px; transition: background 0.2s; }
        .btn-login:hover { background: #2563eb; }
        .alert-danger { background: #fee2e2; color: #991b1b; padding: 12px; border-radius: 4px; font-size: 13px; margin-bottom: 20px; border-left: 4px solid #991b1b; display: flex; align-items: center; gap: 8px; }
    </style>
</head>
<body>

    <div class="login-card">
        <div class="brand-header">
            <a href="#" style="color:#0f172a; text-decoration: none; font-weight: 700; font-size: 22px;">
                <i class="fa-solid fa-screwdriver-wrench" style="color:#3b82f6;"></i> Admin<span style="color:#3b82f6;">Console</span>
            </a>
            <p style="color: #64748b; font-size: 13px; margin-top: 5px;">RanjanCabs Logistics Gateway</p>
        </div>

        <?php if(!empty($error)): ?>
            <div class="alert-danger">
                <i class="fa-solid fa-circle-exclamation"></i> <?php echo htmlspecialchars($error); ?>
            </div>
        <?php endif; ?>

        <form action="admin_login.php" method="POST" autocomplete="off">
            <div class="form-group">
                <label>Username</label>
                <input type="text" name="username" required placeholder="Enter admin username">
            </div>
            <div class="form-group">
                <label>Password</label>
                <input type="password" name="password" required placeholder="••••••••">
            </div>
            <button type="submit" class="btn-login">Authenticate Session</button>
        </form>
    </div>

</body>
</html>