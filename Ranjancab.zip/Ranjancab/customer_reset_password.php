<?php
session_start();
require_once 'db.php';

$error_message = "";
$success_message = "";
$token = $_GET['token'] ?? ($_POST['token'] ?? '');
$valid_token = false;
$customer_phone = "";

if (!empty($token)) {
    // Validate the token and expiry (15 mins window) in PHP to prevent timezone mismatch
    $stmt = $conn->prepare("SELECT customer_phone, reset_token_expiry FROM customer_credentials WHERE reset_token = ? LIMIT 1");
    $stmt->bind_param("s", $token);
    $stmt->execute();
    $res = $stmt->get_result();
    
    if ($res->num_rows > 0) {
        $row = $res->fetch_assoc();
        if (strtotime($row['reset_token_expiry']) >= time()) {
            $valid_token = true;
            $customer_phone = $row['customer_phone'];
        }
    }
    $stmt->close();
}

if ($_SERVER["REQUEST_METHOD"] == "POST" && $valid_token) {
    $password = trim($_POST['password'] ?? '');
    $confirm_password = trim($_POST['confirm_password'] ?? '');

    if (!empty($password) && !empty($confirm_password)) {
        if ($password === $confirm_password) {
            // Hash password and update database
            $hashed_password = password_hash($password, PASSWORD_BCRYPT);
            
            $up_stmt = $conn->prepare("UPDATE customer_credentials SET password = ?, reset_token = NULL, reset_token_expiry = NULL WHERE customer_phone = ?");
            $up_stmt->bind_param("ss", $hashed_password, $customer_phone);
            
            if ($up_stmt->execute()) {
                $success_message = "Password updated successfully! Redirecting you to the login desk...";
                // Redirect after 2 seconds
                header("refresh:2;url=customer_login.php");
            } else {
                $error_message = "Failed to update password. Please try again.";
            }
            $up_stmt->close();
        } else {
            $error_message = "Passwords do not match.";
        }
    } else {
        $error_message = "Please enter both password fields.";
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Reset Password | RanjanCabs</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Outfit:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
    <style>
        :root {
            --bg-gradient: linear-gradient(135deg, #0b132b 0%, #1c2541 50%, #3a506b 100%);
            --card-bg: rgba(28, 37, 65, 0.7);
            --card-border: rgba(255, 255, 255, 0.08);
            --primary: #f59e0b;
            --primary-hover: #d97706;
            --text-main: #f8fafc;
            --text-muted: #94a3b8;
            --text-dark: #0f172a;
            --input-bg: rgba(11, 19, 43, 0.6);
            --input-border: rgba(255, 255, 255, 0.15);
            --input-focus: #f59e0b;
            --danger: #ef4444;
            --danger-bg: rgba(127, 29, 29, 0.4);
            --danger-border: rgba(239, 68, 68, 0.4);
            --success: #10b981;
            --success-bg: rgba(6, 78, 59, 0.4);
            --success-border: rgba(16, 185, 129, 0.4);
        }

        * {
            box-sizing: border-box;
            margin: 0;
            padding: 0;
            font-family: 'Outfit', sans-serif;
            transition: all 0.25s cubic-bezier(0.4, 0, 0.2, 1);
        }

        body {
            background: var(--bg-gradient);
            color: var(--text-main);
            min-height: 100vh;
            display: flex;
            flex-direction: column;
            overflow-x: hidden;
        }

        .navbar {
            background: rgba(11, 19, 43, 0.8);
            backdrop-filter: blur(10px);
            border-bottom: 1px solid var(--card-border);
            padding: 15px 40px;
            display: flex;
            justify-content: space-between;
            align-items: center;
            position: fixed;
            top: 0;
            left: 0;
            right: 0;
            z-index: 1000;
        }

        .navbar .logo a {
            color: #fff;
            text-decoration: none;
            font-size: 24px;
            font-weight: 800;
            display: flex;
            align-items: center;
            gap: 10px;
        }

        .navbar .logo i {
            color: var(--primary);
        }

        .navbar .logo span {
            color: var(--primary);
        }

        .navbar .back-btn {
            color: var(--text-muted);
            text-decoration: none;
            border: 1px solid rgba(255,255,255,0.15);
            padding: 8px 18px;
            border-radius: 30px;
            font-size: 14px;
            font-weight: 500;
            display: flex;
            align-items: center;
            gap: 8px;
            background: rgba(255,255,255,0.03);
        }

        .navbar .back-btn:hover {
            color: #fff;
            border-color: var(--primary);
            background: rgba(245, 158, 11, 0.1);
            transform: translateY(-2px);
        }

        .login-container {
            flex: 1;
            display: flex;
            justify-content: center;
            align-items: center;
            padding: 100px 20px 40px;
            position: relative;
        }

        .login-card {
            background: var(--card-bg);
            backdrop-filter: blur(15px);
            border: 1px solid var(--card-border);
            padding: 40px;
            border-radius: 20px;
            box-shadow: 0 20px 40px rgba(0, 0, 0, 0.4);
            width: 100%;
            max-width: 450px;
            z-index: 10;
        }

        h2 {
            text-align: center;
            font-size: 28px;
            font-weight: 800;
            margin-bottom: 6px;
            color: #fff;
            letter-spacing: -0.5px;
        }

        .subtitle {
            text-align: center;
            color: var(--text-muted);
            font-size: 14px;
            margin-bottom: 30px;
            line-height: 1.5;
        }

        .input-group {
            margin-bottom: 20px;
            position: relative;
        }

        label {
            display: block;
            margin-bottom: 8px;
            font-weight: 600;
            color: var(--text-main);
            font-size: 14px;
            display: flex;
            align-items: center;
            gap: 6px;
        }

        .input-wrapper {
            position: relative;
        }

        .input-wrapper i {
            position: absolute;
            left: 15px;
            top: 50%;
            transform: translateY(-50%);
            color: var(--text-muted);
            font-size: 16px;
            pointer-events: none;
        }

        input {
            width: 100%;
            padding: 14px 15px 14px 45px;
            border: 1px solid var(--input-border);
            border-radius: 10px;
            box-sizing: border-box;
            font-size: 15px;
            background: var(--input-bg);
            color: #fff;
        }

        input:focus {
            outline: none;
            border-color: var(--input-focus);
            box-shadow: 0 0 15px rgba(245, 158, 11, 0.15);
            background: rgba(11, 19, 43, 0.8);
        }

        .submit-btn {
            width: 100%;
            padding: 14px;
            background: var(--primary);
            color: var(--text-dark);
            border: none;
            border-radius: 10px;
            font-weight: 700;
            cursor: pointer;
            font-size: 16px;
            letter-spacing: 0.5px;
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 8px;
            box-shadow: 0 4px 15px rgba(245, 158, 11, 0.2);
            margin-top: 10px;
        }

        .submit-btn:hover {
            background: var(--primary-hover);
            transform: translateY(-2px);
            box-shadow: 0 6px 20px rgba(245, 158, 11, 0.35);
        }

        .alert {
            color: #fff;
            background: var(--danger-bg);
            border: 1px solid var(--danger-border);
            padding: 12px 15px;
            border-radius: 8px;
            margin-bottom: 22px;
            font-size: 14px;
            display: flex;
            align-items: center;
            gap: 10px;
            line-height: 1.4;
        }

        .alert-success {
            background: var(--success-bg);
            border: 1px solid var(--success-border);
            color: #fff;
        }

        .back-login {
            text-align: center;
            margin-top: 25px;
            padding-top: 20px;
            border-top: 1px solid rgba(255,255,255,0.06);
            font-size: 14px;
        }

        .back-login a {
            color: var(--primary);
            font-weight: 600;
            text-decoration: none;
        }

        .back-login a:hover {
            text-decoration: underline;
        }
    </style>
</head>
<body>

    <header class="navbar">
        <div class="logo">
            <a href="index.php"><i class="fa-solid fa-taxi"></i> Ranjan<span>Cabs</span></a>
        </div>
        <div>
            <a href="customer_login.php" class="back-btn"><i class="fa-solid fa-house"></i> Home</a>
        </div>
    </header>

    <main class="login-container">
        <div class="login-card">
            <h2>Set New Password</h2>
            <p class="subtitle">Complete your password reset. Ensure it's secure and memorable.</p>
            
            <?php if (!$valid_token): ?>
                <div class="alert"><i class="fa-solid fa-circle-xmark"></i> <div>The password reset token is invalid or has expired. Please request a new link.</div></div>
                <div class="back-login">
                    <a href="customer_forgot_password.php">Request New Reset Link ➔</a>
                </div>
            <?php else: ?>

                <?php if (!empty($error_message)): ?>
                    <div class="alert"><i class="fa-solid fa-circle-exclamation"></i> <?php echo $error_message; ?></div>
                <?php endif; ?>

                <?php if (!empty($success_message)): ?>
                    <div class="alert alert-success"><i class="fa-solid fa-circle-check"></i> <div><?php echo $success_message; ?></div></div>
                <?php endif; ?>

                <form action="customer_reset_password.php" method="POST">
                    <input type="hidden" name="token" value="<?php echo htmlspecialchars($token); ?>">
                    
                    <div class="input-group">
                        <label for="password"><i class="fa-solid fa-lock"></i> New Password</label>
                        <div class="input-wrapper">
                            <i class="fa-solid fa-key"></i>
                            <input type="password" id="password" name="password" placeholder="Min 6 characters" required>
                        </div>
                    </div>

                    <div class="input-group">
                        <label for="confirm_password"><i class="fa-solid fa-shield-check"></i> Confirm New Password</label>
                        <div class="input-wrapper">
                            <i class="fa-solid fa-key"></i>
                            <input type="password" id="confirm_password" name="confirm_password" placeholder="Confirm your password" required>
                        </div>
                    </div>

                    <button type="submit" class="submit-btn">
                        <i class="fa-solid fa-lock-open"></i> Reset Password
                    </button>
                </form>
            <?php endif; ?>

            <div class="back-login">
                Abort and return to <a href="customer_login.php">Login Desk ➔</a>
            </div>
        </div>
    </main>

</body>
</html>
