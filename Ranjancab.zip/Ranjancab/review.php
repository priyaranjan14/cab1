<?php
session_start();

$conn = new mysqli("localhost", "root", "", "ranjancab");
if ($conn->connect_error) {
    die("Database connectivity failure: " . $conn->connect_error);
}
$conn->set_charset("utf8mb4");

$pickup_raw = isset($_POST['pickup_location']) ? trim($_POST['pickup_location']) : '';
$drop_raw   = isset($_POST['drop_location'])   ? trim($_POST['drop_location'])   : '';

if (empty($pickup_raw) || empty($drop_raw)) {
    header("Location: index.php?status=error&reason=missing_locations");
    exit();
}

function extractBaseCity($loc) {
    if (strpos($loc, ',') !== false) {
        return trim(explode(',', $loc)[0]);
    }
    return $loc;
}

$pickup_city = extractBaseCity($pickup_raw);
$drop_city   = extractBaseCity($drop_raw);

$distance = 0.00;
$route_stmt = $conn->prepare(
    "SELECT estimated_distance FROM routes
     WHERE LOWER(pickup_point) = LOWER(?) AND LOWER(drop_point) = LOWER(?) LIMIT 1"
);
$route_stmt->bind_param("ss", $pickup_city, $drop_city);
$route_stmt->execute();
$route_stmt->bind_result($estimated_distance);
if ($route_stmt->fetch()) {
    $distance = floatval($estimated_distance);
} else {
    $route_stmt->free_result();
    $rev_stmt = $conn->prepare(
        "SELECT estimated_distance FROM routes
         WHERE LOWER(pickup_point) = LOWER(?) AND LOWER(drop_point) = LOWER(?) LIMIT 1"
    );
    $rev_stmt->bind_param("ss", $drop_city, $pickup_city);
    $rev_stmt->execute();
    $rev_stmt->bind_result($rev_dist);
    if ($rev_stmt->fetch()) {
        $distance = floatval($rev_dist);
    } else {
        header("Location: index.php?status=error&reason=no_mapped_route");
        exit();
    }
    $rev_stmt->close();
}
$route_stmt->close();

$rate_per_km    = 14.50;
$portal_charges = 200.00;
$car_type       = isset($_POST['car_type'])  ? trim($_POST['car_type'])  : 'Sedan';
$trip_type      = isset($_POST['trip_type']) ? trim($_POST['trip_type']) : 'Oneway';

$pricing_stmt = $conn->prepare(
    "SELECT rate_per_km, portal_charges FROM pricing_settings WHERE car_type = ? LIMIT 1"
);
if ($pricing_stmt) {
    $pricing_stmt->bind_param("s", $car_type);
    $pricing_stmt->execute();
    $pricing_res = $pricing_stmt->get_result();
    if ($row = $pricing_res->fetch_assoc()) {
        $rate_per_km    = floatval($row['rate_per_km']);
        $portal_charges = floatval($row['portal_charges']);
    }
    $pricing_stmt->close();
}

$computed_fare = ($distance * $rate_per_km) + $portal_charges;
if ($trip_type === 'Roundtrip' || $trip_type === 'Round Trip') {
    $computed_fare *= 1.85;
}
$total_fare     = round($computed_fare, 2);
$advance_paid   = round($total_fare * 0.10, 2);
$driver_balance = round($total_fare * 0.90, 2);

$_SESSION['pending_booking'] = [
    'pickup_location' => $pickup_raw,
    'drop_location'   => $drop_raw,
    'pickup_date'     => $_POST['pickup_date']   ?? '',
    'pickup_time'     => $_POST['pickup_time']   ?? '',
    'trip_type'       => $trip_type,
    'return_date'     => $_POST['return_date']   ?? null,
    'car_type'        => $car_type,
    'distance_km'     => $distance,
    'total_fare'      => $total_fare,
    'advance_paid'    => $advance_paid,
    'driver_balance'  => $driver_balance,
    'discounted_fare' => $total_fare,
];

// Fetch active coupon codes to display as chips
$coupons_display = [];
$tbl_check = $conn->query("SHOW TABLES LIKE 'coupon_codes'");
if ($tbl_check && $tbl_check->num_rows > 0) {
    $cpn_res = $conn->query(
        "SELECT code, description, discount_percent FROM coupon_codes
         WHERE is_active = 1
           AND (valid_from IS NULL OR valid_from <= CURDATE())
           AND (valid_until IS NULL OR valid_until >= CURDATE())
           AND (max_usage = 0 OR usage_count < max_usage)
         ORDER BY id LIMIT 5"
    );
    if ($cpn_res) {
        while ($r = $cpn_res->fetch_assoc()) {
            $coupons_display[] = $r;
        }
    }
}
$conn->close();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Review Your Ride | RanjanCabs</title>
    <link rel="stylesheet" href="style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        .review-details-container {
            background: #fff;
            border-radius: 8px;
            padding: 15px;
            margin-bottom: 18px;
            border: 1px dashed #cbd5e1;
        }
        .detail-row {
            display: flex;
            justify-content: space-between;
            padding: 9px 0;
            border-bottom: 1px solid #f1f5f9;
            font-size: 13px;
        }
        .detail-row:last-child { border-bottom: none; }
        .detail-row .lbl { color: #64748b; font-weight: 500; }
        .detail-row .val { color: #0f172a; font-weight: 600; text-align: right; max-width: 65%; }

        /* Fare breakdown */
        .fare-breakdown-box {
            background: #f0f9ff;
            border: 1px solid #bae6fd;
            border-radius: 8px;
            padding: 16px;
            margin-bottom: 18px;
        }
        .fare-row {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 8px 0;
            border-bottom: 1px solid #e0f2fe;
            font-size: 13px;
            font-weight: 600;
        }
        .fare-row:last-child {
            border-bottom: none;
            border-top: 2px solid #7dd3fc;
            padding-top: 12px;
            margin-top: 4px;
        }
        .fare-row .flbl { color: #0369a1; }
        .fare-row .fval { color: #0f172a; }
        .fare-row.discount .flbl,
        .fare-row.discount .fval { color: #16a34a; }
        .fare-row.advance .fval { color: #b45309; }
        .fare-row.grand .fval { font-size: 18px; color: #0369a1; font-weight: 800; }

        /* Coupon section */
        .coupon-section {
            background: #fffbeb;
            border: 1px solid #fde68a;
            border-radius: 8px;
            padding: 14px;
            margin-bottom: 18px;
        }
        .coupon-section label {
            display: block;
            font-size: 13px;
            font-weight: 800;
            color: #92400e;
            margin-bottom: 10px;
        }
        .coupon-chips {
            display: flex;
            flex-wrap: wrap;
            gap: 6px;
            margin-bottom: 10px;
        }
        .coupon-chip {
            background: #fef3c7;
            border: 1px solid #f59e0b;
            border-radius: 999px;
            padding: 5px 12px;
            font-size: 12px;
            font-weight: 800;
            color: #92400e;
            cursor: pointer;
            letter-spacing: 1px;
            transition: all 0.2s;
        }
        .coupon-chip:hover { background: #f59e0b; color: #fff; border-color: #f59e0b; }
        .coupon-input-row {
            display: flex;
            gap: 8px;
        }
        .coupon-input-row input {
            flex: 1;
            border: 2px dashed #f59e0b;
            border-radius: 6px;
            padding: 10px 12px;
            font-size: 14px;
            font-weight: 700;
            letter-spacing: 2px;
            text-transform: uppercase;
            background: #fff;
            color: #172033;
        }
        .coupon-input-row input:focus { border-color: #d97706; outline: none; }
        .btn-apply-coupon {
            background: #172033;
            color: #fff;
            border: none;
            padding: 10px 18px;
            border-radius: 6px;
            font-weight: 700;
            cursor: pointer;
            font-size: 13px;
            white-space: nowrap;
            transition: background 0.2s;
        }
        .btn-apply-coupon:hover { background: #0f172a; }
        .coupon-msg {
            margin-top: 8px;
            font-size: 13px;
            font-weight: 700;
            padding: 8px 10px;
            border-radius: 5px;
            display: none;
        }
        .coupon-msg.success { background: #dcfce7; color: #166534; display: block; }
        .coupon-msg.error   { background: #fee2e2; color: #991b1b; display: block; }

        .action-flex-buttons {
            display: flex;
            gap: 12px;
            margin-top: 20px;
        }
        .btn-back-modify {
            flex: 1;
            background: #cbd5e1;
            color: #334155;
            text-align: center;
            padding: 13px;
            border-radius: 6px;
            text-decoration: none;
            font-size: 14px;
            font-weight: 600;
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 6px;
            transition: background 0.2s;
        }
        .btn-back-modify:hover { background: #94a3b8; }
        .submit-btn { flex: 2; }

        @media (max-width: 480px) {
            .action-flex-buttons { flex-direction: column; }
            .submit-btn { flex: none; }
        }
    </style>
</head>
<body>
    <?php include 'header1.php'; ?>

    <main class="hero-section" style="padding-top:100px;">
        <div class="hero-overlay"></div>
        <div class="hero-container">
            <div class="hero-text">
                <h1>Review Your Ride.</h1>
                <p>Check the fare breakdown, apply a coupon if you have one, then confirm your booking.</p>
            </div>

            <div class="booking-card">
                <h2><i class="fa-solid fa-clipboard-check"></i> Step 2 of 2 — Confirm Booking</h2>

                <div class="review-details-container">
                    <div class="detail-row">
                        <span class="lbl">Journey Type</span>
                        <span class="val"><?php echo htmlspecialchars($_SESSION['pending_booking']['trip_type']); ?></span>
                    </div>
                    <div class="detail-row">
                        <span class="lbl">Pickup</span>
                        <span class="val"><?php echo htmlspecialchars($_SESSION['pending_booking']['pickup_location']); ?></span>
                    </div>
                    <div class="detail-row">
                        <span class="lbl">Drop</span>
                        <span class="val"><?php echo htmlspecialchars($_SESSION['pending_booking']['drop_location']); ?></span>
                    </div>
                    <div class="detail-row">
                        <span class="lbl">Date &amp; Time</span>
                        <span class="val"><?php echo date("d M Y", strtotime($_SESSION['pending_booking']['pickup_date'])); ?> @ <?php echo htmlspecialchars($_SESSION['pending_booking']['pickup_time']); ?></span>
                    </div>
                    <?php if (!empty($_SESSION['pending_booking']['return_date'])): ?>
                    <div class="detail-row">
                        <span class="lbl">Return Date</span>
                        <span class="val"><?php echo date("d M Y", strtotime($_SESSION['pending_booking']['return_date'])); ?></span>
                    </div>
                    <?php endif; ?>
                    <div class="detail-row">
                        <span class="lbl">Vehicle Class</span>
                        <span class="val"><?php echo htmlspecialchars($_SESSION['pending_booking']['car_type']); ?></span>
                    </div>
                    <div class="detail-row">
                        <span class="lbl">Distance</span>
                        <span class="val"><?php echo $_SESSION['pending_booking']['distance_km']; ?> km</span>
                    </div>
                </div>

                <!-- Fare Breakdown -->
                <div class="fare-breakdown-box">
                    <div class="fare-row">
                        <span class="flbl"><i class="fa-solid fa-calculator"></i> Estimated Fare</span>
                        <span class="fval" id="display_total_fare">₹<?php echo number_format($total_fare, 2); ?></span>
                    </div>
                    <div class="fare-row discount" id="discount_row" style="display:none;">
                        <span class="flbl"><i class="fa-solid fa-tag"></i> Coupon Discount</span>
                        <span class="fval" id="display_discount">- ₹0.00</span>
                    </div>
                    <div class="fare-row" id="dfrow" style="display:none;">
                        <span class="flbl"><i class="fa-solid fa-receipt"></i> Fare After Discount</span>
                        <span class="fval" id="display_discounted_fare">₹<?php echo number_format($total_fare, 2); ?></span>
                    </div>
                    <div class="fare-row advance">
                        <span class="flbl"><i class="fa-solid fa-money-bill-wave"></i> Advance to Pay Now <small>(10%)</small></span>
                        <span class="fval" id="display_advance">₹<?php echo number_format($advance_paid, 2); ?></span>
                    </div>
                    <div class="fare-row">
                        <span class="flbl"><i class="fa-solid fa-handshake"></i> Balance to Driver After Trip <small>(90%)</small></span>
                        <span class="fval" id="display_balance">₹<?php echo number_format($driver_balance, 2); ?></span>
                    </div>
                    <div class="fare-row grand">
                        <span class="flbl"><strong>Total Fare</strong></span>
                        <span class="fval"><strong id="display_final">₹<?php echo number_format($total_fare, 2); ?></strong></span>
                    </div>
                </div>

                <!-- Coupon Code Section -->
                <div class="coupon-section">
                    <label><i class="fa-solid fa-ticket"></i> Have a Coupon Code?</label>
                    <?php if (!empty($coupons_display)): ?>
                    <div class="coupon-chips">
                        <?php foreach ($coupons_display as $cpn): ?>
                            <span class="coupon-chip"
                                  onclick="applyCouponFromChip('<?= htmlspecialchars($cpn['code']) ?>')"
                                  title="<?= htmlspecialchars($cpn['description'] ?? '') ?>">
                                <?= htmlspecialchars($cpn['code']) ?>
                            </span>
                        <?php endforeach; ?>
                    </div>
                    <?php endif; ?>
                    <div class="coupon-input-row">
                        <input type="text" id="coupon_input" placeholder="ENTER CODE" maxlength="30">
                        <button type="button" class="btn-apply-coupon" onclick="applyCoupon()">
                            <i class="fa-solid fa-check"></i> Apply
                        </button>
                    </div>
                    <div id="coupon_msg" class="coupon-msg"></div>
                </div>

                <form action="confirm_booking.php" method="POST" autocomplete="off">
                    <input type="hidden" name="pickup_location"  value="<?php echo htmlspecialchars($_SESSION['pending_booking']['pickup_location']); ?>">
                    <input type="hidden" name="drop_location"    value="<?php echo htmlspecialchars($_SESSION['pending_booking']['drop_location']); ?>">
                    <input type="hidden" name="pickup_date"      value="<?php echo htmlspecialchars($_SESSION['pending_booking']['pickup_date']); ?>">
                    <input type="hidden" name="pickup_time"      value="<?php echo htmlspecialchars($_SESSION['pending_booking']['pickup_time']); ?>">
                    <input type="hidden" name="return_date"      value="<?php echo htmlspecialchars($_SESSION['pending_booking']['return_date'] ?? ''); ?>">
                    <input type="hidden" name="trip_type"        value="<?php echo htmlspecialchars($_SESSION['pending_booking']['trip_type']); ?>">
                    <input type="hidden" name="car_type"         value="<?php echo htmlspecialchars($_SESSION['pending_booking']['car_type']); ?>">
                    <input type="hidden" name="distance"         value="<?php echo htmlspecialchars($_SESSION['pending_booking']['distance_km']); ?>">
                    <input type="hidden" name="total_fare"       value="<?php echo htmlspecialchars($total_fare); ?>">
                    <input type="hidden" name="discounted_fare"  id="form_discounted_fare"  value="<?php echo htmlspecialchars($total_fare); ?>">
                    <input type="hidden" name="advance_paid"     id="form_advance_paid"     value="<?php echo htmlspecialchars($advance_paid); ?>">
                    <input type="hidden" name="driver_balance"   id="form_driver_balance"   value="<?php echo htmlspecialchars($driver_balance); ?>">
                    <input type="hidden" name="coupon_code"      id="form_coupon_code"      value="">
                    <input type="hidden" name="coupon_discount"  id="form_coupon_discount"  value="0">

                    <div class="input-group">
                        <label for="customer_name">Your Full Name</label>
                        <input type="text" id="customer_name" name="customer_name"
                               placeholder="Enter your full name" required>
                    </div>
                    <div class="input-group">
                        <label for="customer_phone">Mobile Number</label>
                        <input type="tel" id="customer_phone" name="customer_phone"
                               placeholder="10-digit mobile number" pattern="[0-9]{10}" title="Enter a valid 10-digit mobile number" required>
                    </div>

                    <div class="action-flex-buttons">
                        <a href="index.php" class="btn-back-modify"><i class="fa-solid fa-arrow-left-long"></i> Back</a>
                        <button type="submit" class="submit-btn">
                            Confirm &amp; Pay Advance &nbsp;<i class="fa-solid fa-circle-check"></i>
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </main>

<script>
const BASE_FARE = <?php echo $total_fare; ?>;

function formatMoney(v) {
    return '₹' + parseFloat(v).toFixed(2).replace(/\B(?=(\d{3})+(?!\d))/g, ',');
}

function recalc(discountedFare, discountAmount, couponCode) {
    var advance = Math.round(discountedFare * 0.10 * 100) / 100;
    var balance = Math.round((discountedFare - advance) * 100) / 100;

    document.getElementById('display_advance').textContent  = formatMoney(advance);
    document.getElementById('display_balance').textContent  = formatMoney(balance);
    document.getElementById('display_final').textContent    = formatMoney(discountedFare);

    document.getElementById('form_advance_paid').value      = advance.toFixed(2);
    document.getElementById('form_driver_balance').value    = balance.toFixed(2);
    document.getElementById('form_discounted_fare').value   = discountedFare.toFixed(2);
    document.getElementById('form_coupon_code').value       = couponCode || '';
    document.getElementById('form_coupon_discount').value   = discountAmount ? discountAmount.toFixed(2) : '0';

    if (discountAmount > 0) {
        document.getElementById('display_discount').textContent       = '- ' + formatMoney(discountAmount);
        document.getElementById('display_discounted_fare').textContent = formatMoney(discountedFare);
        document.getElementById('discount_row').style.display = 'flex';
        document.getElementById('dfrow').style.display        = 'flex';
    } else {
        document.getElementById('discount_row').style.display = 'none';
        document.getElementById('dfrow').style.display        = 'none';
    }
}

function applyCouponFromChip(code) {
    document.getElementById('coupon_input').value = code;
    applyCoupon();
}

function applyCoupon() {
    var code = document.getElementById('coupon_input').value.trim().toUpperCase();
    var msg  = document.getElementById('coupon_msg');
    msg.className = 'coupon-msg';
    msg.textContent = '';

    if (!code) {
        msg.className = 'coupon-msg error';
        msg.textContent = 'Please enter a coupon code.';
        return;
    }

    fetch('validate_coupon.php?code=' + encodeURIComponent(code) + '&fare=' + BASE_FARE)
        .then(function(r) { return r.json(); })
        .then(function(data) {
            if (data.valid) {
                recalc(data.new_fare, data.discount_amount, data.code);
                msg.className   = 'coupon-msg success';
                msg.textContent = '✓ ' + data.code + ' applied! You save ' + formatMoney(data.discount_amount) + '.';
            } else {
                recalc(BASE_FARE, 0, '');
                msg.className   = 'coupon-msg error';
                msg.textContent = data.message || 'Invalid coupon code.';
            }
        })
        .catch(function() {
            msg.className   = 'coupon-msg error';
            msg.textContent = 'Could not validate coupon. Please try again.';
        });
}

// Allow pressing Enter in coupon input
document.getElementById('coupon_input').addEventListener('keydown', function(e) {
    if (e.key === 'Enter') { e.preventDefault(); applyCoupon(); }
});
</script>
</body>
</html>
