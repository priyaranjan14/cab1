<?php
session_start();

// 1. Establish System Database Connection
$conn = new mysqli("localhost", "root", "", "ranjancab"); // Synced with database name used in prior steps
if ($conn->connect_error) {
    die("Database connectivity failure: " . $conn->connect_error);
}

// 2. Parse Inbound Form Payload Data from index.php
$pickup_raw = isset($_POST['pickup_location']) ? trim($_POST['pickup_location']) : '';
$drop_raw   = isset($_POST['drop_location']) ? trim($_POST['drop_location']) : '';

if (empty($pickup_raw) || empty($drop_raw)) {
    header("Location: index.php?status=error&reason=missing_locations");
    exit();
}

/**
 * Robust Core Extraction Utility:
 * Isolates the anchor base city whether it contains a joined comma list or standard values.
 */
function extractBaseCity($locationString) {
    if (strpos($locationString, ',') !== false) {
        $parts = explode(',', $locationString);
        return trim($parts[0]);
    }
    return $locationString;
}

$final_pickup_search = extractBaseCity($pickup_raw); 
$final_drop_search   = extractBaseCity($drop_raw);   

// 3. PURE ROUTE VALIDATION ENGINE: Check for mapping connectivity in the routes table matrix
$distance = 0.00;
$route_stmt = $conn->prepare("SELECT estimated_distance FROM routes WHERE LOWER(pickup_point) = LOWER(?) AND LOWER(drop_point) = LOWER(?) LIMIT 1");

if ($route_stmt) {
    $route_stmt->bind_param("ss", $final_pickup_search, $final_drop_search);
    $route_stmt->execute();
    $route_stmt->bind_result($estimated_distance);
    
    if ($route_stmt->fetch()) {
        $distance = floatval($estimated_distance);
    } else {
        // Fallback directional evaluation check
        $route_stmt->free_result();
        $reverse_stmt = $conn->prepare("SELECT estimated_distance FROM routes WHERE LOWER(pickup_point) = LOWER(?) AND LOWER(drop_point) = LOWER(?) LIMIT 1");
        $reverse_stmt->bind_param("ss", $final_drop_search, $final_pickup_search);
        $reverse_stmt->execute();
        $reverse_stmt->bind_result($rev_distance);
        
        if ($reverse_stmt->fetch()) {
            $distance = floatval($rev_distance);
        } else {
            header("Location: index.php?status=error&reason=no_mapped_route");
            exit();
        }
        $reverse_stmt->close();
    }
    $route_stmt->close();
}

// ==========================================================================
// 4. FINANCIAL CALCULATIONS PROCESSING (DATABASE DRIVEN)
// ==========================================================================

// Fallback baseline defaults in case database lookup fails or car type is missing
$rate_per_km        = 14.50; 
$portal_charges     = 200.00;
$advance_threshold  = 500.00; // Treated as a flat Indian Rupee (INR) value

$car_type  = isset($_POST['car_type']) ? trim($_POST['car_type']) : 'Sedan';
$trip_type = isset($_POST['trip_type']) ? trim($_POST['trip_type']) : 'Oneway';
$distance  = isset($distance) ? floatval($distance) : 0.00; // Handled from previous segments

// Query pricing schema context mapping to selected car_type
$pricing_stmt = $conn->prepare("SELECT rate_per_km, portal_charges, advance_percentage FROM pricing_settings WHERE car_type = ? LIMIT 1");
if ($pricing_stmt) {
    $pricing_stmt->bind_param("s", $car_type);
    $pricing_stmt->execute();
    $pricing_res = $pricing_stmt->get_result();
    
    if ($row = $pricing_res->fetch_assoc()) {
        $rate_per_km       = floatval($row['rate_per_km']);
        $portal_charges    = floatval($row['portal_charges']);
        // Column matches structural field mapping, but processing reads it as flat INR
        $advance_threshold = floatval($row['advance_percentage']); 
    }
    $pricing_stmt->close();
}

// 1. Calculate Formula: (Distance X Rate per Km) + Portal Charges
$computed_fare = ($distance * $rate_per_km) + $portal_charges;

// 2. Evaluate Variable Scaling Multipliers based on User Selected Route Class
if ($trip_type === 'Roundtrip' || $trip_type === 'Round Trip') {
    $computed_fare = $computed_fare * 1.85; 
}

// Round total values cleanly to matching standard currency parameters
$total_fare = round($computed_fare, 2);

// 3. Set Flat Rupee Advance Deposit Requirement Checked Against Dynamic Thresholds
// If the trip cost falls below your minimum setup, capture full amount upfront; otherwise assign fixed threshold.
$advance_to_pay = ($total_fare < $advance_threshold) ? $total_fare : $advance_threshold;
$advance_to_pay = round($advance_to_pay, 2);

// Store data in session to retain info for visual fallback validation if needed
$_SESSION['pending_booking'] = [
    'pickup_location' => $pickup_raw, 
    'drop_location'   => $drop_raw,   
    'pickup_date'     => $_POST['pickup_date'] ?? '',
    'pickup_time'     => $_POST['pickup_time'] ?? '',
    'trip_type'       => $trip_type,
    'return_date'     => $_POST['return_date'] ?? null,
    'car_type'        => $_POST['car_type'] ?? '',
    'distance_km'     => $distance,
    'total_fare'      => round($computed_fare, 2)
];
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Review Your Ride | RanjanCabs</title>
    <link rel="stylesheet" href="style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        .review-details-container {
            background: #ffffff;
            border-radius: 6px;
            padding: 15px;
            margin-bottom: 20px;
            border: 1px dashed #cbd5e1;
        }
        .detail-row {
            display: flex;
            justify-content: space-between;
            padding: 10px 0;
            border-bottom: 1px solid #f1f5f9;
            font-size: 13px;
        }
        .detail-row:last-child {
            border-bottom: none;
        }
        .detail-row span:first-child {
            color: #64748b;
            font-weight: 500;
        }
        .detail-row span:last-child {
            color: #0f172a;
            font-weight: 600;
            text-align: right;
            max-width: 65%;
        }
        .fare-display-box {
            background: #f0f9ff;
            border: 1px solid #bae6fd;
            border-radius: 6px;
            padding: 12px;
            text-align: center;
            margin-bottom: 20px;
        }
        .fare-display-box span {
            font-size: 11px;
            color: #0369a1;
            font-weight: 700;
            text-transform: uppercase;
            letter-spacing: 0.5px;
        }
        .fare-display-box .amount {
            font-size: 26px;
            font-weight: 800;
            color: #0369a1;
            margin-top: 2px;
        }
        .action-flex-buttons {
            display: flex;
            gap: 12px;
            margin-top: 20px;
        }
        .action-flex-buttons .btn-back-modify {
            flex: 1;
            background: #cbd5e1;
            color: #334155;
            text-align: center;
            padding: 12px;
            border-radius: 6px;
            text-decoration: none;
            font-size: 14px;
            font-weight: 600;
            transition: background 0.2s;
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 6px;
        }
        .action-flex-buttons .btn-back-modify:hover {
            background: #94a3b8;
        }
        .action-flex-buttons .btn-submit-booking {
            flex: 2;
            margin-bottom: 0; 
        }
    </style>
</head>
<body>

    <header class="navbar">
        <div class="nav-container">
            <div class="logo">
                <a href="index.php"><i class="fa-solid fa-taxi"></i> Ranjan<span>Cabs</span></a>
            </div>
            
            <nav class="nav-menu" id="navMenu">
                <a href="index.php" class="active">Home</a>
                <a href="#">Our Fleet</a>
                <a href="#">Services</a>
                <a href="#">Contact</a>
            </nav>

            <div class="nav-actions">
                <div class="dropdown">
                    <button class="login-btn"><i class="fa-solid fa-user"></i> Login <i class="fa-solid fa-caret-down"></i></button>
                    <div class="dropdown-content">
                        <a href="login.php"><i class="fa-solid fa-user-tie"></i> Customer Login</a>
                        <a href="driver_login.php?role=driver"><i class="fa-solid fa-id-card"></i> Driver Login</a>
                        <a href="admin_login.php?role=admin"><i class="fa-solid fa-user-gear"></i> Admin Portal</a>
                    </div>
                </div>
                <button class="menu-toggle" id="mobileMenuBtn">
                    <i class="fa-solid fa-bars"></i>
                </button>
            </div>
        </div>
    </header>

    <main class="hero-section">
        <div class="hero-overlay"></div>
        <div class="hero-container">
            
            <div class="hero-text">
                <h1>Verify Details, <br>Confirm Your Ride.</h1>
                <p>Please review your routing itinerary parameters and fill out the contact fields below to dispatch your professional driver asset.</p>
            </div>

            <div class="booking-card">
                <h2><i class="fa-solid fa-clipboard-check"></i> Book a Taxi (Step 2 of 2)</h2>
                
                <div class="review-details-container">
                    <div class="detail-row">
                        <span>Journey Classification</span>
                        <span><?php echo htmlspecialchars($_SESSION['pending_booking']['trip_type']); ?></span>
                    </div>
                    <div class="detail-row">
                        <span>Pickup Address</span>
                        <span><?php echo htmlspecialchars($_SESSION['pending_booking']['pickup_location']); ?></span>
                    </div>
                    <div class="detail-row">
                        <span>Drop Address</span>
                        <span><?php echo htmlspecialchars($_SESSION['pending_booking']['drop_location']); ?></span>
                    </div>
                    <div class="detail-row">
                        <span>Scheduled Setup</span>
                        <span><?php echo date("d-M-Y", strtotime($_SESSION['pending_booking']['pickup_date'])); ?> @ <?php echo htmlspecialchars($_SESSION['pending_booking']['pickup_time']); ?></span>
                    </div>
                    <?php if(!empty($_SESSION['pending_booking']['return_date'])): ?>
                    <div class="detail-row">
                        <span>Return Journey Setup</span>
                        <span><?php echo date("d-M-Y", strtotime($_SESSION['pending_booking']['return_date'])); ?></span>
                    </div>
                    <?php endif; ?>
                    <div class="detail-row">
                        <span>Vehicle Class Variant</span>
                        <span><?php echo htmlspecialchars($_SESSION['pending_booking']['car_type']); ?></span>
                    </div>
                    <div class="detail-row">
                        <span>Base Track Distance</span>
                        <span><?php echo $_SESSION['pending_booking']['distance_km']; ?> km</span>
                    </div>
                </div>

                <div class="fare-display-box">
                    <span>Computational Estimated Fare</span>
                    <div class="amount">₹<?php echo number_format($_SESSION['pending_booking']['total_fare'], 2); ?></div>
                </div>

                <form action="confirm_booking.php" method="POST" autocomplete="off">
                    
                    <input type="hidden" name="pickup_location" value="<?php echo htmlspecialchars($_SESSION['pending_booking']['pickup_location']); ?>">
                    <input type="hidden" name="drop_location" value="<?php echo htmlspecialchars($_SESSION['pending_booking']['drop_location']); ?>">
                    <input type="hidden" name="pickup_date" value="<?php echo htmlspecialchars($_SESSION['pending_booking']['pickup_date']); ?>">
                    <input type="hidden" name="pickup_time" value="<?php echo htmlspecialchars($_SESSION['pending_booking']['pickup_time']); ?>">
                    <input type="hidden" name="return_date" value="<?php echo htmlspecialchars($_SESSION['pending_booking']['return_date'] ?? ''); ?>">
                    <input type="hidden" name="trip_type" value="<?php echo htmlspecialchars($_SESSION['pending_booking']['trip_type']); ?>">
                    <input type="hidden" name="car_type" value="<?php echo htmlspecialchars($_SESSION['pending_booking']['car_type']); ?>">
                    <input type="hidden" name="distance" value="<?php echo htmlspecialchars($_SESSION['pending_booking']['distance_km']); ?>">
                    <input type="hidden" name="total_fare" value="<?php echo htmlspecialchars($_SESSION['pending_booking']['total_fare']); ?>">
                    
                    <div class="input-group">
                        <label for="customer_name">Passenger Full Name</label>
                        <input type="text" id="customer_name" name="customer_name" placeholder="Enter your full name" required>
                    </div>

                    <div class="input-group">
                        <label for="customer_phone">Mobile Number (For Dispatch Alerts)</label>
                        <input type="tel" id="customer_phone" name="customer_phone" placeholder="Enter 10-digit mobile phone number" pattern="[0-9]{10}" title="Please enter a valid 10-digit mobile number" required>
                    </div>

                    <div class="action-flex-buttons">
                        <a href="index.php" class="btn-back-modify"><i class="fa-solid fa-arrow-left-long"></i> Back</a>
                        <button type="submit" class="submit-btn btn-submit-booking">Confirm Booking <i class="fa-solid fa-circle-check" style="margin-left: 4px;"></i></button>
                    </div>

                </form>
            </div>

        </div>
    </main>

<script>
    const mobileMenuBtn = document.getElementById('mobileMenuBtn');
    const navMenu = document.getElementById('navMenu');

    mobileMenuBtn.addEventListener('click', () => {
        navMenu.classList.toggle('active');
    });
</script>
</body>
</html>
<?php $conn->close(); ?>