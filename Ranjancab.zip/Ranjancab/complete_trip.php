<?php
session_start();
header('Content-Type: application/json');

if (!isset($_SESSION['driver_id'])) {
    echo json_encode(['success' => false, 'message' => 'Session expired. Please log in again.']);
    exit();
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo json_encode(['success' => false, 'message' => 'Invalid request method.']);
    exit();
}

$driver_id  = intval($_SESSION['driver_id']);
$booking_id = isset($_POST['booking_id']) ? intval($_POST['booking_id']) : 0;

$conn = new mysqli("localhost", "root", "", "ranjancab");
if ($conn->connect_error) {
    echo json_encode(['success' => false, 'message' => 'Database connection failure.']);
    exit();
}

// Update the booking status to 3 (Completed) only if it belongs to this driver and is currently active (2)
$sql = "UPDATE bookings SET booking_flag = 3 WHERE id = ? AND assigned_driver_id = ? AND booking_flag = 2";
$stmt = $conn->prepare($sql);
$stmt->bind_param("ii", $booking_id, $driver_id);
$stmt->execute();

if ($stmt->affected_rows > 0) {
    echo json_encode(['success' => true, 'message' => 'Trip marked as completed successfully.']);
} else {
    echo json_encode(['success' => false, 'message' => 'Unable to update trip status. Verify if trip state is valid.']);
}

$stmt->close();
$conn->close();
exit();
?>