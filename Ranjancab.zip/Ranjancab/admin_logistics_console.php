<?php
// Operational States Logistics Console Module
if (!defined('ADMIN_SHIELD_ACTIVE')) { die('Direct system access restricted.'); }
?>
<div class="data-table-frame" style="border-top: 4px solid #0284c7;">
    <h3 style="margin: 0 0 20px 0; color: #0f172a; font-size: 16px;"><i class="fa-solid fa-receipt" style="color:#0284c7;"></i> Operational States Logistics Console</h3>
    
    <?php if(!empty($booking_msg)): ?>
        <div class="alert-notify" style="background:#f0f9ff; color:#0369a1; padding: 12px; margin-bottom: 15px; border-radius: 4px;"><i class="fa-solid fa-bolt"></i> <?php echo htmlspecialchars($booking_msg); ?></div>
    <?php endif; ?>

    <div class="tab-navigation-bar" style="display: flex; gap: 10px; margin-bottom: 20px; border-bottom: 2px solid #e2e8f0; padding-bottom: 2px;">
        <button class="tab-trigger active" onclick="switchOperationalTab(event, 'tab-in-transit')" style="padding: 10px 20px; border: none; background: none; font-weight: 600; font-size: 13px; cursor: pointer; color: #0284c7; border-bottom: 2px solid #0284c7;">In Transit</button>
        <button class="tab-trigger" onclick="switchOperationalTab(event, 'tab-past-rides')" style="padding: 10px 20px; border: none; background: none; font-weight: 600; font-size: 13px; cursor: pointer; color: #64748b;">Past Rides</button>
        <button class="tab-trigger" onclick="switchOperationalTab(event, 'tab-cancelled-rides')" style="padding: 10px 20px; border: none; background: none; font-weight: 600; font-size: 13px; cursor: pointer; color: #64748b;">Cancelled</button>
    </div>

    <div id="tab-in-transit" class="operational-tab-content" style="display: block;">
        <table class="transit-table" style="width:100%; border-collapse: collapse;">
            <thead>
                <tr>
                    <th>Ref No</th>
                    <th>Layout Type</th>
                    <th>Customer Info</th>
                    <th>Route Context</th>
                    <th>Class</th>
                    <th>Schedule (Outbound / Return)</th>
                    <th>OTP</th>
                    <th>Driver</th>
                    <th>Fare</th>
                    <th>Override</th>
                </tr>
            </thead>
            <tbody>
                <?php if($in_transit_result && $in_transit_result->num_rows > 0): ?>
                    <?php while($b_row = $in_transit_result->fetch_assoc()): ?>
                        <tr>
                            <td><strong style="color:#0284c7;"><?php echo htmlspecialchars($b_row['booking_ref_no']); ?></strong></td>
                            <td>
                                <?php if($b_row['trip_type'] === 'Roundtrip' || $b_row['trip_type'] === 'Round Trip'): ?>
                                    <span class="status-badge" style="background:#e0f2fe; color:#0369a1; padding: 2px 6px; border-radius: 4px; font-size: 11px;"><i class="fa-solid fa-arrows-rotate"></i> Round-Trip</span>
                                <?php else: ?>
                                    <span class="status-badge" style="background:#f1f5f9; color:#475569; padding: 2px 6px; border-radius: 4px; font-size: 11px;"><i class="fa-solid fa-arrow-right-long"></i> One-Way</span>
                                <?php endif; ?>
                            </td>
                            <td><strong><?php echo htmlspecialchars($b_row['customer_name']); ?></strong><br><small><?php echo htmlspecialchars($b_row['customer_phone']); ?></small></td>
                            <td><small style="font-weight:600;"><?php echo htmlspecialchars($b_row['pickup_location']); ?></small><br><small style="color:#64748b;">➔ <?php echo htmlspecialchars($b_row['drop_location']); ?></small></td>
                            <td><span class="status-badge" style="background:#f1f5f9; color:#334155; padding: 2px 6px; border-radius: 4px; font-size: 11px;"><?php echo htmlspecialchars($b_row['car_type']); ?></span></td>
                            <td>
                                <small><strong>Depart:</strong> <?php echo date("d-M-y", strtotime($b_row['pickup_date'])); ?> @ <?php echo date("g:i A", strtotime($b_row['pickup_time'])); ?></small>
                                <?php if(!empty($b_row['return_date'])): ?>
                                    <br><small style="color:#0284c7;"><strong>Return:</strong> <?php echo date("d-M-y", strtotime($b_row['return_date'])); ?></small>
                                <?php endif; ?>
                            </td>
                            <td><code style="font-size:13px; font-weight:700; color:#0369a1; background:#e0f2fe; padding:2px 6px; border-radius:4px;"><?php echo htmlspecialchars($b_row['otp_code']); ?></code></td>
                            <td><?php echo htmlspecialchars($b_row['driver_name'] ?? 'Unassigned'); ?></td>
                            <td><strong>₹<?php echo htmlspecialchars($b_row['driver_balance']); ?></strong></td>
                            <td>
                                <form action="admin.php" method="POST" class="inline-action-form" style="margin:0;">
                                    <input type="hidden" name="action" value="assign_booking_driver">
                                    <input type="hidden" name="booking_id" value="<?php echo $b_row['id']; ?>">
                                    <select name="driver_id" onchange="this.form.submit()" style="padding:4px; font-size:11px; width:130px;">
                                        <option value="">-- Assign --</option>
                                        <?php $drivers_for_bookings->data_seek(0); while($d = $drivers_for_bookings->fetch_assoc()): ?>
                                            <option value="<?php echo $d['id']; ?>" <?php echo ($b_row['assigned_driver_id'] == $d['id']) ? 'selected' : ''; ?>><?php echo htmlspecialchars($d['driver_name']); ?></option>
                                        <?php $drivers_for_bookings->data_seek(0); endwhile; ?>
                                    </select>
                                </form>
                            </td>
                        </tr>
                    <?php endwhile; ?>
                <?php else: ?>
                    <tr><td colspan="10" style="text-align: center; color: #94a3b8; padding: 30px 0;">No active journeys.</td></tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>

    <div id="tab-past-rides" class="operational-tab-content" style="display: none;">
        <table class="transit-table" style="width:100%; border-collapse: collapse;">
            <thead>
                <tr>
                    <th>Ref No</th>
                    <th>Type</th>
                    <th>Customer</th>
                    <th>Route</th>
                    <th>Class</th>
                    <th>Date Completed</th>
                    <th>Flfilled By</th>
                    <th>Revenue</th>
                </tr>
            </thead>
            <tbody>
                <?php if($past_rides_result && $past_rides_result->num_rows > 0): ?>
                    <?php while($b_row = $past_rides_result->fetch_assoc()): ?>
                        <tr style="background: #f8fafc;">
                            <td><strong style="color:#166534;"><?php echo htmlspecialchars($b_row['booking_ref_no']); ?></strong></td>
                            <td><small><?php echo htmlspecialchars($b_row['trip_type']); ?></small></td>
                            <td><strong><?php echo htmlspecialchars($b_row['customer_name']); ?></strong></td>
                            <td><small><?php echo htmlspecialchars($b_row['pickup_location']); ?> ➔ <?php echo htmlspecialchars($b_row['drop_location']); ?></small></td>
                            <td><span class="status-badge" style="padding: 2px 6px; border-radius: 4px; font-size: 11px;"><?php echo htmlspecialchars($b_row['car_type']); ?></span></td>
                            <td><small><?php echo date("d-M-Y", strtotime($b_row['pickup_date'])); ?></small></td>
                            <td><strong><?php echo htmlspecialchars($b_row['driver_name'] ?? 'System Sync'); ?></strong></td>
                            <td><strong style="color:#166534;">₹<?php echo htmlspecialchars($b_row['driver_balance']); ?></strong></td>
                        </tr>
                    <?php endwhile; ?>
                <?php else: ?>
                    <tr><td colspan="8" style="text-align: center; color: #94a3b8; padding: 30px 0;">No history logged.</td></tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>

    <div id="tab-cancelled-rides" class="operational-tab-content" style="display: none;">
        <table class="transit-table" style="width:100%; border-collapse: collapse;">
            <thead>
                <tr>
                    <th>Ref No</th>
                    <th>Type</th>
                    <th>Customer Info</th>
                    <th>Intended Route</th>
                    <th>Vehicle Class</th>
                    <th>Status</th>
                </tr>
            </thead>
            <tbody>
                <?php if($cancelled_result && $cancelled_result->num_rows > 0): ?>
                    <?php while($b_row = $cancelled_result->fetch_assoc()): ?>
                        <tr style="background:#fff5f5; color:#991b1b;">
                            <td><strong><?php echo htmlspecialchars($b_row['booking_ref_no']); ?></strong></td>
                            <td><small><?php echo htmlspecialchars($b_row['trip_type']); ?></small></td>
                            <td><strong><?php echo htmlspecialchars($b_row['customer_name']); ?></strong></td>
                            <td><small><?php echo htmlspecialchars($b_row['pickup_location']); ?> ➔ <?php echo htmlspecialchars($b_row['drop_location']); ?></small></td>
                            <td><?php echo htmlspecialchars($b_row['car_type']); ?></td>
                            <td><span class="status-badge" style="background:#ef4444; color:#fff; padding: 2px 6px; border-radius: 4px; font-size: 11px;">Dropped</span></td>
                        </tr>
                    <?php endwhile; ?>
                <?php else: ?>
                    <tr><td colspan="6" style="text-align: center; color: #94a3b8; padding: 30px 0;">No administrative cancellations logged.</td></tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>