<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>CityCabs | Premium Taxi Booking</title>
    <link rel="stylesheet" href="style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
<style>
    /* --- Trip Type Tabs Layout Container --- */
.trip-type-tabs { 
    display: flex; 
    background: transparent; /* Blank/Transparent Background container */
    padding: 0; 
    border-radius: 4px; 
    gap: 10px; 
    margin-bottom: 20px; 
    width: 100%;
}

/* --- Individual Tab State (Matches Submit Button Baseline) --- */
.trip-tab { 
    flex: 1; 
    background: transparent; /* Blank background baseline */
    color: var(--primary-color); /* Yellow Text */
    border: 2px solid var(--primary-color); /* Yellow border framing */
    padding: 12px; 
    font-size: 14px; 
    font-weight: 700; 
    text-transform: uppercase; 
    letter-spacing: 0.5px;
    border-radius: 4px; 
    cursor: pointer; 
    transition: background var(--transition-speed), color var(--transition-speed); 
    text-align: center;
}

/* --- Active/Selected Tab State (Inverts exactly like Submit Button Hover) --- */
.trip-tab.active { 
    background-color: var(--secondary-color); /* Dark Charcoal */
    color: var(--primary-color); /* Keeps the distinct Yellow Text */
    border-color: var(--secondary-color);
    box-shadow: 0 4px 10px rgba(0, 0, 0, 0.15);
}

/* --- Optional Hover State for Polish --- */
.trip-tab:hover:not(.active) {
    background-color: rgba(255, 193, 7, 0.1); /* Subtle yellow tint on hover */
}
    </style>
</head>
<body>

<?php
include 'header1.php';
?>
    
    <main class="hero-section">
        <div class="hero-overlay"></div>
        <div class="hero-container">
            
            <div class="hero-text">
                <h1>Reliable Rides, <br>Just a Click Away.</h1>
                <p>Book your ride instantly with RanjanCabs. Safe, affordable, and 24/7 professional service at your doorstep.</p>
            </div>

            <div class="booking-card">
                <h2><i class="fa-solid fa-map-location-dot"></i> Book a Taxi (Step 1 of 2)</h2>
                
                <?php
                if (isset($_GET['status'])) {
                    if ($_GET['status'] == 'success') {
                        echo '<p class="alert success"><i class="fa-solid fa-circle-check"></i> Ride booked successfully!</p>';
                    } elseif ($_GET['status'] == 'error') {
                        $reason = isset($_GET['reason']) ? htmlspecialchars($_GET['reason']) : '';
                        if ($reason == 'unsupported_pickup_station' || $reason == 'invalid_pickup_zone') {
                            echo '<p class="alert error"><i class="fa-solid fa-circle-exclamation"></i> Pickup city is outside our operational service range.</p>';
                        } elseif ($reason == 'unsupported_drop_station' || $reason == 'invalid_drop_zone') {
                            echo '<p class="alert error"><i class="fa-solid fa-circle-exclamation"></i> Drop destination city is outside our operational service range.</p>';
                        } elseif ($reason == 'no_mapped_route') {
                            echo '<p class="alert error"><i class="fa-solid fa-circle-exclamation"></i> No standard transit route found between these cities.</p>';
                        } else {
                            echo '<p class="alert error"><i class="fa-solid fa-circle-exclamation"></i> Error processing booking. Try again.</p>';
                        }
                    }
                }
                ?>

                <div class="trip-type-tabs">
                    <button type="button" id="tab-oneway" class="trip-tab active" onclick="updateJourneyLayout('Oneway')">One-Way</button>
                    <button type="button" id="tab-roundtrip" class="trip-tab" onclick="updateJourneyLayout('Roundtrip')">Round-Trip</button>
                </div>

                <form action="review.php" method="POST" id="bookingForm" autocomplete="off">
                    <input type="hidden" name="trip_type" id="trip_type_input" value="Oneway">

                    <div class="input-group">
                        <label for="pickup">Pickup Location</label>
                        <input type="text" id="pickup" name="pickup_location" placeholder="Enter pickup address" required>
                        <div id="pickupSuggest" class="autosuggest-panel"></div>
                        
                        <div id="pickup_custom_container" class="custom-address-field">
                            <label id="pickup_custom_label" for="pickup_manual_address">Specify Address</label>
                            <input type="text" id="pickup_manual_address" placeholder="e.g., House No. 42, Sector C, Arera Colony">
                        </div>
                    </div>

                    <div class="input-group">
                        <label for="drop">Drop Location</label>
                        <input type="text" id="drop" name="drop_location" placeholder="Enter destination address" required>
                        <div id="dropSuggest" class="autosuggest-panel"></div>

                        <div id="drop_custom_container" class="custom-address-field">
                            <label id="drop_custom_label" for="drop_manual_address">Specify Address</label>
                            <input type="text" id="drop_manual_address" placeholder="e.g., Office Suite 101, DB City Corporate Park">
                        </div>
                    </div>

                    <div class="row">
                        <div class="input-group">
                            <label for="date">Pickup Date</label>
                            <input type="date" id="date" name="pickup_date" required>
                        </div>
                        <div class="input-group">
                            <label for="time">Pickup Time</label>
                            <input type="time" id="time" name="pickup_time" required>
                        </div>
                    </div>

                    <div id="return_date_wrapper" class="input-group" style="display: none;">
                        <label for="return_date" style="color: #0284c7; font-weight: 700;">Return Date</label>
                        <input type="date" id="return_date" name="return_date">
                    </div>

                    <div class="input-group">
                        <label for="car_type">Select Vehicle Class</label>
                        <select id="car_type" name="car_type" required>
                            <option value="" disabled selected>Choose a car option</option>
                            <option value="Economy">Economy</option>
                            <option value="Sedan">Sedan</option>
                            <option value="SUV">SUV</option>
                            <option value="Luxury">Luxury</option>
                        </select>
                    </div>

                    <button type="submit" class="submit-btn">Check Fare & Review Details</button>
                </form>
            </div>
        </div>
    </main>

<script>
    // Navigation Toggle Logic
    const mobileMenuBtn = document.getElementById('mobileMenuBtn');
    const navMenu = document.getElementById('navMenu');
    mobileMenuBtn.addEventListener('click', () => { navMenu.classList.toggle('active'); });

    const dateInput = document.getElementById('date');
    const timeInput = document.getElementById('time');
    const returnDateInput = document.getElementById('return_date');
    const today = new Date();
    const formattedToday = `${today.getFullYear()}-${String(today.getMonth() + 1).padStart(2, '0')}-${String(today.getDate()).padStart(2, '0')}`;
    dateInput.min = formattedToday;

    function updateJourneyLayout(type) {
        document.getElementById('tab-oneway').classList.remove('active');
        document.getElementById('tab-roundtrip').classList.remove('active');
        document.getElementById('trip_type_input').value = type;
        
        if (type === 'Oneway') {
            document.getElementById('tab-oneway').classList.add('active');
            document.getElementById('return_date_wrapper').style.display = 'none';
            returnDateInput.removeAttribute('required');
        } else {
            document.getElementById('tab-roundtrip').classList.add('active');
            document.getElementById('return_date_wrapper').style.display = 'block';
            returnDateInput.setAttribute('required', 'required');
            returnDateInput.min = dateInput.value || formattedToday;
        }
    }

    // Helper to get pure city anchor name from "Bhopal (Other Location)"
    function getCleanCityName(val) {
        if(val.includes('(Other Location)')) {
            return val.split('(')[0].trim();
        }
        return val.trim();
    }

    function evaluateLocationCustomStatus(inputElement, containerId, innerFieldId, labelId) {
        const container = document.getElementById(containerId);
        const innerField = document.getElementById(innerFieldId);
        const label = document.getElementById(labelId);
        
        if (inputElement.value.includes('(Other Location)')) {
            const cityName = getCleanCityName(inputElement.value);
            label.innerText = `Specify Custom Address inside ${cityName}`;
            container.style.display = 'block';
            innerField.setAttribute('required', 'required');
        } else {
            container.style.display = 'none';
            innerField.removeAttribute('required');
            innerField.value = '';
        }
    }

    document.getElementById('pickup').addEventListener('input', function() {
        evaluateLocationCustomStatus(this, 'pickup_custom_container', 'pickup_manual_address', 'pickup_custom_label');
    });
    document.getElementById('drop').addEventListener('input', function() {
        evaluateLocationCustomStatus(this, 'drop_custom_container', 'drop_manual_address', 'drop_custom_label');
    });

    // Formatting payload fields explicitly before data transport 
    document.getElementById('bookingForm').addEventListener('submit', function(e) {
        const pInput = document.getElementById('pickup');
        const pManual = document.getElementById('pickup_manual_address');
        const dInput = document.getElementById('drop');
        const dManual = document.getElementById('drop_manual_address');

        if (pInput.value.includes('(Other Location)') && pManual.value.trim() !== '') {
            const city = getCleanCityName(pInput.value);
            pInput.value = `${city}, ${pManual.value.trim()}`;
        }
        if (dInput.value.includes('(Other Location)') && dManual.value.trim() !== '') {
            const city = getCleanCityName(dInput.value);
            dInput.value = `${city}, ${dManual.value.trim()}`;
        }
    });

    let masterLocationDatabase = [];
    function loadRouteDataViaAJAX() {
        const xhr = new XMLHttpRequest();
        xhr.open('GET', 'get_routes.php', true);
        xhr.onload = function() {
            if (xhr.status >= 200 && xhr.status < 400) {
                try {
                    const data = JSON.parse(xhr.responseText);
                    masterLocationDatabase = data.locations || [];
                } catch (e) {}
            }
        };
        xhr.send();
    }
    loadRouteDataViaAJAX();

    function setupSuggestions(inputElementId, panelElementId, containerId, innerFieldId, labelId) {
        const input = document.getElementById(inputElementId);
        const panel = document.getElementById(panelElementId);
        
        input.addEventListener('input', function() {
            const query = this.value.toLowerCase().trim();
            panel.innerHTML = '';
            if (query.length === 0) { panel.style.display = 'none'; return; }
            
            const matches = masterLocationDatabase.filter(item => item.toLowerCase().includes(query));
            if (matches.length > 0) {
                matches.forEach(match => {
                    const div = document.createElement('div');
                    div.className = 'suggest-item';
                    div.innerHTML = `<i class="fa-solid fa-location-dot"></i> <span>${match}</span>`;
                    div.addEventListener('click', () => {
                        input.value = match;
                        panel.style.display = 'none';
                        evaluateLocationCustomStatus(input, containerId, innerFieldId, labelId);
                    });
                    panel.appendChild(div);
                });
                panel.style.display = 'block';
            } else { panel.style.display = 'none'; }
        });
    }
    setupSuggestions('pickup', 'pickupSuggest', 'pickup_custom_container', 'pickup_manual_address', 'pickup_custom_label');
    setupSuggestions('drop', 'dropSuggest', 'drop_custom_container', 'drop_manual_address', 'drop_custom_label');
</script>
</body>
</html>