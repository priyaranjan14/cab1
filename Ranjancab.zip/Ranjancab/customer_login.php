<?php
session_start();

// If a customer session is already active, skip the login screen entirely
if (isset($_SESSION['customer_id'])) {
    header("Location: customer_dashboard.php");
    exit();
}

$error_message = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $mobile_number = trim($_POST['mobile_number']);

    if (!empty($mobile_number)) {
        
        $conn = new mysqli("localhost", "root", "", "ranjancab");
        if ($conn->connect_error) {
            die("Database connection failed: " . $conn->connect_error);
        }

        // FIXED: Changed first_name/last_name to customer_name, and mobile_number to customer_phone to align with the schema
        $stmt = $conn->prepare("SELECT id, customer_name, customer_phone FROM bookings WHERE customer_phone = ? ORDER BY id DESC LIMIT 1");
        $stmt->bind_param("s", $mobile_number);
        $stmt->execute();
        $result = $stmt->get_result();
        
        if ($result->num_rows > 0) {
            $user = $result->fetch_assoc();
            
            // Set session tokens for the dashboard
            $_SESSION['customer_id']    = $user['id'];
            $_SESSION['customer_name']  = $user['customer_name']; // Maps perfectly to the dashboard pipeline variable
            $_SESSION['customer_phone'] = $user['customer_phone'];
            
            $stmt->close(); 
            $conn->close();
            header("Location: customer_dashboard.php");
            exit();
        } else {
            $error_message = "Mobile Number not found in our booking history.";
        }
        $stmt->close();
        $conn->close();
    } else {
        $error_message = "Please enter your registered mobile number.";
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Customer Fast Login | RanjanCabs</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        body { font-family: Arial, sans-serif; background: #f4f6f9; display: flex; flex-direction: column; min-height: 100vh; margin: 0; }
        .navbar { background-color: #2c3e50; padding: 15px 30px; display: flex; justify-content: space-between; align-items: center; box-shadow: 0 2px 5px rgba(0,0,0,0.1); }
        .navbar .logo a { color: #fff; text-decoration: none; font-size: 22px; font-weight: bold; }
        .navbar .logo span { color: #f1c40f; }
        .navbar .back-btn { color: #fff; text-decoration: none; border: 1px solid rgba(255,255,255,0.4); padding: 6px 12px; border-radius: 4px; font-size: 14px; }
        .login-container { flex: 1; display: flex; justify-content: center; align-items: center; padding: 20px; }
        .booking-card { background: white; padding: 35px; border-radius: 8px; box-shadow: 0 4px 15px rgba(0,0,0,0.1); width: 100%; max-width: 400px; }
        h2 { text-align: center; margin-bottom: 8px; color: #2c3e50; }
        .subtitle { text-align: center; color: #666; font-size: 13px; margin-bottom: 20px; }
        .input-group { margin-bottom: 18px; }
        label { display: block; margin-bottom: 6px; font-weight: bold; color: #555; font-size: 14px; }
        input { width: 100%; padding: 11px; border: 1px solid #ccc; border-radius: 4px; box-sizing: border-box; font-size: 15px; }
        .submit-btn { width: 100%; padding: 12px; background: #2c3e50; color: white; border: none; border-radius: 4px; font-weight: bold; cursor: pointer; font-size: 16px; margin-top: 10px; }
        .submit-btn:hover { background: #34495e; }
        .alert { color: #e74c3c; background: #fde8e7; padding: 12px; border-radius: 4px; margin-bottom: 20px; font-size: 14px; border-left: 4px solid #e74c3c; }
        .role-switch { text-align: center; margin-top: 20px; padding-top: 15px; border-top: 1px solid #eee; font-size: 14px; }
        .role-switch a { color: #2563eb; font-weight: bold; text-decoration: none; }
        .test-badge { background: #e8f4fd; color: #1d4ed8; padding: 10px; border-radius: 4px; font-size: 12px; text-align: center; margin-top: 15px; }
    </style>
</head>
<body>

    <header class="navbar">
        <div class="logo">
            <a href="index.php"><i class="fa-solid fa-taxi"></i> Ranjan<span>Cabs</span></a>
        </div>
        <div><a href="index.php" class="back-btn">Back to Home</a></div>
    </header>

    <main class="login-container">
        <div class="booking-card">
            <h2><i class="fa-solid fa-bolt"></i> Express Login</h2>
            <p class="subtitle">Testing Mode: Access your dashboard with just your phone number.</p>
            
            <?php if (!empty($error_message)): ?>
                <div class="alert error"><i class="fa-solid fa-circle-exclamation"></i> <?php echo $error_message; ?></div>
            <?php endif; ?>

            <form action="customer_login.php" method="POST">
                <div class="input-group">
                    <label for="mobile_number">Registered Mobile Number</label>
                    <input type="tel" id="mobile_number" name="mobile_number" placeholder="e.g. Enter any mobile no from bookings" required>
                </div>

                <button type="submit" class="submit-btn">Bypass & Launch Dashboard</button>
            </form>

            <div class="test-badge">
                <strong>Testing Quick Tip:</strong> Make sure the mobile number you enter already exists inside your database's <code>bookings</code> table.
            </div>

            <div class="role-switch">
                Switch to Driver Portal? <a href="login.php">Driver Login ➔</a>
            </div>
        </div>
    </main>

</body>
</html>