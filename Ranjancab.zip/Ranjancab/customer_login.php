<?php
session_start();
require_once 'db.php';

// If a customer session is already active, skip the login screen entirely
if (isset($_SESSION['customer_id'])) {
    header("Location: customer_dashboard.php");
    exit();
}

$error_message = "";
$active_tab = "password"; // Default tab

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $action = $_POST['action'] ?? 'password_login';
    
    if ($action === 'password_login') {
        $active_tab = "password";
        $login_input = trim($_POST['login_input'] ?? '');
        $password = trim($_POST['password'] ?? '');

        if (!empty($login_input) && !empty($password)) {
            // Check customer_credentials
            $stmt = $conn->prepare("SELECT customer_phone, password FROM customer_credentials WHERE customer_phone = ? OR customer_email = ? LIMIT 1");
            $stmt->bind_param("ss", $login_input, $login_input);
            $stmt->execute();
            $res = $stmt->get_result();
            
            if ($res->num_rows > 0) {
                $cred = $res->fetch_assoc();
                if (password_verify($password, $cred['password'])) {
                    // Fetch latest booking details for this phone number to populate session
                    $b_stmt = $conn->prepare("SELECT id, customer_name, customer_phone FROM bookings WHERE customer_phone = ? ORDER BY id DESC LIMIT 1");
                    $b_stmt->bind_param("s", $cred['customer_phone']);
                    $b_stmt->execute();
                    $b_res = $b_stmt->get_result();
                    
                    if ($b_res->num_rows > 0) {
                        $user = $b_res->fetch_assoc();
                        $_SESSION['customer_id']    = $user['id'];
                        $_SESSION['customer_name']  = $user['customer_name'];
                        $_SESSION['customer_phone'] = $user['customer_phone'];
                        
                        $b_stmt->close();
                        $stmt->close();
                        header("Location: customer_dashboard.php");
                        exit();
                    } else {
                        // Edge case: Credentials exist but no booking history was found
                        // We will set name as "Valued Customer" and use phone
                        $_SESSION['customer_id']    = 999999; // Dummy ID if no bookings exist
                        $_SESSION['customer_name']  = "Customer";
                        $_SESSION['customer_phone'] = $cred['customer_phone'];
                        
                        $b_stmt->close();
                        $stmt->close();
                        header("Location: customer_dashboard.php");
                        exit();
                    }
                } else {
                    $error_message = "Invalid password. Please try again.";
                }
            } else {
                $error_message = "No account found with that mobile number or email. You may need to reset your password first to set up credentials.";
            }
            $stmt->close();
        } else {
            $error_message = "Please enter both credentials and password.";
        }
    } elseif ($action === 'express_login') {
        $active_tab = "express";
        $mobile_number = trim($_POST['mobile_number'] ?? '');

        if (!empty($mobile_number)) {
            $stmt = $conn->prepare("SELECT id, customer_name, customer_phone FROM bookings WHERE customer_phone = ? ORDER BY id DESC LIMIT 1");
            $stmt->bind_param("s", $mobile_number);
            $stmt->execute();
            $result = $stmt->get_result();
            
            if ($result->num_rows > 0) {
                $user = $result->fetch_assoc();
                
                // Set session tokens for the dashboard
                $_SESSION['customer_id']    = $user['id'];
                $_SESSION['customer_name']  = $user['customer_name'];
                $_SESSION['customer_phone'] = $user['customer_phone'];
                
                $stmt->close(); 
                header("Location: customer_dashboard.php");
                exit();
            } else {
                $error_message = "Mobile number not found in our booking history.";
            }
            $stmt->close();
        } else {
            $error_message = "Please enter your registered mobile number.";
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Customer Login | RanjanCabs</title>
    <link rel="stylesheet" href="style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        body {
            background-color: #f8fafc;
            display: flex;
            flex-direction: column;
            min-height: 100vh;
        }

        main {
            flex: 1;
            padding: 80px 20px 80px;
        }

        .login-container {
            max-width: 1200px;
            margin: 0 auto;
        }

        .login-header {
            text-align: center;
            margin-bottom: 50px;
        }

        .login-header h1 {
            font-size: clamp(32px, 5vw, 48px);
            color: #172033;
            margin-bottom: 16px;
            line-height: 1.2;
        }

        .login-header p {
            color: #64748b;
            font-size: 16px;
            max-width: 600px;
            margin: 0 auto;
        }

        .login-content {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 50px;
            max-width: 1100px;
            margin: 0 auto;
            align-items: center;
        }

        .login-visual {
            display: flex;
            flex-direction: column;
            gap: 20px;
        }

        .login-benefit {
            background: #ffffff;
            border: 1px solid #e2e8f0;
            border-radius: 8px;
            padding: 20px;
            box-shadow: 0 12px 30px rgba(15,23,42,0.05);
            display: flex;
            gap: 16px;
            align-items: flex-start;
        }

        .login-benefit-icon {
            width: 48px;
            height: 48px;
            border-radius: 8px;
            background: #fff7df;
            color: #b7791f;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 24px;
            flex-shrink: 0;
        }

        .login-benefit-text h3 {
            color: #172033;
            font-size: 16px;
            font-weight: 700;
            margin-bottom: 4px;
        }

        .login-benefit-text p {
            color: #64748b;
            font-size: 14px;
            line-height: 1.5;
        }

        .login-form-card {
            background: #ffffff;
            border: 1px solid #e2e8f0;
            border-radius: 12px;
            padding: 40px;
            box-shadow: 0 12px 30px rgba(15,23,42,0.05);
        }

        .login-form-card h2 {
            font-size: 24px;
            color: #172033;
            margin-bottom: 6px;
            font-weight: 700;
        }

        .form-subtitle {
            color: #64748b;
            font-size: 14px;
            margin-bottom: 28px;
            line-height: 1.5;
        }

        /* Error Alert */
        .alert {
            background: #fee2e2;
            border: 1px solid #fca5a5;
            border-radius: 8px;
            padding: 12px 16px;
            margin-bottom: 24px;
            font-size: 14px;
            color: #991b1b;
            display: flex;
            align-items: center;
            gap: 10px;
            animation: slideDown 0.3s ease-out;
        }

        .alert i {
            flex-shrink: 0;
        }

        /* Tabs Navigation */
        .login-tabs {
            display: flex;
            gap: 12px;
            background: #f1f5f9;
            padding: 4px;
            border-radius: 10px;
            margin-bottom: 28px;
            border: 1px solid #e2e8f0;
        }

        .tab-btn {
            flex: 1;
            background: transparent;
            border: none;
            color: #64748b;
            padding: 10px 16px;
            font-size: 14px;
            font-weight: 600;
            cursor: pointer;
            border-radius: 8px;
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 8px;
            transition: all 0.3s ease;
        }

        .tab-btn:hover {
            color: #334155;
        }

        .tab-btn.active {
            background: #ffffff;
            color: #172033;
            box-shadow: 0 2px 8px rgba(15,23,42,0.08);
            border: 1px solid #cbd5e1;
        }

        .tab-content {
            display: none;
        }

        .tab-content.active {
            display: block;
            animation: fadeIn 0.3s ease-out;
        }

        /* Form Elements */
        .input-group {
            margin-bottom: 20px;
        }

        label {
            display: block;
            margin-bottom: 8px;
            font-weight: 600;
            color: #172033;
            font-size: 14px;
        }

        .input-wrapper {
            position: relative;
        }

        .input-wrapper i {
            position: absolute;
            left: 14px;
            top: 50%;
            transform: translateY(-50%);
            color: #cbd5e1;
            font-size: 16px;
            pointer-events: none;
        }

        input {
            width: 100%;
            padding: 12px 14px 12px 42px;
            border: 1px solid #e2e8f0;
            border-radius: 8px;
            font-size: 15px;
            background: #ffffff;
            color: #172033;
            transition: all 0.3s ease;
        }

        input::placeholder {
            color: #cbd5e1;
        }

        input:focus {
            outline: none;
            border-color: #f59e0b;
            box-shadow: 0 0 0 3px rgba(245, 158, 11, 0.1);
            background: #fffbf0;
        }

        /* Utility Links */
        .forgot-link {
            display: block;
            text-align: right;
            margin-top: -12px;
            margin-bottom: 24px;
            font-size: 13px;
            color: #f59e0b;
            text-decoration: none;
            font-weight: 600;
            transition: all 0.3s ease;
        }

        .forgot-link:hover {
            color: #d97706;
        }

        /* Buttons */
        .submit-btn {
            width: 100%;
            padding: 12px 20px;
            background: linear-gradient(135deg, #f59e0b 0%, #f97316 100%);
            color: #ffffff;
            border: none;
            border-radius: 8px;
            font-weight: 700;
            cursor: pointer;
            font-size: 15px;
            letter-spacing: 0.5px;
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 8px;
            box-shadow: 0 4px 12px rgba(245, 158, 11, 0.2);
            transition: all 0.3s ease;
            text-transform: uppercase;
        }

        .submit-btn:hover {
            transform: translateY(-2px);
            box-shadow: 0 6px 16px rgba(245, 158, 11, 0.3);
        }

        .submit-btn:active {
            transform: translateY(0);
        }

        .submit-btn.express-btn {
            background: linear-gradient(135deg, #10b981 0%, #059669 100%);
            box-shadow: 0 4px 12px rgba(16, 185, 129, 0.2);
        }

        .submit-btn.express-btn:hover {
            box-shadow: 0 6px 16px rgba(16, 185, 129, 0.3);
        }

        /* Info Box */
        .info-box {
            background: #eff6ff;
            border: 1px solid #bfdbfe;
            border-radius: 8px;
            padding: 16px;
            margin-top: 24px;
            font-size: 13px;
            color: #1e40af;
            line-height: 1.6;
        }

        .info-box strong {
            display: block;
            margin-bottom: 8px;
            font-size: 14px;
        }

        .info-box code {
            background: #dbeafe;
            padding: 3px 8px;
            border-radius: 4px;
            font-family: 'Courier New', monospace;
            font-weight: 600;
        }

        /* Role Switch */
        .role-switch {
            text-align: center;
            margin-top: 24px;
            padding-top: 20px;
            border-top: 1px solid #e2e8f0;
            font-size: 14px;
            color: #64748b;
        }

        .role-switch a {
            color: #f59e0b;
            font-weight: 700;
            text-decoration: none;
            transition: all 0.3s ease;
        }

        .role-switch a:hover {
            color: #d97706;
        }

        /* Footer */
        .site-footer {
            background: #101827;
            color: #cbd5e1;
            padding: 46px 20px 22px;
            margin-top: auto;
        }

        .footer-grid {
            max-width: 1200px;
            margin: 0 auto;
            display: grid;
            grid-template-columns: 1.4fr 1fr 1fr 1fr;
            gap: 24px;
        }

        .footer-brand {
            color: #fff;
            font-size: 24px;
            font-weight: 900;
            margin-bottom: 10px;
        }

        .footer-brand span {
            color: var(--primary-color);
        }

        .footer-col h3 {
            color: #fff;
            font-size: 15px;
            margin-bottom: 12px;
            font-weight: 700;
        }

        .footer-col p,
        .footer-col a {
            color: #cbd5e1;
            text-decoration: none;
            display: block;
            margin-bottom: 8px;
            font-size: 14px;
            line-height: 1.6;
        }

        .footer-col a:hover {
            color: var(--primary-color);
        }

        .footer-bottom {
            max-width: 1200px;
            margin: 28px auto 0;
            border-top: 1px solid rgba(255,255,255,0.1);
            padding-top: 18px;
            font-size: 13px;
            color: #94a3b8;
        }

        /* Animations */
        @keyframes fadeIn {
            from { opacity: 0; transform: translateY(10px); }
            to { opacity: 1; transform: translateY(0); }
        }

        @keyframes slideDown {
            from { opacity: 0; transform: translateY(-10px); }
            to { opacity: 1; transform: translateY(0); }
        }

        @media (max-width: 900px) {
            .login-content {
                grid-template-columns: 1fr;
                gap: 30px;
            }

            .login-visual {
                order: 2;
            }

            .login-form-card {
                order: 1;
            }

            main {
                padding: 60px 20px 60px;
            }

            .footer-grid {
                grid-template-columns: 1fr;
            }

            .login-header {
                margin-bottom: 35px;
            }
        }
    </style>
</head>
<body>


    <?php include 'header1.php'; ?>

    <main class="login-container">
        <div class="login-header">
            <h1>Customer Portal Login</h1>
            <p>Access your cab bookings, track driver status, view OTPs, download invoices, and manage active trips.</p>
        </div>

        <div class="login-content">
            <!-- Left Side - Benefits -->
            <div class="login-visual">
                <div class="login-benefit">
                    <div class="login-benefit-icon">
                        <i class="fa-solid fa-map"></i>
                    </div>
                    <div class="login-benefit-text">
                        <h3>Track Your Ride</h3>
                        <p>View live driver location and real-time ETA for your booked trips.</p>
                    </div>
                </div>

                <div class="login-benefit">
                    <div class="login-benefit-icon">
                        <i class="fa-solid fa-ticket"></i>
                    </div>
                    <div class="login-benefit-text">
                        <h3>Download Invoices</h3>
                        <p>Get invoice records for all your rides for reimbursement or records.</p>
                    </div>
                </div>

                <div class="login-benefit">
                    <div class="login-benefit-icon">
                        <i class="fa-solid fa-shield-halved"></i>
                    </div>
                    <div class="login-benefit-text">
                        <h3>OTP Security</h3>
                        <p>View secure OTP codes for trip verification with your driver.</p>
                    </div>
                </div>

                <div class="login-benefit">
                    <div class="login-benefit-icon">
                        <i class="fa-solid fa-history"></i>
                    </div>
                    <div class="login-benefit-text">
                        <h3>Booking History</h3>
                        <p>Access all your past and upcoming bookings in one place.</p>
                    </div>
                </div>
            </div>

            <!-- Right Side - Login Form -->
            <div class="login-form-card">
                <h2><i class="fa-solid fa-user-circle"></i> Welcome Back</h2>
                <p class="form-subtitle">Use your mobile number and password to access your account</p>

                <?php if (!empty($error_message)): ?>
                    <div class="alert"><i class="fa-solid fa-circle-exclamation"></i> <?php echo $error_message; ?></div>
                <?php endif; ?>

                <div class="login-tabs">
                    <button type="button" class="tab-btn <?php echo $active_tab === 'password' ? 'active' : ''; ?>" onclick="switchTab('password')">
                        <i class="fa-solid fa-lock"></i> Secure Login
                    </button>
                    <button type="button" class="tab-btn <?php echo $active_tab === 'express' ? 'active' : ''; ?>" onclick="switchTab('express')">
                        <i class="fa-solid fa-bolt"></i> Quick Access
                    </button>
                </div>

                <!-- Secure Password Login -->
                <div id="password-form-container" class="tab-content <?php echo $active_tab === 'password' ? 'active' : ''; ?>">
                    <form action="customer_login.php" method="POST">
                        <input type="hidden" name="action" value="password_login">
                        
                        <div class="input-group">
                            <label for="login_input"><i class="fa-solid fa-phone"></i> Mobile Number</label>
                            <div class="input-wrapper">
                                <i class="fa-solid fa-mobile-button"></i>
                                <input type="text" id="login_input" name="login_input" placeholder="Enter your registered mobile number" required>
                            </div>
                        </div>

                        <div class="input-group">
                            <label for="password"><i class="fa-solid fa-key"></i> Password</label>
                            <div class="input-wrapper">
                                <i class="fa-solid fa-lock"></i>
                                <input type="password" id="password" name="password" placeholder="Enter your password" required>
                            </div>
                        </div>

                        <a href="customer_forgot_password.php" class="forgot-link">Forgot your password?</a>

                        <button type="submit" class="submit-btn">
                            <i class="fa-solid fa-sign-in-alt"></i> Login Securely
                        </button>
                    </form>

                    <div class="info-box">
                        <strong>First time logging in?</strong>
                        Your login credentials are your mobile number as both username and password.
                    </div>
                </div>

                <!-- Quick Access Login -->
                <div id="express-form-container" class="tab-content <?php echo $active_tab === 'express' ? 'active' : ''; ?>">
                    <form action="customer_login.php" method="POST">
                        <input type="hidden" name="action" value="express_login">
                        
                        <div class="input-group">
                            <label for="mobile_number"><i class="fa-solid fa-phone"></i> Mobile Number</label>
                            <div class="input-wrapper">
                                <i class="fa-solid fa-mobile-button"></i>
                                <input type="tel" id="mobile_number" name="mobile_number" placeholder="Enter your registered mobile number" required>
                            </div>
                        </div>

                        <button type="submit" class="submit-btn express-btn">
                            <i class="fa-solid fa-bolt"></i> Quick Access
                        </button>
                    </form>

                    <div class="info-box">
                        <strong>Quick Access Method:</strong>
                        Enter your mobile number to directly access your dashboard. This works if you have a booking history with us.
                    </div>
                </div>

                <div class="role-switch">
                    Are you a Driver? <a href="driver_login.php"><i class="fa-solid fa-right-to-bracket"></i> Driver Login</a>
                </div>
            </div>
        </div>
    </main>

    <footer class="site-footer">
        <div class="footer-grid">
            <div class="footer-col">
                <div class="footer-brand"><i class="fa-solid fa-taxi"></i> Ranjan<span>Cabs</span></div>
                <p>Reliable cab booking with verified drivers, clear fares, live dashboards, and invoice-ready trip records.</p>
            </div>
            <div class="footer-col">
                <h3>Quick Links</h3>
                <a href="index.php#book">Book a Taxi</a>
                <a href="index.php">Home</a>
                <a href="blog.php">Blog</a>
                <a href="customer_forgot_password.php">Reset Password</a>
            </div>
            <div class="footer-col">
                <h3>Services</h3>
                <p>One-way rides</p>
                <p>Round trips</p>
                <p>Intercity routes</p>
                <p>Verified fleet dispatch</p>
            </div>
            <div class="footer-col">
                <h3>Contact</h3>
                <p><i class="fa-solid fa-location-dot"></i> Bhopal, Madhya Pradesh</p>
                <p><i class="fa-solid fa-phone"></i> +91 89591 58195</p>
                <p><i class="fa-solid fa-envelope"></i> support@ranjancabs.local</p>
            </div>
        </div>
        <div class="footer-bottom">Copyright <?= date('Y') ?> RanjanCabs. All rights reserved.</div>
    </footer>

    <script>
        function switchTab(tabName) {
            document.querySelectorAll('.tab-btn').forEach(btn => btn.classList.remove('active'));
            document.querySelectorAll('.tab-content').forEach(content => content.classList.remove('active'));

            if (tabName === 'password') {
                document.querySelector('.tab-btn:nth-child(1)').classList.add('active');
                document.getElementById('password-form-container').classList.add('active');
            } else {
                document.querySelector('.tab-btn:nth-child(2)').classList.add('active');
                document.getElementById('express-form-container').classList.add('active');
            }
        }
    </script>
</body>
</html>