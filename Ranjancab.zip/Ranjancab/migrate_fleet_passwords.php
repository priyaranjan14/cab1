<?php
$conn = new mysqli("localhost", "root", "", "Ranjancab");

if ($conn->connect_error) {
    die("Database connection failure: " . $conn->connect_error);
}

// Fetch all drivers to generate their default passwords
$result = $conn->query("SELECT id, driver_name FROM fleet");

if ($result->num_rows > 0) {
    $update_stmt = $conn->prepare("UPDATE fleet SET password = ?, is_first_login = 1 WHERE id = ?");
    
    while ($driver = $result->fetch_assoc()) {
        $full_name = trim($driver['driver_name']);
        $name_parts = explode(' ', $full_name);
        
        // Isolate the last element as the Last Name. Fallback to full name if it's a single word.
        $last_name = (count($name_parts) > 1) ? end($name_parts) : $full_name;
        
        // Always hash passwords securely before database storage
        $hashed_password = password_hash($last_name, PASSWORD_BCRYPT);
        
        $update_stmt->bind_param("si", $hashed_password, $driver['id']);
        $update_stmt->execute();
    }
    
    $update_stmt->close();
    echo "<h3>Migration Successful! All driver passwords initialized to their Last Name.</h3>";
} else {
    echo "No fleet records found to migrate.";
}

$conn->close();
?>