<?php
session_start();

if (!isset($_SESSION['driver_id'])) {
    header("Location: driver_login.php");
    exit();
}

$conn = new mysqli("localhost", "root", "", "Ranjancab");

if ($conn->connect_error) {
    die("Database link failure: " . $conn->connect_error);
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'complete_trip') {
    
    $booking_id = intval($_POST['booking_id']);
    $driver_id  = intval($_SESSION['driver_id']);

    // Flip booking_flag to 3 (Completed / Archived Trip)
    $stmt = $conn->prepare("UPDATE bookings SET booking_flag = 3 WHERE id = ? AND assigned_driver_id = ?");
    $stmt->bind_param("ii", $booking_id, $driver_id);
    
    if ($stmt->execute()) {
        $stmt->close();
        $conn->close();
        // Redirect back with a clean slate notification
        header("Location: driver_dashboard.php?status=ride_completed");
        exit();
    } else {
        $stmt->close();
        $conn->close();
        header("Location: driver_dashboard.php?status=error");
        exit();
    }
} else {
    header("Location: driver_dashboard.php");
    exit();
}
?>