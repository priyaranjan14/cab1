<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>CityCabs | Premium Taxi Booking</title>
    <link rel="stylesheet" href="style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
</head>
<body>

    <header class="navbar">
        <div class="nav-container">
            <div class="logo">
                <a href="#"><i class="fa-solid fa-taxi"></i> Ranjan<span>Cabs</span></a>
            </div>
            
            <nav class="nav-menu" id="navMenu">
                <a href="#" class="active">Home</a>
                <a href="#">Our Fleet</a>
                <a href="#">Services</a>
                <a href="#">Contact</a>
            </nav>

            <div class="nav-actions">
                <div class="dropdown">
                    <button class="login-btn"><i class="fa-solid fa-user"></i> Login <i class="fa-solid fa-caret-down"></i></button>
                    <div class="dropdown-content">
                        <a href="login.php"><i class="fa-solid fa-user-tie"></i> Customer Login</a>
                        <a href="driver_login.php?role=driver"><i class="fa-solid fa-id-card"></i> Driver Login</a>
                        <a href="admin_login.php?role=admin"><i class="fa-solid fa-user-gear"></i> Admin Portal</a>
                    </div>
                </div>
                <button class="menu-toggle" id="mobileMenuBtn">
                    <i class="fa-solid fa-bars"></i>
                </button>
            </div>
        </div>
    </header>

    <main class="hero-section">
        <div class="hero-overlay"></div>
        <div class="hero-container">
            
            <div class="hero-text">
                <h1>Reliable Rides, <br>Just a Click Away.</h1>
                <p>Book your ride instantly with RanjanCabs. Safe, affordable, and 24/7 professional service at your doorstep.</p>
            </div>

            <div class="booking-card">
                <h2><i class="fa-solid fa-map-location-dot"></i> Book a Taxi</h2>
                
                <?php
                if (isset($_GET['status'])) {
                    if ($_GET['status'] == 'success') {
                        echo '<p class="alert success"><i class="fa-solid fa-circle-check"></i> Ride booked successfully!</p>';
                    } elseif ($_GET['status'] == 'error') {
                        echo '<p class="alert error"><i class="fa-solid fa-circle-exclamation"></i> Error processing booking. Try again.</p>';
                    } elseif ($_GET['status'] == 'blocked') {
                        echo '<p class="alert error"><i class="fa-solid fa-hand"></i> Cannot book! You have an active ride request pending allocation.</p>';
                    }
                }
                ?>

                <form action="review.php" method="POST" id="bookingForm">
                    
                    <div class="row">
                        <div class="input-group">
                            <label for="first_name">First Name</label>
                            <input type="text" id="first_name" name="first_name" placeholder="John" required>
                        </div>
                        <div class="input-group">
                            <label for="last_name">Last Name (Your Password)</label>
                            <input type="text" id="last_name" name="last_name" placeholder="Doe" required>
                        </div>
                    </div>
                    
                    <div class="input-group">
                        <label for="mobile_number">Mobile Number (Your Login ID)</label>
                        <input type="tel" id="mobile_number" name="mobile_number" placeholder="9876543210" required>
                    </div>

                    <div class="input-group">
                        <label for="pickup">Pickup Location</label>
                        <input type="text" id="pickup" name="pickup_location" placeholder="Enter pickup address" required>
                    </div>

                    <div class="input-group">
                        <label for="drop">Drop Location</label>
                        <input type="text" id="drop" name="drop_location" placeholder="Enter destination address" required>
                    </div>

                    <div class="row">
                        <div class="input-group">
                            <label for="date">Pickup Date</label>
                            <input type="date" id="date" name="pickup_date" required>
                        </div>
                        <div class="input-group">
                            <label for="time">Pickup Time</label>
                            <input type="time" id="time" name="pickup_time" required>
                        </div>
                    </div>

                    <div class="input-group">
                        <label for="car_type">Select Vehicle Class</label>
                        <select id="car_type" name="car_type" required>
                            <option value="" disabled selected>Choose a car option</option>
                            <option value="Economy">Economy (Budget Friendly)</option>
                            <option value="Sedan">Sedan (Comfortable Business)</option>
                            <option value="SUV">SUV (Spacious Family)</option>
                            <option value="Luxury">Luxury (Premium Experience)</option>
                        </select>
                    </div>

                    <button type="submit" class="submit-btn">Confirm Ride Booking</button>
                </form>
            </div>

        </div>
    </main>

    <script>
        const mobileMenuBtn = document.getElementById('mobileMenuBtn');
        const navMenu = document.getElementById('navMenu');

        mobileMenuBtn.addEventListener('click', () => {
            navMenu.classList.toggle('active');
            const icon = mobileMenuBtn.querySelector('i');
            if(navMenu.classList.contains('active')) {
                icon.classList.replace('fa-bars', 'fa-xmark');
            } else {
                icon.classList.replace('fa-xmark', 'fa-bars');
            }
        });
    </script>
</body>
</html>