<?php
session_start();

if (isset($_SESSION['driver_id'])) {
    header("Location: driver_dashboard.php");
    exit();
}

$error_message = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $mobile_number = trim($_POST['mobile_number']);

    if (!empty($mobile_number)) {
        
        $conn = new mysqli("localhost", "root", "", "ranjancab");
        if ($conn->connect_error) {
            die("Database engine connectivity failure: " . $conn->connect_error);
        }

        // Aligned to exact unique column: mobile_number inside fleet table
        $stmt = $conn->prepare("SELECT id, driver_name FROM fleet WHERE mobile_number = ? LIMIT 1");
        $stmt->bind_param("s", $mobile_number);
        $stmt->execute();
        $result = $stmt->get_result();
        
        if ($result->num_rows > 0) {
            $driver = $result->fetch_assoc();
            
            $_SESSION['driver_id']    = $driver['id'];
            $_SESSION['driver_name']  = $driver['driver_name'];
            
            $stmt->close(); 
            $conn->close();
            
            header("Location: driver_dashboard.php");
            exit();
        } else {
            $error_message = "Mobile number not found inside active fleet database registry.";
        }
        $stmt->close();
        $conn->close();
    } else {
        $error_message = "Please enter your registered mobile number.";
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Driver Desk Login | RanjanCabs</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        body { font-family: 'Segoe UI', Arial, sans-serif; background: #0f172a; display: flex; flex-direction: column; min-height: 100vh; margin: 0; color: #f8fafc; }
        .navbar { background-color: #1e293b; padding: 15px 30px; display: flex; justify-content: space-between; align-items: center; border-bottom: 1px solid #334155; }
        .navbar .logo a { color: #fff; text-decoration: none; font-size: 22px; font-weight: bold; }
        .navbar .logo span { color: #f59e0b; }
        .navbar .back-btn { color: #94a3b8; text-decoration: none; border: 1px solid #334155; padding: 6px 12px; border-radius: 4px; font-size: 14px; }
        
        .login-container { flex: 1; display: flex; justify-content: center; align-items: center; padding: 20px; }
        .booking-card { background: #1e293b; padding: 35px; border-radius: 8px; box-shadow: 0 10px 15px -3px rgba(0,0,0,0.3); width: 100%; max-width: 400px; border: 1px solid #334155; }
        h2 { text-align: center; margin-bottom: 8px; color: #fff; }
        .subtitle { text-align: center; color: #94a3b8; font-size: 13px; margin-bottom: 25px; }
        
        .input-group { margin-bottom: 20px; }
        label { display: block; margin-bottom: 8px; font-weight: 600; color: #cbd5e1; font-size: 14px; }
        input { width: 100%; padding: 12px; border: 1px solid #475569; border-radius: 4px; box-sizing: border-box; font-size: 15px; background: #0f172a; color: #fff; }
        input:focus { outline: none; border-color: #f59e0b; }
        
        .submit-btn { width: 100%; padding: 12px; background: #f59e0b; color: #0f172a; border: none; border-radius: 4px; font-weight: bold; cursor: pointer; font-size: 16px; margin-top: 10px; text-transform: uppercase; }
        .submit-btn:hover { background: #d97706; }
        .alert { color: #f87171; background: #7f1d1d; padding: 12px; border-radius: 4px; margin-bottom: 20px; font-size: 14px; border-left: 4px solid #ef4444; }
        .role-switch { text-align: center; margin-top: 25px; padding-top: 15px; border-top: 1px solid #334155; font-size: 14px; color: #94a3b8; }
        .role-switch a { color: #f59e0b; font-weight: bold; text-decoration: none; }
    </style>
</head>
<body>
    <header class="navbar">
        <div class="logo"><a href="index.php"><i class="fa-solid fa-taxi"></i> Ranjan<span>Cabs</span></a></div>
        <div><a href="index.php" class="back-btn">Back to Home</a></div>
    </header>

    <main class="login-container">
        <div class="booking-card">
            <h2><i class="fa-solid fa-id-card-clip" style="color: #f59e0b;"></i> Pilot Authentication</h2>
            <p class="subtitle">Enter your registered fleet contact number to fetch live sync channels.</p>
            
            <?php if (!empty($error_message)): ?>
                <div class="alert error"><i class="fa-solid fa-triangle-exclamation"></i> <?php echo $error_message; ?></div>
            <?php endif; ?>

            <form action="driver_login.php" method="POST">
                <div class="input-group">
                    <label for="mobile_number">Driver Mobile Number</label>
                    <input type="tel" id="mobile_number" name="mobile_number" placeholder="e.g. Fleet Phone No." required>
                </div>
                <button type="submit" class="submit-btn">Launch Cockpit Terminal</button>
            </form>

            <div class="role-switch">
                Are you looking for your rides? <a href="customer_login.php">Customer Login ➔</a>
            </div>
        </div>
    </main>
</body>
</html>