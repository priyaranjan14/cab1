<?php
session_start();

// Strict Access Guard: Only allowed for logged-in drivers
if (!isset($_SESSION['driver_id'])) {
    header("Location: login.php");
    exit();
}

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    // Safely extract and format payload arguments
    $booking_id = isset($_POST['booking_id']) ? intval($_POST['booking_id']) : 0;
    $driver_id  = $_SESSION['driver_id'];

    if ($booking_id > 0) {
        // Initialize Database Connection Engine Instance
        $conn = new mysqli("localhost", "root", "", "ranjancab");
        if ($conn->connect_error) {
            die("Critical system link connectivity failure: " . $conn->connect_error);
        }

        // Validate that this ride belongs to this driver and is currently active (flag = 2)
        $verify_sql = "SELECT id FROM bookings WHERE id = ? AND assigned_driver_id = ? AND booking_flag = 2 LIMIT 1";
        $verify_stmt = $conn->prepare($verify_sql);
        $verify_stmt->bind_param("ii", $booking_id, $driver_id);
        $verify_stmt->execute();
        $verify_result = $verify_stmt->get_result();

        if ($verify_result->num_rows > 0) {
            // Update Core Registry State to 3 (Trip Completed Successfully)
            $update_sql = "UPDATE bookings SET booking_flag = 3 WHERE id = ?";
            $update_stmt = $conn->prepare($update_sql);
            $update_stmt->bind_param("i", $booking_id);
            
            if ($update_stmt->execute()) {
                $update_stmt->close();
                $verify_stmt->close();
                $conn->close();
                
                // Safe return with a successful execution flag notice parameter
                header("Location: driver_dashboard.php?status=trip_completed");
                exit();
            }
            $update_stmt->close();
        }
        $verify_stmt->close();
        $conn->close();
    }
}

// Global fallback escape route for corrupted data frames or missing post variables
header("Location: driver_dashboard.php");
exit();
?>