<?php
session_start();

// Unset driver identifiers safely
unset($_SESSION['driver_id']);
unset($_SESSION['driver_name']);

// Destroy the master tracking matrix only if no user sessions are running
if (!isset($_SESSION['customer_id'])) {
    $_SESSION = array();

    if (ini_get("session.use_cookies")) {
        $params = session_get_cookie_params();
        setcookie(
            session_name(), 
            '', 
            time() - 42000,
            $params["path"], 
            $params["domain"],
            $params["secure"], 
            $params["httponly"]
        );
    }
    session_destroy();
}

header("Location: driver_login.php");
exit();
?>