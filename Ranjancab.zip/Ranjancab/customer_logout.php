<?php
session_start();

// 1. Unset specific customer session parameters cleanly
unset($_SESSION['customer_id']);
unset($_SESSION['customer_name']);
unset($_SESSION['customer_phone']);

// 2. Check if a driver session is active. 
// If no driver is logged in, completely wipe and reset everything for maximum security.
if (!isset($_SESSION['driver_id'])) {
    // Clear any remaining array data elements
    $_SESSION = array();

    // Clear the session cookie from the user's browser storage
    if (ini_get("session.use_cookies")) {
        $params = session_get_cookie_params();
        setcookie(
            session_name(), 
            '', 
            time() - 42000,
            $params["path"], 
            $params["domain"],
            $params["secure"], 
            $params["httponly"]
        );
    }

    // Completely destroy the session on the server side
    session_destroy();
}

// 3. Redirect back to the fast login portal interface
header("Location: customer_login.php");
exit();
?>