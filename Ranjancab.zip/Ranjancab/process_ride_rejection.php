<?php
session_start();
if (!isset($_SESSION['driver_logged_in']) || $_SESSION['driver_logged_in'] !== true) {
    header("Location: driver_login.php");
    exit();
}

$conn = new mysqli("localhost", "root", "", "Ranjancab");
if ($conn->connect_error) { die("Database error."); }

$driver_id  = intval($_SESSION['driver_id']);
$booking_id = intval($_POST['booking_id']);

if ($booking_id > 0) {
    // 1. Record this specific driver's rejection mapping entry
    $reject_stmt = $conn->prepare("INSERT INTO booking_rejections (booking_id, driver_id) VALUES (?, ?)");
    $reject_stmt->bind_param("ii", $booking_id, $driver_id);
    $reject_stmt->execute();
    $reject_stmt->close();

    // 2. Fetch the metadata variables from the current booking
    $b_stmt = $conn->prepare("SELECT pickup_location, car_type FROM bookings WHERE id = ?");
    $b_stmt->bind_param("i", $booking_id);
    $b_stmt->execute();
    $booking = $b_stmt->get_result()->fetch_assoc();
    $b_stmt->close();

    if ($booking) {
        // 3. Break down the text string into clean keywords
        $clean_input = preg_replace('/[^\w\s]/', ' ', $booking['pickup_location']); 
        $keywords = array_filter(explode(' ', $clean_input));

        $next_driver_id = null;

        if (!empty($keywords)) {
            $like_conditions = [];
            $bind_types = "";
            $bind_params = [];

            foreach ($keywords as $word) {
                if (strlen($word) > 2) {
                    $like_conditions[] = "? LIKE CONCAT('%', base_station, '%') OR base_station LIKE ?";
                    $bind_types .= "ss";
                    $bind_params[] = $word;
                    $bind_params[] = "%" . $word . "%";
                }
            }

            if (!empty($like_conditions)) {
                $keyword_clause = "(" . implode(" OR ", $like_conditions) . ")";

                // 4. Query the next high-rated pilot avoiding the updated rejection logs
                $queue_sql = "SELECT id FROM fleet 
                              WHERE $keyword_clause 
                                AND car_type = ? 
                                AND is_verified = 1
                                AND id NOT IN (SELECT driver_id FROM booking_rejections WHERE booking_id = ?)
                              ORDER BY star_rating DESC 
                              LIMIT 1";

                $bind_types .= "si";
                $bind_params[] = $booking['car_type'];
                $bind_params[] = $booking_id;

                $q_stmt = $conn->prepare($queue_sql);
                $q_stmt->bind_param($bind_types, ...$bind_params);
                $q_stmt->execute();
                $next_driver = $q_stmt->get_result()->fetch_assoc();
                $q_stmt->close();

                if ($next_driver) {
                    $next_driver_id = $next_driver['id'];
                }
            }
        }

        // 5. Commit routing changes directly to the booking status row
        if ($next_driver_id) {
            $up_stmt = $conn->prepare("UPDATE bookings SET assigned_driver_id = ? WHERE id = ?");
            $up_stmt->bind_param("ii", $next_driver_id, $booking_id);
        } else {
            $up_stmt = $conn->prepare("UPDATE bookings SET assigned_driver_id = NULL WHERE id = ?");
            $up_stmt->bind_param("i", $booking_id);
        }
        $up_stmt->execute();
        $up_stmt->close();
    }
}

$conn->close();
header("Location: driver_dashboard.php?status=offer_declined");
exit();
?>