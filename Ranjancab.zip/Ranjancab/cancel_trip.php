<?php
session_start();
if (!isset($_SESSION['driver_id'])) exit(json_encode(['success' => false, 'message' => 'Unauthorized']));

$conn = new mysqli("localhost", "root", "", "ranjancab");
$booking_id = intval($_POST['booking_id']);
$driver_id = $_SESSION['driver_id'];

// Verify the trip actually belongs to this driver before cancelling
$check = $conn->prepare("SELECT id FROM bookings WHERE id = ? AND assigned_driver_id = ? AND booking_flag = 2");
$check->bind_param("ii", $booking_id, $driver_id);
$check->execute();

if ($check->get_result()->num_rows > 0) {
    // Reset the booking: Unassign driver and set status back to open (flag = 1)
    $stmt = $conn->prepare("UPDATE bookings SET assigned_driver_id = NULL, booking_flag = 1 WHERE id = ?");
    $stmt->bind_param("i", $booking_id);
    
    if ($stmt->execute()) {
        echo json_encode(['success' => true]);
    } else {
        echo json_encode(['success' => false, 'message' => 'Database update failed.']);
    }
} else {
    echo json_encode(['success' => false, 'message' => 'Invalid request.']);
}
?>