<aside class="sidebar">
    <div class="brand">
        <span class="text-warning"><i class="fa-solid fa-square-rss"></i></span>
        <span>RANJAN CAB HQ</span>
    </div>
    <ul class="nav flex-column sidebar-menu list-unstyled w-100" id="controlDeckTabs" role="tablist">
        <li class="nav-item" role="presentation">
            <button class="nav-link active" id="live-ops-tab" data-bs-toggle="pill" data-bs-target="#live-ops-pane" type="button" role="tab" aria-controls="live-ops-pane" aria-selected="true">
                <i class="fa-solid fa-tower-broadcast"></i> <span>Live Terminal</span>
            </button>
        </li>
        <li class="nav-item" role="presentation">
            <button class="nav-link" id="bookings-tab" data-bs-toggle="pill" data-bs-target="#bookings-pane" type="button" role="tab" aria-controls="bookings-pane" aria-selected="false">
                <i class="fa-solid fa-list-check"></i> <span>Bookings Matrix (<?= $bookings_result->num_rows ?>)</span>
            </button>
        </li>
        <li class="nav-item" role="presentation">
            <button class="nav-link" id="cancelled-tab" data-bs-toggle="pill" data-bs-target="#cancelled-pane" type="button" role="tab" aria-controls="cancelled-pane" aria-selected="false">
                <i class="fa-solid fa-ban"></i> <span>Cancellation Logs (<?= $cancelled_result->num_rows ?>)</span>
            </button>
        </li>
        <li class="nav-item" role="presentation">
            <button class="nav-link" id="fleet-tab" data-bs-toggle="pill" data-bs-target="#fleet-pane" type="button" role="tab" aria-controls="fleet-pane" aria-selected="false">
                <i class="fa-solid fa-id-card-clip"></i> <span>Fleet Operators (<?= $fleet_result->num_rows ?>)</span>
            </button>
        </li>
        <li class="nav-item" role="presentation">
            <button class="nav-link" id="tariffs-tab" data-bs-toggle="pill" data-bs-target="#tariffs-pane" type="button" role="tab" aria-controls="tariffs-pane" aria-selected="false">
                <i class="fa-solid fa-coins"></i> <span>Tariff Systems</span>
            </button>
        </li>
        <li class="nav-item" role="presentation">
            <button class="nav-link" id="routes-tab" data-bs-toggle="pill" data-bs-target="#routes-pane" type="button" role="tab" aria-controls="routes-pane" aria-selected="false">
                <i class="fa-solid fa-route"></i> <span>Active Corridors</span>
            </button>
        </li>
    </ul>
</aside>