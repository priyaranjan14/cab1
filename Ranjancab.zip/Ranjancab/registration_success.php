<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Registration Successful | RanjanCabs</title>
    <link rel="stylesheet" href="style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        /* Reusing index.php header/hero style background for visual continuity */
        .success-hero {
            min-height: 400px;
            padding: 112px 0 46px;
            background: url('https://images.unsplash.com/photo-1503376780353-7e6692767b70?q=80&w=1920') no-repeat center center/cover;
            display: flex;
            align-items: center;
            justify-content: center;
            text-align: center;
            color: #fff;
            position: relative;
        }
        .success-overlay {
            position: absolute; top: 0; left: 0; right: 0; bottom: 0;
            background: linear-gradient(115deg, rgba(12,18,32,0.92) 0%, rgba(12,18,32,0.76) 52%, rgba(12,18,32,0.42) 100%);
            z-index: 1;
        }
        .success-card {
            position: relative; z-index: 2;
            background: rgba(23, 32, 51, 0.85);
            border: 1px solid rgba(255, 255, 255, 0.24);
            border-radius: 12px;
            padding: 40px;
            max-width: 550px;
            width: 90%;
            box-shadow: 0 20px 50px rgba(0,0,0,0.5);
        }
        .success-icon {
            font-size: 60px;
            color: #16a34a;
            margin-bottom: 20px;
        }
        .success-card h2 {
            font-size: 32px;
            margin-bottom: 15px;
            color: #fff;
        }
        .success-card p {
            font-size: 16px;
            color: #cbd5e1;
            margin-bottom: 30px;
            line-height: 1.5;
        }
        .btn-group {
            display: flex;
            gap: 15px;
            justify-content: center;
        }
        .btn-primary {
            background: #f59e0b;
            color: #172033;
            padding: 14px 28px;
            border-radius: 6px;
            font-weight: 700;
            text-decoration: none;
            transition: background 0.2s;
        }
        .btn-primary:hover { background: #d97706; }
        
        .btn-secondary {
            background: rgba(255,255,255,0.1);
            color: #fff;
            padding: 14px 28px;
            border-radius: 6px;
            font-weight: 700;
            text-decoration: none;
            border: 1px solid rgba(255,255,255,0.2);
            transition: background 0.2s;
        }
        .btn-secondary:hover { background: rgba(255,255,255,0.2); }
    </style>
</head>
<body>

<?php include 'header1.php'; ?>

<main class="success-hero">
    <div class="success-overlay"></div>
    <div class="success-card">
        <div class="success-icon"><i class="fa-solid fa-circle-check"></i></div>
        <h2>Registration Complete</h2>
        <p>Your driver profile has been successfully created. Please note that your <strong>KYC is currently pending</strong>. An administrator will verify your documents before you can start accepting rides.</p>
        
        <div class="btn-group">
            <a href="driver_login.php" class="btn-primary"><i class="fa-solid fa-right-to-bracket"></i> Driver Login</a>
            <a href="index.php" class="btn-secondary"><i class="fa-solid fa-house"></i> Back to Home</a>
        </div>
    </div>
</main>

<?php
// Reusing the footer structure from index.php
?>
<footer class="site-footer" id="contact" style="margin-top:0;">
    <div class="footer-grid">
        <div class="footer-col">
            <div class="footer-brand"><i class="fa-solid fa-taxi"></i> Ranjan<span>Cabs</span></div>
            <p>Reliable cab booking with verified drivers, clear fares, live dashboards, and invoice-ready trip records.</p>
        </div>
        <div class="footer-col">
            <h3>Quick Links</h3>
            <a href="index.php#book">Book a Taxi</a>
            <a href="customer_login.php">Customer Login</a>
            <a href="driver_login.php">Driver Login</a>
            <a href="blog.php">Blog</a>
        </div>
        <div class="footer-col">
            <h3>Services</h3>
            <p>One-way rides</p>
            <p>Round trips</p>
            <p>Intercity routes</p>
            <p>Verified fleet dispatch</p>
        </div>
        <div class="footer-col">
            <h3>Contact</h3>
            <p><i class="fa-solid fa-location-dot"></i> Bhopal, Madhya Pradesh</p>
            <p><i class="fa-solid fa-phone"></i> +91 89591 58195</p>
            <p><i class="fa-solid fa-envelope"></i> support@ranjancabs.local</p>
        </div>
    </div>
    <div class="footer-bottom">Copyright <?= date('Y') ?> RanjanCabs. All rights reserved.</div>
</footer>

</body>
</html>