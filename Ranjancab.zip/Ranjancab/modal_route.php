<div class="modal fade" id="addRouteModal" tabindex="-1">
    <div class="modal-dialog">
        <form method="POST" action="admin.php" class="modal-content">
            <div class="modal-header"><h5 class="modal-title">Deploy Route</h5></div>
            <div class="modal-body">
                <input type="hidden" name="action" value="add_route">
                <input type="text" name="pickup_point" class="form-control mb-2" placeholder="Pickup" required>
                <input type="text" name="drop_point" class="form-control mb-2" placeholder="Drop" required>
            </div>
            <div class="modal-footer"><button type="submit" class="btn btn-primary">Save</button></div>
        </form>
    </div>
</div>