<?php
$conn = new mysqli("localhost", "root", "", "Ranjancab");

if ($conn->connect_error) {
    die("Database connection failure: " . $conn->connect_error);
}

// 1. TEMPORARILY DISABLE FOREIGN KEY CONSTRAINT CHECKS
$conn->query("SET FOREIGN_KEY_CHECKS = 0");

// 2. Drop existing table if it exists
$conn->query("DROP TABLE IF EXISTS fleet");

// 3. Create the clean table structure (Plain-Text Mode for Testing)
$table_sql = "CREATE TABLE fleet (
    id INT AUTO_INCREMENT PRIMARY KEY,
    driver_name VARCHAR(100) NOT NULL,
    mobile_number VARCHAR(15) NOT NULL UNIQUE,
    password VARCHAR(255) NOT NULL,
    is_first_login TINYINT(1) DEFAULT 1,
    vehicle_number VARCHAR(20) NOT NULL,
    model_name VARCHAR(50) NOT NULL,
    car_type VARCHAR(20) NOT NULL,
    base_station VARCHAR(100) NOT NULL,
    star_rating DECIMAL(3,2) DEFAULT 5.00,
    is_verified TINYINT(1) DEFAULT 1
)";

if ($conn->query($table_sql) === TRUE) {
    echo "<h3>Table 'fleet' recreated successfully!</h3>";
    
    // 4. Insert testing driver data (Password set as plain text last name 'Kumar')
    $insert_sql = "INSERT INTO fleet (driver_name, mobile_number, password, is_first_login, vehicle_number, model_name, car_type, base_station) 
                   VALUES ('Sanjeev Kumar', '8959158195', 'Kumar', 1, 'MP-04-HE-1234', 'Maruti Dzire', 'Sedan', 'Bhopal ISBT')";
    
    if ($conn->query($insert_sql) === TRUE) {
        echo "<p>Test driver data seeded successfully! Mobile: <b>8959158195</b>, Password: <b>Kumar</b></p>";
    }
} else {
    echo "Error creating table: " . $conn->error;
}

// 5. RE-ENABLE FOREIGN KEY CONSTRAINT CHECKS FOR SYSTEM STABILITY
$conn->query("SET FOREIGN_KEY_CHECKS = 1");

$conn->close();
?>