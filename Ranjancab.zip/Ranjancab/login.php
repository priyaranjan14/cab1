<?php
session_start();

// If a driver session is already active, skip the login screen entirely
if (isset($_SESSION['driver_id'])) {
    header("Location: driver_dashboard.php");
    exit();
}

$error_msg = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $mobile   = trim($_POST['mobile_number']);
    $password = trim($_POST['password']);

    // Initialize Database Connection
    $conn = new mysqli("localhost", "root", "", "ranjancab");
    if ($conn->connect_error) {
        die("Database connection failed: " . $conn->connect_error);
    }

    // Direct Plain-Text Match Query (No Hashing Used)
    $sql = "SELECT * FROM fleet WHERE mobile_number = ? AND password = ? AND is_verified = 1 AND status = 'Active' LIMIT 1";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("ss", $mobile, $password);
    $stmt->execute();
    $result = $stmt->get_result();
    $driver = $result->fetch_assoc();
    $stmt->close();

    if ($driver) {
        // Map database table columns directly to active session data keys
        $_SESSION['driver_id']    = $driver['id'];
        $_SESSION['driver_name']  = $driver['driver_name']; 
        $_SESSION['base_station'] = $driver['base_station'];
        $_SESSION['car_type']     = $driver['car_type'];

        $conn->close();
        header("Location: driver_dashboard.php");
        exit();
    } else {
        $error_msg = "Invalid mobile number or password.";
    }
    $conn->close();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Driver Login - Ranjancab</title>
    <style>
        body { font-family: Arial, sans-serif; background: #f4f6f9; display: flex; justify-content: center; align-items: center; height: 100vh; margin: 0; }
        .login-box { background: white; padding: 30px; border-radius: 8px; box-shadow: 0 4px 15px rgba(0,0,0,0.1); width: 100%; max-width: 400px; }
        h2 { text-align: center; margin-bottom: 20px; color: #2c3e50; }
        .form-group { margin-bottom: 15px; }
        label { display: block; margin-bottom: 5px; font-weight: bold; color: #555; }
        input { width: 100%; padding: 10px; border: 1px solid #ccc; border-radius: 4px; box-sizing: border-box; width: 100%; }
        button { width: 100%; padding: 12px; background: #2c3e50; color: white; border: none; border-radius: 4px; font-weight: bold; cursor: pointer; font-size: 16px; margin-top: 10px; }
        button:hover { background: #34495e; }
        .error { color: #e74c3c; background: #fde8e7; padding: 10px; border-radius: 4px; margin-bottom: 15px; font-size: 14px; text-align: center; }
        .demo-hint { background: #e8f4fd; font-size: 12px; color: #1d4ed8; padding: 10px; border-radius: 4px; margin-top: 15px; text-align: center; }
    </style>
</head>
<body>
<div class="login-box">
    <h2>Driver Login</h2>
    
    <?php if(!empty($error_msg)): ?>
        <div class="error"><?= htmlspecialchars($error_msg) ?></div>
    <?php endif; ?>
    
    <form action="login.php" method="POST">
        <div class="form-group">
            <label>Mobile Number</label>
            <input type="text" name="mobile_number" placeholder="Enter mobile number" required>
        </div>
        <div class="form-group">
            <label>Password</label>
            <input type="password" name="password" placeholder="Enter password" required>
        </div>
        <button type="submit">Login</button>
    </form>
    
    <div class="demo-hint">
        <strong>Driver Test Login Details:</strong><br>
        Mobile: 9876543210 | Password: pilot123
    </div>
</div>
</body>
</html>