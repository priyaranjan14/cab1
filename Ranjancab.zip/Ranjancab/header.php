<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Master Command & Control Suite | Admin</title>
    
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    
    <style>
        :root {
            --brand-primary: #f59e0b;     
            --brand-dark: #0f172a;        
            --brand-bg: #f8fafc;          
            --panel-bg: #ffffff;          
            --text-dark: #1e293b;         
            --text-light: #64748b;        
            --border-subtle: #e2e8f0;     
        }

        body { 
            font-family: 'Plus Jakarta Sans', sans-serif; 
            font-size: 0.875rem;          
            background-color: var(--brand-bg); 
            color: var(--text-dark); 
            overflow-x: hidden;
        }
        
        .app-container { display: flex; min-height: 100vh; }
        
        .sidebar { 
            width: 280px; 
            background-color: var(--brand-dark); 
            padding: 24px 20px; 
            display: flex; 
            flex-direction: column;
            z-index: 100;
            position: fixed;
            top: 0;
            bottom: 0;
            left: 0;
            transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
        }
        
        .sidebar .brand { 
            font-size: 1.25rem; 
            font-weight: 700; 
            color: #ffffff; 
            margin-bottom: 32px; 
            display: flex; 
            align-items: center; 
            gap: 10px;
            letter-spacing: -0.5px;
        }
        
        .sidebar-menu .nav-link { 
            color: #94a3b8; 
            padding: 12px 16px; 
            border-radius: 8px; 
            font-weight: 500; 
            font-size: 0.875rem;
            display: flex; 
            align-items: center; 
            gap: 12px;
            width: 100%; 
            background: none; 
            border: none; 
            text-align: left;
            transition: all 0.2s ease;
            margin-bottom: 6px;
        }
        
        .sidebar-menu .nav-link:hover { 
            background-color: rgba(255, 255, 255, 0.04); 
            color: #f8fafc; 
        }
        
        .sidebar-menu .nav-link.active { 
            background-color: var(--brand-primary);
            color: var(--brand-dark);
            font-weight: 600;
        }

        .main-content { 
            flex: 1; 
            padding: 40px; 
            margin-left: 280px;
            min-width: 0;
            transition: all 0.3s ease;
        }
        
        .metric-widget { 
            background: var(--panel-bg); 
            border: 1px solid var(--border-subtle); 
            border-radius: 14px; 
            padding: 24px; 
            box-shadow: 0 1px 3px 0 rgba(0, 0, 0, 0.05);
            position: relative;
            overflow: hidden;
            transition: transform 0.2s ease, box-shadow 0.2s ease;
        }

        .metric-widget:hover {
            transform: translateY(-2px);
            box-shadow: 0 10px 15px -3px rgba(0, 0, 0, 0.05);
        }

        .metric-icon-bg {
            position: absolute;
            right: -10px;
            bottom: -10px;
            font-size: 4.5rem;
            opacity: 0.06;
            transform: rotate(-15deg);
        }
        
        .data-panel { 
            background: var(--panel-bg); 
            border: 1px solid var(--border-subtle); 
            border-radius: 16px; 
            padding: 28px; 
            box-shadow: 0 4px 6px -1px rgba(0, 0, 0, 0.02), 0 2px 4px -1px rgba(0, 0, 0, 0.02); 
        }
        
        .table { color: var(--text-dark); margin-bottom: 0; font-size: 0.875rem; }
        .table thead th { 
            background-color: #f1f5f9; 
            color: var(--text-light); 
            font-weight: 600; 
            text-transform: uppercase; 
            font-size: 0.75rem; 
            letter-spacing: 0.05em; 
            padding: 14px 16px; 
            border-bottom: 1px solid var(--border-subtle);
        }
        .table tbody td { padding: 16px; border-bottom: 1px solid var(--border-subtle); vertical-align: middle; }
        .table-hover tbody tr:hover td { background-color: #f8fafc !important; }
        
        .badge-custom { font-weight: 600; padding: 6px 12px; border-radius: 20px; font-size: 0.75rem; display: inline-flex; align-items: center; gap: 6px; }
        .badge-active { background: #dbeafe; color: #1e40af; }
        .badge-completed { background: #d1fae5; color: #065f46; }
        .badge-cancelled { background: #fee2e2; color: #991b1b; }
        
        .form-control, .form-select { 
            background-color: #ffffff; 
            border: 1px solid var(--border-subtle); 
            color: var(--text-dark);
            padding: 10px 14px;
            border-radius: 8px;
            font-size: 0.875rem;
        }
        .form-control:focus, .form-select:focus { 
            border-color: var(--brand-primary); 
            box-shadow: 0 0 0 4px rgba(245, 158, 11, 0.12); 
            outline: none;
        }

        .input-group-text {
            background-color: #e2e8f0 !important;
            color: var(--text-dark) !important;
            border: 1px solid var(--border-subtle);
            font-weight: 600;
        }
        
        .btn { font-size: 0.875rem; padding: 10px 20px; border-radius: 8px; font-weight: 500; transition: all 0.2s ease; }
        .btn-sm { font-size: 0.815rem; padding: 6px 12px; border-radius: 6px; }
        .btn-dark { background-color: var(--brand-dark); border-color: var(--brand-dark); }
        .btn-dark:hover { background-color: #1e293b; border-color: #1e293b; }
        .btn-primary-custom { background-color: var(--brand-primary); border-color: var(--brand-primary); color: var(--brand-dark); font-weight: 600; }
        .btn-primary-custom:hover { background-color: #d97706; border-color: #d97706; color: white; }

        .modal-content { border-radius: 16px; border: none; box-shadow: 0 20px 25px -5px rgba(0,0,0,0.1); }
        .invoice-link { text-decoration: none; transition: opacity 0.2s ease; }
        .invoice-link:hover { opacity: 0.85; }

        .tariff-editing-card {
            border: 2px dashed var(--brand-primary) !important;
            background-color: #fffbeb !important;
        }

        @media (max-width: 1199.98px) {
            .sidebar { width: 72px; padding: 20px 10px; align-items: center; }
            .sidebar .brand span:not(:first-child), .sidebar-menu .nav-link span { display: none; }
            .sidebar .brand { margin-bottom: 24px; justify-content: center; }
            .sidebar-menu .nav-link { justify-content: center; padding: 12px; }
            .main-content { margin-left: 72px; padding: 24px; }
        }
    </style>
</head>
<body>
<div class="app-container w-100">