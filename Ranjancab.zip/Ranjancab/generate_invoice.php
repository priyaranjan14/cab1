<?php
mysqli_report(MYSQLI_REPORT_ERROR | MYSQLI_REPORT_STRICT);

try {
    $conn = new mysqli("localhost", "root", "", "ranjancab");
    $conn->set_charset("utf8mb4");
} catch (Exception $e) {
    die("<div style='padding:24px;font-family:sans-serif;color:red;'>Database connection failed.</div>");
}

if (empty(trim($_GET['ref'] ?? ''))) {
    die("<div style='padding:24px;font-family:sans-serif;'>Missing booking reference.</div>");
}

$booking_ref = trim($_GET['ref']);
$data        = null;
$is_cancelled = false;

// Try completed booking first
try {
    $stmt = $conn->prepare(
        "SELECT b.*, f.driver_name, f.vehicle_number, f.model_name, f.mobile_number AS driver_phone
         FROM bookings b
         LEFT JOIN fleet f ON b.assigned_driver_id = f.id
         WHERE b.booking_ref_no = ? AND b.booking_flag = 3
         LIMIT 1"
    );
    $stmt->bind_param("s", $booking_ref);
    $stmt->execute();
    $data = $stmt->get_result()->fetch_assoc();
    $stmt->close();
} catch (Exception $e) { }

// Fallback: cancelled booking
if (!$data) {
    try {
        $stmt2 = $conn->prepare(
            "SELECT cb.*, f.driver_name, f.vehicle_number, f.model_name, f.mobile_number AS driver_phone
             FROM cancelled_bookings cb
             LEFT JOIN fleet f ON cb.assigned_driver_id = f.id
             WHERE cb.booking_ref_no = ?
             LIMIT 1"
        );
        $stmt2->bind_param("s", $booking_ref);
        $stmt2->execute();
        $data = $stmt2->get_result()->fetch_assoc();
        $stmt2->close();
        if ($data) $is_cancelled = true;
    } catch (Exception $e) { }
}

$conn->close();

if (!$data) {
    die("<div style='padding:40px;font-family:sans-serif;text-align:center;'>No invoice found for reference <strong>" . htmlspecialchars($booking_ref) . "</strong>.</div>");
}

$total_fare      = floatval($data['total_fare'] ?? 0);
$discounted_fare = floatval($data['discounted_fare'] ?? $total_fare);
$advance_paid    = floatval($data['advance_paid'] ?? 0);
$driver_balance  = floatval($data['driver_balance'] ?? ($total_fare - $advance_paid));
$coupon_code     = $data['coupon_code'] ?? '';
$coupon_discount = floatval($data['coupon_discount'] ?? 0);
$coupon_applied  = !empty($coupon_code) && $coupon_discount > 0;

$invoice_no = 'INV-' . date('Ymd') . '-' . strtoupper(substr(md5($booking_ref), 0, 5));
$generated  = date('d M Y, h:i A');
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Invoice <?= htmlspecialchars($data['booking_ref_no']) ?> | RanjanCabs</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        :root {
            --brand:  #f59e0b;
            --ink:    #0f172a;
            --muted:  #64748b;
        }
        body {
            background: #f1f5f9;
            font-family: 'Segoe UI', Arial, sans-serif;
            color: var(--ink);
            -webkit-print-color-adjust: exact;
            print-color-adjust: exact;
        }
        .invoice-sheet {
            max-width: 820px;
            margin: 32px auto;
            background: #fff;
            border-radius: 10px;
            box-shadow: 0 8px 32px rgba(0,0,0,0.08);
            overflow: hidden;
        }
        /* Header stripe */
        .inv-header {
            background: var(--ink);
            color: #fff;
            padding: 28px 32px;
            display: flex;
            justify-content: space-between;
            align-items: flex-start;
            flex-wrap: wrap;
            gap: 16px;
        }
        .inv-brand { font-size: 22px; font-weight: 900; }
        .inv-brand span { color: var(--brand); }
        .inv-brand small { display: block; font-size: 12px; font-weight: 400; color: #94a3b8; margin-top: 4px; }
        .inv-ref { text-align: right; }
        .inv-ref .ref-no { font-size: 20px; font-weight: 800; font-family: monospace; color: var(--brand); }
        .inv-ref small { display: block; font-size: 12px; color: #94a3b8; margin-top: 2px; }

        /* Status badge */
        .status-strip {
            padding: 10px 32px;
            font-size: 13px;
            font-weight: 700;
            display: flex;
            align-items: center;
            gap: 8px;
        }
        .status-strip.completed  { background: #dcfce7; color: #166534; }
        .status-strip.cancelled  { background: #fee2e2; color: #991b1b; }

        /* Body */
        .inv-body { padding: 28px 32px; }

        /* Info grid */
        .info-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(180px, 1fr));
            gap: 20px;
            margin-bottom: 28px;
            padding-bottom: 24px;
            border-bottom: 1px solid #e2e8f0;
        }
        .info-block small {
            display: block;
            font-size: 11px;
            font-weight: 800;
            text-transform: uppercase;
            letter-spacing: 0.5px;
            color: var(--muted);
            margin-bottom: 5px;
        }
        .info-block strong {
            font-size: 15px;
            color: var(--ink);
        }
        .info-block span {
            display: block;
            font-size: 13px;
            color: var(--muted);
            margin-top: 2px;
        }

        /* Route */
        .route-block {
            background: #f8fafc;
            border: 1px solid #e2e8f0;
            border-radius: 8px;
            padding: 18px 20px;
            margin-bottom: 28px;
            display: flex;
            align-items: center;
            gap: 16px;
            flex-wrap: wrap;
        }
        .route-block .point { flex: 1; min-width: 160px; }
        .route-block .point small {
            display: block;
            font-size: 11px;
            font-weight: 800;
            text-transform: uppercase;
            color: var(--muted);
            margin-bottom: 4px;
        }
        .route-block .point strong { font-size: 15px; }
        .route-block .point.origin strong  { color: #16a34a; }
        .route-block .point.dest strong    { color: #dc2626; }
        .route-block .arrow { font-size: 22px; color: var(--muted); }

        /* Fare table */
        .fare-table { width: 100%; border-collapse: collapse; margin-bottom: 28px; }
        .fare-table th {
            background: var(--ink);
            color: #fff;
            padding: 11px 14px;
            font-size: 12px;
            text-transform: uppercase;
            letter-spacing: 0.5px;
        }
        .fare-table td { padding: 12px 14px; font-size: 14px; border-bottom: 1px solid #f1f5f9; }
        .fare-table .lbl { color: var(--muted); font-weight: 600; }
        .fare-table .val { text-align: right; font-weight: 700; }
        .fare-table .val.green { color: #16a34a; }
        .fare-table .val.amber { color: #b45309; }
        .fare-table tfoot td {
            border-top: 2px solid var(--ink);
            background: #f8fafc;
            font-size: 15px;
            font-weight: 800;
        }
        .fare-table tfoot .val { color: #16a34a; }

        /* Footer note */
        .inv-footer {
            border-top: 1px solid #e2e8f0;
            padding-top: 18px;
            margin-top: 4px;
            display: flex;
            justify-content: space-between;
            align-items: flex-end;
            flex-wrap: wrap;
            gap: 16px;
        }
        .inv-footer p { font-size: 12px; color: var(--muted); max-width: 400px; line-height: 1.6; margin: 0; }
        .inv-footer .sig-block {
            text-align: center;
            border-top: 1px solid var(--muted);
            padding-top: 8px;
            min-width: 160px;
            font-size: 12px;
            color: var(--muted);
            font-weight: 700;
        }

        /* Action bar */
        .action-bar {
            background: #f8fafc;
            border-top: 1px solid #e2e8f0;
            padding: 16px 32px;
            display: flex;
            gap: 12px;
            flex-wrap: wrap;
        }
        .btn-print {
            background: var(--ink);
            color: #fff;
            border: none;
            padding: 10px 22px;
            border-radius: 6px;
            font-weight: 700;
            font-size: 14px;
            cursor: pointer;
        }
        .btn-back {
            background: #fff;
            color: var(--ink);
            border: 1px solid #cbd5e1;
            padding: 10px 22px;
            border-radius: 6px;
            font-weight: 700;
            font-size: 14px;
            text-decoration: none;
        }
        .btn-back:hover { background: #f1f5f9; }

        @media (max-width: 600px) {
            .inv-header, .inv-body { padding: 20px 18px; }
            .inv-brand { font-size: 18px; }
            .action-bar { padding: 14px 18px; }
            .status-strip { padding: 10px 18px; }
        }

        @media print {
            body { background: #fff !important; }
            .invoice-sheet { box-shadow: none; border-radius: 0; margin: 0; }
            .action-bar { display: none !important; }
            @page { size: A4; margin: 0.5in; }
        }
    </style>
</head>
<body>
<div class="invoice-sheet">

    <!-- Header -->
    <div class="inv-header">
        <div class="inv-brand">
            <i class="fa-solid fa-taxi"></i> Ranjan<span>Cabs</span>
            <small>Bhopal, Madhya Pradesh &nbsp;|&nbsp; +91 89591 58195 &nbsp;|&nbsp; support@ranjancabs.local</small>
        </div>
        <div class="inv-ref">
            <div class="ref-no"><?= htmlspecialchars($data['booking_ref_no']) ?></div>
            <small>Invoice No: <?= htmlspecialchars($invoice_no) ?></small>
            <small>Generated: <?= $generated ?></small>
        </div>
    </div>

    <!-- Status -->
    <div class="status-strip <?= $is_cancelled ? 'cancelled' : 'completed' ?>">
        <i class="fa-solid <?= $is_cancelled ? 'fa-circle-xmark' : 'fa-circle-check' ?>"></i>
        <?= $is_cancelled ? 'CANCELLED BOOKING' : 'TRIP COMPLETED — PAID' ?>
    </div>

    <!-- Body -->
    <div class="inv-body">

        <!-- Info grid -->
        <div class="info-grid">
            <div class="info-block">
                <small>Passenger</small>
                <strong><?= htmlspecialchars($data['customer_name']) ?></strong>
                <span><?= htmlspecialchars($data['customer_phone']) ?></span>
            </div>
            <div class="info-block">
                <small>Driver</small>
                <strong><?= $data['driver_name'] ? htmlspecialchars($data['driver_name']) : 'Not Assigned' ?></strong>
                <span><?= $data['vehicle_number'] ? htmlspecialchars($data['vehicle_number']) : '' ?><?= $data['model_name'] ? ' · ' . htmlspecialchars($data['model_name']) : '' ?></span>
            </div>
            <div class="info-block">
                <small>Trip Date</small>
                <strong><?= date('d M Y', strtotime($data['pickup_date'])) ?></strong>
                <span><?= htmlspecialchars($data['pickup_time']) ?> hrs</span>
            </div>
            <div class="info-block">
                <small>Vehicle Class</small>
                <strong><?= htmlspecialchars($data['car_type']) ?></strong>
                <span><?= htmlspecialchars($data['trip_type'] ?? 'Oneway') ?></span>
            </div>
        </div>

        <!-- Route -->
        <div class="route-block">
            <div class="point origin">
                <small><i class="fa-solid fa-circle" style="color:#16a34a;font-size:8px;"></i> Pickup</small>
                <strong><?= htmlspecialchars($data['pickup_location']) ?></strong>
            </div>
            <div class="arrow">→</div>
            <div class="point dest">
                <small><i class="fa-solid fa-circle" style="color:#dc2626;font-size:8px;"></i> Drop</small>
                <strong><?= htmlspecialchars($data['drop_location']) ?></strong>
            </div>
            <?php if (!empty($data['distance'])): ?>
            <div class="point" style="text-align:right;">
                <small>Distance</small>
                <strong><?= number_format(floatval($data['distance']), 0) ?> km</strong>
            </div>
            <?php endif; ?>
        </div>

        <!-- Fare Table -->
        <table class="fare-table">
            <thead>
                <tr>
                    <th>Description</th>
                    <th style="text-align:right;">Amount (INR)</th>
                </tr>
            </thead>
            <tbody>
                <tr>
                    <td class="lbl">Base Fare</td>
                    <td class="val">₹<?= number_format($total_fare, 2) ?></td>
                </tr>
                <?php if ($coupon_applied): ?>
                <tr>
                    <td class="lbl"><i class="fa-solid fa-tag" style="color:#16a34a;"></i> Coupon Discount (<?= htmlspecialchars($coupon_code) ?>)</td>
                    <td class="val green">- ₹<?= number_format($coupon_discount, 2) ?></td>
                </tr>
                <tr>
                    <td class="lbl">Fare After Discount</td>
                    <td class="val">₹<?= number_format($discounted_fare, 2) ?></td>
                </tr>
                <?php endif; ?>
                <tr style="background:#f0fdf4;">
                    <td class="lbl amber" style="color:#b45309;font-weight:700;"><i class="fa-solid fa-money-bill-wave"></i> Advance Paid Online (10%)</td>
                    <td class="val amber" style="color:#b45309;">₹<?= number_format($advance_paid, 2) ?></td>
                </tr>
                <tr>
                    <td class="lbl"><i class="fa-solid fa-handshake"></i> Balance Paid to Driver (90%)</td>
                    <td class="val">₹<?= number_format($driver_balance, 2) ?></td>
                </tr>
            </tbody>
            <tfoot>
                <tr>
                    <td class="lbl">Total Amount Settled</td>
                    <td class="val">₹<?= number_format($discounted_fare, 2) ?></td>
                </tr>
            </tfoot>
        </table>

        <!-- Footer -->
        <div class="inv-footer">
            <p>This is a system-generated invoice for booking <?= htmlspecialchars($data['booking_ref_no']) ?>. It serves as proof of trip settlement. For support, contact support@ranjancabs.local.</p>
            <div class="sig-block">Authorised by RanjanCabs</div>
        </div>
    </div>

    <!-- Action Bar -->
    <div class="action-bar">
        <button class="btn-print" onclick="window.print()"><i class="fa-solid fa-print"></i> Print / Download PDF</button>
        <a href="customer_dashboard.php" class="btn-back"><i class="fa-solid fa-arrow-left"></i> Back to Dashboard</a>
        <a href="index.php" class="btn-back"><i class="fa-solid fa-home"></i> Home</a>
    </div>

</div>
</body>
</html>
