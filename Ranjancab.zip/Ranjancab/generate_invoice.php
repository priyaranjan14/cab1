<?php
mysqli_report(MYSQLI_REPORT_ERROR | MYSQLI_REPORT_STRICT);

$servername = "localhost";
$username   = "root";
$password   = "";
$dbname     = "ranjancab";

try {
    $conn = new mysqli($servername, $username, $password, $dbname);
    $conn->set_charset("utf8mb4");
} catch (Exception $e) {
    die("<div class='alert alert-danger m-4'>HQ Database Connection Failure: " . $e->getMessage() . "</div>");
}

if (!isset($_GET['ref']) || empty(trim($_GET['ref']))) {
    die("<div class='container text-center mt-5'><div class='alert alert-warning d-inline-block'><strong>Error 400:</strong> Missing transaction reference vector.</div></div>");
}

$booking_ref = trim($_GET['ref']);

try {
    $stmt = $conn->prepare("SELECT b.*, f.driver_name, f.vehicle_number, f.mobile_number as driver_phone 
                            FROM bookings b 
                            LEFT JOIN fleet f ON b.assigned_driver_id = f.id 
                            WHERE b.booking_ref_no = ? AND b.booking_flag = 3 
                            LIMIT 1");
    $stmt->bind_param("s", $booking_ref);
    $stmt->execute();
    $data = $stmt->get_result()->fetch_assoc();

    if (!$data) {
        $stmt_alt = $conn->prepare("SELECT cb.*, f.driver_name, f.vehicle_number, f.mobile_number as driver_phone 
                                    FROM cancelled_bookings cb 
                                    LEFT JOIN fleet f ON cb.assigned_driver_id = f.id 
                                    WHERE cb.booking_ref_no = ? 
                                    LIMIT 1");
        $stmt_alt->bind_param("s", $booking_ref);
        $stmt_alt->execute();
        $data = $stmt_alt->get_result()->fetch_assoc();
        if ($data) { $data['is_cancelled_record'] = true; }
    }

    if (!$data) {
        die("<div class='container text-center mt-5'><div class='alert alert-danger d-inline-block'>No transactional record matches reference signature sequence.</div></div>");
    }
} catch (Exception $e) {
    die("<div class='alert alert-danger m-4'>Data Stream Retrieval Fault: " . $e->getMessage() . "</div>");
}

$total_fare   = floatval($data['total_fare']);
$advance_paid = isset($data['advance_paid']) ? floatval($data['advance_paid']) : 0.00;
$balance_due  = $total_fare - $advance_paid;
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Invoice_<?= htmlspecialchars($data['booking_ref_no']) ?></title>
    
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700&display=swap" rel="stylesheet">
    
    <style>
        body {
            font-family: 'Plus Jakarta Sans', sans-serif;
            background-color: #f8fafc;
            color: #0f172a;
            -webkit-print-color-adjust: exact !important;
            print-color-adjust: exact !important;
        }
        
        /* Master Layout Scaffolding Box */
        .invoice-container {
            max-width: 820px;
            background: #ffffff;
        }

        /* Strict Single-Page Printing Engine Overrides */
        @media print {
            @page {
                size: A4;
                margin: 0.5in;
            }
            html, body {
                height: 100%;
                background-color: #ffffff !important;
                overflow: hidden;
            }
            .invoice-container {
                box-shadow: none !important;
                border: none !important;
                margin: 0 !important;
                padding: 0 !important;
                max-width: 100% !important;
                page-break-inside: avoid !important;
            }
            .no-print { 
                display: none !important; 
            }
            /* Compress operational spaces slightly inside print layouts */
            .mb-5-custom { margin-bottom: 1.5rem !important; }
            .p-4-custom { padding: 1rem !important; }
        }
        
        @media union and (min-width: 992px) {
            .mb-5-custom { margin-bottom: 3rem !important; }
            .p-4-custom { padding: 1.5rem !important; }
        }
    </style>
</head>
<body class="py-4">

    <div class="container no-print mb-3" style="max-width: 820px;">
        <div class="d-flex justify-content-between align-items-center bg-white border rounded-3 p-2 px-3 shadow-sm">
            <a href="admin.php" class="btn btn-sm btn-outline-secondary fw-semibold rounded-2">
                &larr; Return to HQ
            </a>
            <button onclick="window.print();" class="btn btn-sm btn-dark fw-semibold rounded-2 d-flex align-items-center gap-2">
                <svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" fill="currentColor" class="bi bi-printer-fill" viewBox="0 0 16 16">
                    <path d="M5 1a2 2 0 0 0-2 2v2H2a2 2 0 0 0-2 2v3a2 2 0 0 0 2 2h1v1a2 2 0 0 0 2 2h6a2 2 0 0 0 2-2v-1h1a2 2 0 0 0 2-2V7a2 2 0 0 0-2-2h-1V3a2 2 0 0 0-2-2zm4 4.5V7a.5.5 0 0 1-1 0V5.5a.5.5 0 0 1 1 0M11 5.5V7a.5.5 0 0 1-1 0V5.5a.5.5 0 0 1 1 0M4 3a1 1 0 0 1 1-1h6a1 1 0 0 1 1 1v2H4zM1.92 7h12.16c.115 0 .21.084.226.198l.424 2.968A1 1 0 0 1 13.737 11H2.263a1 1 0 0 1-.973-1.834l.424-2.968A.25.25 0 0 1 1.92 7M4 12a1 1 0 0 1 1-1h6a1 1 0 0 1 1 1v2H4z"/>
                </svg> Download PDF / Print
            </button>
        </div>
    </div>

    <div class="container invoice-container border rounded-4 p-4 p-md-5 shadow-sm">
        
        <div class="row align-items-center border-bottom pb-4 mb-4 mb-5-custom">
            <div class="col-7">
                <h2 class="h4 fw-bold text-dark tracking-tight mb-1">RANJAN CAB SERVICES</h2>
                <p class="text-muted small mb-0 lh-sm">
                    Premium Industrial Logistics & Transit Networks<br>
                    Ranchi, Jharkhand, India
                </p>
            </div>
            <div class="col-5 text-end">
                <?php if (isset($data['is_cancelled_record'])): ?>
                    <span class="badge bg-danger-subtle text-danger border border-danger-subtle rounded-pill px-3 py-1.5 small fw-bold mb-2">REVOKED / CANCELLED</span>
                <?php else: ?>
                    <span class="badge bg-success-subtle text-success border border-success-subtle rounded-pill px-3 py-1.5 small fw-bold mb-2">OFFICIAL INVOICE</span>
                <?php endif; ?>
                <div class="font-monospace fw-bold fs-5 text-secondary">#<?= htmlspecialchars($data['booking_ref_no']) ?></div>
            </div>
        </div>

        <div class="row g-4 mb-4 mb-5-custom">
            <div class="col-6 col-md-3">
                <div class="text-uppercase text-muted fw-bold font-monospace mb-1" style="font-size: 0.7rem; letter-spacing: 0.05em;">Passenger Client</div>
                <div class="fw-bold text-dark text-truncate"><?= htmlspecialchars($data['customer_name']) ?></div>
                <div class="text-secondary small font-monospace"><?= htmlspecialchars($data['customer_phone']) ?></div>
            </div>
            <div class="col-6 col-md-3">
                <div class="text-uppercase text-muted fw-bold font-monospace mb-1" style="font-size: 0.7rem; letter-spacing: 0.05em;">Fleet Operational Asset</div>
                <div class="fw-bold text-dark text-truncate"><?= $data['driver_name'] ? htmlspecialchars($data['driver_name']) : 'Unallocated' ?></div>
                <div class="text-secondary small font-monospace text-truncate"><?= $data['vehicle_number'] ? htmlspecialchars($data['vehicle_number']) : 'No Asset Bound' ?></div>
            </div>
            <div class="col-6 col-md-3">
                <div class="text-uppercase text-muted fw-bold font-monospace mb-1" style="font-size: 0.7rem; letter-spacing: 0.05em;">Dispatch Date</div>
                <div class="fw-bold text-dark"><?= date('d-M-Y', strtotime($data['pickup_date'])) ?></div>
                <div class="text-secondary small font-monospace"><?= htmlspecialchars($data['pickup_time']) ?> Hours</div>
            </div>
            <div class="col-6 col-md-3">
                <div class="text-uppercase text-muted fw-bold font-monospace mb-1" style="font-size: 0.7rem; letter-spacing: 0.05em;">Logistics Class</div>
                <div><span class="badge bg-light text-dark border border-secondary-subtle px-2 py-1.5 text-uppercase font-monospace mt-0.5" style="font-size: 0.65rem;"><?= htmlspecialchars($data['car_type']) ?></span></div>
            </div>
        </div>

        <div class="bg-light border rounded-3 p-3 p-4-custom mb-4 mb-5-custom">
            <div class="row g-3 align-items-center">
                <div class="col-md-5">
                    <div class="text-uppercase text-success fw-bold font-monospace mb-1" style="font-size: 0.68rem; letter-spacing: 0.03em;">
                        <span class="d-inline-block rounded-circle bg-success me-1.5" style="width: 6px; height: 6px; vertical-align: middle;"></span> Origin Node (Pickup)
                    </div>
                    <div class="fw-semibold text-dark small lh-sm"><?= htmlspecialchars($data['pickup_location']) ?></div>
                </div>
                <div class="col-md-2 text-center my-1 my-md-0 d-none d-md-block">
                    <span class="text-muted font-monospace fs-5">&rarr;</span>
                </div>
                <div class="col-md-5">
                    <div class="text-uppercase text-danger fw-bold font-monospace mb-1" style="font-size: 0.68rem; letter-spacing: 0.03em;">
                        <span class="d-inline-block rounded-circle bg-danger me-1.5" style="width: 6px; height: 6px; vertical-align: middle;"></span> Terminal Node (Drop)
                    </div>
                    <div class="fw-semibold text-dark small lh-sm"><?= htmlspecialchars($data['drop_location']) ?></div>
                </div>
            </div>
        </div>

        <div class="table-responsive mb-4 mb-5-custom">
            <table class="table align-middle border-bottom mb-0">
                <thead class="table-light border-top border-bottom">
                    <tr class="text-uppercase font-monospace text-muted" style="font-size: 0.7rem; letter-spacing: 0.05em;">
                        <th class="py-2.5 ps-3">Core Operational Logistics Description</th>
                        <th class="text-end py-2.5 pe-3" style="width: 200px;">Subtotal Amount (INR)</th>
                    </tr>
                </thead>
                <tbody class="text-dark small">
                    <tr>
                        <td class="py-3 ps-3">
                            <div class="fw-bold mb-0.5">Base Route Transit Corridor Execution Fee</div>
                            <div class="text-muted extra-small lh-sm" style="font-size: 0.75rem;">Consolidated line item including localized dynamic tariff adjustments, path fuel metrics, and operator dispatch clearing.</div>
                        </td>
                        <td class="text-end fw-bold font-monospace pe-3">₹<?= number_format($total_fare, 2) ?></td>
                    </tr>
                    <tr class="table-light border-top-0">
                        <td class="text-end text-muted fw-semibold py-2">Gross Total Assessment:</td>
                        <td class="text-end font-monospace fw-semibold pe-3 py-2">₹<?= number_format($total_fare, 2) ?></td>
                    </tr>
                    <tr class="table-light">
                        <td class="text-end text-success fw-semibold py-1">Advance Escrow Deposit Credited:</td>
                        <td class="text-end font-monospace text-success fw-semibold pe-3 py-1">- ₹<?= number_format($advance_paid, 2) ?></td>
                    </tr>
                    <tr class="table-secondary border-top border-dark">
                        <td class="text-end text-dark fw-bold py-2.5">Net Settlement Balance Outstanding:</td>
                        <td class="text-end font-monospace text-dark fw-bold fs-6 pe-3 py-2.5">₹<?= number_format($balance_due, 2) ?></td>
                    </tr>
                </tbody>
            </table>
        </div>

        <div class="row pt-3 mt-4 border-top g-3 align-items-end">
            <div class="col-sm-7">
                <div class="text-uppercase text-muted fw-bold font-monospace mb-1" style="font-size: 0.65rem; letter-spacing: 0.05em;">Terms & Electronic Compliance</div>
                <p class="text-muted mb-0 lh-base" style="font-size: 0.72rem;">
                    This document serves as an automatic system ledger synchronization outcome for Ranjan Cab control architecture pipelines. Physical signature confirmation matrices are omitted.
                </p>
            </div>
            <div class="col-sm-5 text-sm-end text-center">
                <div class="d-inline-block border-top border-secondary pt-1.5 px-4 text-center" style="min-width: 180px;">
                    <div class="text-uppercase text-dark fw-bold font-monospace" style="font-size: 0.65rem; letter-spacing: 0.05em;">System Engine Verified</div>
                    <div class="font-monospace text-muted" style="font-size: 0.65rem;">Auto-Release Authorization</div>
                </div>
            </div>
        </div>

    </div>

</body>
</html>