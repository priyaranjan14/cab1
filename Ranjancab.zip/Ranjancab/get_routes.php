<?php
// Set headers to properly handle JSON payloads
header('Content-Type: application/json');

// Initialize local database handle
$conn = new mysqli("localhost", "root", "", "ranjancab");

if ($conn->connect_error) {
    die(json_encode(["error" => "Database link down", "locations" => []]));
}

// 1. Fetch unique pickup points
$pickups = [];
$result1 = $conn->query("SELECT DISTINCT `pickup_point` FROM `routes` WHERE `pickup_point` IS NOT NULL AND `pickup_point` != ''");
if ($result1) {
    while ($row = $result1->fetch_assoc()) {
        $pickups[] = $row['pickup_point'];
    }
}

// 2. Fetch unique drop points
$drops = [];
$result2 = $conn->query("SELECT DISTINCT `drop_point` FROM `routes` WHERE `drop_point` IS NOT NULL AND `drop_point` != ''");
if ($result2) {
    while ($row = $result2->fetch_assoc()) {
        $drops[] = $row['drop_point'];
    }
}

// 3. Combine both columns, drop duplicates, and reset sequential indices
$combinedList = array_values(array_unique(array_merge($pickups, $drops)));

// 4. Output the structural payload key 'locations' your index.php JavaScript needs
echo json_encode([
    "status" => "success",
    "locations" => $combinedList
]);

$conn->close();
?>