<?php
$conn = new mysqli("localhost", "root", "", "Ranjancab");

if ($conn->connect_error) {
    die("Database connection failure: " . $conn->connect_error);
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $first_name      = trim($_POST['first_name']);
    $last_name       = trim($_POST['last_name']);
    $mobile_number   = trim($_POST['mobile_number']);
    $pickup_location = trim($_POST['pickup_location']);
    $drop_location   = trim($_POST['drop_location']);
    $pickup_date     = $_POST['pickup_date'];
    $pickup_time     = $_POST['pickup_time'];
    $car_type        = $_POST['car_type'];
    
    $distance        = floatval($_POST['distance']);
    $total_fare      = floatval($_POST['total_fare']);
    $advance_paid    = floatval($_POST['advance_paid']); 
    $driver_balance  = floatval($_POST['driver_balance']);

    // Check duplicate pending bookings
    $check_stmt = $conn->prepare("SELECT id FROM bookings WHERE mobile_number = ? AND booking_flag = 1 AND assigned_driver_id IS NULL LIMIT 1");
    $check_stmt->bind_param("s", $mobile_number);
    $check_stmt->execute();
    $check_stmt->store_result();

    if ($check_stmt->num_rows > 0) {
        $check_stmt->close(); 
        $conn->close();
        header("Location: index.php?status=blocked");
        exit();
    }
    $check_stmt->close();

    $otp_code = rand(1000, 9999);

    // booking_flag = 1 (Active/Searching), assigned_driver_id explicitly NULL initially
    $sql = "INSERT INTO bookings (first_name, last_name, mobile_number, pickup_location, drop_location, pickup_date, pickup_time, car_type, distance, total_fare, advance_paid, driver_balance, otp_code, booking_flag, assigned_driver_id) 
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 1, NULL)";
    
    $stmt = $conn->prepare($sql);
    if ($stmt) {
        $stmt->bind_param(
            "ssssssssddddi", 
            $first_name, 
            $last_name, 
            $mobile_number, 
            $pickup_location, 
            $drop_location, 
            $pickup_date, 
            $pickup_time, 
            $car_type, 
            $distance, 
            $total_fare, 
            $advance_paid, 
            $driver_balance, 
            $otp_code
        );
        
        if ($stmt->execute()) {
            $inserted_id = $stmt->insert_id;
            $stmt->close();

            // CUSTOM 6-DIGIT REFERENCE GENERATION
            $mobile_prefix = substr($mobile_number, 0, 3);
            $running_serial = str_pad(($inserted_id % 1000), 3, "0", STR_PAD_LEFT);
            $booking_ref_no = $mobile_prefix . $running_serial;

            $update_stmt = $conn->prepare("UPDATE bookings SET booking_ref_no = ? WHERE id = ?");
            $update_stmt->bind_param("si", $booking_ref_no, $inserted_id);
            $update_stmt->execute();
            $update_stmt->close();

            $conn->close();
            header("Location: confirmation.php?id=" . $inserted_id);
            exit();
        }
    }
    header("Location: index.php?status=error");
    exit();
}
$conn->close();
?>