<?php
session_start();

// Admin Authentication Shield
if (!isset($_SESSION['admin_logged_in']) || $_SESSION['admin_logged_in'] !== true || !isset($_SESSION['admin_id'])) {
    header("Location: admin_login.php");
    exit();
}

// Database Connection
$conn = new mysqli("localhost", "root", "", "ranjancab");
if ($conn->connect_error) {
    die("Database connection failed: " . $conn->connect_error);
}

// initialize messages
$msg = $success_msg = $error_msg = $route_msg = $booking_msg = '';

// Process actions (create/update/delete)
require_once __DIR__ . '/includes/admin_actions.php';

// Execute queries used in the UI
require_once __DIR__ . '/includes/admin_queries.php';

// Render UI pieces
require_once __DIR__ . '/includes/admin_header.php';
require_once __DIR__ . '/includes/admin_controls.php';
require_once __DIR__ . '/includes/admin_tables.php';
require_once __DIR__ . '/includes/admin_scripts.php';
require_once __DIR__ . '/includes/admin_footer.php';

$conn->close();
?>
$total_drivers      = $conn->query("SELECT COUNT(*) as count FROM fleet")->fetch_assoc()['count'];
$total_bookings     = $conn->query("SELECT COUNT(*) as count FROM bookings")->fetch_assoc()['count'];
$total_routes       = $conn->query("SELECT COUNT(*) as count FROM routes")->fetch_assoc()['count'];
$total_rejections   = $conn->query("SELECT COUNT(*) as count FROM booking_rejections")->fetch_assoc()['count'];
$completed_bookings = $conn->query("SELECT COUNT(*) as count FROM bookings WHERE booking_flag = 3")->fetch_assoc()['count'];
$active_bookings    = $conn->query("SELECT COUNT(*) as count FROM bookings WHERE booking_flag = 1")->fetch_assoc()['count'];

$in_transit_result = $conn->query("
    SELECT b.*, f.driver_name, f.vehicle_number 
    FROM bookings b 
    LEFT JOIN fleet f ON b.assigned_driver_id = f.id 
    WHERE b.booking_flag = 1
    ORDER BY b.pickup_date ASC, b.pickup_time ASC
");

$past_rides_result = $conn->query("
    SELECT b.*, f.driver_name, f.vehicle_number 
    FROM bookings b 
    LEFT JOIN fleet f ON b.assigned_driver_id = f.id 
    WHERE b.booking_flag = 3
    ORDER BY b.pickup_date DESC, b.id DESC
");

$cancelled_result = $conn->query("
    SELECT b.*, f.driver_name, f.vehicle_number 
    FROM bookings b 
    LEFT JOIN fleet f ON b.assigned_driver_id = f.id 
    WHERE b.booking_flag = 2
    ORDER BY b.id DESC
");

$fleet_result = $conn->query("SELECT * FROM fleet ORDER BY id DESC");
$route_result = $conn->query("SELECT * FROM routes ORDER BY id DESC");
if (!$route_result) {
    die("Database Query Failure on Routes Extraction Stack.");
}

$drivers_for_bookings = $conn->query("SELECT id, driver_name, vehicle_number FROM fleet ORDER BY driver_name ASC");

$sys_fin = $conn->query("SELECT 
    SUM(CASE WHEN b.booking_flag = 3 THEN b.driver_balance ELSE 0 END) as realized_rev,
    SUM(CASE WHEN b.booking_flag = 1 THEN b.driver_balance ELSE 0 END) as active_escrow,
    COUNT(CASE WHEN b.booking_flag = 0 OR b.assigned_driver_id IS NULL THEN 1 END) as pending_trips
    FROM bookings b
")->fetch_assoc();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Global Core Control | RanjanCabs Engine</title>
    <link rel="stylesheet" href="style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        .admin-container { max-width: 1750px; margin: 30px auto; padding: 0 25px; display: grid; grid-template-columns: 1fr 2.8fr; gap: 30px; }
        .stats-strip { display: grid; grid-template-columns: repeat(auto-fit, minmax(220px, 1fr)); gap: 20px; max-width: 1700px; margin: 30px auto 0 auto; padding: 0 25px; }
        .stat-card { background: #fff; padding: 20px; border-radius: 8px; box-shadow: 0 4px 12px rgba(0,0,0,0.05); border-left: 4px solid #3b82f6; }
        .control-card { background: #fff; padding: 25px; border-radius: 8px; box-shadow: 0 4px 12px rgba(0,0,0,0.05); margin-bottom: 30px; height: fit-content; }
        .form-group { margin-bottom: 15px; }
        .form-group label { display: block; font-size: 11px; font-weight: 600; color: #334155; margin-bottom: 6px; text-transform: uppercase; letter-spacing: 0.5px; }
        .form-group input, .form-group select { width: 100%; padding: 10px; border: 1px solid #cbd5e1; border-radius: 4px; font-size: 13px; box-sizing: border-box; }
        .data-panel-stack { display: flex; flex-direction: column; gap: 30px; max-width: 100%; overflow: hidden; }
        .data-table-frame { background: #fff; padding: 25px; border-radius: 8px; box-shadow: 0 4px 12px rgba(0,0,0,0.05); overflow-x: auto; -webkit-overflow-scrolling: touch; }
        .transit-table { width: 100%; border-collapse: collapse; text-align: left; font-size: 13px; }
        .transit-table th { background: #0f172a; color: #fff; padding: 12px; font-weight: 500; white-space: nowrap; }
        .transit-table td { padding: 12px; border-bottom: 1px solid #e2e8f0; color: #334155; vertical-align: middle; white-space: nowrap; }
        .transit-table tr:hover { background: #f8fafc; }
        .alert-notify { background:#e0f2fe; color:#0369a1; padding:12px; border-radius:4px; font-size:12px; margin-bottom:15px; font-weight:500; }
        .inline-action-form { display: inline-flex; align-items: center; gap: 5px; margin: 0; }
        .action-btn-sm { padding: 6px 10px; border: none; border-radius: 4px; font-size: 11px; font-weight: 600; cursor: pointer; color: #fff; }
        
        @media(max-width: 1400px) { 
            .admin-container { grid-template-columns: 1fr; padding: 0 15px; } 
            .stats-strip { padding: 0 15px; }
        }
        @media(max-width: 991px) {
            .admin-container { margin: 15px auto; gap: 20px; }
            .control-card, .data-table-frame { padding: 15px; }
        }
    </style>
</head>
<body style="background-color: #f1f5f9; margin: 0; font-family: system-ui, -apple-system, sans-serif;">

    <header class="navbar" style="background-color: #0f172a; padding: 15px 30px;">
        <div style="display: flex; justify-content: space-between; align-items: center; max-width: 1750px; margin: 0 auto;">
            <div class="logo"><a href="#" style="color:#fff; text-decoration: none; font-weight: 700; font-size: 20px;"><i class="fa-solid fa-screwdriver-wrench" style="color:#3b82f6;"></i> Admin<span style="color:#3b82f6;">Console</span></a></div>
            <a href="admin_logout.php" style="background-color:#ef4444; color:#fff; text-decoration:none; padding:8px 16px; border-radius:4px; font-size:13px; font-weight:600;"><i class="fa-solid fa-power-off"></i> Terminate Session</a>
        </div>
    </header>

    <div class="stats-strip">
        <div class="stat-card" style="border-left-color: #22c55e;">
            <small style="color: #64748b; font-weight:600; text-transform:uppercase; font-size:11px;">Total Drivers</small>
            <h2 style="margin: 5px 0 0 0; color: #0f172a;"><?php echo $total_drivers; ?></h2>
        </div>
        <div class="stat-card" style="border-left-color: #0284c7;">
            <small style="color: #64748b; font-weight:600; text-transform:uppercase; font-size:11px;">Total Bookings</small>
            <h2 style="margin: 5px 0 0 0; color: #0f172a;"><?php echo $total_bookings; ?></h2>
        </div>
        <div class="stat-card" style="border-left-color: #10b981;">
            <small style="color: #64748b; font-weight:600; text-transform:uppercase; font-size:11px;">Total Routes</small>
            <h2 style="margin: 5px 0 0 0; color: #0f172a;"><?php echo $total_routes; ?></h2>
        </div>
        <div class="stat-card" style="border-left-color: #f59e0b;">
            <small style="color: #64748b; font-weight:600; text-transform:uppercase; font-size:11px;">Completed Rides</small>
            <h2 style="margin: 5px 0 0 0; color: #0f172a;"><?php echo $completed_bookings; ?></h2>
        </div>
        <div class="stat-card" style="border-left-color: #ef4444;">
            <small style="color: #64748b; font-weight:600; text-transform:uppercase; font-size:11px;">Active Rides</small>
            <h2 style="margin: 5px 0 0 0; color: #0f172a;"><?php echo $active_bookings; ?></h2>
        </div>
        <div class="stat-card" style="border-left-color: #8b5cf6;">
            <small style="color: #64748b; font-weight:600; text-transform:uppercase; font-size:11px;">Total Rejections</small>
            <h2 style="margin: 5px 0 0 0; color: #0f172a;"><?php echo $total_rejections; ?></h2>
        </div>
    </div>

    <?php if(!empty($success_msg)): ?>
        <div style="max-width:1750px; margin:20px auto; padding:0 25px;">
            <div style="background:#dcfce7; color:#15803d; padding:12px; border-radius:4px; font-size:13px; font-weight:500; border-left:4px solid #15803d;">
                <i class="fa-solid fa-circle-check"></i> <?php echo htmlspecialchars($success_msg); ?>
            </div>
        </div>
    <?php endif; ?>
    
    <?php if(!empty($error_msg)): ?>
        <div style="max-width:1750px; margin:20px auto; padding:0 25px;">
            <div style="background:#fee2e2; color:#991b1b; padding:12px; border-radius:4px; font-size:13px; font-weight:500; border-left:4px solid #991b1b;">
                <i class="fa-solid fa-circle-exclamation"></i> <?php echo htmlspecialchars($error_msg); ?>
            </div>
        </div>
    <?php endif; ?>

    <div class="admin-container">
        <div>
            <div class="control-card">
                <h3 style="margin: 0 0 20px 0; color: #0f172a; font-size: 15px; border-bottom: 1px solid #e2e8f0; padding-bottom: 10px;"><i class="fa-solid fa-bus" style="color:#3b82f6;"></i> Provision New Asset</h3>
                <?php if(!empty($msg)): ?>
                    <div class="alert-notify"><i class="fa-solid fa-circle-info"></i> <?php echo htmlspecialchars($msg); ?></div>
                <?php endif; ?>
                <form action="admin.php" method="POST" autocomplete="off">
                    <input type="hidden" name="action" value="register_fleet">
                    <div class="form-group"><label>Vehicle License Plate No</label><input type="text" name="vehicle_number" placeholder="e.g. MP04CW3708" required></div>
                    <div class="form-group"><label>Vehicle Variant/Model</label><input type="text" name="model_name" placeholder="e.g. Swift Dzire" required></div>
                    <div class="form-group">
                        <label>System Classification Class</label>
                        <select name="car_type" required>
                            <option value="" disabled selected>Choose a car option</option>
                            <option value="Economy">Economy (Budget Friendly)</option>
                            <option value="Sedan">Sedan (Comfortable Business)</option>
                            <option value="SUV">SUV (Spacious Family)</option>
                            <option value="Luxury">Luxury (Premium Experience)</option>
                        </select>
                    </div>
                    <div class="form-group"><label>Operator/Driver Full Name</label><input type="text" name="driver_name" placeholder="Legal Name" required></div>
                    <div class="form-group"><label>Mobile Communications Line</label><input type="text" name="mobile_number" maxlength="10" pattern="\d{10}" placeholder="10-digit number" required></div>
                    <div class="form-group"><label>Commercial Driving License No</label><input type="text" name="driver_license_no" placeholder="e.g. DL123456" required></div>
                    <div class="form-group"><label>Identity Mapping Reference ID</label><input type="text" name="aadhaar_no" maxlength="12" pattern="\d{12}" placeholder="12-digit configuration number" required></div>
                    <div class="form-group"><label>Regional Home Base Station</label><input type="text" name="base_station" placeholder="e.g. Depot Station A" required></div>
                    <button type="submit" style="width:100%; background:#3b82f6; color:#fff; border:none; padding:12px; font-weight:600; border-radius:4px; cursor:pointer; font-size:13px;"><i class="fa-solid fa-cloud-arrow-up"></i> Save Asset</button>
                </form>
            </div>

            <div class="control-card">
                <h3 style="margin: 0 0 20px 0; color: #0f172a; font-size: 15px; border-bottom: 1px solid #e2e8f0; padding-bottom: 10px;"><i class="fa-solid fa-map-location-dot" style="color:#10b981;"></i> Establish Transit Route</h3>
                <?php if(!empty($route_msg)): ?>
                    <div class="alert-notify" style="background:#ecfdf5; color:#047857;"><i class="fa-solid fa-square-check"></i> <?php echo htmlspecialchars($route_msg); ?></div>
                <?php endif; ?>
                <form action="admin.php" method="POST" autocomplete="off">
                    <input type="hidden" name="action" value="register_route">
                    <div class="form-group"><label>Pickup Location</label><input type="text" name="pickup_point" placeholder="Departure Point" required></div>
                    <div class="form-group"><label>Drop Location</label><input type="text" name="drop_point" placeholder="Arrival Destination" required></div>
                    <div class="form-group"><label>Distance (km)</label><input type="number" step="0.01" name="estimated_distance" placeholder="Distance in kilometers" required></div>
                    <button type="submit" style="width:100%; background:#10b981; color:#fff; border:none; padding:12px; font-weight:600; border-radius:4px; cursor:pointer; font-size:13px;"><i class="fa-solid fa-route"></i> Deploy Route</button>
                </form>
            </div>
        </div>

        <div class="data-panel-stack">
            <div class="data-table-frame" style="border-top: 4px solid #0284c7;">
                <h3 style="margin: 0 0 20px 0; color: #0f172a; font-size: 16px;">
                    <i class="fa-solid fa-receipt" style="color:#0284c7;"></i> Operational States Logistics Console
                </h3>
                
                <?php if(!empty($booking_msg)): ?>
                    <div class="alert-notify" style="background:#f0f9ff; color:#0369a1;"><i class="fa-solid fa-bolt"></i> <?php echo htmlspecialchars($booking_msg); ?></div>
                <?php endif; ?>

                <div class="tab-navigation-bar" style="display: flex; gap: 10px; margin-bottom: 20px; border-bottom: 2px solid #e2e8f0; padding-bottom: 2px; overflow-x: auto;">
                    <button class="tab-trigger active" onclick="switchOperationalTab(event, 'tab-in-transit')" style="padding: 10px 20px; border: none; background: none; font-weight: 600; font-size: 13px; cursor: pointer; color: #0284c7; border-bottom: 2px solid #0284c7; margin-bottom: -4px; transition: all 0.2s; white-space: nowrap;">
                        <i class="fa-solid fa-taxi"></i> In Transit (<?php echo $in_transit_result ? $in_transit_result->num_rows : 0; ?>)
                    </button>
                    <button class="tab-trigger" onclick="switchOperationalTab(event, 'tab-past-rides')" style="padding: 10px 20px; border: none; background: none; font-weight: 600; font-size: 13px; cursor: pointer; color: #64748b; margin-bottom: -4px; transition: all 0.2s; white-space: nowrap;">
                        <i class="fa-solid fa-clock-rotate-left"></i> Past Rides (<?php echo $past_rides_result ? $past_rides_result->num_rows : 0; ?>)
                    </button>
                    <button class="tab-trigger" onclick="switchOperationalTab(event, 'tab-cancelled-rides')" style="padding: 10px 20px; border: none; background: none; font-weight: 600; font-size: 13px; cursor: pointer; color: #64748b; margin-bottom: -4px; transition: all 0.2s; white-space: nowrap;">
                        <i class="fa-solid fa-ban"></i> Cancelled (<?php echo $cancelled_result ? $cancelled_result->num_rows : 0; ?>)
                    </button>
                </div>

                <div id="tab-in-transit" class="operational-tab-content" style="display: block;">
                    <table class="transit-table">
                        <thead>
                            <tr>
                                <th>Ref No</th>
                                <th>Customer Info</th>
                                <th>Route Context</th>
                                <th>Schedule</th>
                                <th>OTP</th>
                                <th>Driver Assigned</th>
                                <th>Fare Matrix</th>
                                <th>Action Override</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if($in_transit_result && $in_transit_result->num_rows > 0): ?>
                                <?php while($b_row = $in_transit_result->fetch_assoc()): ?>
                                    <tr>
                                        <td><strong style="color:#0369a1;"><?php echo htmlspecialchars($b_row['booking_ref_no']); ?></strong></td>
                                        <td><strong><?php echo htmlspecialchars($b_row['customer_name']); ?></strong><br><small><?php echo htmlspecialchars($b_row['customer_phone']); ?></small></td>
                                        <td><i class="fa-solid fa-location-dot" style="color: #64748b; font-size: 11px;"></i> <small style="font-weight:600;"><?php echo htmlspecialchars($b_row['pickup_location']); ?></small><br><small style="color:#64748b;">➔ <?php echo htmlspecialchars($b_row['drop_location']); ?></small></td>
                                        <td><small><?php echo date("d-M-y", strtotime($b_row['pickup_date'])); ?></small><br><small style="color:#475569;"><?php echo date("g:i A", strtotime($b_row['pickup_time'])); ?></small></td>
                                        <td><code style="font-size:13px; font-weight:700; color:#0369a1; background:#e0f2fe; padding:2px 6px; border-radius:4px;"><?php echo htmlspecialchars($b_row['otp_code']); ?></code></td>
                                        <td style="color: #1e293b; font-weight: 500;"><?php echo htmlspecialchars($b_row['driver_name'] ?? 'Unassigned'); ?></td>
                                        <td><small style="color:#1e293b; font-weight:600;">Due: ₹<?php echo htmlspecialchars($b_row['driver_balance']); ?></small></td>
                                        <td>
                                            <form action="admin.php" method="POST" class="inline-action-form" style="margin-bottom: 5px;">
                                                <input type="hidden" name="action" value="assign_booking_driver">
                                                <input type="hidden" name="booking_id" value="<?php echo $b_row['id']; ?>">
                                                <select name="driver_id" onchange="this.form.submit()" style="padding:4px; font-size:12px; width:150px;">
                                                    <option value="">-- Reassign Driver --</option>
                                                    <?php 
                                                    $drivers_for_bookings->data_seek(0);
                                                    while($d = $drivers_for_bookings->fetch_assoc()): 
                                                    ?>
                                                        <option value="<?php echo $d['id']; ?>" <?php echo ($b_row['assigned_driver_id'] == $d['id']) ? 'selected' : ''; ?>>
                                                            <?php echo htmlspecialchars($d['driver_name']); ?>
                                                        </option>
                                                    <?php endwhile; ?>
                                                </select>
                                            </form>
                                            <form action="admin.php" method="POST" class="inline-action-form" onsubmit="return confirm('Force administrative cancellation on this live transit ride?');">
                                                <input type="hidden" name="action" value="admin_cancel_booking">
                                                <input type="hidden" name="booking_id" value="<?php echo $b_row['id']; ?>">
                                                <button type="submit" class="action-btn-sm" style="background:#ef4444;"><i class="fa-solid fa-trash-can"></i> Cancel</button>
                                            </form>
                                        </td>
                                    </tr>
                                <?php endwhile; ?>
                            <?php else: ?>
                                <tr><td colspan="8" style="text-align: center; color: #94a3b8; padding: 30px 0;">No active rides currently operational in transit.</td></tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>

                <div id="tab-past-rides" class="operational-tab-content" style="display: none;">
                    <table class="transit-table">
                        <thead>
                            <tr>
                                <th>Ref No</th>
                                <th>Customer Info</th>
                                <th>Route Context</th>
                                <th>Schedule</th>
                                <th>Driver Assigned</th>
                                <th>Fare</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if($past_rides_result && $past_rides_result->num_rows > 0): ?>
                                <?php while($p_row = $past_rides_result->fetch_assoc()): ?>
                                    <tr>
                                        <td><strong style="color:#16a34a;"><?php echo htmlspecialchars($p_row['booking_ref_no']); ?></strong></td>
                                        <td><strong><?php echo htmlspecialchars($p_row['customer_name']); ?></strong></td>
                                        <td><small><?php echo htmlspecialchars($p_row['pickup_location'] . " ➔ " . $p_row['drop_location']); ?></small></td>
                                        <td><small><?php echo date("d-M-y", strtotime($p_row['pickup_date'])); ?></small></td>
                                        <td><?php echo htmlspecialchars($p_row['driver_name'] ?? 'None'); ?></td>
                                        <td>₹<?php echo htmlspecialchars($p_row['total_fare']); ?></td>
                                    </tr>
                                <?php endwhile; ?>
                            <?php else: ?>
                                <tr><td colspan="6" style="text-align: center; color: #94a3b8; padding: 30px 0;">No historical completed records found.</td></tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>

                <div id="tab-cancelled-rides" class="operational-tab-content" style="display: none;">
                    <table class="transit-table">
                        <thead>
                            <tr>
                                <th>Ref No</th>
                                <th>Customer Info</th>
                                <th>Route Context</th>
                                <th>Driver Scope</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if($cancelled_result && $cancelled_result->num_rows > 0): ?>
                                <?php while($c_row = $cancelled_result->fetch_assoc()): ?>
                                    <tr>
                                        <td><strong style="color:#dc2626;"><?php echo htmlspecialchars($c_row['booking_ref_no']); ?></strong></td>
                                        <td><strong><?php echo htmlspecialchars($c_row['customer_name']); ?></strong></td>
                                        <td><small><?php echo htmlspecialchars($c_row['pickup_location'] . " ➔ " . $c_row['drop_location']); ?></small></td>
                                        <td><?php echo htmlspecialchars($c_row['driver_name'] ?? 'N/A'); ?></td>
                                    </tr>
                                <?php endwhile; ?>
                            <?php else: ?>
                                <tr><td colspan="4" style="text-align: center; color: #94a3b8; padding: 30px 0;">No cancelled listings logged.</td></tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>

            </div>
        </div>
    </div>

    <script>
        function switchOperationalTab(evt, tabId) {
            var i, tabcontent, tabtriggers;
            tabcontent = document.getElementsByClassName("operational-tab-content");
            for (i = 0; i < tabcontent.length; i++) {
                tabcontent[i].style.display = "none";
            }
            tabtriggers = document.getElementsByClassName("tab-trigger");
            for (i = 0; i < tabtriggers.length; i++) {
                tabtriggers[i].classList.remove("active");
                tabtriggers[i].style.color = "#64748b";
                tabtriggers[i].style.borderBottom = "none";
            }
            document.getElementById(tabId).style.display = "block";
            evt.currentTarget.classList.add("active");
            evt.currentTarget.style.color = "#0284c7";
            evt.currentTarget.style.borderBottom = "2px solid #0284c7";
        }
    </script>
    <a href="cancelled_booking.php" class="btn">View Cancellation Archive</a>
</body>
</html>