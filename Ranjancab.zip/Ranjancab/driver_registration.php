<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Driver Registration | RanjanCabs</title>
    <link rel="stylesheet" href="style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        /* Shared Hero-Style background */
        body { background: #f8fafc; margin: 0; font-family: sans-serif; }
        .reg-hero {
            padding: 100px 20px;
            background: url('https://images.unsplash.com/photo-1503376780353-7e6692767b70?q=80&w=1920') no-repeat center center/cover;
            display: flex; justify-content: center; align-items: center; min-height: 80vh;
        }
        .reg-card {
            background: #fff;
            padding: 40px;
            border-radius: 12px;
            box-shadow: 0 20px 25px -5px rgba(0, 0, 0, 0.1);
            max-width: 500px;
            width: 100%;
        }
        .reg-card h2 { color: #172033; margin-top: 0; margin-bottom: 24px; display: flex; align-items: center; gap: 10px; }
        .input-group { margin-bottom: 20px; }
        .input-group label { display: block; margin-bottom: 8px; font-weight: 700; color: #475569; font-size: 14px; }
        .input-group input, .input-group select {
            width: 100%; padding: 12px; border: 1px solid #e2e8f0; border-radius: 8px;
            box-sizing: border-box; font-size: 15px; transition: border 0.2s;
        }
        .input-group input:focus { border-color: #b7791f; outline: none; }
        .submit-btn {
            width: 100%; padding: 14px; background: #172033; color: #fff; border: none;
            border-radius: 8px; font-weight: 800; cursor: pointer; transition: background 0.2s;
        }
        .submit-btn:hover { background: #0f172a; }
        .form-footer { margin-top: 20px; text-align: center; font-size: 14px; color: #64748b; }
        .form-footer a { color: #b7791f; text-decoration: none; font-weight: bold; }
    </style>
</head>
<body>

<?php include 'header1.php'; ?>

<main class="reg-hero">
    <div class="reg-card">
        <h2><i class="fa-solid fa-id-card"></i> Driver Registration</h2>
        <form action="process_driver_reg.php" method="POST">
            <div class="input-group">
                <label>Full Name</label>
                <input type="text" name="driver_name" placeholder="Enter your full name" required>
            </div>
            <div class="input-group">
                <label>Mobile Number</label>
                <input type="tel" name="mobile_number" placeholder="10-digit mobile number" required>
            </div>
            <div class="input-group">
                <label>Vehicle Number</label>
                <input type="text" name="vehicle_number" placeholder="e.g., MP-04-AB-1234" required>
            </div>
            <div class="input-group">
                <label>Model Name</label>
                <input type="text" name="model_name" placeholder="e.g., Maruti Dzire" required>
            </div>
            <div class="input-group">
                <label>Car Type</label>
                <select name="car_type" required>
                    <option value="" disabled selected>Select vehicle class</option>
                    <option value="Hatchback">Hatchback</option>
                    <option value="Sedan">Sedan</option>
                    <option value="SUV">SUV</option>
                </select>
            </div>
            <div class="input-group">
                <label>Base Station</label>
                <input type="text" name="base_station" placeholder="Your primary operating city" required>
            </div>
            <button type="submit" class="submit-btn">Complete Registration</button>
        </form>
        <div class="form-footer">
            Already registered? <a href="driver_login.php">Login here</a>
        </div>
    </div>
</main>

</body>
</html>