<?php
// JavaScript helpers for admin UI (modals, tab switching)
?>
            <script>
            function switchOperationalTab(event, tabId) {
                const contents = document.querySelectorAll('.operational-tab-content');
                contents.forEach(content => content.style.display = 'none');

                const triggers = document.querySelectorAll('.tab-trigger');
                triggers.forEach(trigger => {
                    trigger.classList.remove('active');
                    trigger.style.color = '#64748b';
                    trigger.style.borderBottom = 'none';
                });

                document.getElementById(tabId).style.display = 'block';

                const target = event.currentTarget;
                target.classList.add('active');
                if(tabId === 'tab-in-transit') {
                    target.style.color = '#0284c7';
                    target.style.borderBottom = '2px solid #0284c7';
                } else if(tabId === 'tab-past-rides') {
                    target.style.color = '#166534';
                    target.style.borderBottom = '2px solid #166534';
                } else if(tabId === 'tab-cancelled-rides') {
                    target.style.color = '#ef4444';
                    target.style.borderBottom = '2px solid #ef4444';
                }
            }

            function editRoute(routeId, pickupPoint, dropPoint, distance) {
                const form = document.createElement('form');
                form.method = 'POST';
                form.action = 'admin.php';
                form.innerHTML = `
                    <div style="position:fixed; top:0; left:0; right:0; bottom:0; background:rgba(0,0,0,0.5); display:flex; justify-content:center; align-items:center; z-index:9999;">
                        <div style="background:white; padding:30px; border-radius:8px; max-width:500px; width:90%;">
                            <h3 style="margin:0 0 20px 0; color:#0f172a;">Edit Route</h3>
                            <input type="hidden" name="action" value="update_route">
                            <input type="hidden" name="route_id" value="${routeId}">
                            <div class="form-group"><label>Pickup Location</label><input type="text" name="pickup_point" value="${pickupPoint}" required></div>
                            <div class="form-group"><label>Drop Location</label><input type="text" name="drop_point" value="${dropPoint}" required></div>
                            <div class="form-group"><label>Distance (km)</label><input type="number" step="0.01" name="estimated_distance" value="${distance}" required></div>
                            <div style="display:flex; gap:10px; margin-top:10px;"><button type="submit" style="flex:1; padding:10px; background:#3b82f6; color:white; border:none; border-radius:4px; cursor:pointer; font-weight:600;">Save Changes</button><button type="button" onclick="this.closest('form').parentElement.parentElement.remove()" style="flex:1; padding:10px; background:#e2e8f0; color:#475569; border:none; border-radius:4px; cursor:pointer; font-weight:600;">Cancel</button></div>
                        </div>
                    </div>
                `;
                document.body.appendChild(form);
            }

            function editBooking(bookingId) {
                window.location.href = 'edit_booking.php?id=' + bookingId;
            }

            function editDriver(driverId) {
                window.location.href = 'edit_driver.php?id=' + driverId;
            }
            </script>
