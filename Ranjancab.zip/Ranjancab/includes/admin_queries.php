<?php
// Runs queries used by the admin UI. Assumes $conn exists.

// Basic system metrics
$sys_fin = $conn->query("SELECT 
    SUM(CASE WHEN b.booking_flag = 3 THEN b.driver_balance ELSE 0 END) as realized_rev,
    SUM(CASE WHEN b.booking_flag = 1 THEN b.driver_balance ELSE 0 END) as active_escrow,
    COUNT(CASE WHEN b.booking_flag = 0 OR b.assigned_driver_id IS NULL THEN 1 END) as pending_trips
    FROM bookings b
")->fetch_assoc();

// Aggregates and lists
$fleet_result = $conn->query("SELECT * FROM fleet ORDER BY id DESC");
$route_result = $conn->query("SELECT * FROM routes ORDER BY id DESC");
if (!$route_result) { die("Database Query Failure on Routes Extraction Stack: " . $conn->error); }
$drivers_for_bookings = $conn->query("SELECT id, driver_name, vehicle_number FROM fleet ORDER BY driver_name ASC");

$in_transit_result = $conn->query("
    SELECT b.*, f.driver_name, f.vehicle_number 
    FROM bookings b 
    LEFT JOIN fleet f ON b.assigned_driver_id = f.id 
    WHERE b.booking_flag = 1
    ORDER BY b.pickup_date ASC, b.pickup_time ASC
");

$past_rides_result = $conn->query("
    SELECT b.*, f.driver_name, f.vehicle_number 
    FROM bookings b 
    LEFT JOIN fleet f ON b.assigned_driver_id = f.id 
    WHERE b.booking_flag = 3
    ORDER BY b.pickup_date DESC, b.id DESC
");

$cancelled_result = $conn->query("
    SELECT b.*, f.driver_name, f.vehicle_number 
    FROM bookings b 
    LEFT JOIN fleet f ON b.assigned_driver_id = f.id 
    WHERE b.booking_flag = 2
    ORDER BY b.id DESC
");

// Full lists
$all_bookings_result = $conn->query("SELECT * FROM bookings ORDER BY id DESC");
$rejections_result = $conn->query("
    SELECT br.*, f.driver_name, b.first_name, b.last_name, b.mobile_number 
    FROM booking_rejections br 
    LEFT JOIN fleet f ON br.driver_id = f.id 
    LEFT JOIN bookings b ON br.booking_id = b.id 
    ORDER BY br.rejected_at DESC
");

$total_drivers = $conn->query("SELECT COUNT(*) as count FROM fleet")->fetch_assoc()['count'];
$total_bookings = $conn->query("SELECT COUNT(*) as count FROM bookings")->fetch_assoc()['count'];
$total_routes = $conn->query("SELECT COUNT(*) as count FROM routes")->fetch_assoc()['count'];
$total_rejections = $conn->query("SELECT COUNT(*) as count FROM booking_rejections")->fetch_assoc()['count'];
$completed_bookings = $conn->query("SELECT COUNT(*) as count FROM bookings WHERE booking_flag = 3")->fetch_assoc()['count'];
$active_bookings = $conn->query("SELECT COUNT(*) as count FROM bookings WHERE booking_flag = 1")->fetch_assoc()['count'];

?>
