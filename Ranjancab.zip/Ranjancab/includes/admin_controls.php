<?php
// Left column controls: fleet registration and route registration
?>
            <div class="control-card">
                <h3 style="margin: 0 0 20px 0; color: #0f172a; font-size: 15px; border-bottom: 1px solid #e2e8f0; padding-bottom: 10px;"><i class="fa-solid fa-bus-front" style="color:#3b82f6;"></i> Provision New Asset</h3>
                <form action="admin.php" method="POST" autocomplete="off">
                    <input type="hidden" name="action" value="register_fleet">
                    <div class="form-group"><label>Vehicle License Plate No</label><input type="text" name="vehicle_number" placeholder="e.g. MP04CW3708" required></div>
                    <div class="form-group"><label>Vehicle Variant/Model</label><input type="text" name="model_name" placeholder="e.g. Swift Dzire" required></div>
                    <div class="form-group">
                        <label>System Classification Class</label>
                        <select name="car_type" required>
                            <option value="" disabled selected>Choose a car option</option>
                            <option value="Economy">Economy (Budget Friendly)</option>
                            <option value="Sedan">Sedan (Comfortable Business)</option>
                            <option value="SUV">SUV (Spacious Family)</option>
                            <option value="Luxury">Luxury (Premium Experience)</option>
                        </select>
                    </div>
                    <div class="form-group"><label>Operator/Driver Full Name</label><input type="text" name="driver_name" placeholder="Legal Name" required></div>
                    <div class="form-group"><label>Mobile Communications Line</label><input type="text" name="mobile_number" maxlength="10" pattern="\d{10}" placeholder="10-digit number" required></div>
                    <div class="form-group"><label>Commercial Driving License No</label><input type="text" name="driver_license_no" placeholder="e.g. DL123456" required></div>
                    <div class="form-group"><label>Identity Mapping Reference ID</label><input type="text" name="aadhaar_no" maxlength="12" pattern="\d{12}" placeholder="12-digit configuration number" required></div>
                    <div class="form-group"><label>Regional Home Base Station</label><input type="text" name="base_station" placeholder="e.g. Depot Station A" required></div>
                    <button type="submit" style="width:100%; background:#3b82f6; color:#fff; border:none; padding:12px; font-weight:600; border-radius:4px; cursor:pointer; font-size:13px;"><i class="fa-solid fa-cloud-arrow-up"></i> Save Asset</button>
                </form>
            </div>

            <div class="control-card">
                <h3 style="margin: 0 0 20px 0; color: #0f172a; font-size: 15px; border-bottom: 1px solid #e2e8f0; padding-bottom: 10px;"><i class="fa-solid fa-map-location-dot" style="color:#10b981;"></i> Establish Transit Route</h3>
                <form action="admin.php" method="POST" autocomplete="off">
                    <input type="hidden" name="action" value="register_route">
                    <div class="form-group"><label>Pickup Location</label><input type="text" name="pickup_point" placeholder="Departure Point" required></div>
                    <div class="form-group"><label>Drop Location</label><input type="text" name="drop_point" placeholder="Arrival Destination" required></div>
                    <div class="form-group"><label>Distance (km)</label><input type="number" step="0.01" name="estimated_distance" placeholder="Distance in kilometers" required></div>
                    <button type="submit" style="width:100%; background:#10b981; color:#fff; border:none; padding:12px; font-weight:600; border-radius:4px; cursor:pointer; font-size:13px;"><i class="fa-solid fa-route"></i> Deploy Route</button>
                </form>
            </div>
