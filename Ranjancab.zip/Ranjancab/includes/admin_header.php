<?php
// Header and first part of the admin HTML layout
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Global Core Control | RanjanCabs Engine</title>
    <link rel="stylesheet" href="style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        /* (styles preserved from original file) */
        .admin-container { max-width: 1750px; margin: 30px auto; padding: 0 25px; display: grid; grid-template-columns: 1fr 2.8fr; gap: 30px; }
        .stats-strip { display: grid; grid-template-columns: repeat(6, 1fr); gap: 20px; max-width: 1700px; margin: 30px auto 0 auto; padding: 0 25px; }
        .stat-card { background: #fff; padding: 20px; border-radius: 8px; box-shadow: 0 4px 12px rgba(0,0,0,0.05); border-left: 4px solid #3b82f6; }
        .control-card { background: #fff; padding: 25px; border-radius: 8px; box-shadow: 0 4px 12px rgba(0,0,0,0.05); margin-bottom: 30px; height: fit-content; }
        .form-group { margin-bottom: 15px; }
        .form-group label { display: block; font-size: 11px; font-weight: 600; color: #334155; margin-bottom: 6px; text-transform: uppercase; letter-spacing: 0.5px; }
        .form-group input, .form-group select { width: 100%; padding: 10px; border: 1px solid #cbd5e1; border-radius: 4px; font-size: 13px; box-sizing: border-box; }
        .data-panel-stack { display: flex; flex-direction: column; gap: 30px; }
        .data-table-frame { background: #fff; padding: 25px; border-radius: 8px; box-shadow: 0 4px 12px rgba(0,0,0,0.05); overflow-x: auto; }
        .transit-table { width: 100%; border-collapse: collapse; text-align: left; font-size: 13px; }
        .transit-table th { background: #0f172a; color: #fff; padding: 12px; font-weight: 500; white-space: nowrap; }
        .transit-table td { padding: 12px; border-bottom: 1px solid #e2e8f0; color: #334155; vertical-align: middle; white-space: nowrap; }
        .transit-table tr:hover { background: #f8fafc; }
        .status-badge { padding: 4px 8px; border-radius: 12px; font-weight: 600; font-size: 11px; display: inline-block; text-transform: uppercase; }
        .alert-notify { background:#e0f2fe; color:#0369a1; padding:12px; border-radius:4px; font-size:12px; margin-bottom:15px; font-weight:500; }
        .inline-action-form { display: inline-flex; align-items: center; gap: 5px; margin: 0; }
        .action-btn-sm { padding: 6px 10px; border: none; border-radius: 4px; font-size: 11px; font-weight: 600; cursor: pointer; color: #fff; }
        @media(max-width: 1400px) { .admin-container { grid-template-columns: 1fr; padding: 0 15px; } .stats-strip { grid-template-columns: repeat(3, 1fr); padding: 0 15px; } }
        @media(max-width: 991px) { .stats-strip { grid-template-columns: 1fr; gap: 15px; } .admin-container { margin: 15px auto; gap: 20px; } .control-card, .data-table-frame { padding: 15px; } }
    </style>
</head>
<body style="background-color: #f1f5f9; margin: 0; font-family: system-ui, -apple-system, sans-serif;">

    <header class="navbar" style="background-color: #0f172a; padding: 15px 30px;">
        <div style="display: flex; justify-content: space-between; align-items: center; max-width: 1750px; margin: 0 auto;">
            <div class="logo"><a href="#" style="color:#fff; text-decoration: none; font-weight: 700; font-size: 20px;"><i class="fa-solid fa-screwdriver-wrench" style="color:#3b82f6;"></i> Admin<span style="color:#3b82f6;">Console</span></a></div>
            <a href="admin_logout.php" style="background-color:#ef4444; color:#fff; text-decoration:none; padding:8px 16px; border-radius:4px; font-size:13px; font-weight:600;"><i class="fa-solid fa-power-off"></i> Terminate Session</a>
        </div>
    </header>

    <div class="stats-strip">
        <div class="stat-card" style="border-left-color: #22c55e;">
            <small style="color: #64748b; font-weight:600; text-transform:uppercase; font-size:11px;">Total Drivers</small>
            <h2 style="margin: 5px 0 0 0; color: #0f172a;"><?php echo $total_drivers; ?></h2>
        </div>
        <div class="stat-card" style="border-left-color: #0284c7;">
            <small style="color: #64748b; font-weight:600; text-transform:uppercase; font-size:11px;">Total Bookings</small>
            <h2 style="margin: 5px 0 0 0; color: #0f172a;"><?php echo $total_bookings; ?></h2>
        </div>
        <div class="stat-card" style="border-left-color: #10b981;">
            <small style="color: #64748b; font-weight:600; text-transform:uppercase; font-size:11px;">Total Routes</small>
            <h2 style="margin: 5px 0 0 0; color: #0f172a;"><?php echo $total_routes; ?></h2>
        </div>
        <div class="stat-card" style="border-left-color: #f59e0b;">
            <small style="color: #64748b; font-weight:600; text-transform:uppercase; font-size:11px;">Completed Rides</small>
            <h2 style="margin: 5px 0 0 0; color: #0f172a;"><?php echo $completed_bookings; ?></h2>
        </div>
        <div class="stat-card" style="border-left-color: #ef4444;">
            <small style="color: #64748b; font-weight:600; text-transform:uppercase; font-size:11px;">Active Rides</small>
            <h2 style="margin: 5px 0 0 0; color: #0f172a;"><?php echo $active_bookings; ?></h2>
        </div>
        <div class="stat-card" style="border-left-color: #8b5cf6;">
            <small style="color: #64748b; font-weight:600; text-transform:uppercase; font-size:11px;">Total Rejections</small>
            <h2 style="margin: 5px 0 0 0; color: #0f172a;"><?php echo $total_rejections; ?></h2>
        </div>
    </div>

    <div class="admin-container">
        <div>
            <?php if(!empty($msg)): ?>
                <div class="control-card"><div class="alert-notify"><i class="fa-solid fa-circle-info"></i> <?php echo htmlspecialchars($msg); ?></div></div>
            <?php endif; ?>
            <?php if(!empty($route_msg)): ?>
                <div class="control-card"><div class="alert-notify" style="background:#ecfdf5; color:#047857;"><i class="fa-solid fa-square-check"></i> <?php echo htmlspecialchars($route_msg); ?></div></div>
            <?php endif; ?>
            <?php if(!empty($success_msg)): ?>
                <div style="max-width:1750px; margin:20px auto; padding:0 25px;"><div style="background:#dcfce7; color:#15803d; padding:12px; border-radius:4px; font-size:13px; font-weight:500; border-left:4px solid #15803d;"><i class="fa-solid fa-circle-check"></i> <?php echo htmlspecialchars($success_msg); ?></div></div>
            <?php endif; ?>
            <?php if(!empty($error_msg)): ?>
                <div style="max-width:1750px; margin:20px auto; padding:0 25px;"><div style="background:#fee2e2; color:#991b1b; padding:12px; border-radius:4px; font-size:13px; font-weight:500; border-left:4px solid #991b1b;"><i class="fa-solid fa-circle-exclamation"></i> <?php echo htmlspecialchars($error_msg); ?></div></div>
            <?php endif; ?>
