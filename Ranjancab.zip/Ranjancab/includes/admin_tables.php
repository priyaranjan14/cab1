<?php
// Renders the right-column tables for bookings, routes, fleet, and rejections
?>
            <div class="data-panel-stack">
                <div class="data-table-frame" style="border-top: 4px solid #0284c7;">
                    <h3 style="margin: 0 0 20px 0; color: #0f172a; font-size: 16px;"><i class="fa-solid fa-receipt" style="color:#0284c7;"></i> Operational States Logistics Console</h3>
                    <div class="tab-navigation-bar" style="display: flex; gap: 10px; margin-bottom: 20px; border-bottom: 2px solid #e2e8f0; padding-bottom: 2px;">
                        <button class="tab-trigger active" onclick="switchOperationalTab(event, 'tab-in-transit')" style="padding: 10px 20px; border: none; background: none; font-weight: 600; font-size: 13px; cursor: pointer; color: #0284c7; border-bottom: 2px solid #0284c7; margin-bottom: -4px; transition: all 0.2s;">
                            <i class="fa-solid fa-taxi"></i> In Transit (<?php echo $in_transit_result ? $in_transit_result->num_rows : 0; ?>)
                        </button>
                        <button class="tab-trigger" onclick="switchOperationalTab(event, 'tab-past-rides')" style="padding: 10px 20px; border: none; background: none; font-weight: 600; font-size: 13px; cursor: pointer; color: #64748b; margin-bottom: -4px; transition: all 0.2s;">
                            <i class="fa-solid fa-clock-rotate-left"></i> Past Rides (<?php echo $past_rides_result ? $past_rides_result->num_rows : 0; ?>)
                        </button>
                        <button class="tab-trigger" onclick="switchOperationalTab(event, 'tab-cancelled-rides')" style="padding: 10px 20px; border: none; background: none; font-weight: 600; font-size: 13px; cursor: pointer; color: #64748b; margin-bottom: -4px; transition: all 0.2s;">
                            <i class="fa-solid fa-ban"></i> Cancelled (<?php echo $cancelled_result ? $cancelled_result->num_rows : 0; ?>)
                        </button>
                    </div>

                    <div id="tab-in-transit" class="operational-tab-content" style="display: block;">
                        <table class="transit-table">
                            <thead>
                                <tr>
                                    <th>Ref No</th>
                                    <th>Customer Info</th>
                                    <th>Route Context</th>
                                    <th>Schedule</th>
                                    <th>OTP</th>
                                    <th>Driver Assigned</th>
                                    <th>Fare Matrix</th>
                                    <th>Action Override</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php if($in_transit_result && $in_transit_result->num_rows > 0): ?>
                                    <?php while($b_row = $in_transit_result->fetch_assoc()): ?>
                                        <tr>
                                            <td><strong style="color:#0369a1;"><?php echo htmlspecialchars($b_row['booking_ref_no']); ?></strong></td>
                                            <td><strong><?php echo htmlspecialchars($b_row['first_name'] . " " . $b_row['last_name']); ?></strong><br><small><?php echo htmlspecialchars($b_row['mobile_number']); ?></small></td>
                                            <td><i class="fa-solid fa-location-dot" style="color: #64748b; font-size: 11px;"></i> <small style="font-weight:600;"><?php echo htmlspecialchars($b_row['pickup_location']); ?></small><br><small style="color:#64748b;">➔ <?php echo htmlspecialchars($b_row['drop_location']); ?></small></td>
                                            <td><small><?php echo date("d-M-y", strtotime($b_row['pickup_date'])); ?></small><br><small style="color:#475569;"><?php echo date("g:i A", strtotime($b_row['pickup_time'])); ?></small></td>
                                            <td><code style="font-size:13px; font-weight:700; color:#0369a1; background:#e0f2fe; padding:2px 6px; border-radius:4px;"><?php echo htmlspecialchars($b_row['otp_code']); ?></code></td>
                                            <td style="color: #1e293b; font-weight: 500;"><?php echo htmlspecialchars($b_row['driver_name'] ?? 'Unassigned'); ?></td>
                                            <td><small style="color:#1e293b; font-weight:600;">Due: ₹<?php echo htmlspecialchars($b_row['driver_balance']); ?></small></td>
                                            <td>
                                                <form action="admin.php" method="POST" class="inline-action-form" style="margin-bottom: 5px;">
                                                    <input type="hidden" name="action" value="assign_booking_driver">
                                                    <input type="hidden" name="booking_id" value="<?php echo $b_row['id']; ?>">
                                                    <select name="driver_id" onchange="this.form.submit()" style="padding:4px; font-size:12px; width:150px;">
                                                        <option value="">-- Reassign Driver --</option>
                                                        <?php 
                                                        $drivers_for_bookings->data_seek(0);
                                                        while($d = $drivers_for_bookings->fetch_assoc()): 
                                                        ?>
                                                            <option value="<?php echo $d['id']; ?>" <?php echo ($b_row['assigned_driver_id'] == $d['id']) ? 'selected' : ''; ?>>
                                                                <?php echo htmlspecialchars($d['driver_name']); ?>
                                                            </option>
                                                        <?php endwhile; ?>
                                                    </select>
                                                </form>
                                                <form action="admin.php" method="POST" class="inline-action-form" onsubmit="return confirm('Force administrative cancellation on this live transit ride?');">
                                                    <input type="hidden" name="action" value="admin_cancel_booking">
                                                    <input type="hidden" name="booking_id" value="<?php echo $b_row['id']; ?>">
                                                    <button type="submit" class="action-btn-sm" style="background:#ef4444;"><i class="fa-solid fa-trash-can"></i> Cancel</button>
                                                </form>
                                            </td>
                                        </tr>
                                    <?php endwhile; ?>
                                <?php else: ?>
                                    <tr><td colspan="8" style="text-align: center; color: #94a3b8; padding: 30px 0;">No active rides currently operational in transit.</td></tr>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>

                    <div id="tab-past-rides" class="operational-tab-content" style="display: none;">
                        <table class="transit-table">
                            <thead>
                                <tr>
                                    <th>Ref No</th>
                                    <th>Customer Info</th>
                                    <th>Route Context</th>
                                    <th>Completed Date</th>
                                    <th>Fulfilled By</th>
                                    <th>Collected Revenue</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php if($past_rides_result && $past_rides_result->num_rows > 0): ?>
                                    <?php while($b_row = $past_rides_result->fetch_assoc()): ?>
                                        <tr style="background: #f8fafc;">
                                            <td><strong style="color:#166534;"><?php echo htmlspecialchars($b_row['booking_ref_no']); ?></strong></td>
                                            <td><strong><?php echo htmlspecialchars($b_row['first_name'] . " " . $b_row['last_name']); ?></strong></td>
                                            <td><small><?php echo htmlspecialchars($b_row['pickup_location']); ?> ➔ <?php echo htmlspecialchars($b_row['drop_location']); ?></small></td>
                                            <td><small style="color: #475569;"><?php echo date("d-M-Y", strtotime($b_row['pickup_date'])); ?></small></td>
                                            <td><strong><i class="fa-solid fa-id-card"></i> <?php echo htmlspecialchars($b_row['driver_name'] ?? 'System Sync'); ?></strong></td>
                                            <td><strong style="color:#166534;">₹<?php echo htmlspecialchars($b_row['driver_balance']); ?></strong></td>
                                        </tr>
                                    <?php endwhile; ?>
                                <?php else: ?>
                                    <tr><td colspan="6" style="text-align: center; color: #94a3b8; padding: 30px 0;">No past records archived in history.</td></tr>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>

                    <div id="tab-cancelled-rides" class="operational-tab-content" style="display: none;">
                        <table class="transit-table">
                            <thead>
                                <tr>
                                    <th>Ref No</th>
                                    <th>Customer Info</th>
                                    <th>Intended Route</th>
                                    <th>Scheduled Date</th>
                                    <th>Vehicle Class</th>
                                    <th>Status</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php if($cancelled_result && $cancelled_result->num_rows > 0): ?>
                                    <?php while($b_row = $cancelled_result->fetch_assoc()): ?>
                                        <tr style="background:#fff5f5; color:#991b1b;">
                                            <td><strong><?php echo htmlspecialchars($b_row['booking_ref_no']); ?></strong></td>
                                            <td><strong><?php echo htmlspecialchars($b_row['first_name'] . " " . $b_row['last_name']); ?></strong></td>
                                            <td><small><?php echo htmlspecialchars($b_row['pickup_location']); ?> ➔ <?php echo htmlspecialchars($b_row['drop_location']); ?></small></td>
                                            <td><small><?php echo date("d-M-y", strtotime($b_row['pickup_date'])); ?></small></td>
                                            <td><span class="status-badge" style="background:#fee2e2; color:#991b1b;"><?php echo htmlspecialchars($b_row['car_type']); ?></span></td>
                                            <td><span class="status-badge" style="background:#ef4444; color:#fff;"><i class="fa-solid fa-ban"></i> Dropped</span></td>
                                        </tr>
                                    <?php endwhile; ?>
                                <?php else: ?>
                                    <tr><td colspan="6" style="text-align: center; color: #94a3b8; padding: 30px 0;">No administrative cancellations logged.</td></tr>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                </div>

                <!-- Routes table and rejection logs -->
                <div class="data-table-frame">
                    <h3 style="margin: 0 0 20px 0; color: #0f172a; font-size: 16px;"><i class="fa-solid fa-route" style="color:#10b981;"></i> System Logged Transit Routes</h3>
                    <table class="transit-table">
                        <thead>
                            <tr>
                                <th>Route ID</th>
                                <th>Pickup Location</th>
                                <th>Drop Location</th>
                                <th>Distance Mapping</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if($route_result && $route_result->num_rows > 0): ?>
                                <?php while($r_row = $route_result->fetch_assoc()): ?>
                                    <tr>
                                        <td><code>#RT-<?php echo $r_row['id']; ?></code></td>
                                        <td style="font-weight: 600; color:#0f172a;"><?php echo htmlspecialchars($r_row['pickup_point']); ?></td>
                                        <td style="font-weight: 600; color:#0f172a;"><?php echo htmlspecialchars($r_row['drop_point']); ?></td>
                                        <td><?php echo htmlspecialchars($r_row['estimated_distance']); ?> km</td>
                                        <td>
                                            <button onclick="editRoute(<?php echo $r_row['id']; ?>, '<?php echo htmlspecialchars($r_row['pickup_point']); ?>', '<?php echo htmlspecialchars($r_row['drop_point']); ?>', <?php echo $r_row['estimated_distance']; ?>)" class="action-btn-sm" style="background:#3b82f6; margin-right:5px;"><i class="fa-solid fa-pen"></i> Edit</button>
                                            <form action="admin.php" method="POST" style="display:inline;" onsubmit="return confirm('Delete this route?');">
                                                <input type="hidden" name="action" value="delete_route">
                                                <input type="hidden" name="route_id" value="<?php echo $r_row['id']; ?>">
                                                <button type="submit" class="action-btn-sm" style="background:#ef4444;"><i class="fa-solid fa-trash"></i> Delete</button>
                                            </form>
                                        </td>
                                    </tr>
                                <?php endwhile; ?>
                            <?php else: ?>
                                <tr><td colspan="5" style="text-align: center; color: #94a3b8; padding: 30px 0;">No routing maps initialized in table storage.</td></tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>

                <div class="data-table-frame" style="border-top: 4px solid #8b5cf6;">
                    <h3 style="margin: 0 0 20px 0; color: #0f172a; font-size: 16px;"><i class="fa-solid fa-ban" style="color:#8b5cf6;"></i> Booking Rejections Log</h3>
                    <table class="transit-table">
                        <thead>
                            <tr>
                                <th>Rejection ID</th>
                                <th>Driver Name</th>
                                <th>Customer</th>
                                <th>Booking Ref</th>
                                <th>Rejected At</th>
                                <th>Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if($rejections_result && $rejections_result->num_rows > 0): ?>
                                <?php while($rej_row = $rejections_result->fetch_assoc()): ?>
                                    <tr style="background:#fef3c7;">
                                        <td><code>#RJ-<?php echo $rej_row['id']; ?></code></td>
                                        <td><strong><?php echo htmlspecialchars($rej_row['driver_name'] ?? 'Unknown'); ?></strong></td>
                                        <td><small><?php echo htmlspecialchars(($rej_row['first_name'] ?? '') . " " . ($rej_row['last_name'] ?? '')); ?></small></td>
                                        <td><strong><?php echo htmlspecialchars($rej_row['booking_id']); ?></strong></td>
                                        <td><small style="color:#475569;"><?php echo date("d-M-Y H:i", strtotime($rej_row['rejected_at'])); ?></small></td>
                                        <td>
                                            <form action="admin.php" method="POST" style="display:inline;" onsubmit="return confirm('Clear this rejection record?');">
                                                <input type="hidden" name="action" value="delete_rejection">
                                                <input type="hidden" name="rejection_id" value="<?php echo $rej_row['id']; ?>">
                                                <button type="submit" class="action-btn-sm" style="background:#ef4444;"><i class="fa-solid fa-trash"></i> Clear</button>
                                            </form>
                                        </td>
                                    </tr>
                                <?php endwhile; ?>
                            <?php else: ?>
                                <tr><td colspan="6" style="text-align: center; color: #94a3b8; padding: 30px 0;">No rejection records found.</td></tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>

                <div class="data-table-frame">
                    <h3 style="margin: 0 0 20px 0; color: #0f172a; font-size: 16px;"><i class="fa-solid fa-receipt" style="color:#0284c7;"></i> All Bookings Management</h3>
                    <table class="transit-table" style="font-size: 12px;">
                        <thead>
                            <tr>
                                <th>Booking ID</th>
                                <th>Reference</th>
                                <th>Customer</th>
                                <th>Mobile</th>
                                <th>Route</th>
                                <th>Schedule</th>
                                <th>Fare</th>
                                <th>Status</th>
                                <th>Driver</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if($all_bookings_result && $all_bookings_result->num_rows > 0): ?>
                                <?php while($all_row = $all_bookings_result->fetch_assoc()): ?>
                                    <tr>
                                        <td><code>#BK-<?php echo $all_row['id']; ?></code></td>
                                        <td><?php echo htmlspecialchars($all_row['booking_ref_no'] ?? 'N/A'); ?></td>
                                        <td><strong><?php echo htmlspecialchars($all_row['first_name'] . " " . $all_row['last_name']); ?></strong></td>
                                        <td><small><?php echo htmlspecialchars($all_row['mobile_number']); ?></small></td>
                                        <td><small><?php echo htmlspecialchars(substr($all_row['pickup_location'], 0, 15)); ?> → <?php echo htmlspecialchars(substr($all_row['drop_location'], 0, 15)); ?></small></td>
                                        <td><small><?php echo date("d-M", strtotime($all_row['pickup_date'])); ?><br><?php echo date("H:i", strtotime($all_row['pickup_time'])); ?></small></td>
                                        <td><strong>₹<?php echo $all_row['total_fare']; ?></strong></td>
                                        <td>
                                            <?php 
                                            $flags = [0 => 'Pending', 1 => 'Active', 2 => 'Cancelled', 3 => 'Completed'];
                                            $colors = [0 => '#94a3b8', 1 => '#0284c7', 2 => '#ef4444', 3 => '#15803d'];
                                            $flag = $all_row['booking_flag'] ?? 0;
                                            ?>
                                            <span class="status-badge" style="background:<?php echo $colors[$flag]; ?>20; color:<?php echo $colors[$flag]; ?>;"><?php echo $flags[$flag]; ?></span>
                                        </td>
                                        <td><small><?php echo htmlspecialchars($all_row['assigned_driver_id'] ? "Assigned" : "Unassigned"); ?></small></td>
                                        <td style="white-space: nowrap;">
                                            <button onclick="editBooking(<?php echo $all_row['id']; ?>)" class="action-btn-sm" style="background:#3b82f6; font-size:11px;"><i class="fa-solid fa-pen"></i> Edit</button>
                                            <form action="admin.php" method="POST" style="display:inline;" onsubmit="return confirm('Delete this booking?');">
                                                <input type="hidden" name="action" value="delete_booking">
                                                <input type="hidden" name="booking_id" value="<?php echo $all_row['id']; ?>">
                                                <button type="submit" class="action-btn-sm" style="background:#ef4444; font-size:11px;"><i class="fa-solid fa-trash"></i> Delete</button>
                                            </form>
                                        </td>
                                    </tr>
                                <?php endwhile; ?>
                            <?php else: ?>
                                <tr><td colspan="10" style="text-align: center; color: #94a3b8; padding: 30px 0;">No bookings found in system.</td></tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
<?php
// Right column data panels: operational tabs, fleet, routes, rejections, bookings
?>
        </div>

        <div class="data-panel-stack">
            <div class="data-table-frame" style="border-top: 4px solid #0284c7;">
                <h3 style="margin: 0 0 20px 0; color: #0f172a; font-size: 16px;"><i class="fa-solid fa-receipt" style="color:#0284c7;"></i> Operational States Logistics Console</h3>

                <?php if(!empty($booking_msg)): ?>
                    <div class="alert-notify" style="background:#f0f9ff; color:#0369a1;"><i class="fa-solid fa-bolt"></i> <?php echo htmlspecialchars($booking_msg); ?></div>
                <?php endif; ?>

                <div class="tab-navigation-bar" style="display: flex; gap: 10px; margin-bottom: 20px; border-bottom: 2px solid #e2e8f0; padding-bottom: 2px;">
                    <button class="tab-trigger active" onclick="switchOperationalTab(event, 'tab-in-transit')" style="padding: 10px 20px; border: none; background: none; font-weight: 600; font-size: 13px; cursor: pointer; color: #0284c7; border-bottom: 2px solid #0284c7; margin-bottom: -4px; transition: all 0.2s;">
                        <i class="fa-solid fa-taxi"></i> In Transit (<?php echo $in_transit_result ? $in_transit_result->num_rows : 0; ?>)
                    </button>
                    <button class="tab-trigger" onclick="switchOperationalTab(event, 'tab-past-rides')" style="padding: 10px 20px; border: none; background: none; font-weight: 600; font-size: 13px; cursor: pointer; color: #64748b; margin-bottom: -4px; transition: all 0.2s;">
                        <i class="fa-solid fa-clock-rotate-left"></i> Past Rides (<?php echo $past_rides_result ? $past_rides_result->num_rows : 0; ?>)
                    </button>
                    <button class="tab-trigger" onclick="switchOperationalTab(event, 'tab-cancelled-rides')" style="padding: 10px 20px; border: none; background: none; font-weight: 600; font-size: 13px; cursor: pointer; color: #64748b; margin-bottom: -4px; transition: all 0.2s;">
                        <i class="fa-solid fa-ban"></i> Cancelled (<?php echo $cancelled_result ? $cancelled_result->num_rows : 0; ?>)
                    </button>
                </div>

                <div id="tab-in-transit" class="operational-tab-content" style="display: block;">
                    <table class="transit-table">
                        <thead>
                            <tr>
                                <th>Ref No</th>
                                <th>Customer Info</th>
                                <th>Route Context</th>
                                <th>Schedule</th>
                                <th>OTP</th>
                                <th>Driver Assigned</th>
                                <th>Fare Matrix</th>
                                <th>Action Override</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if($in_transit_result && $in_transit_result->num_rows > 0): ?>
                                <?php while($b_row = $in_transit_result->fetch_assoc()): ?>
                                    <tr>
                                        <td><strong style="color:#0369a1;"><?php echo htmlspecialchars($b_row['booking_ref_no']); ?></strong></td>
                                        <td><strong><?php echo htmlspecialchars($b_row['first_name'] . " " . $b_row['last_name']); ?></strong><br><small><?php echo htmlspecialchars($b_row['mobile_number']); ?></small></td>
                                        <td><i class="fa-solid fa-location-dot" style="color: #64748b; font-size: 11px;"></i> <small style="font-weight:600;"><?php echo htmlspecialchars($b_row['pickup_location']); ?></small><br><small style="color:#64748b;">➔ <?php echo htmlspecialchars($b_row['drop_location']); ?></small></td>
                                        <td><small><?php echo date("d-M-y", strtotime($b_row['pickup_date'])); ?></small><br><small style="color:#475569;"><?php echo date("g:i A", strtotime($b_row['pickup_time'])); ?></small></td>
                                        <td><code style="font-size:13px; font-weight:700; color:#0369a1; background:#e0f2fe; padding:2px 6px; border-radius:4px;"><?php echo htmlspecialchars($b_row['otp_code']); ?></code></td>
                                        <td style="color: #1e293b; font-weight: 500;"><?php echo htmlspecialchars($b_row['driver_name'] ?? 'Unassigned'); ?></td>
                                        <td><small style="color:#1e293b; font-weight:600;">Due: ₹<?php echo htmlspecialchars($b_row['driver_balance']); ?></small></td>
                                        <td>
                                            <form action="admin.php" method="POST" class="inline-action-form" style="margin-bottom: 5px;">
                                                <input type="hidden" name="action" value="assign_booking_driver">
                                                <input type="hidden" name="booking_id" value="<?php echo $b_row['id']; ?>">
                                                <select name="driver_id" onchange="this.form.submit()" style="padding:4px; font-size:12px; width:150px;">
                                                    <option value="">-- Reassign Driver --</option>
                                                    <?php 
                                                    $drivers_for_bookings->data_seek(0);
                                                    while($d = $drivers_for_bookings->fetch_assoc()): 
                                                    ?>
                                                        <option value="<?php echo $d['id']; ?>" <?php echo ($b_row['assigned_driver_id'] == $d['id']) ? 'selected' : ''; ?>>
                                                            <?php echo htmlspecialchars($d['driver_name']); ?>
                                                        </option>
                                                    <?php endwhile; ?>
                                                </select>
                                            </form>
                                            <form action="admin.php" method="POST" class="inline-action-form" onsubmit="return confirm('Force administrative cancellation on this live transit ride?');">
                                                <input type="hidden" name="action" value="admin_cancel_booking">
                                                <input type="hidden" name="booking_id" value="<?php echo $b_row['id']; ?>">
                                                <button type="submit" class="action-btn-sm" style="background:#ef4444;"><i class="fa-solid fa-trash-can"></i> Cancel</button>
                                            </form>
                                        </td>
                                    </tr>
                                <?php endwhile; ?>
                            <?php else: ?>
                                <tr><td colspan="8" style="text-align: center; color: #94a3b8; padding: 30px 0;">No active rides currently operational in transit.</td></tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>

                <div id="tab-past-rides" class="operational-tab-content" style="display: none;">
                    <table class="transit-table">
                        <thead>
                            <tr>
                                <th>Ref No</th>
                                <th>Customer Info</th>
                                <th>Route Context</th>
                                <th>Completed Date</th>
                                <th>Fulfilled By</th>
                                <th>Collected Revenue</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if($past_rides_result && $past_rides_result->num_rows > 0): ?>
                                <?php while($b_row = $past_rides_result->fetch_assoc()): ?>
                                    <tr style="background: #f8fafc;">
                                        <td><strong style="color:#166534;"><?php echo htmlspecialchars($b_row['booking_ref_no']); ?></strong></td>
                                        <td><strong><?php echo htmlspecialchars($b_row['first_name'] . " " . $b_row['last_name']); ?></strong></td>
                                        <td><small><?php echo htmlspecialchars($b_row['pickup_location']); ?> ➔ <?php echo htmlspecialchars($b_row['drop_location']); ?></small></td>
                                        <td><small style="color: #475569;"><?php echo date("d-M-Y", strtotime($b_row['pickup_date'])); ?></small></td>
                                        <td><strong><i class="fa-solid fa-id-card"></i> <?php echo htmlspecialchars($b_row['driver_name'] ?? 'System Sync'); ?></strong></td>
                                        <td><strong style="color:#166534;">₹<?php echo htmlspecialchars($b_row['driver_balance']); ?></strong></td>
                                    </tr>
                                <?php endwhile; ?>
                            <?php else: ?>
                                <tr><td colspan="6" style="text-align: center; color: #94a3b8; padding: 30px 0;">No past records archived in history.</td></tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>

                <div id="tab-cancelled-rides" class="operational-tab-content" style="display: none;">
                    <table class="transit-table">
                        <thead>
                            <tr>
                                <th>Ref No</th>
                                <th>Customer Info</th>
                                <th>Intended Route</th>
                                <th>Scheduled Date</th>
                                <th>Vehicle Class</th>
                                <th>Status</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if($cancelled_result && $cancelled_result->num_rows > 0): ?>
                                <?php while($b_row = $cancelled_result->fetch_assoc()): ?>
                                    <tr style="background:#fff5f5; color:#991b1b;">
                                        <td><strong><?php echo htmlspecialchars($b_row['booking_ref_no']); ?></strong></td>
                                        <td><strong><?php echo htmlspecialchars($b_row['first_name'] . " " . $b_row['last_name']); ?></strong></td>
                                        <td><small><?php echo htmlspecialchars($b_row['pickup_location']); ?> ➔ <?php echo htmlspecialchars($b_row['drop_location']); ?></small></td>
                                        <td><small><?php echo date("d-M-y", strtotime($b_row['pickup_date'])); ?></small></td>
                                        <td><span class="status-badge" style="background:#fee2e2; color:#991b1b;"><?php echo htmlspecialchars($b_row['car_type']); ?></span></td>
                                        <td><span class="status-badge" style="background:#ef4444; color:#fff;"><i class="fa-solid fa-ban"></i> Dropped</span></td>
                                    </tr>
                                <?php endwhile; ?>
                            <?php else: ?>
                                <tr><td colspan="6" style="text-align: center; color: #94a3b8; padding: 30px 0;">No administrative cancellations logged.</td></tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>

            <div class="data-table-frame" style="border-top: 4px solid #0f172a;">
                <h3 style="margin: 0 0 20px 0; color: #0f172a; font-size: 16px; border-bottom: 1px solid #e2e8f0; padding-bottom: 10px;"><i class="fa-solid fa-car" style="color:#0f172a;"></i> Registered Operational Assets</h3>
                <table class="transit-table">
                    <thead>
                        <tr>
                            <th>Asset ID</th>
                            <th>Vehicle Details</th>
                            <th>Classification</th>
                            <th>Assigned Driver</th>
                            <th>Contact</th>
                            <th>Verification Check</th>
                            <th>Base Station</th>
                            <th>Status</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if($fleet_result && $fleet_result->num_rows > 0): ?>
                            <?php while($row = $fleet_result->fetch_assoc()): ?>
                                <tr>
                                    <td><code>#FL-<?php echo $row['id']; ?></code></td>
                                    <td>
                                        <span style="font-weight: 700; color:#0f172a; display:block;"><?php echo htmlspecialchars($row['vehicle_number']); ?></span>
                                        <small style="color: #64748b;"><?php echo htmlspecialchars($row['model_name']); ?></small>
                                    </td>
                                    <td><span class="status-badge" style="background: #f1f5f9; color: #334155;"><?php echo htmlspecialchars($row['car_type']); ?></span></td>
                                    <td style="font-weight: 600;"><?php echo htmlspecialchars($row['driver_name']); ?></td>
                                    <td><small><i class="fa-solid fa-phone"></i> <?php echo htmlspecialchars($row['mobile_number']); ?></small></td>
                                    <td>
                                        <small style="color:#475569; font-family: monospace;">
                                            <?php 
                                            $clean_id = preg_replace('/\s+/', '', $row['aadhaar_no']);
                                            echo (strlen($clean_id) >= 4) ? "********" . htmlspecialchars(substr($clean_id, -4)) : "[Omitted Reference]";
                                            ?>
                                        </small>
                                    </td>
                                    <td>
                                        <span style="color: #475569; font-weight: 500; font-size: 12px;">
                                            <i class="fa-solid fa-building"></i> <?php echo htmlspecialchars($row['base_station'] ?? 'Main Hub'); ?>
                                        </span>
                                    </td>
                                    <td>
                                        <?php if(($row['is_verified'] ?? 0) == 1): ?>
                                            <span class="status-badge" style="background:#dcfce7; color:#15803d;">Verified</span>
                                        <?php else: ?>
                                            <span class="status-badge" style="background:#fef3c7; color:#d97706;">Pending Audit</span>
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <button onclick="editDriver(<?php echo $row['id']; ?>)" class="action-btn-sm" style="background:#3b82f6; font-size:11px; margin-right:3px;"><i class="fa-solid fa-pen"></i> Edit</button>
                                        <?php if(($row['is_verified'] ?? 0) == 0): ?>
                                            <form action="admin.php" method="POST" style="display:inline;">
                                                <input type="hidden" name="action" value="verify_driver">
                                                <input type="hidden" name="driver_id" value="<?php echo $row['id']; ?>">
                                                <button type="submit" class="action-btn-sm" style="background:#10b981; font-size:11px; margin-right:3px;"><i class="fa-solid fa-check"></i> Verify</button>
                                            </form>
                                        <?php endif; ?>
                                        <form action="admin.php" method="POST" style="display:inline;" onsubmit="return confirm('Delete this driver and all associated records?');">
                                            <input type="hidden" name="action" value="delete_driver">
                                            <input type="hidden" name="driver_id" value="<?php echo $row['id']; ?>">
                                            <button type="submit" class="action-btn-sm" style="background:#ef4444; font-size:11px;"><i class="fa-solid fa-trash"></i> Delete</button>
                                        </form>
                                    </td>
                                </tr>
                            <?php endwhile; ?>
                        <?php else: ?>
                            <tr><td colspan="9" style="text-align: center; color: #94a3b8; padding: 30px 0;">No fleet entries discovered.</td></tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>

            <div class="data-table-frame">
                <h3 style="margin: 0 0 20px 0; color: #0f172a; font-size: 16px; border-bottom: 1px solid #e2e8f0; padding-bottom: 10px;"><i class="fa-solid fa-route" style="color:#10b981;"></i> System Logged Transit Routes</h3>
                <table class="transit-table">
                    <thead>
                        <tr>
                            <th>Route ID</th>
                            <th>Pickup Location</th>
                            <th>Drop Location</th>
                            <th>Distance Mapping</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if($route_result && $route_result->num_rows > 0): ?>
                            <?php while($r_row = $route_result->fetch_assoc()): ?>
                                <tr>
                                    <td><code>#RT-<?php echo $r_row['id']; ?></code></td>
                                    <td style="font-weight: 600; color:#0f172a;"><?php echo htmlspecialchars($r_row['pickup_point']); ?></td>
                                    <td style="font-weight: 600; color:#0f172a;"><?php echo htmlspecialchars($r_row['drop_point']); ?></td>
                                    <td><?php echo htmlspecialchars($r_row['estimated_distance']); ?> km</td>
                                    <td>
                                        <button onclick="editRoute(<?php echo $r_row['id']; ?>, '<?php echo htmlspecialchars($r_row['pickup_point']); ?>', '<?php echo htmlspecialchars($r_row['drop_point']); ?>', <?php echo $r_row['estimated_distance']; ?>)" class="action-btn-sm" style="background:#3b82f6; margin-right:5px;"><i class="fa-solid fa-pen"></i> Edit</button>
                                        <form action="admin.php" method="POST" style="display:inline;" onsubmit="return confirm('Delete this route?');">
                                            <input type="hidden" name="action" value="delete_route">
                                            <input type="hidden" name="route_id" value="<?php echo $r_row['id']; ?>">
                                            <button type="submit" class="action-btn-sm" style="background:#ef4444;"><i class="fa-solid fa-trash"></i> Delete</button>
                                        </form>
                                    </td>
                                </tr>
                            <?php endwhile; ?>
                        <?php else: ?>
                            <tr><td colspan="5" style="text-align: center; color: #94a3b8; padding: 30px 0;">No routing maps initialized in table storage.</td></tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>

            <div class="data-table-frame" style="border-top: 4px solid #8b5cf6;">
                <h3 style="margin: 0 0 20px 0; color: #0f172a; font-size: 16px; border-bottom: 1px solid #e2e8f0; padding-bottom: 10px;"><i class="fa-solid fa-ban" style="color:#8b5cf6;"></i> Booking Rejections Log</h3>
                <table class="transit-table">
                    <thead>
                        <tr>
                            <th>Rejection ID</th>
                            <th>Driver Name</th>
                            <th>Customer</th>
                            <th>Booking Ref</th>
                            <th>Rejected At</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if($rejections_result && $rejections_result->num_rows > 0): ?>
                            <?php while($rej_row = $rejections_result->fetch_assoc()): ?>
                                <tr style="background:#fef3c7;">
                                    <td><code>#RJ-<?php echo $rej_row['id']; ?></code></td>
                                    <td><strong><?php echo htmlspecialchars($rej_row['driver_name'] ?? 'Unknown'); ?></strong></td>
                                    <td><small><?php echo htmlspecialchars(($rej_row['first_name'] ?? '') . " " . ($rej_row['last_name'] ?? '')); ?></small></td>
                                    <td><strong><?php echo htmlspecialchars($rej_row['booking_id']); ?></strong></td>
                                    <td><small style="color:#475569;"><?php echo date("d-M-Y H:i", strtotime($rej_row['rejected_at'])); ?></small></td>
                                    <td>
                                        <form action="admin.php" method="POST" style="display:inline;" onsubmit="return confirm('Clear this rejection record?');">
                                            <input type="hidden" name="action" value="delete_rejection">
                                            <input type="hidden" name="rejection_id" value="<?php echo $rej_row['id']; ?>">
                                            <button type="submit" class="action-btn-sm" style="background:#ef4444;"><i class="fa-solid fa-trash"></i> Clear</button>
                                        </form>
                                    </td>
                                </tr>
                            <?php endwhile; ?>
                        <?php else: ?>
                            <tr><td colspan="6" style="text-align: center; color: #94a3b8; padding: 30px 0;">No rejection records found.</td></tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>

            <div class="data-table-frame">
                <h3 style="margin: 0 0 20px 0; color: #0f172a; font-size: 16px; border-bottom: 1px solid #e2e8f0; padding-bottom: 10px;"><i class="fa-solid fa-receipt" style="color:#0284c7;"></i> All Bookings Management</h3>
                <table class="transit-table" style="font-size: 12px;">
                    <thead>
                        <tr>
                            <th>Booking ID</th>
                            <th>Reference</th>
                            <th>Customer</th>
                            <th>Mobile</th>
                            <th>Route</th>
                            <th>Schedule</th>
                            <th>Fare</th>
                            <th>Status</th>
                            <th>Driver</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if($all_bookings_result && $all_bookings_result->num_rows > 0): ?>
                            <?php while($all_row = $all_bookings_result->fetch_assoc()): ?>
                                <tr>
                                    <td><code>#BK-<?php echo $all_row['id']; ?></code></td>
                                    <td><?php echo htmlspecialchars($all_row['booking_ref_no'] ?? 'N/A'); ?></td>
                                    <td><strong><?php echo htmlspecialchars($all_row['first_name'] . " " . $all_row['last_name']); ?></strong></td>
                                    <td><small><?php echo htmlspecialchars($all_row['mobile_number']); ?></small></td>
                                    <td><small><?php echo htmlspecialchars(substr($all_row['pickup_location'], 0, 15)); ?> → <?php echo htmlspecialchars(substr($all_row['drop_location'], 0, 15)); ?></small></td>
                                    <td><small><?php echo date("d-M", strtotime($all_row['pickup_date'])); ?><br><?php echo date("H:i", strtotime($all_row['pickup_time'])); ?></small></td>
                                    <td><strong>₹<?php echo $all_row['total_fare']; ?></strong></td>
                                    <td>
                                        <?php 
                                        $flags = [0 => 'Pending', 1 => 'Active', 2 => 'Cancelled', 3 => 'Completed'];
                                        $colors = [0 => '#94a3b8', 1 => '#0284c7', 2 => '#ef4444', 3 => '#15803d'];
                                        $flag = $all_row['booking_flag'] ?? 0;
                                        ?>
                                        <span class="status-badge" style="background:<?php echo $colors[$flag]; ?>20; color:<?php echo $colors[$flag]; ?>;"><?php echo $flags[$flag]; ?></span>
                                    </td>
                                    <td><small><?php echo htmlspecialchars($all_row['assigned_driver_id'] ? "Assigned" : "Unassigned"); ?></small></td>
                                    <td style="white-space: nowrap;">
                                        <button onclick="editBooking(<?php echo $all_row['id']; ?>)" class="action-btn-sm" style="background:#3b82f6; font-size:11px;"><i class="fa-solid fa-pen"></i> Edit</button>
                                        <form action="admin.php" method="POST" style="display:inline;" onsubmit="return confirm('Delete this booking?');">
                                            <input type="hidden" name="action" value="delete_booking">
                                            <input type="hidden" name="booking_id" value="<?php echo $all_row['id']; ?>">
                                            <button type="submit" class="action-btn-sm" style="background:#ef4444; font-size:11px;"><i class="fa-solid fa-trash"></i> Delete</button>
                                        </form>
                                    </td>
                                </tr>
                            <?php endwhile; ?>
                        <?php else: ?>
                            <tr><td colspan="10" style="text-align: center; color: #94a3b8; padding: 30px 0;">No bookings found in system.</td></tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
