<?php
// This file handles all POST actions for the admin panel.
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action'])) {
    // register_fleet and register_route handled by original admin.php
    if ($_POST['action'] === 'register_fleet') {
        $vehicle_number    = trim($_POST['vehicle_number']);
        $model_name        = trim($_POST['model_name']);
        $car_type          = trim($_POST['car_type']);
        $driver_name       = trim($_POST['driver_name']);
        $mobile_number     = trim($_POST['mobile_number']);
        $driver_license_no = trim($_POST['driver_license_no']);
        $aadhaar_no        = preg_replace('/\s+/', '', trim($_POST['aadhaar_no']));
        $base_station      = trim($_POST['base_station']);
        $star_rating       = 5.0;

        $stmt = $conn->prepare("INSERT INTO fleet (vehicle_number, model_name, car_type, driver_name, star_rating, mobile_number, driver_license_no, aadhaar_no, base_station) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)");
        if ($stmt) {
            $stmt->bind_param("sssssdsss", $vehicle_number, $model_name, $car_type, $driver_name, $star_rating, $mobile_number, $driver_license_no, $aadhaar_no, $base_station);
            if ($stmt->execute()) {
                $msg = "Operational transit asset successfully provisioned into logistics registry.";
            } else {
                $msg = "Execution fault encountered during asset allocation: " . $stmt->error;
            }
            $stmt->close();
        }
    }

    if ($_POST['action'] === 'register_route') {
        $pickup_point       = trim($_POST['pickup_point']);
        $drop_point         = trim($_POST['drop_point']);
        $estimated_distance = floatval($_POST['estimated_distance']);

        $r_stmt = $conn->prepare("INSERT INTO routes (pickup_point, drop_point, estimated_distance) VALUES (?, ?, ?)");
        if ($r_stmt) {
            $r_stmt->bind_param("ssd", $pickup_point, $drop_point, $estimated_distance);
            if ($r_stmt->execute()) {
                $route_msg = "Transit itinerary path configuration successfully deployed to database.";
            } else {
                $route_msg = "Execution fault encountered during path matrix setup: " . $r_stmt->error;
            }
            $r_stmt->close();
        }
    }

    if ($_POST['action'] === 'assign_booking_driver') {
        $b_id = intval($_POST['booking_id']);
        $d_id = intval($_POST['driver_id']);
        $b_stmt = $conn->prepare("UPDATE bookings SET assigned_driver_id = ?, booking_flag = 1 WHERE id = ?");
        if ($b_stmt) {
            $b_stmt->bind_param("ii", $d_id, $b_id);
            if ($b_stmt->execute()) {
                $booking_msg = "Driver successfully assigned and dispatched to user ride context.";
            } else {
                $booking_msg = "Assignment update fault: " . $b_stmt->error;
            }
            $b_stmt->close();
        }
    }

    if ($_POST['action'] === 'admin_cancel_booking') {
        $b_id = intval($_POST['booking_id']);
        $c_stmt = $conn->prepare("UPDATE bookings SET booking_flag = 2 WHERE id = ?");
        if ($c_stmt) {
            $c_stmt->bind_param("i", $b_id);
            if ($c_stmt->execute()) {
                $booking_msg = "Booking status successfully set to Cancelled by admin override.";
            } else {
                $booking_msg = "Cancellation process fault: " . $c_stmt->error;
            }
            $c_stmt->close();
        }
    }

    // Update driver
    if ($_POST['action'] === 'update_driver') {
        $driver_id       = intval($_POST['driver_id']);
        $driver_name     = trim($_POST['driver_name']);
        $mobile_number   = trim($_POST['mobile_number']);
        $car_type        = trim($_POST['car_type']);
        $base_station    = trim($_POST['base_station']);
        $vehicle_number  = trim($_POST['vehicle_number']);
        $model_name      = trim($_POST['model_name']);
        $status          = trim($_POST['status']);

        $upd_stmt = $conn->prepare("UPDATE fleet SET driver_name = ?, mobile_number = ?, car_type = ?, base_station = ?, vehicle_number = ?, model_name = ?, status = ? WHERE id = ?");
        if ($upd_stmt) {
            $upd_stmt->bind_param("sssssssi", $driver_name, $mobile_number, $car_type, $base_station, $vehicle_number, $model_name, $status, $driver_id);
            if ($upd_stmt->execute()) {
                $success_msg = "Driver information updated successfully.";
            } else {
                $error_msg = "Update failed: " . $upd_stmt->error;
            }
            $upd_stmt->close();
        }
    }

    // Delete driver
    if ($_POST['action'] === 'delete_driver') {
        $driver_id = intval($_POST['driver_id']);
        $del_stmt = $conn->prepare("DELETE FROM fleet WHERE id = ?");
        if ($del_stmt) {
            $del_stmt->bind_param("i", $driver_id);
            if ($del_stmt->execute()) {
                $success_msg = "Driver record removed from system.";
            } else {
                $error_msg = "Deletion failed: " . $del_stmt->error;
            }
            $del_stmt->close();
        }
    }

    // Update route
    if ($_POST['action'] === 'update_route') {
        $route_id            = intval($_POST['route_id']);
        $pickup_point        = trim($_POST['pickup_point']);
        $drop_point          = trim($_POST['drop_point']);
        $estimated_distance  = floatval($_POST['estimated_distance']);

        $upd_route = $conn->prepare("UPDATE routes SET pickup_point = ?, drop_point = ?, estimated_distance = ? WHERE id = ?");
        if ($upd_route) {
            $upd_route->bind_param("ssdi", $pickup_point, $drop_point, $estimated_distance, $route_id);
            if ($upd_route->execute()) {
                $success_msg = "Route information updated successfully.";
            } else {
                $error_msg = "Route update failed: " . $upd_route->error;
            }
            $upd_route->close();
        }
    }

    // Delete route
    if ($_POST['action'] === 'delete_route') {
        $route_id = intval($_POST['route_id']);
        $del_route = $conn->prepare("DELETE FROM routes WHERE id = ?");
        if ($del_route) {
            $del_route->bind_param("i", $route_id);
            if ($del_route->execute()) {
                $success_msg = "Route removed from system.";
            } else {
                $error_msg = "Route deletion failed: " . $del_route->error;
            }
            $del_route->close();
        }
    }

    // Update booking
    if ($_POST['action'] === 'update_booking') {
        $booking_id      = intval($_POST['booking_id']);
        $first_name      = trim($_POST['first_name']);
        $last_name       = trim($_POST['last_name']);
        $mobile_number   = trim($_POST['mobile_number']);
        $pickup_location = trim($_POST['pickup_location']);
        $drop_location   = trim($_POST['drop_location']);
        $car_type        = trim($_POST['car_type']);
        $total_fare      = floatval($_POST['total_fare']);
        $booking_flag    = intval($_POST['booking_flag']);

        $upd_book = $conn->prepare("UPDATE bookings SET first_name = ?, last_name = ?, mobile_number = ?, pickup_location = ?, drop_location = ?, car_type = ?, total_fare = ?, booking_flag = ? WHERE id = ?");
        if ($upd_book) {
            $upd_book->bind_param("ssssssdii", $first_name, $last_name, $mobile_number, $pickup_location, $drop_location, $car_type, $total_fare, $booking_flag, $booking_id);
            if ($upd_book->execute()) {
                $success_msg = "Booking information updated successfully.";
            } else {
                $error_msg = "Booking update failed: " . $upd_book->error;
            }
            $upd_book->close();
        }
    }

    // Delete booking
    if ($_POST['action'] === 'delete_booking') {
        $booking_id = intval($_POST['booking_id']);
        $del_book = $conn->prepare("DELETE FROM bookings WHERE id = ?");
        if ($del_book) {
            $del_book->bind_param("i", $booking_id);
            if ($del_book->execute()) {
                $success_msg = "Booking record deleted from system.";
            } else {
                $error_msg = "Booking deletion failed: " . $del_book->error;
            }
            $del_book->close();
        }
    }

    // Delete booking rejection
    if ($_POST['action'] === 'delete_rejection') {
        $rejection_id = intval($_POST['rejection_id']);
        $del_rej = $conn->prepare("DELETE FROM booking_rejections WHERE id = ?");
        if ($del_rej) {
            $del_rej->bind_param("i", $rejection_id);
            if ($del_rej->execute()) {
                $success_msg = "Rejection record cleared from system.";
            } else {
                $error_msg = "Deletion failed: " . $del_rej->error;
            }
            $del_rej->close();
        }
    }

    // Verify driver
    if ($_POST['action'] === 'verify_driver') {
        $driver_id = intval($_POST['driver_id']);
        $ver_stmt = $conn->prepare("UPDATE fleet SET is_verified = 1 WHERE id = ?");
        if ($ver_stmt) {
            $ver_stmt->bind_param("i", $driver_id);
            if ($ver_stmt->execute()) {
                $success_msg = "Driver verification status updated.";
            } else {
                $error_msg = "Verification failed: " . $ver_stmt->error;
            }
            $ver_stmt->close();
        }
    }
}
?>
