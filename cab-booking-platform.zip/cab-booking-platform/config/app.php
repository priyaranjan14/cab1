<?php

return [
    'name' => env('APP_NAME', 'MetroCab'),
    'env' => env('APP_ENV', 'production'),
    'url' => rtrim(env('APP_URL', 'http://localhost:8000'), '/'),
    'key' => env('APP_KEY', 'change-me'),
    'timezone' => 'Asia/Kolkata',
];
