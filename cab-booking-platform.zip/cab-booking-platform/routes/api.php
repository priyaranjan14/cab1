<?php

use App\Controllers\ApiController;
use App\Controllers\BookingController;

$router->get('/api/v1/vehicle-types', [ApiController::class, 'vehicleTypes']);
$router->post('/api/v1/fares/estimate', [ApiController::class, 'estimate']);
$router->post('/api/v1/driver/location', [ApiController::class, 'driverLocation']);
$router->post('/api/v1/support/tickets', [ApiController::class, 'supportTicket']);
$router->post('/ajax/fare-estimate', [BookingController::class, 'estimate']);
