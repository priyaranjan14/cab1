<?php

use App\Controllers\AdminController;
use App\Controllers\AuthController;
use App\Controllers\BookingController;
use App\Controllers\DashboardController;
use App\Controllers\HomeController;

$router->get('/', [HomeController::class, 'index']);
$router->get('/page/{slug}', [HomeController::class, 'page']);

$router->get('/login', [AuthController::class, 'loginForm']);
$router->get('/register', [AuthController::class, 'registerForm']);
$router->post('/login', [AuthController::class, 'login']);
$router->post('/register', [AuthController::class, 'register']);
$router->post('/auth/otp/send', [AuthController::class, 'sendOtp']);
$router->get('/auth/google/redirect', [AuthController::class, 'googleRedirect']);
$router->get('/auth/google/callback', [AuthController::class, 'googleCallback']);
$router->get('/logout', [AuthController::class, 'logout']);

$router->get('/book', [BookingController::class, 'search']);
$router->post('/bookings', [BookingController::class, 'store']);
$router->get('/dashboard', [DashboardController::class, 'index']);
$router->get('/admin/reports', [AdminController::class, 'reports']);
$router->post('/admin/action', [AdminController::class, 'action']);
