<?php

namespace App\Core;

abstract class Controller
{
    protected function view(string $template, array $data = [], string $layout = 'app'): void
    {
        extract($data, EXTR_SKIP);
        $viewPath = dirname(__DIR__) . "/Views/{$template}.php";
        if (!is_file($viewPath)) {
            abort(500, "View {$template} not found");
        }
        ob_start();
        require $viewPath;
        $content = ob_get_clean();
        require dirname(__DIR__) . "/Views/layouts/{$layout}.php";
    }
}
