<?php

namespace App\Core;

final class Router
{
    private array $routes = [];

    public function get(string $path, array|callable $handler): void
    {
        $this->add('GET', $path, $handler);
    }

    public function post(string $path, array|callable $handler): void
    {
        $this->add('POST', $path, $handler);
    }

    public function put(string $path, array|callable $handler): void
    {
        $this->add('PUT', $path, $handler);
    }

    private function add(string $method, string $path, array|callable $handler): void
    {
        $pattern = preg_replace('#\{([a-zA-Z_][a-zA-Z0-9_]*)\}#', '(?P<$1>[^/]+)', $path);
        $this->routes[$method][] = ['path' => $path, 'pattern' => '#^' . $pattern . '$#', 'handler' => $handler];
    }

    public function dispatch(Request $request): void
    {
        foreach ($this->routes[$request->method()] ?? [] as $route) {
            if (preg_match($route['pattern'], $request->path(), $matches)) {
                $params = array_filter($matches, 'is_string', ARRAY_FILTER_USE_KEY);
                $this->invoke($route['handler'], $request, $params);
                return;
            }
        }

        abort(404, 'Page not found');
    }

    private function invoke(array|callable $handler, Request $request, array $params): void
    {
        if (is_array($handler)) {
            [$class, $method] = $handler;
            $controller = new $class();
            $controller->{$method}($request, ...array_values($params));
            return;
        }

        $handler($request, ...array_values($params));
    }
}
