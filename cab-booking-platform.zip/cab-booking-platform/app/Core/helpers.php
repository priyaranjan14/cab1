<?php

function env(string $key, mixed $default = null): mixed
{
    static $vars = null;
    if ($vars === null) {
        $vars = [];
        $file = dirname(__DIR__, 2) . '/.env';
        if (is_file($file)) {
            foreach (file($file, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES) as $line) {
                if (str_starts_with(trim($line), '#') || !str_contains($line, '=')) {
                    continue;
                }
                [$name, $value] = explode('=', $line, 2);
                $vars[trim($name)] = trim($value, " \t\n\r\0\x0B\"'");
            }
        }
    }

    return $vars[$key] ?? getenv($key) ?: $default;
}

function config(string $key, mixed $default = null): mixed
{
    [$file, $item] = array_pad(explode('.', $key, 2), 2, null);
    static $loaded = [];
    if (!isset($loaded[$file])) {
        $path = dirname(__DIR__, 2) . "/config/{$file}.php";
        $loaded[$file] = is_file($path) ? require $path : [];
    }

    return $item ? ($loaded[$file][$item] ?? $default) : $loaded[$file];
}

function e(?string $value): string
{
    return htmlspecialchars((string) $value, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8');
}

function url(string $path = ''): string
{
    return config('app.url') . '/' . ltrim($path, '/');
}

function asset(string $path): string
{
    return url('assets/' . ltrim($path, '/'));
}

function csrf_token(): string
{
    if (empty($_SESSION['_csrf'])) {
        $_SESSION['_csrf'] = bin2hex(random_bytes(32));
    }

    return $_SESSION['_csrf'];
}

function csrf_field(): string
{
    return '<input type="hidden" name="_csrf" value="' . e(csrf_token()) . '">';
}

function abort(int $status, string $message = 'Request failed'): never
{
    http_response_code($status);
    echo $message;
    exit;
}
