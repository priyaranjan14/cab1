<?php

namespace App\Models;

final class Booking extends BaseModel
{
    public function estimate(array $data): array
    {
        $stmt = $this->db->prepare('SELECT * FROM vehicle_types WHERE id = ? AND is_active = 1');
        $stmt->execute([(int) $data['vehicle_type_id']]);
        $vehicle = $stmt->fetch() ?: ['base_fare' => 99, 'per_km_rate' => 16, 'per_minute_rate' => 2, 'waiting_charge_per_minute' => 2];
        $distance = max(1, (float) $data['distance_km']);
        $minutes = max(5, (int) $data['duration_minutes']);
        $subtotal = (float) $vehicle['base_fare'] + $distance * (float) $vehicle['per_km_rate'] + $minutes * (float) $vehicle['per_minute_rate'];
        $tax = round($subtotal * 0.05, 2);
        $total = round($subtotal + $tax, 2);

        return [
            'base_fare' => (float) $vehicle['base_fare'],
            'distance_km' => $distance,
            'duration_minutes' => $minutes,
            'subtotal' => round($subtotal, 2),
            'tax' => $tax,
            'total' => $total,
        ];
    }

    public function create(array $data): int
    {
        $estimate = $this->estimate($data);
        $stmt = $this->db->prepare('INSERT INTO bookings (booking_code, customer_id, service_type, pickup_address, pickup_lat, pickup_lng, drop_address, drop_lat, drop_lng, scheduled_at, vehicle_type_id, distance_km, duration_minutes, fare_subtotal, tax_amount, discount_amount, total_amount, payment_method, status) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)');
        $stmt->execute([
            'MC' . date('ymd') . random_int(10000, 99999),
            $data['customer_id'],
            $data['service_type'],
            $data['pickup_address'],
            $data['pickup_lat'] ?? null,
            $data['pickup_lng'] ?? null,
            $data['drop_address'],
            $data['drop_lat'] ?? null,
            $data['drop_lng'] ?? null,
            $data['scheduled_at'],
            $data['vehicle_type_id'],
            $estimate['distance_km'],
            $estimate['duration_minutes'],
            $estimate['subtotal'],
            $estimate['tax'],
            $data['discount_amount'] ?? 0,
            $estimate['total'] - (float) ($data['discount_amount'] ?? 0),
            $data['payment_method'],
            'pending',
        ]);
        return (int) $this->db->lastInsertId();
    }

    public function forUser(int $userId, string $role): array
    {
        $sql = match ($role) {
            'driver' => 'SELECT * FROM v_booking_summary WHERE driver_id = ? ORDER BY id DESC',
            'admin' => 'SELECT * FROM v_booking_summary ORDER BY id DESC LIMIT 200',
            default => 'SELECT * FROM v_booking_summary WHERE customer_id = ? ORDER BY id DESC',
        };
        $stmt = $this->db->prepare($sql);
        $stmt->execute($role === 'admin' ? [] : [$userId]);
        return $stmt->fetchAll();
    }
}
