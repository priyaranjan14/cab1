<?php

namespace App\Models;

final class User extends BaseModel
{
    public function findByEmailOrPhone(string $identity): ?array
    {
        $stmt = $this->db->prepare('SELECT * FROM users WHERE email = ? OR phone = ? LIMIT 1');
        $stmt->execute([$identity, $identity]);
        return $stmt->fetch() ?: null;
    }

    public function find(int $id): ?array
    {
        $stmt = $this->db->prepare('SELECT * FROM users WHERE id = ? LIMIT 1');
        $stmt->execute([$id]);
        return $stmt->fetch() ?: null;
    }

    public function create(array $data): int
    {
        $stmt = $this->db->prepare('INSERT INTO users (name, email, phone, password_hash, role, status, email_verified_at) VALUES (?, ?, ?, ?, ?, ?, ?)');
        $stmt->execute([
            $data['name'],
            $data['email'],
            $data['phone'],
            password_hash($data['password'], PASSWORD_DEFAULT),
            $data['role'] ?? 'customer',
            $data['status'] ?? 'active',
            $data['email_verified_at'] ?? null,
        ]);
        return (int) $this->db->lastInsertId();
    }

    public function storeOtp(int $userId, string $purpose): string
    {
        $otp = (string) random_int(100000, 999999);
        $hash = password_hash($otp, PASSWORD_DEFAULT);
        $stmt = $this->db->prepare('INSERT INTO otp_tokens (user_id, purpose, token_hash, expires_at) VALUES (?, ?, ?, DATE_ADD(NOW(), INTERVAL 10 MINUTE))');
        $stmt->execute([$userId, $purpose, $hash]);
        return $otp;
    }

    public function verifyOtp(int $userId, string $purpose, string $otp): bool
    {
        $stmt = $this->db->prepare('SELECT * FROM otp_tokens WHERE user_id = ? AND purpose = ? AND consumed_at IS NULL AND expires_at > NOW() ORDER BY id DESC LIMIT 1');
        $stmt->execute([$userId, $purpose]);
        $row = $stmt->fetch();
        if (!$row || !password_verify($otp, $row['token_hash'])) {
            return false;
        }
        $this->db->prepare('UPDATE otp_tokens SET consumed_at = NOW() WHERE id = ?')->execute([$row['id']]);
        return true;
    }
}
