<?php

namespace App\Models;

final class Lookup extends BaseModel
{
    public function vehicleTypes(): array
    {
        return $this->db->query('SELECT * FROM vehicle_types WHERE is_active = 1 ORDER BY seats, name')->fetchAll();
    }

    public function cmsPage(string $slug): ?array
    {
        $stmt = $this->db->prepare('SELECT * FROM cms_pages WHERE slug = ? AND status = "published" LIMIT 1');
        $stmt->execute([$slug]);
        return $stmt->fetch() ?: null;
    }

    public function dashboardStats(): array
    {
        return [
            'bookings' => (int) $this->db->query('SELECT COUNT(*) FROM bookings')->fetchColumn(),
            'drivers' => (int) $this->db->query('SELECT COUNT(*) FROM driver_profiles')->fetchColumn(),
            'vehicles' => (int) $this->db->query('SELECT COUNT(*) FROM vehicles')->fetchColumn(),
            'revenue' => (float) $this->db->query('SELECT COALESCE(SUM(total_amount),0) FROM bookings WHERE status IN ("completed","in_progress")')->fetchColumn(),
        ];
    }
}
