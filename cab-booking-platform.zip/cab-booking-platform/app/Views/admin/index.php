<section class="panel-page">
    <div class="container">
        <div class="panel-heading">
            <div>
                <p class="eyebrow">Admin panel</p>
                <h1 class="h3">Operations command center</h1>
            </div>
            <a href="<?= e(url('/admin/reports')) ?>" class="btn btn-dark">Reports</a>
        </div>
        <?php require __DIR__ . '/../partials/stat_grid.php'; ?>
        <div class="row g-3 mb-4">
            <?php foreach (['Driver verification', 'Coupons', 'Payments', 'Support tickets', 'CMS pages', 'Notifications'] as $module): ?>
                <div class="col-md-4"><button class="module-tile admin-action" data-action="<?= e($module) ?>"><?= e($module) ?></button></div>
            <?php endforeach; ?>
        </div>
        <?php require __DIR__ . '/../partials/bookings_table.php'; ?>
    </div>
</section>
