<section class="panel-page">
    <div class="container">
        <div class="panel-heading"><h1 class="h3">Reports & Analytics</h1></div>
        <?php require __DIR__ . '/../partials/stat_grid.php'; ?>
        <div class="booking-card">
            <h2 class="h5">Available exports</h2>
            <div class="d-flex flex-wrap gap-2">
                <button class="btn btn-outline-dark">Bookings CSV</button>
                <button class="btn btn-outline-dark">Driver payouts</button>
                <button class="btn btn-outline-dark">Revenue report</button>
                <button class="btn btn-outline-dark">Coupon usage</button>
            </div>
        </div>
    </div>
</section>
