<div id="fare-estimate-fields" class="row g-3">
    <div class="col-md-6">
        <label class="form-label">Pickup</label>
        <input class="form-control" name="pickup_address" value="Connaught Place, Delhi" required>
    </div>
    <div class="col-md-6">
        <label class="form-label">Drop</label>
        <input class="form-control" name="drop_address" value="IGI Airport, Delhi" required>
    </div>
    <div class="col-md-4">
        <label class="form-label">Service</label>
        <select class="form-select" name="service_type">
            <option value="local">Local</option>
            <option value="one_way">One-way</option>
            <option value="round_trip">Round trip</option>
            <option value="airport">Airport</option>
            <option value="outstation">Outstation</option>
        </select>
    </div>
    <div class="col-md-4">
        <label class="form-label">Vehicle</label>
        <select class="form-select" name="vehicle_type_id">
            <?php foreach ($vehicleTypes as $type): ?>
                <option value="<?= (int) $type['id'] ?>"><?= e($type['name']) ?> - <?= (int) $type['seats'] ?> seats</option>
            <?php endforeach; ?>
        </select>
    </div>
    <div class="col-md-2">
        <label class="form-label">KM</label>
        <input class="form-control" name="distance_km" type="number" min="1" step="0.1" value="18">
    </div>
    <div class="col-md-2">
        <label class="form-label">Mins</label>
        <input class="form-control" name="duration_minutes" type="number" min="5" value="45">
    </div>
    <div class="col-12 d-grid">
        <button class="btn btn-dark estimate-trigger" type="button">Estimate fare</button>
    </div>
    <div class="col-12">
        <div id="fare-result" class="fare-result d-none"></div>
    </div>
</div>
