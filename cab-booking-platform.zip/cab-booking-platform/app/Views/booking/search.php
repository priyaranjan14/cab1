<section class="py-5">
    <div class="container">
        <div class="row g-4">
            <div class="col-lg-7">
                <h1 class="h2">Book your cab</h1>
                <p class="text-muted">Choose trip type, estimate fare, then confirm booking.</p>
                <div class="booking-card">
                    <form id="booking-form" class="row g-3">
                        <?= csrf_field() ?>
                        <?php require __DIR__ . '/_estimate_form.php'; ?>
                        <div class="row g-3 mt-1">
                            <div class="col-md-6">
                                <label class="form-label">Schedule</label>
                                <input class="form-control" name="scheduled_at" type="datetime-local" required>
                            </div>
                            <div class="col-md-6">
                                <label class="form-label">Payment</label>
                                <select class="form-select" name="payment_method">
                                    <option value="cash">Cash</option>
                                    <option value="upi">UPI</option>
                                    <option value="razorpay">Razorpay</option>
                                    <option value="payu">PayU</option>
                                    <option value="stripe">Stripe</option>
                                    <option value="wallet">Wallet</option>
                                </select>
                            </div>
                            <div class="col-12 d-grid"><button class="btn btn-primary btn-lg" type="submit">Confirm booking</button></div>
                        </div>
                    </form>
                </div>
            </div>
            <div class="col-lg-5">
                <div class="map-placeholder">Live map and driver tracking surface</div>
            </div>
        </div>
    </div>
</section>
