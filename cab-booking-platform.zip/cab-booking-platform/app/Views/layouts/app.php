<!doctype html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="<?= e($description ?? 'Book local, airport, round trip and outstation cabs with verified drivers.') ?>">
    <meta name="csrf-token" content="<?= e(csrf_token()) ?>">
    <title><?= e(($title ?? 'Cab Booking') . ' | ' . config('app.name')) ?></title>
    <link rel="canonical" href="<?= e(url($_SERVER['REQUEST_URI'] ?? '/')) ?>">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="<?= e(asset('css/app.css')) ?>" rel="stylesheet">
</head>
<body>
<nav class="navbar navbar-expand-lg navbar-light bg-white border-bottom sticky-top">
    <div class="container">
        <a class="navbar-brand fw-bold" href="<?= e(url('/')) ?>"><?= e(config('app.name')) ?></a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#nav"><span class="navbar-toggler-icon"></span></button>
        <div class="collapse navbar-collapse" id="nav">
            <ul class="navbar-nav ms-auto align-items-lg-center gap-lg-2">
                <li class="nav-item"><a class="nav-link" href="<?= e(url('/book')) ?>">Book</a></li>
                <li class="nav-item"><a class="nav-link" href="<?= e(url('/page/faq')) ?>">FAQ</a></li>
                <li class="nav-item"><a class="nav-link" href="<?= e(url('/page/blog')) ?>">Blog</a></li>
                <?php if (\App\Core\Auth::check()): ?>
                    <li class="nav-item"><a class="btn btn-dark btn-sm" href="<?= e(url('/dashboard')) ?>">Dashboard</a></li>
                    <li class="nav-item"><a class="nav-link" href="<?= e(url('/logout')) ?>">Logout</a></li>
                <?php else: ?>
                    <li class="nav-item"><a class="nav-link" href="<?= e(url('/login')) ?>">Login</a></li>
                    <li class="nav-item"><a class="btn btn-primary btn-sm" href="<?= e(url('/register')) ?>">Register</a></li>
                <?php endif; ?>
            </ul>
        </div>
    </div>
</nav>
<main><?= $content ?></main>
<footer class="footer py-4 border-top">
    <div class="container d-flex flex-wrap justify-content-between gap-2 small text-muted">
        <span>&copy; <?= date('Y') ?> <?= e(config('app.name')) ?></span>
        <span>Secure cab booking, verified drivers, transparent fares.</span>
    </div>
</footer>
<script src="https://code.jquery.com/jquery-3.7.1.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
<script src="<?= e(asset('js/app.js')) ?>"></script>
</body>
</html>
