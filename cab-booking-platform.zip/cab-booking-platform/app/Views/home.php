<section class="hero">
    <div class="container">
        <div class="row align-items-center g-4">
            <div class="col-lg-6">
                <p class="eyebrow">Local, airport, outstation, round trip</p>
                <h1>Book reliable cabs with upfront fares and verified drivers.</h1>
                <p class="lead text-muted">A complete multi-role cab platform for customers, drivers, vendors, fleet owners, and admins.</p>
                <div class="d-flex flex-wrap gap-2">
                    <a href="<?= e(url('/book')) ?>" class="btn btn-primary btn-lg">Book a cab</a>
                    <a href="<?= e(url('/register')) ?>" class="btn btn-outline-dark btn-lg">Join as driver</a>
                </div>
            </div>
            <div class="col-lg-6">
                <div class="booking-card shadow-sm">
                    <h2 class="h4 mb-3">Fare estimate</h2>
                    <form id="fare-estimate-form">
                        <?php require __DIR__ . '/booking/_estimate_form.php'; ?>
                    </form>
                </div>
            </div>
        </div>
    </div>
</section>
<section class="py-5 bg-light">
    <div class="container">
        <div class="row g-3">
            <?php foreach (['Real-time tracking', 'Wallet & coupons', 'Razorpay PayU Stripe UPI', 'Driver verification'] as $item): ?>
                <div class="col-md-3"><div class="feature-tile"><?= e($item) ?></div></div>
            <?php endforeach; ?>
        </div>
    </div>
</section>
