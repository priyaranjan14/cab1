<article class="py-5">
    <div class="container narrow">
        <p class="eyebrow"><?= e($page['slug']) ?></p>
        <h1><?= e($page['title']) ?></h1>
        <div class="cms-body"><?= $page['body_html'] ?></div>
    </div>
</article>
