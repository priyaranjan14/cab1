<section class="panel-page">
    <div class="container">
        <div class="panel-heading">
            <div>
                <p class="eyebrow">Driver dashboard</p>
                <h1 class="h3">Trips, verification, and tracking</h1>
            </div>
            <button class="btn btn-success" id="share-location">Share live location</button>
        </div>
        <div class="alert alert-info">Upload license, RC, insurance, and bank KYC from the verification workflow before accepting trips.</div>
        <?php require __DIR__ . '/../partials/bookings_table.php'; ?>
    </div>
</section>
