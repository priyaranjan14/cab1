<section class="auth-page">
    <div class="auth-panel">
        <h1 class="h3">Welcome back</h1>
        <p class="text-muted">Login with email/phone and password. OTP and Google hooks are included for provider wiring.</p>
        <form id="login-form" class="vstack gap-3">
            <?= csrf_field() ?>
            <input class="form-control" name="identity" placeholder="Email or phone" required>
            <input class="form-control" name="password" type="password" placeholder="Password" required>
            <button class="btn btn-primary" type="submit">Login</button>
            <button class="btn btn-outline-dark" type="button" id="send-otp">Send OTP</button>
            <a class="btn btn-light border" href="<?= e(url('/auth/google/redirect')) ?>">Continue with Google</a>
        </form>
    </div>
</section>
