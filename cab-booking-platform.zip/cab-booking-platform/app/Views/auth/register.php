<section class="auth-page">
    <div class="auth-panel">
        <h1 class="h3">Create account</h1>
        <form id="register-form" class="vstack gap-3">
            <?= csrf_field() ?>
            <input class="form-control" name="name" placeholder="Full name" required>
            <input class="form-control" name="email" type="email" placeholder="Email" required>
            <input class="form-control" name="phone" placeholder="Phone" required>
            <input class="form-control" name="password" type="password" placeholder="Password" minlength="8" required>
            <select class="form-select" name="role">
                <option value="customer">Customer</option>
                <option value="driver">Driver</option>
                <option value="vendor">Vendor</option>
                <option value="fleet_owner">Fleet owner</option>
            </select>
            <button class="btn btn-primary" type="submit">Register</button>
        </form>
    </div>
</section>
