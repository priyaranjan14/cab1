<div class="row g-3 mb-4">
    <div class="col-6 col-lg-3"><div class="stat"><span>Bookings</span><strong><?= number_format($stats['bookings'] ?? 0) ?></strong></div></div>
    <div class="col-6 col-lg-3"><div class="stat"><span>Drivers</span><strong><?= number_format($stats['drivers'] ?? 0) ?></strong></div></div>
    <div class="col-6 col-lg-3"><div class="stat"><span>Vehicles</span><strong><?= number_format($stats['vehicles'] ?? 0) ?></strong></div></div>
    <div class="col-6 col-lg-3"><div class="stat"><span>Revenue</span><strong>Rs <?= number_format($stats['revenue'] ?? 0, 2) ?></strong></div></div>
</div>
