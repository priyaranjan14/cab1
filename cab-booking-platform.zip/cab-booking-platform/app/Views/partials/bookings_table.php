<div class="booking-card table-responsive">
    <h2 class="h5 mb-3">Bookings</h2>
    <table class="table align-middle">
        <thead><tr><th>Code</th><th>Trip</th><th>Pickup</th><th>Drop</th><th>Total</th><th>Status</th></tr></thead>
        <tbody>
        <?php foreach ($bookings as $booking): ?>
            <tr>
                <td><?= e($booking['booking_code']) ?></td>
                <td><?= e(str_replace('_', ' ', $booking['service_type'])) ?></td>
                <td><?= e($booking['pickup_address']) ?></td>
                <td><?= e($booking['drop_address']) ?></td>
                <td>Rs <?= number_format((float) $booking['total_amount'], 2) ?></td>
                <td><span class="badge text-bg-secondary"><?= e($booking['status']) ?></span></td>
            </tr>
        <?php endforeach; ?>
        <?php if (!$bookings): ?>
            <tr><td colspan="6" class="text-muted">No bookings yet.</td></tr>
        <?php endif; ?>
        </tbody>
    </table>
</div>
