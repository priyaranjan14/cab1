<section class="panel-page">
    <div class="container">
        <div class="panel-heading">
            <div>
                <p class="eyebrow">Customer dashboard</p>
                <h1 class="h3">Hi, <?= e($user['name']) ?></h1>
            </div>
            <a href="<?= e(url('/book')) ?>" class="btn btn-primary">New booking</a>
        </div>
        <?php require __DIR__ . '/../partials/stat_grid.php'; ?>
        <?php require __DIR__ . '/../partials/bookings_table.php'; ?>
    </div>
</section>
