<?php

namespace App\Controllers;

use App\Core\Auth;
use App\Core\Controller;
use App\Core\Request;
use App\Core\Response;
use App\Models\Lookup;

final class AdminController extends Controller
{
    public function reports(Request $request): void
    {
        Auth::requireRole(['admin']);
        $this->view('admin/reports', ['title' => 'Reports & Analytics', 'stats' => (new Lookup())->dashboardStats()]);
    }

    public function action(Request $request): void
    {
        Auth::requireRole(['admin']);
        Response::json(['ok' => true, 'message' => 'Admin action queued for workflow processing.']);
    }
}
