<?php

namespace App\Controllers;

use App\Core\Auth;
use App\Core\Controller;
use App\Core\Request;
use App\Core\Response;
use App\Models\Booking;
use App\Models\Lookup;

final class BookingController extends Controller
{
    public function search(Request $request): void
    {
        $this->view('booking/search', ['title' => 'Book a Cab', 'vehicleTypes' => (new Lookup())->vehicleTypes()]);
    }

    public function estimate(Request $request): void
    {
        $estimate = (new Booking())->estimate($request->all());
        Response::json(['ok' => true, 'estimate' => $estimate]);
    }

    public function store(Request $request): void
    {
        Auth::requireRole(['customer', 'admin']);
        if (!hash_equals($_SESSION['_csrf'] ?? '', (string) $request->input('_csrf'))) {
            Response::json(['ok' => false, 'message' => 'Invalid CSRF token'], 419);
        }
        $data = $request->all();
        $data['customer_id'] = Auth::id();
        $id = (new Booking())->create($data);
        Response::json(['ok' => true, 'booking_id' => $id, 'redirect' => '/dashboard']);
    }
}
