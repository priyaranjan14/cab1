<?php

namespace App\Controllers;

use App\Core\Auth;
use App\Core\Controller;
use App\Core\Request;
use App\Core\Response;
use App\Models\User;

final class AuthController extends Controller
{
    public function loginForm(Request $request): void
    {
        $this->view('auth/login', ['title' => 'Login']);
    }

    public function registerForm(Request $request): void
    {
        $this->view('auth/register', ['title' => 'Create Account']);
    }

    public function login(Request $request): void
    {
        $this->verifyCsrf($request);
        $user = (new User())->findByEmailOrPhone((string) $request->input('identity'));
        if (!$user || !password_verify((string) $request->input('password'), $user['password_hash'])) {
            Response::json(['ok' => false, 'message' => 'Invalid credentials'], 422);
        }
        if ($user['status'] !== 'active') {
            Response::json(['ok' => false, 'message' => 'Account is not active'], 403);
        }
        Auth::login($user);
        Response::json(['ok' => true, 'redirect' => '/dashboard']);
    }

    public function register(Request $request): void
    {
        $this->verifyCsrf($request);
        $role = in_array($request->input('role'), ['customer', 'driver', 'vendor', 'fleet_owner'], true) ? $request->input('role') : 'customer';
        $id = (new User())->create([
            'name' => trim((string) $request->input('name')),
            'email' => filter_var($request->input('email'), FILTER_VALIDATE_EMAIL),
            'phone' => preg_replace('/[^0-9+]/', '', (string) $request->input('phone')),
            'password' => (string) $request->input('password'),
            'role' => $role,
            'status' => $role === 'customer' ? 'active' : 'pending_verification',
        ]);
        $user = (new User())->find($id);
        Auth::login($user);
        Response::json(['ok' => true, 'redirect' => '/dashboard']);
    }

    public function sendOtp(Request $request): void
    {
        $user = (new User())->findByEmailOrPhone((string) $request->input('identity'));
        if (!$user) {
            Response::json(['ok' => false, 'message' => 'User not found'], 404);
        }
        $otp = (new User())->storeOtp((int) $user['id'], 'login');
        Response::json(['ok' => true, 'message' => 'OTP generated. Wire SMS provider in production.', 'dev_otp' => $otp]);
    }

    public function logout(Request $request): void
    {
        Auth::logout();
        Response::redirect('/');
    }

    public function googleRedirect(Request $request): void
    {
        $clientId = env('GOOGLE_CLIENT_ID', '');
        if (!$clientId) {
            abort(501, 'Google OAuth is not configured. Set GOOGLE_CLIENT_ID and GOOGLE_CLIENT_SECRET.');
        }
        $state = bin2hex(random_bytes(16));
        $_SESSION['oauth_state'] = $state;
        $params = http_build_query([
            'client_id' => $clientId,
            'redirect_uri' => url('/auth/google/callback'),
            'response_type' => 'code',
            'scope' => 'openid email profile',
            'state' => $state,
            'access_type' => 'offline',
            'prompt' => 'select_account',
        ]);
        header('Location: https://accounts.google.com/o/oauth2/v2/auth?' . $params);
        exit;
    }

    public function googleCallback(Request $request): void
    {
        if (!hash_equals($_SESSION['oauth_state'] ?? '', (string) $request->input('state'))) {
            abort(419, 'Invalid OAuth state');
        }
        abort(501, 'Exchange the authorization code server-side, verify the ID token, then link social_accounts.');
    }

    private function verifyCsrf(Request $request): void
    {
        if (!hash_equals($_SESSION['_csrf'] ?? '', (string) $request->input('_csrf'))) {
            Response::json(['ok' => false, 'message' => 'Invalid CSRF token'], 419);
        }
    }
}
