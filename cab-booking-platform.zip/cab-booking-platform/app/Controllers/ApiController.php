<?php

namespace App\Controllers;

use App\Core\Auth;
use App\Core\Database;
use App\Core\Request;
use App\Core\Response;
use App\Models\Booking;
use App\Models\Lookup;

final class ApiController
{
    public function vehicleTypes(Request $request): void
    {
        Response::json(['ok' => true, 'data' => (new Lookup())->vehicleTypes()]);
    }

    public function driverLocation(Request $request): void
    {
        Auth::requireRole(['driver', 'admin']);
        $db = Database::connection();
        $stmt = $db->prepare('INSERT INTO driver_locations (driver_id, lat, lng, heading, speed, recorded_at) VALUES (?, ?, ?, ?, ?, NOW())');
        $stmt->execute([Auth::id(), $request->input('lat'), $request->input('lng'), $request->input('heading', 0), $request->input('speed', 0)]);
        Response::json(['ok' => true]);
    }

    public function estimate(Request $request): void
    {
        Response::json(['ok' => true, 'estimate' => (new Booking())->estimate($request->all())]);
    }

    public function supportTicket(Request $request): void
    {
        Auth::requireRole(['customer', 'driver', 'vendor', 'fleet_owner', 'admin']);
        $db = Database::connection();
        $stmt = $db->prepare('INSERT INTO support_tickets (user_id, subject, category, priority, status) VALUES (?, ?, ?, ?, "open")');
        $stmt->execute([Auth::id(), $request->input('subject'), $request->input('category', 'general'), $request->input('priority', 'normal')]);
        Response::json(['ok' => true, 'ticket_id' => (int) $db->lastInsertId()]);
    }
}
