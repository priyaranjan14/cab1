<?php

namespace App\Controllers;

use App\Core\Controller;
use App\Core\Request;
use App\Models\Lookup;

final class HomeController extends Controller
{
    public function index(Request $request): void
    {
        $this->view('home', ['vehicleTypes' => (new Lookup())->vehicleTypes()]);
    }

    public function page(Request $request, string $slug): void
    {
        $page = (new Lookup())->cmsPage($slug);
        if (!$page) {
            abort(404, 'Page not found');
        }
        $this->view('cms/page', ['page' => $page, 'title' => $page['meta_title'] ?: $page['title']]);
    }
}
