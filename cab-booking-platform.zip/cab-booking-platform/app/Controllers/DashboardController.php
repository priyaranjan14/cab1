<?php

namespace App\Controllers;

use App\Core\Auth;
use App\Core\Controller;
use App\Core\Request;
use App\Models\Booking;
use App\Models\Lookup;

final class DashboardController extends Controller
{
    public function index(Request $request): void
    {
        Auth::requireRole(['customer', 'driver', 'vendor', 'fleet_owner', 'admin']);
        $user = Auth::user();
        $view = match ($user['role']) {
            'driver' => 'driver/index',
            'vendor', 'fleet_owner' => 'vendor/index',
            'admin' => 'admin/index',
            default => 'dashboard/index',
        };
        $this->view($view, [
            'title' => 'Dashboard',
            'user' => $user,
            'bookings' => (new Booking())->forUser((int) $user['id'], $user['role']),
            'stats' => (new Lookup())->dashboardStats(),
        ]);
    }
}
