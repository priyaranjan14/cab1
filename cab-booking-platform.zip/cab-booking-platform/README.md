# MetroCab Booking Platform

Production-oriented PHP 8 MVC cab booking website covering customer, driver, fleet/vendor, and admin flows.

## Stack

- PHP 8+, PDO, MySQL 8
- HTML5, CSS3, Bootstrap 5, JavaScript, jQuery, AJAX
- MVC with front controller routing
- CSRF protection, password hashing, PDO prepared statements, role middleware

## Quick Start

1. Copy `.env.example` to `.env` and update credentials.
2. Import `database/schema.sql` into MySQL 8.
3. Serve the app from `public/`.

```bash
php -S localhost:8000 -t public
```

Default seeded users use the password `password`. Update their passwords immediately after import.

See `docs/DEPLOYMENT.md` for production deployment.
