(function ($) {
    'use strict';

    const csrf = $('meta[name="csrf-token"]').attr('content');

    function toast(message) {
        const node = $('<div class="alert alert-dark position-fixed bottom-0 start-50 translate-middle-x mb-3 shadow"></div>').text(message);
        $('body').append(node);
        setTimeout(() => node.fadeOut(200, () => node.remove()), 2600);
    }

    function post(url, data) {
        return $.ajax({
            url,
            method: 'POST',
            data,
            headers: {'X-CSRF-TOKEN': csrf, 'X-Requested-With': 'XMLHttpRequest'}
        });
    }

    $(document).on('click', '.estimate-trigger', function () {
        const form = $(this).closest('form');
        const result = form.find('#fare-result');
        post('/ajax/fare-estimate', form.serialize())
            .done(function (res) {
                const f = res.estimate;
                result.removeClass('d-none').html(
                    `<strong>Total: Rs ${f.total.toFixed(2)}</strong><br>` +
                    `Base Rs ${f.base_fare.toFixed(2)} + ${f.distance_km} km + ${f.duration_minutes} mins + tax Rs ${f.tax.toFixed(2)}`
                );
            })
            .fail(function () {
                toast('Could not estimate fare');
            });
    });

    $('#login-form').on('submit', function (event) {
        event.preventDefault();
        post('/login', $(this).serialize())
            .done(res => window.location.href = res.redirect)
            .fail(xhr => toast(xhr.responseJSON?.message || 'Login failed'));
    });

    $('#register-form').on('submit', function (event) {
        event.preventDefault();
        post('/register', $(this).serialize())
            .done(res => window.location.href = res.redirect)
            .fail(xhr => toast(xhr.responseJSON?.message || 'Registration failed'));
    });

    $('#send-otp').on('click', function () {
        post('/auth/otp/send', {identity: $('[name="identity"]').val(), _csrf: csrf})
            .done(res => toast(res.message + (res.dev_otp ? ` OTP: ${res.dev_otp}` : '')))
            .fail(xhr => toast(xhr.responseJSON?.message || 'OTP failed'));
    });

    $('#booking-form').on('submit', function (event) {
        event.preventDefault();
        post('/bookings', $(this).serialize())
            .done(res => window.location.href = res.redirect)
            .fail(xhr => toast(xhr.responseJSON?.message || 'Booking failed. Please login first.'));
    });

    $('#share-location').on('click', function () {
        if (!navigator.geolocation) {
            toast('Geolocation not supported');
            return;
        }
        navigator.geolocation.getCurrentPosition(function (pos) {
            post('/api/v1/driver/location', {
                lat: pos.coords.latitude,
                lng: pos.coords.longitude,
                heading: pos.coords.heading || 0,
                speed: pos.coords.speed || 0,
                _csrf: csrf
            }).done(() => toast('Location shared'));
        });
    });

    $('.admin-action').on('click', function () {
        post('/admin/action', {action: $(this).data('action'), _csrf: csrf})
            .done(res => toast(res.message));
    });
})(jQuery);
