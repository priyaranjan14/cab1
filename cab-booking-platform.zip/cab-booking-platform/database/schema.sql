CREATE DATABASE IF NOT EXISTS cab_booking CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE cab_booking;

SET FOREIGN_KEY_CHECKS = 0;
DROP TABLE IF EXISTS audit_logs, support_ticket_messages, support_tickets, notifications, cms_pages, blog_posts, faqs, payment_transactions, refunds, wallet_transactions, wallets, coupon_redemptions, coupons, booking_status_history, driver_locations, bookings, vehicles, vehicle_types, driver_documents, driver_profiles, vendor_profiles, fleet_owner_profiles, otp_tokens, social_accounts, password_resets, users, roles;
SET FOREIGN_KEY_CHECKS = 1;

CREATE TABLE roles (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(40) NOT NULL UNIQUE,
    label VARCHAR(80) NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

CREATE TABLE users (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(120) NOT NULL,
    email VARCHAR(160) NOT NULL UNIQUE,
    phone VARCHAR(30) NOT NULL UNIQUE,
    password_hash VARCHAR(255) NOT NULL,
    role ENUM('customer','driver','vendor','fleet_owner','admin') NOT NULL DEFAULT 'customer',
    status ENUM('active','inactive','pending_verification','suspended') NOT NULL DEFAULT 'active',
    avatar_path VARCHAR(255) NULL,
    email_verified_at DATETIME NULL,
    phone_verified_at DATETIME NULL,
    last_login_at DATETIME NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX idx_users_role_status (role, status)
) ENGINE=InnoDB;

CREATE TABLE social_accounts (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    user_id BIGINT UNSIGNED NOT NULL,
    provider VARCHAR(40) NOT NULL,
    provider_id VARCHAR(180) NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    UNIQUE KEY uq_social_provider (provider, provider_id),
    CONSTRAINT fk_social_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB;

CREATE TABLE otp_tokens (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    user_id BIGINT UNSIGNED NOT NULL,
    purpose VARCHAR(40) NOT NULL,
    token_hash VARCHAR(255) NOT NULL,
    expires_at DATETIME NOT NULL,
    consumed_at DATETIME NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_otp_lookup (user_id, purpose, expires_at),
    CONSTRAINT fk_otp_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB;

CREATE TABLE password_resets (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    user_id BIGINT UNSIGNED NOT NULL,
    token_hash VARCHAR(255) NOT NULL,
    expires_at DATETIME NOT NULL,
    consumed_at DATETIME NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT fk_reset_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB;

CREATE TABLE vendor_profiles (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    user_id BIGINT UNSIGNED NOT NULL UNIQUE,
    company_name VARCHAR(160) NOT NULL,
    gst_number VARCHAR(30) NULL,
    pan_number VARCHAR(20) NULL,
    address TEXT NULL,
    verification_status ENUM('pending','approved','rejected') DEFAULT 'pending',
    CONSTRAINT fk_vendor_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB;

CREATE TABLE fleet_owner_profiles (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    user_id BIGINT UNSIGNED NOT NULL UNIQUE,
    business_name VARCHAR(160) NOT NULL,
    agreement_status ENUM('pending','signed','blocked') DEFAULT 'pending',
    payout_cycle ENUM('weekly','biweekly','monthly') DEFAULT 'weekly',
    CONSTRAINT fk_fleet_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB;

CREATE TABLE driver_profiles (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    user_id BIGINT UNSIGNED NOT NULL UNIQUE,
    vendor_id BIGINT UNSIGNED NULL,
    fleet_owner_id BIGINT UNSIGNED NULL,
    license_number VARCHAR(60) NOT NULL,
    experience_years TINYINT UNSIGNED DEFAULT 0,
    availability_status ENUM('offline','online','on_trip') DEFAULT 'offline',
    verification_status ENUM('pending','approved','rejected') DEFAULT 'pending',
    rating DECIMAL(3,2) DEFAULT 5.00,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT fk_driver_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    CONSTRAINT fk_driver_vendor FOREIGN KEY (vendor_id) REFERENCES vendor_profiles(id) ON DELETE SET NULL,
    CONSTRAINT fk_driver_fleet FOREIGN KEY (fleet_owner_id) REFERENCES fleet_owner_profiles(id) ON DELETE SET NULL
) ENGINE=InnoDB;

CREATE TABLE driver_documents (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    driver_id BIGINT UNSIGNED NOT NULL,
    doc_type ENUM('license','aadhaar','pan','police_verification','photo') NOT NULL,
    file_path VARCHAR(255) NOT NULL,
    status ENUM('pending','approved','rejected') DEFAULT 'pending',
    reviewed_by BIGINT UNSIGNED NULL,
    reviewed_at DATETIME NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT fk_doc_driver FOREIGN KEY (driver_id) REFERENCES driver_profiles(id) ON DELETE CASCADE,
    CONSTRAINT fk_doc_reviewer FOREIGN KEY (reviewed_by) REFERENCES users(id) ON DELETE SET NULL
) ENGINE=InnoDB;

CREATE TABLE vehicle_types (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(80) NOT NULL,
    slug VARCHAR(90) NOT NULL UNIQUE,
    seats TINYINT UNSIGNED NOT NULL,
    base_fare DECIMAL(10,2) NOT NULL,
    per_km_rate DECIMAL(10,2) NOT NULL,
    per_minute_rate DECIMAL(10,2) NOT NULL,
    waiting_charge_per_minute DECIMAL(10,2) NOT NULL DEFAULT 0,
    is_active TINYINT(1) DEFAULT 1
) ENGINE=InnoDB;

CREATE TABLE vehicles (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    owner_user_id BIGINT UNSIGNED NOT NULL,
    driver_id BIGINT UNSIGNED NULL,
    vehicle_type_id BIGINT UNSIGNED NOT NULL,
    registration_number VARCHAR(30) NOT NULL UNIQUE,
    make VARCHAR(80) NOT NULL,
    model VARCHAR(80) NOT NULL,
    color VARCHAR(40) NULL,
    fuel_type ENUM('petrol','diesel','cng','ev','hybrid') DEFAULT 'petrol',
    permit_number VARCHAR(80) NULL,
    insurance_expires_at DATE NULL,
    fitness_expires_at DATE NULL,
    status ENUM('pending','active','maintenance','blocked') DEFAULT 'pending',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_vehicle_status_type (status, vehicle_type_id),
    CONSTRAINT fk_vehicle_owner FOREIGN KEY (owner_user_id) REFERENCES users(id) ON DELETE CASCADE,
    CONSTRAINT fk_vehicle_driver FOREIGN KEY (driver_id) REFERENCES driver_profiles(id) ON DELETE SET NULL,
    CONSTRAINT fk_vehicle_type FOREIGN KEY (vehicle_type_id) REFERENCES vehicle_types(id)
) ENGINE=InnoDB;

CREATE TABLE bookings (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    booking_code VARCHAR(30) NOT NULL UNIQUE,
    customer_id BIGINT UNSIGNED NOT NULL,
    driver_id BIGINT UNSIGNED NULL,
    vehicle_id BIGINT UNSIGNED NULL,
    service_type ENUM('local','one_way','round_trip','airport','outstation') NOT NULL,
    pickup_address VARCHAR(255) NOT NULL,
    pickup_lat DECIMAL(10,7) NULL,
    pickup_lng DECIMAL(10,7) NULL,
    drop_address VARCHAR(255) NOT NULL,
    drop_lat DECIMAL(10,7) NULL,
    drop_lng DECIMAL(10,7) NULL,
    scheduled_at DATETIME NOT NULL,
    started_at DATETIME NULL,
    completed_at DATETIME NULL,
    vehicle_type_id BIGINT UNSIGNED NOT NULL,
    distance_km DECIMAL(10,2) NOT NULL,
    duration_minutes INT UNSIGNED NOT NULL,
    fare_subtotal DECIMAL(10,2) NOT NULL,
    tax_amount DECIMAL(10,2) NOT NULL DEFAULT 0,
    discount_amount DECIMAL(10,2) NOT NULL DEFAULT 0,
    total_amount DECIMAL(10,2) NOT NULL,
    payment_method ENUM('cash','upi','wallet','razorpay','payu','stripe') NOT NULL DEFAULT 'cash',
    payment_status ENUM('pending','authorized','paid','failed','refunded') DEFAULT 'pending',
    status ENUM('pending','accepted','driver_assigned','arrived','in_progress','completed','cancelled') DEFAULT 'pending',
    cancellation_reason VARCHAR(255) NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX idx_bookings_customer_status (customer_id, status),
    INDEX idx_bookings_driver_status (driver_id, status),
    INDEX idx_bookings_schedule (scheduled_at),
    CONSTRAINT fk_booking_customer FOREIGN KEY (customer_id) REFERENCES users(id),
    CONSTRAINT fk_booking_driver FOREIGN KEY (driver_id) REFERENCES driver_profiles(id) ON DELETE SET NULL,
    CONSTRAINT fk_booking_vehicle FOREIGN KEY (vehicle_id) REFERENCES vehicles(id) ON DELETE SET NULL,
    CONSTRAINT fk_booking_vehicle_type FOREIGN KEY (vehicle_type_id) REFERENCES vehicle_types(id)
) ENGINE=InnoDB;

CREATE TABLE booking_status_history (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    booking_id BIGINT UNSIGNED NOT NULL,
    old_status VARCHAR(40) NULL,
    new_status VARCHAR(40) NOT NULL,
    changed_by BIGINT UNSIGNED NULL,
    note VARCHAR(255) NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT fk_history_booking FOREIGN KEY (booking_id) REFERENCES bookings(id) ON DELETE CASCADE,
    CONSTRAINT fk_history_user FOREIGN KEY (changed_by) REFERENCES users(id) ON DELETE SET NULL
) ENGINE=InnoDB;

CREATE TABLE driver_locations (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    driver_id BIGINT UNSIGNED NOT NULL,
    booking_id BIGINT UNSIGNED NULL,
    lat DECIMAL(10,7) NOT NULL,
    lng DECIMAL(10,7) NOT NULL,
    heading DECIMAL(6,2) DEFAULT 0,
    speed DECIMAL(8,2) DEFAULT 0,
    recorded_at DATETIME NOT NULL,
    INDEX idx_driver_locations_latest (driver_id, recorded_at),
    CONSTRAINT fk_location_driver FOREIGN KEY (driver_id) REFERENCES driver_profiles(id) ON DELETE CASCADE,
    CONSTRAINT fk_location_booking FOREIGN KEY (booking_id) REFERENCES bookings(id) ON DELETE SET NULL
) ENGINE=InnoDB;

CREATE TABLE wallets (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    user_id BIGINT UNSIGNED NOT NULL UNIQUE,
    balance DECIMAL(12,2) NOT NULL DEFAULT 0,
    currency CHAR(3) NOT NULL DEFAULT 'INR',
    CONSTRAINT fk_wallet_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB;

CREATE TABLE wallet_transactions (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    wallet_id BIGINT UNSIGNED NOT NULL,
    booking_id BIGINT UNSIGNED NULL,
    type ENUM('credit','debit') NOT NULL,
    amount DECIMAL(12,2) NOT NULL,
    description VARCHAR(255) NOT NULL,
    reference VARCHAR(120) NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT fk_wallet_tx_wallet FOREIGN KEY (wallet_id) REFERENCES wallets(id) ON DELETE CASCADE,
    CONSTRAINT fk_wallet_tx_booking FOREIGN KEY (booking_id) REFERENCES bookings(id) ON DELETE SET NULL
) ENGINE=InnoDB;

CREATE TABLE coupons (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    code VARCHAR(40) NOT NULL UNIQUE,
    description VARCHAR(255) NULL,
    discount_type ENUM('flat','percent') NOT NULL,
    discount_value DECIMAL(10,2) NOT NULL,
    max_discount DECIMAL(10,2) NULL,
    min_order_amount DECIMAL(10,2) DEFAULT 0,
    starts_at DATETIME NOT NULL,
    ends_at DATETIME NOT NULL,
    usage_limit INT UNSIGNED NULL,
    per_user_limit INT UNSIGNED DEFAULT 1,
    is_active TINYINT(1) DEFAULT 1
) ENGINE=InnoDB;

CREATE TABLE coupon_redemptions (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    coupon_id BIGINT UNSIGNED NOT NULL,
    user_id BIGINT UNSIGNED NOT NULL,
    booking_id BIGINT UNSIGNED NOT NULL,
    discount_amount DECIMAL(10,2) NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT fk_redemption_coupon FOREIGN KEY (coupon_id) REFERENCES coupons(id),
    CONSTRAINT fk_redemption_user FOREIGN KEY (user_id) REFERENCES users(id),
    CONSTRAINT fk_redemption_booking FOREIGN KEY (booking_id) REFERENCES bookings(id)
) ENGINE=InnoDB;

CREATE TABLE payment_transactions (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    booking_id BIGINT UNSIGNED NOT NULL,
    gateway ENUM('cash','upi','razorpay','payu','stripe','wallet') NOT NULL,
    gateway_order_id VARCHAR(120) NULL,
    gateway_payment_id VARCHAR(120) NULL,
    amount DECIMAL(10,2) NOT NULL,
    currency CHAR(3) DEFAULT 'INR',
    status ENUM('initiated','authorized','captured','failed','refunded') DEFAULT 'initiated',
    payload_json JSON NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX idx_payment_gateway (gateway, status),
    CONSTRAINT fk_payment_booking FOREIGN KEY (booking_id) REFERENCES bookings(id) ON DELETE CASCADE
) ENGINE=InnoDB;

CREATE TABLE refunds (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    payment_transaction_id BIGINT UNSIGNED NOT NULL,
    amount DECIMAL(10,2) NOT NULL,
    reason VARCHAR(255) NULL,
    status ENUM('requested','processed','failed') DEFAULT 'requested',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT fk_refund_payment FOREIGN KEY (payment_transaction_id) REFERENCES payment_transactions(id) ON DELETE CASCADE
) ENGINE=InnoDB;

CREATE TABLE notifications (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    user_id BIGINT UNSIGNED NULL,
    channel ENUM('email','sms','whatsapp','push','in_app') NOT NULL,
    subject VARCHAR(160) NULL,
    message TEXT NOT NULL,
    status ENUM('queued','sent','failed') DEFAULT 'queued',
    sent_at DATETIME NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_notifications_status (status, channel),
    CONSTRAINT fk_notification_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE SET NULL
) ENGINE=InnoDB;

CREATE TABLE support_tickets (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    user_id BIGINT UNSIGNED NOT NULL,
    booking_id BIGINT UNSIGNED NULL,
    subject VARCHAR(180) NOT NULL,
    category VARCHAR(80) NOT NULL DEFAULT 'general',
    priority ENUM('low','normal','high','urgent') DEFAULT 'normal',
    status ENUM('open','pending','resolved','closed') DEFAULT 'open',
    assigned_to BIGINT UNSIGNED NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    CONSTRAINT fk_ticket_user FOREIGN KEY (user_id) REFERENCES users(id),
    CONSTRAINT fk_ticket_booking FOREIGN KEY (booking_id) REFERENCES bookings(id) ON DELETE SET NULL,
    CONSTRAINT fk_ticket_agent FOREIGN KEY (assigned_to) REFERENCES users(id) ON DELETE SET NULL
) ENGINE=InnoDB;

CREATE TABLE support_ticket_messages (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    ticket_id BIGINT UNSIGNED NOT NULL,
    user_id BIGINT UNSIGNED NOT NULL,
    message TEXT NOT NULL,
    attachment_path VARCHAR(255) NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT fk_ticket_message_ticket FOREIGN KEY (ticket_id) REFERENCES support_tickets(id) ON DELETE CASCADE,
    CONSTRAINT fk_ticket_message_user FOREIGN KEY (user_id) REFERENCES users(id)
) ENGINE=InnoDB;

CREATE TABLE cms_pages (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    slug VARCHAR(120) NOT NULL UNIQUE,
    title VARCHAR(180) NOT NULL,
    body_html MEDIUMTEXT NOT NULL,
    meta_title VARCHAR(180) NULL,
    meta_description VARCHAR(255) NULL,
    status ENUM('draft','published') DEFAULT 'draft',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB;

CREATE TABLE blog_posts (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    author_id BIGINT UNSIGNED NOT NULL,
    slug VARCHAR(140) NOT NULL UNIQUE,
    title VARCHAR(200) NOT NULL,
    excerpt VARCHAR(255) NULL,
    body_html MEDIUMTEXT NOT NULL,
    status ENUM('draft','published') DEFAULT 'draft',
    published_at DATETIME NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT fk_blog_author FOREIGN KEY (author_id) REFERENCES users(id)
) ENGINE=InnoDB;

CREATE TABLE faqs (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    question VARCHAR(255) NOT NULL,
    answer TEXT NOT NULL,
    sort_order INT DEFAULT 0,
    is_active TINYINT(1) DEFAULT 1
) ENGINE=InnoDB;

CREATE TABLE audit_logs (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    actor_id BIGINT UNSIGNED NULL,
    action VARCHAR(120) NOT NULL,
    entity_type VARCHAR(80) NOT NULL,
    entity_id BIGINT UNSIGNED NULL,
    ip_address VARCHAR(45) NULL,
    user_agent VARCHAR(255) NULL,
    metadata_json JSON NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_audit_entity (entity_type, entity_id),
    CONSTRAINT fk_audit_actor FOREIGN KEY (actor_id) REFERENCES users(id) ON DELETE SET NULL
) ENGINE=InnoDB;

DELIMITER //
CREATE TRIGGER trg_user_wallet_after_insert
AFTER INSERT ON users
FOR EACH ROW
BEGIN
    INSERT INTO wallets (user_id, balance) VALUES (NEW.id, 0);
END//

CREATE TRIGGER trg_booking_status_after_insert
AFTER INSERT ON bookings
FOR EACH ROW
BEGIN
    INSERT INTO booking_status_history (booking_id, old_status, new_status, note)
    VALUES (NEW.id, NULL, NEW.status, 'Booking created');
    INSERT INTO notifications (user_id, channel, subject, message)
    VALUES (NEW.customer_id, 'in_app', 'Booking created', CONCAT('Your booking ', NEW.booking_code, ' is pending.'));
END//

CREATE TRIGGER trg_booking_status_after_update
AFTER UPDATE ON bookings
FOR EACH ROW
BEGIN
    IF OLD.status <> NEW.status THEN
        INSERT INTO booking_status_history (booking_id, old_status, new_status, note)
        VALUES (NEW.id, OLD.status, NEW.status, 'Status changed');
    END IF;
END//

CREATE PROCEDURE sp_estimate_fare(
    IN p_vehicle_type_id BIGINT UNSIGNED,
    IN p_distance_km DECIMAL(10,2),
    IN p_duration_minutes INT,
    OUT p_total DECIMAL(10,2)
)
BEGIN
    DECLARE v_base DECIMAL(10,2);
    DECLARE v_km DECIMAL(10,2);
    DECLARE v_min DECIMAL(10,2);
    SELECT base_fare, per_km_rate, per_minute_rate INTO v_base, v_km, v_min
    FROM vehicle_types WHERE id = p_vehicle_type_id;
    SET p_total = ROUND(v_base + (p_distance_km * v_km) + (p_duration_minutes * v_min), 2);
END//

CREATE PROCEDURE sp_assign_nearest_driver(IN p_booking_id BIGINT UNSIGNED)
BEGIN
    DECLARE v_driver_id BIGINT UNSIGNED;
    SELECT dl.driver_id INTO v_driver_id
    FROM driver_locations dl
    JOIN driver_profiles dp ON dp.id = dl.driver_id
    WHERE dp.availability_status = 'online' AND dp.verification_status = 'approved'
    ORDER BY dl.recorded_at DESC
    LIMIT 1;
    IF v_driver_id IS NOT NULL THEN
        UPDATE bookings SET driver_id = v_driver_id, status = 'driver_assigned' WHERE id = p_booking_id;
        UPDATE driver_profiles SET availability_status = 'on_trip' WHERE id = v_driver_id;
    END IF;
END//
DELIMITER ;

CREATE VIEW v_booking_summary AS
SELECT b.*, cu.name AS customer_name, du.name AS driver_name, vt.name AS vehicle_type
FROM bookings b
JOIN users cu ON cu.id = b.customer_id
LEFT JOIN driver_profiles dp ON dp.id = b.driver_id
LEFT JOIN users du ON du.id = dp.user_id
JOIN vehicle_types vt ON vt.id = b.vehicle_type_id;

CREATE VIEW v_driver_latest_locations AS
SELECT dl.*
FROM driver_locations dl
JOIN (
    SELECT driver_id, MAX(recorded_at) AS latest_at
    FROM driver_locations
    GROUP BY driver_id
) x ON x.driver_id = dl.driver_id AND x.latest_at = dl.recorded_at;

CREATE VIEW v_revenue_daily AS
SELECT DATE(created_at) AS revenue_date, COUNT(*) AS bookings, SUM(total_amount) AS gross_revenue
FROM bookings
WHERE status IN ('completed','in_progress','driver_assigned','accepted')
GROUP BY DATE(created_at);

INSERT INTO roles (name, label) VALUES
('customer','Customer'),('driver','Driver'),('vendor','Vendor'),('fleet_owner','Fleet Owner'),('admin','Administrator');

INSERT INTO users (name, email, phone, password_hash, role, status, email_verified_at, phone_verified_at) VALUES
('Admin User','admin@metrocab.local','9999999999','$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2uheWG/igi','admin','active',NOW(),NOW()),
('Demo Customer','customer@metrocab.local','9000000001','$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2uheWG/igi','customer','active',NOW(),NOW()),
('Demo Driver','driver@metrocab.local','9000000002','$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2uheWG/igi','driver','active',NOW(),NOW()),
('Demo Vendor','vendor@metrocab.local','9000000003','$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2uheWG/igi','vendor','active',NOW(),NOW());

INSERT INTO vendor_profiles (user_id, company_name, gst_number, verification_status) VALUES (4, 'Demo Fleet Services', '07ABCDE1234F1Z5', 'approved');
INSERT INTO driver_profiles (user_id, vendor_id, license_number, availability_status, verification_status) VALUES (3, 1, 'DL-042026000001', 'online', 'approved');

INSERT INTO vehicle_types (name, slug, seats, base_fare, per_km_rate, per_minute_rate, waiting_charge_per_minute) VALUES
('Mini','mini',4,99,13,1.5,2),
('Sedan','sedan',4,149,16,2,2),
('SUV','suv',6,249,22,3,3),
('Luxury','luxury',4,499,38,5,5);

INSERT INTO vehicles (owner_user_id, driver_id, vehicle_type_id, registration_number, make, model, color, fuel_type, status) VALUES
(4, 1, 2, 'DL01AB1234', 'Maruti Suzuki', 'Dzire', 'White', 'cng', 'active');

INSERT INTO coupons (code, description, discount_type, discount_value, max_discount, min_order_amount, starts_at, ends_at, usage_limit, per_user_limit) VALUES
('WELCOME100','Flat welcome discount','flat',100,100,299,NOW(),DATE_ADD(NOW(), INTERVAL 1 YEAR),10000,1),
('AIRPORT10','Airport ride discount','percent',10,250,499,NOW(),DATE_ADD(NOW(), INTERVAL 1 YEAR),5000,3);

INSERT INTO cms_pages (slug, title, body_html, meta_title, meta_description, status) VALUES
('faq','Frequently Asked Questions','<h2>Booking</h2><p>Choose pickup, drop, trip type, vehicle, and payment method to confirm a ride.</p><h2>Payments</h2><p>Cash, UPI, wallet, Razorpay, PayU, and Stripe integrations are supported.</p>','Cab Booking FAQ','Answers about bookings, payments, drivers, refunds, and support.','published'),
('blog','Cab Travel Blog','<p>Publish SEO-friendly city guides, airport transfer tips, outstation travel advice, and fleet updates here.</p>','Cab Travel Blog','Travel articles and cab booking guides.','published'),
('terms','Terms and Conditions','<p>Replace this starter policy with your final legal terms before production launch.</p>','Terms','Terms and conditions for cab booking services.','published'),
('privacy','Privacy Policy','<p>Replace this starter privacy policy with your final privacy notice before production launch.</p>','Privacy Policy','Privacy policy for customers, drivers, vendors, and fleet owners.','published');

INSERT INTO faqs (question, answer, sort_order) VALUES
('Can I book an airport cab?', 'Yes, select Airport in the trip type.', 1),
('Are drivers verified?', 'Drivers require license and document verification before approval.', 2),
('Which payment gateways are supported?', 'Razorpay, PayU, Stripe, UPI, wallet, and cash are modeled.', 3);
