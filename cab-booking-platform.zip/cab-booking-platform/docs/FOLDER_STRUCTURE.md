# Folder Structure

```text
cab-booking-platform/
  app/
    Controllers/       MVC controllers and API controllers
    Core/              Router, request/response, auth, DB, helpers
    Models/            PDO-backed model/repository classes
    Views/             SEO-friendly PHP templates
  config/              App and database configuration
  database/            MySQL schema, views, triggers, procedures, seed data
  docs/                Deployment and API docs
  public/              Web root, index.php, assets, uploads
  routes/              Web and API route definitions
  storage/             Logs and generated runtime files
```

The app uses a front controller in `public/index.php`; all requests pass through the router and controller layer.
