# REST API

Base path: `/api/v1`

## Vehicle Types

`GET /api/v1/vehicle-types`

Returns active cab categories and rate cards.

## Fare Estimate

`POST /api/v1/fares/estimate`

Fields:

- `vehicle_type_id`
- `distance_km`
- `duration_minutes`

## Driver Location

`POST /api/v1/driver/location`

Role: `driver` or `admin`

Fields:

- `lat`
- `lng`
- `heading`
- `speed`

## Support Ticket

`POST /api/v1/support/tickets`

Role: authenticated user

Fields:

- `subject`
- `category`
- `priority`

## AJAX Endpoints

- `POST /ajax/fare-estimate`
- `POST /login`
- `POST /register`
- `POST /auth/otp/send`
- `POST /bookings`
- `POST /admin/action`
