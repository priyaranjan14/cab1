# Module Map

- Customer registration/login: `AuthController`, `users`, `otp_tokens`, login/register views.
- OTP/email/Google login: OTP storage is implemented; provider credentials and redirect/callback should be wired through `social_accounts`.
- Driver registration and verification: `driver_profiles`, `driver_documents`, driver dashboard.
- Vehicle management: `vehicle_types`, `vehicles`, vendor/fleet dashboard.
- Cab search and fare estimation: booking pages, AJAX estimate endpoint, `sp_estimate_fare`.
- Booking management: `bookings`, status history trigger, dashboard tables.
- Real-time driver tracking: `driver_locations`, latest-location view, browser geolocation hook.
- Wallet: `wallets`, `wallet_transactions`, user wallet trigger.
- Coupons/promotions: `coupons`, `coupon_redemptions`.
- Payments: `payment_transactions`, `refunds`, gateway fields for Razorpay, PayU, Stripe, UPI, cash, wallet.
- Dashboards: customer, driver, vendor/fleet, admin views.
- Reports/analytics: admin reports page, `v_revenue_daily`, summary stats.
- Notifications: `notifications` table for SMS, email, WhatsApp, push, in-app queues.
- Support: `support_tickets`, `support_ticket_messages`, REST endpoint.
- CMS/blog/FAQ: `cms_pages`, `blog_posts`, `faqs`, SEO page route.
