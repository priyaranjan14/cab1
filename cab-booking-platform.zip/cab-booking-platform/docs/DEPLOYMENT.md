# Deployment Guide

## Production Checklist

1. Point the web server document root to `public/`.
2. Copy `.env.example` to `.env`.
3. Set a unique `APP_KEY`, database credentials, mail/SMS/WhatsApp keys, Google OAuth credentials, and payment gateway secrets.
4. Import `database/schema.sql` into MySQL 8.
5. Enable HTTPS, HSTS, secure cookies, and server-side rate limiting.
6. Configure cron/queue workers for notifications, refunds, payout exports, and report generation.
7. Replace starter legal CMS pages with approved legal copy.
8. Rotate seeded demo passwords or delete demo users.

## Apache

Use `public/.htaccess` and set:

```apache
DocumentRoot /var/www/metrocab/public
<Directory /var/www/metrocab/public>
    AllowOverride All
    Require all granted
</Directory>
```

## Nginx

```nginx
server {
    listen 443 ssl http2;
    server_name example.com;
    root /var/www/metrocab/public;
    index index.php;

    location / {
        try_files $uri $uri/ /index.php?$query_string;
    }

    location ~ \.php$ {
        include fastcgi_params;
        fastcgi_param SCRIPT_FILENAME $document_root$fastcgi_script_name;
        fastcgi_pass unix:/run/php/php8.3-fpm.sock;
    }
}
```

## Security Notes

- All DB writes use PDO prepared statements.
- Passwords use `password_hash`.
- CSRF tokens are embedded in forms and sent through AJAX.
- Output is escaped with `e()` except CMS HTML, which should be sanitized before admin publishing.
- Gateways and messaging providers are represented by integration points; add vendor SDKs server-side and verify webhooks with signatures.

## Local Run

```bash
php -S localhost:8000 -t public
```

Then open `http://localhost:8000`.
